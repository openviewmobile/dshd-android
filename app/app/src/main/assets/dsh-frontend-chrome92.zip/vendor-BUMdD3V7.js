var _staticBlock;
function _defineProperty(r, t, o) { return (t = _toPropertyKey(t)) in r ? Object.defineProperty(r, t, { value: o, enumerable: !0, configurable: !0, writable: !0 }) : r[t] = o, r; }
function _toPropertyKey(r) { var o = _toPrimitive(r, "string"); return "symbol" == typeof o ? o : o + ""; }
function _toPrimitive(t, e) { if ("object" != typeof t || !t) return t; var r; if ("undefined" != typeof Symbol && void 0 !== (r = t[Symbol.toPrimitive])) { var i = r.call(t, e || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === e ? String : Number)(t); }
var ge = class extends Error {
  constructor(e) {
    super(e), this.name = "ShikiError";
  }
};
function qu(e) {
  return Ui(e);
}
function Ui(e) {
  return Array.isArray(e) ? ju(e) : e instanceof RegExp ? e : typeof e == "object" ? Gu(e) : e;
}
function ju(e) {
  let t = [];
  for (let n = 0, r = e.length; n < r; n++) t[n] = Ui(e[n]);
  return t;
}
function Gu(e) {
  let t = {};
  for (let n in e) t[n] = Ui(e[n]);
  return t;
}
function fl(e, ...t) {
  return t.forEach(n => {
    for (let r in n) e[r] = n[r];
  }), e;
}
function gl(e) {
  const t = ~e.lastIndexOf("/") || ~e.lastIndexOf("\\");
  return t === 0 ? e : ~t === e.length - 1 ? gl(e.substring(0, e.length - 1)) : e.substr(~t + 1);
}
var $a = /\$(\d+)|\${(\d+):\/(downcase|upcase)}/g,
  br = class {
    static hasCaptures(e) {
      return e === null ? !1 : ($a.lastIndex = 0, $a.test(e));
    }
    static replaceCaptures(e, t, n) {
      return e.replace($a, (r, a, i, s) => {
        let o = n[parseInt(a || i, 10)];
        if (o) {
          let l = t.substring(o.start, o.end);
          for (; l[0] === ".";) l = l.substring(1);
          switch (s) {
            case "downcase":
              return l.toLowerCase();
            case "upcase":
              return l.toUpperCase();
            default:
              return l;
          }
        } else return r;
      });
    }
  };
function bl(e, t) {
  return e < t ? -1 : e > t ? 1 : 0;
}
function yl(e, t) {
  if (e === null && t === null) return 0;
  if (!e) return -1;
  if (!t) return 1;
  let n = e.length,
    r = t.length;
  if (n === r) {
    for (let a = 0; a < n; a++) {
      let i = bl(e[a], t[a]);
      if (i !== 0) return i;
    }
    return 0;
  }
  return n - r;
}
function ks(e) {
  return !!(/^#[0-9a-f]{6}$/i.test(e) || /^#[0-9a-f]{8}$/i.test(e) || /^#[0-9a-f]{3}$/i.test(e) || /^#[0-9a-f]{4}$/i.test(e));
}
function vl(e) {
  return e.replace(/[\-\\\{\}\*\+\?\|\^\$\.\,\[\]\(\)\#\s]/g, "\\$&");
}
var wl = class {
    constructor(e) {
      this.fn = e;
    }
    cache = new Map();
    get(e) {
      if (this.cache.has(e)) return this.cache.get(e);
      const t = this.fn(e);
      return this.cache.set(e, t), t;
    }
  },
  Fr = class {
    constructor(e, t, n) {
      this._colorMap = e, this._defaults = t, this._root = n;
    }
    static createFromRawTheme(e, t) {
      return this.createFromParsedTheme(Wu(e), t);
    }
    static createFromParsedTheme(e, t) {
      return Xu(e, t);
    }
    _cachedMatchRoot = new wl(e => this._root.match(e));
    getColorMap() {
      return this._colorMap.getColorMap();
    }
    getDefaults() {
      return this._defaults;
    }
    match(e) {
      if (e === null) return this._defaults;
      const t = e.scopeName,
        r = this._cachedMatchRoot.get(t).find(a => Hu(e.parent, a.parentScopes));
      return r ? new xl(r.fontStyle, r.foreground, r.background) : null;
    }
  },
  Ca = class zr {
    constructor(t, n) {
      this.parent = t, this.scopeName = n;
    }
    static push(t, n) {
      for (const r of n) t = new zr(t, r);
      return t;
    }
    static from(...t) {
      let n = null;
      for (let r = 0; r < t.length; r++) n = new zr(n, t[r]);
      return n;
    }
    push(t) {
      return new zr(this, t);
    }
    getSegments() {
      let t = this;
      const n = [];
      for (; t;) n.push(t.scopeName), t = t.parent;
      return n.reverse(), n;
    }
    toString() {
      return this.getSegments().join(" ");
    }
    extends(t) {
      return this === t ? !0 : this.parent === null ? !1 : this.parent.extends(t);
    }
    getExtensionIfDefined(t) {
      const n = [];
      let r = this;
      for (; r && r !== t;) n.push(r.scopeName), r = r.parent;
      return r === t ? n.reverse() : void 0;
    }
  };
function Hu(e, t) {
  if (t.length === 0) return !0;
  for (let n = 0; n < t.length; n++) {
    let r = t[n],
      a = !1;
    if (r === ">") {
      if (n === t.length - 1) return !1;
      r = t[++n], a = !0;
    }
    for (; e && !Uu(e.scopeName, r);) {
      if (a) return !1;
      e = e.parent;
    }
    if (!e) return !1;
    e = e.parent;
  }
  return !0;
}
function Uu(e, t) {
  return t === e || e.startsWith(t) && e[t.length] === ".";
}
var xl = class {
  constructor(e, t, n) {
    this.fontStyle = e, this.foregroundId = t, this.backgroundId = n;
  }
};
function Wu(e) {
  if (!e) return [];
  if (!e.settings || !Array.isArray(e.settings)) return [];
  let t = e.settings,
    n = [],
    r = 0;
  for (let a = 0, i = t.length; a < i; a++) {
    let s = t[a];
    if (!s.settings) continue;
    let o;
    if (typeof s.scope == "string") {
      let h = s.scope;
      h = h.replace(/^[,]+/, ""), h = h.replace(/[,]+$/, ""), o = h.split(",");
    } else Array.isArray(s.scope) ? o = s.scope : o = [""];
    let l = -1;
    if (typeof s.settings.fontStyle == "string") {
      l = 0;
      let h = s.settings.fontStyle.split(" ");
      for (let f = 0, d = h.length; f < d; f++) switch (h[f]) {
        case "italic":
          l = l | 1;
          break;
        case "bold":
          l = l | 2;
          break;
        case "underline":
          l = l | 4;
          break;
        case "strikethrough":
          l = l | 8;
          break;
      }
    }
    let u = null;
    typeof s.settings.foreground == "string" && ks(s.settings.foreground) && (u = s.settings.foreground);
    let c = null;
    typeof s.settings.background == "string" && ks(s.settings.background) && (c = s.settings.background);
    for (let h = 0, f = o.length; h < f; h++) {
      let b = o[h].trim().split(" "),
        k = b[b.length - 1],
        A = null;
      b.length > 1 && (A = b.slice(0, b.length - 1), A.reverse()), n[r++] = new Vu(k, A, a, l, u, c);
    }
  }
  return n;
}
var Vu = class {
    constructor(e, t, n, r, a, i) {
      this.scope = e, this.parentScopes = t, this.index = n, this.fontStyle = r, this.foreground = a, this.background = i;
    }
  },
  Le = (e => (e[e.NotSet = -1] = "NotSet", e[e.None = 0] = "None", e[e.Italic = 1] = "Italic", e[e.Bold = 2] = "Bold", e[e.Underline = 4] = "Underline", e[e.Strikethrough = 8] = "Strikethrough", e))(Le || {});
function Xu(e, t) {
  e.sort((l, u) => {
    let c = bl(l.scope, u.scope);
    return c !== 0 || (c = yl(l.parentScopes, u.parentScopes), c !== 0) ? c : l.index - u.index;
  });
  let n = 0,
    r = "#000000",
    a = "#ffffff";
  for (; e.length >= 1 && e[0].scope === "";) {
    let l = e.shift();
    l.fontStyle !== -1 && (n = l.fontStyle), l.foreground !== null && (r = l.foreground), l.background !== null && (a = l.background);
  }
  let i = new Yu(t),
    s = new xl(n, i.getId(r), i.getId(a)),
    o = new Ku(new ri(0, null, -1, 0, 0), []);
  for (let l = 0, u = e.length; l < u; l++) {
    let c = e[l];
    o.insert(0, c.scope, c.parentScopes, c.fontStyle, i.getId(c.foreground), i.getId(c.background));
  }
  return new Fr(i, s, o);
}
var Yu = class {
    _isFrozen;
    _lastColorId;
    _id2color;
    _color2id;
    constructor(e) {
      if (this._lastColorId = 0, this._id2color = [], this._color2id = Object.create(null), Array.isArray(e)) {
        this._isFrozen = !0;
        for (let t = 0, n = e.length; t < n; t++) this._color2id[e[t]] = t, this._id2color[t] = e[t];
      } else this._isFrozen = !1;
    }
    getId(e) {
      if (e === null) return 0;
      e = e.toUpperCase();
      let t = this._color2id[e];
      if (t) return t;
      if (this._isFrozen) throw new Error(`Missing color in color map - ${e}`);
      return t = ++this._lastColorId, this._color2id[e] = t, this._id2color[t] = e, t;
    }
    getColorMap() {
      return this._id2color.slice(0);
    }
  },
  Zu = Object.freeze([]),
  ri = class kl {
    scopeDepth;
    parentScopes;
    fontStyle;
    foreground;
    background;
    constructor(t, n, r, a, i) {
      this.scopeDepth = t, this.parentScopes = n || Zu, this.fontStyle = r, this.foreground = a, this.background = i;
    }
    clone() {
      return new kl(this.scopeDepth, this.parentScopes, this.fontStyle, this.foreground, this.background);
    }
    static cloneArr(t) {
      let n = [];
      for (let r = 0, a = t.length; r < a; r++) n[r] = t[r].clone();
      return n;
    }
    acceptOverwrite(t, n, r, a) {
      this.scopeDepth > t ? console.log("how did this happen?") : this.scopeDepth = t, n !== -1 && (this.fontStyle = n), r !== 0 && (this.foreground = r), a !== 0 && (this.background = a);
    }
  },
  Ku = class ai {
    constructor(t, n = [], r = {}) {
      this._mainRule = t, this._children = r, this._rulesWithParentScopes = n;
    }
    _rulesWithParentScopes;
    static _cmpBySpecificity(t, n) {
      if (t.scopeDepth !== n.scopeDepth) return n.scopeDepth - t.scopeDepth;
      let r = 0,
        a = 0;
      for (; t.parentScopes[r] === ">" && r++, n.parentScopes[a] === ">" && a++, !(r >= t.parentScopes.length || a >= n.parentScopes.length);) {
        const i = n.parentScopes[a].length - t.parentScopes[r].length;
        if (i !== 0) return i;
        r++, a++;
      }
      return n.parentScopes.length - t.parentScopes.length;
    }
    match(t) {
      if (t !== "") {
        let r = t.indexOf("."),
          a,
          i;
        if (r === -1 ? (a = t, i = "") : (a = t.substring(0, r), i = t.substring(r + 1)), this._children.hasOwnProperty(a)) return this._children[a].match(i);
      }
      const n = this._rulesWithParentScopes.concat(this._mainRule);
      return n.sort(ai._cmpBySpecificity), n;
    }
    insert(t, n, r, a, i, s) {
      if (n === "") {
        this._doInsertHere(t, r, a, i, s);
        return;
      }
      let o = n.indexOf("."),
        l,
        u;
      o === -1 ? (l = n, u = "") : (l = n.substring(0, o), u = n.substring(o + 1));
      let c;
      this._children.hasOwnProperty(l) ? c = this._children[l] : (c = new ai(this._mainRule.clone(), ri.cloneArr(this._rulesWithParentScopes)), this._children[l] = c), c.insert(t + 1, u, r, a, i, s);
    }
    _doInsertHere(t, n, r, a, i) {
      if (n === null) {
        this._mainRule.acceptOverwrite(t, r, a, i);
        return;
      }
      for (let s = 0, o = this._rulesWithParentScopes.length; s < o; s++) {
        let l = this._rulesWithParentScopes[s];
        if (yl(l.parentScopes, n) === 0) {
          l.acceptOverwrite(t, r, a, i);
          return;
        }
      }
      r === -1 && (r = this._mainRule.fontStyle), a === 0 && (a = this._mainRule.foreground), i === 0 && (i = this._mainRule.background), this._rulesWithParentScopes.push(new ri(t, n, r, a, i));
    }
  },
  cn = class it {
    static toBinaryStr(t) {
      return t.toString(2).padStart(32, "0");
    }
    static print(t) {
      const n = it.getLanguageId(t),
        r = it.getTokenType(t),
        a = it.getFontStyle(t),
        i = it.getForeground(t),
        s = it.getBackground(t);
      console.log({
        languageId: n,
        tokenType: r,
        fontStyle: a,
        foreground: i,
        background: s
      });
    }
    static getLanguageId(t) {
      return (t & 255) >>> 0;
    }
    static getTokenType(t) {
      return (t & 768) >>> 8;
    }
    static containsBalancedBrackets(t) {
      return (t & 1024) !== 0;
    }
    static getFontStyle(t) {
      return (t & 30720) >>> 11;
    }
    static getForeground(t) {
      return (t & 16744448) >>> 15;
    }
    static getBackground(t) {
      return (t & 4278190080) >>> 24;
    }
    static set(t, n, r, a, i, s, o) {
      let l = it.getLanguageId(t),
        u = it.getTokenType(t),
        c = it.containsBalancedBrackets(t) ? 1 : 0,
        h = it.getFontStyle(t),
        f = it.getForeground(t),
        d = it.getBackground(t);
      return n !== 0 && (l = n), r !== 8 && (u = r), a !== null && (c = a ? 1 : 0), i !== -1 && (h = i), s !== 0 && (f = s), o !== 0 && (d = o), (l << 0 | u << 8 | c << 10 | h << 11 | f << 15 | d << 24) >>> 0;
    }
  };
function Pr(e, t) {
  const n = [],
    r = Qu(e);
  let a = r.next();
  for (; a !== null;) {
    let l = 0;
    if (a.length === 2 && a.charAt(1) === ":") {
      switch (a.charAt(0)) {
        case "R":
          l = 1;
          break;
        case "L":
          l = -1;
          break;
        default:
          console.log(`Unknown priority ${a} in scope selector`);
      }
      a = r.next();
    }
    let u = s();
    if (n.push({
      matcher: u,
      priority: l
    }), a !== ",") break;
    a = r.next();
  }
  return n;
  function i() {
    if (a === "-") {
      a = r.next();
      const l = i();
      return u => !!l && !l(u);
    }
    if (a === "(") {
      a = r.next();
      const l = o();
      return a === ")" && (a = r.next()), l;
    }
    if (_s(a)) {
      const l = [];
      do l.push(a), a = r.next(); while (_s(a));
      return u => t(l, u);
    }
    return null;
  }
  function s() {
    const l = [];
    let u = i();
    for (; u;) l.push(u), u = i();
    return c => l.every(h => h(c));
  }
  function o() {
    const l = [];
    let u = s();
    for (; u && (l.push(u), a === "|" || a === ",");) {
      do a = r.next(); while (a === "|" || a === ",");
      u = s();
    }
    return c => l.some(h => h(c));
  }
}
function _s(e) {
  return !!e && !!e.match(/[\w\.:]+/);
}
function Qu(e) {
  let t = /([LR]:|[\w\.:][\w\.:\-]*|[\,\|\-\(\)])/g,
    n = t.exec(e);
  return {
    next: () => {
      if (!n) return null;
      const r = n[0];
      return n = t.exec(e), r;
    }
  };
}
function _l(e) {
  typeof e.dispose == "function" && e.dispose();
}
var Xn = class {
    constructor(e) {
      this.scopeName = e;
    }
    toKey() {
      return this.scopeName;
    }
  },
  Ju = class {
    constructor(e, t) {
      this.scopeName = e, this.ruleName = t;
    }
    toKey() {
      return `${this.scopeName}#${this.ruleName}`;
    }
  },
  ec = class {
    _references = [];
    _seenReferenceKeys = new Set();
    get references() {
      return this._references;
    }
    visitedRule = new Set();
    add(e) {
      const t = e.toKey();
      this._seenReferenceKeys.has(t) || (this._seenReferenceKeys.add(t), this._references.push(e));
    }
  },
  tc = class {
    constructor(e, t) {
      this.repo = e, this.initialScopeName = t, this.seenFullScopeRequests.add(this.initialScopeName), this.Q = [new Xn(this.initialScopeName)];
    }
    seenFullScopeRequests = new Set();
    seenPartialScopeRequests = new Set();
    Q;
    processQueue() {
      const e = this.Q;
      this.Q = [];
      const t = new ec();
      for (const n of e) nc(n, this.initialScopeName, this.repo, t);
      for (const n of t.references) if (n instanceof Xn) {
        if (this.seenFullScopeRequests.has(n.scopeName)) continue;
        this.seenFullScopeRequests.add(n.scopeName), this.Q.push(n);
      } else {
        if (this.seenFullScopeRequests.has(n.scopeName) || this.seenPartialScopeRequests.has(n.toKey())) continue;
        this.seenPartialScopeRequests.add(n.toKey()), this.Q.push(n);
      }
    }
  };
function nc(e, t, n, r) {
  const a = n.lookup(e.scopeName);
  if (!a) {
    if (e.scopeName === t) throw new Error(`No grammar provided for <${t}>`);
    return;
  }
  const i = n.lookup(t);
  e instanceof Xn ? Ir({
    baseGrammar: i,
    selfGrammar: a
  }, r) : ii(e.ruleName, {
    baseGrammar: i,
    selfGrammar: a,
    repository: a.repository
  }, r);
  const s = n.injections(e.scopeName);
  if (s) for (const o of s) r.add(new Xn(o));
}
function ii(e, t, n) {
  if (t.repository && t.repository[e]) {
    const r = t.repository[e];
    Or([r], t, n);
  }
}
function Ir(e, t) {
  e.selfGrammar.patterns && Array.isArray(e.selfGrammar.patterns) && Or(e.selfGrammar.patterns, {
    ...e,
    repository: e.selfGrammar.repository
  }, t), e.selfGrammar.injections && Or(Object.values(e.selfGrammar.injections), {
    ...e,
    repository: e.selfGrammar.repository
  }, t);
}
function Or(e, t, n) {
  for (const r of e) {
    if (n.visitedRule.has(r)) continue;
    n.visitedRule.add(r);
    const a = r.repository ? fl({}, t.repository, r.repository) : t.repository;
    Array.isArray(r.patterns) && Or(r.patterns, {
      ...t,
      repository: a
    }, n);
    const i = r.include;
    if (!i) continue;
    const s = $l(i);
    switch (s.kind) {
      case 0:
        Ir({
          ...t,
          selfGrammar: t.baseGrammar
        }, n);
        break;
      case 1:
        Ir(t, n);
        break;
      case 2:
        ii(s.ruleName, {
          ...t,
          repository: a
        }, n);
        break;
      case 3:
      case 4:
        const o = s.scopeName === t.selfGrammar.scopeName ? t.selfGrammar : s.scopeName === t.baseGrammar.scopeName ? t.baseGrammar : void 0;
        if (o) {
          const l = {
            baseGrammar: t.baseGrammar,
            selfGrammar: o,
            repository: a
          };
          s.kind === 4 ? ii(s.ruleName, l, n) : Ir(l, n);
        } else s.kind === 4 ? n.add(new Ju(s.scopeName, s.ruleName)) : n.add(new Xn(s.scopeName));
        break;
    }
  }
}
var rc = class {
    kind = 0;
  },
  ac = class {
    kind = 1;
  },
  ic = class {
    constructor(e) {
      this.ruleName = e;
    }
    kind = 2;
  },
  sc = class {
    constructor(e) {
      this.scopeName = e;
    }
    kind = 3;
  },
  oc = class {
    constructor(e, t) {
      this.scopeName = e, this.ruleName = t;
    }
    kind = 4;
  };
function $l(e) {
  if (e === "$base") return new rc();
  if (e === "$self") return new ac();
  const t = e.indexOf("#");
  if (t === -1) return new sc(e);
  if (t === 0) return new ic(e.substring(1));
  {
    const n = e.substring(0, t),
      r = e.substring(t + 1);
    return new oc(n, r);
  }
}
var lc = /\\(\d+)/,
  $s = /\\(\d+)/g,
  uc = -1,
  Cl = -2;
var ar = class {
    $location;
    id;
    _nameIsCapturing;
    _name;
    _contentNameIsCapturing;
    _contentName;
    constructor(e, t, n, r) {
      this.$location = e, this.id = t, this._name = n || null, this._nameIsCapturing = br.hasCaptures(this._name), this._contentName = r || null, this._contentNameIsCapturing = br.hasCaptures(this._contentName);
    }
    get debugName() {
      const e = this.$location ? `${gl(this.$location.filename)}:${this.$location.line}` : "unknown";
      return `${this.constructor.name}#${this.id} @ ${e}`;
    }
    getName(e, t) {
      return !this._nameIsCapturing || this._name === null || e === null || t === null ? this._name : br.replaceCaptures(this._name, e, t);
    }
    getContentName(e, t) {
      return !this._contentNameIsCapturing || this._contentName === null ? this._contentName : br.replaceCaptures(this._contentName, e, t);
    }
  },
  cc = class extends ar {
    retokenizeCapturedWithRuleId;
    constructor(e, t, n, r, a) {
      super(e, t, n, r), this.retokenizeCapturedWithRuleId = a;
    }
    dispose() {}
    collectPatterns(e, t) {
      throw new Error("Not supported!");
    }
    compile(e, t) {
      throw new Error("Not supported!");
    }
    compileAG(e, t, n, r) {
      throw new Error("Not supported!");
    }
  },
  mc = class extends ar {
    _match;
    captures;
    _cachedCompiledPatterns;
    constructor(e, t, n, r, a) {
      super(e, t, n, null), this._match = new Yn(r, this.id), this.captures = a, this._cachedCompiledPatterns = null;
    }
    dispose() {
      this._cachedCompiledPatterns && (this._cachedCompiledPatterns.dispose(), this._cachedCompiledPatterns = null);
    }
    get debugMatchRegExp() {
      return `${this._match.source}`;
    }
    collectPatterns(e, t) {
      t.push(this._match);
    }
    compile(e, t) {
      return this._getCachedCompiledPatterns(e).compile(e);
    }
    compileAG(e, t, n, r) {
      return this._getCachedCompiledPatterns(e).compileAG(e, n, r);
    }
    _getCachedCompiledPatterns(e) {
      return this._cachedCompiledPatterns || (this._cachedCompiledPatterns = new Zn(), this.collectPatterns(e, this._cachedCompiledPatterns)), this._cachedCompiledPatterns;
    }
  },
  Cs = class extends ar {
    hasMissingPatterns;
    patterns;
    _cachedCompiledPatterns;
    constructor(e, t, n, r, a) {
      super(e, t, n, r), this.patterns = a.patterns, this.hasMissingPatterns = a.hasMissingPatterns, this._cachedCompiledPatterns = null;
    }
    dispose() {
      this._cachedCompiledPatterns && (this._cachedCompiledPatterns.dispose(), this._cachedCompiledPatterns = null);
    }
    collectPatterns(e, t) {
      for (const n of this.patterns) e.getRule(n).collectPatterns(e, t);
    }
    compile(e, t) {
      return this._getCachedCompiledPatterns(e).compile(e);
    }
    compileAG(e, t, n, r) {
      return this._getCachedCompiledPatterns(e).compileAG(e, n, r);
    }
    _getCachedCompiledPatterns(e) {
      return this._cachedCompiledPatterns || (this._cachedCompiledPatterns = new Zn(), this.collectPatterns(e, this._cachedCompiledPatterns)), this._cachedCompiledPatterns;
    }
  },
  si = class extends ar {
    _begin;
    beginCaptures;
    _end;
    endHasBackReferences;
    endCaptures;
    applyEndPatternLast;
    hasMissingPatterns;
    patterns;
    _cachedCompiledPatterns;
    constructor(e, t, n, r, a, i, s, o, l, u) {
      super(e, t, n, r), this._begin = new Yn(a, this.id), this.beginCaptures = i, this._end = new Yn(s || "￿", -1), this.endHasBackReferences = this._end.hasBackReferences, this.endCaptures = o, this.applyEndPatternLast = l || !1, this.patterns = u.patterns, this.hasMissingPatterns = u.hasMissingPatterns, this._cachedCompiledPatterns = null;
    }
    dispose() {
      this._cachedCompiledPatterns && (this._cachedCompiledPatterns.dispose(), this._cachedCompiledPatterns = null);
    }
    get debugBeginRegExp() {
      return `${this._begin.source}`;
    }
    get debugEndRegExp() {
      return `${this._end.source}`;
    }
    getEndWithResolvedBackReferences(e, t) {
      return this._end.resolveBackReferences(e, t);
    }
    collectPatterns(e, t) {
      t.push(this._begin);
    }
    compile(e, t) {
      return this._getCachedCompiledPatterns(e, t).compile(e);
    }
    compileAG(e, t, n, r) {
      return this._getCachedCompiledPatterns(e, t).compileAG(e, n, r);
    }
    _getCachedCompiledPatterns(e, t) {
      if (!this._cachedCompiledPatterns) {
        this._cachedCompiledPatterns = new Zn();
        for (const n of this.patterns) e.getRule(n).collectPatterns(e, this._cachedCompiledPatterns);
        this.applyEndPatternLast ? this._cachedCompiledPatterns.push(this._end.hasBackReferences ? this._end.clone() : this._end) : this._cachedCompiledPatterns.unshift(this._end.hasBackReferences ? this._end.clone() : this._end);
      }
      return this._end.hasBackReferences && (this.applyEndPatternLast ? this._cachedCompiledPatterns.setSource(this._cachedCompiledPatterns.length() - 1, t) : this._cachedCompiledPatterns.setSource(0, t)), this._cachedCompiledPatterns;
    }
  },
  qr = class extends ar {
    _begin;
    beginCaptures;
    whileCaptures;
    _while;
    whileHasBackReferences;
    hasMissingPatterns;
    patterns;
    _cachedCompiledPatterns;
    _cachedCompiledWhilePatterns;
    constructor(e, t, n, r, a, i, s, o, l) {
      super(e, t, n, r), this._begin = new Yn(a, this.id), this.beginCaptures = i, this.whileCaptures = o, this._while = new Yn(s, Cl), this.whileHasBackReferences = this._while.hasBackReferences, this.patterns = l.patterns, this.hasMissingPatterns = l.hasMissingPatterns, this._cachedCompiledPatterns = null, this._cachedCompiledWhilePatterns = null;
    }
    dispose() {
      this._cachedCompiledPatterns && (this._cachedCompiledPatterns.dispose(), this._cachedCompiledPatterns = null), this._cachedCompiledWhilePatterns && (this._cachedCompiledWhilePatterns.dispose(), this._cachedCompiledWhilePatterns = null);
    }
    get debugBeginRegExp() {
      return `${this._begin.source}`;
    }
    get debugWhileRegExp() {
      return `${this._while.source}`;
    }
    getWhileWithResolvedBackReferences(e, t) {
      return this._while.resolveBackReferences(e, t);
    }
    collectPatterns(e, t) {
      t.push(this._begin);
    }
    compile(e, t) {
      return this._getCachedCompiledPatterns(e).compile(e);
    }
    compileAG(e, t, n, r) {
      return this._getCachedCompiledPatterns(e).compileAG(e, n, r);
    }
    _getCachedCompiledPatterns(e) {
      if (!this._cachedCompiledPatterns) {
        this._cachedCompiledPatterns = new Zn();
        for (const t of this.patterns) e.getRule(t).collectPatterns(e, this._cachedCompiledPatterns);
      }
      return this._cachedCompiledPatterns;
    }
    compileWhile(e, t) {
      return this._getCachedCompiledWhilePatterns(e, t).compile(e);
    }
    compileWhileAG(e, t, n, r) {
      return this._getCachedCompiledWhilePatterns(e, t).compileAG(e, n, r);
    }
    _getCachedCompiledWhilePatterns(e, t) {
      return this._cachedCompiledWhilePatterns || (this._cachedCompiledWhilePatterns = new Zn(), this._cachedCompiledWhilePatterns.push(this._while.hasBackReferences ? this._while.clone() : this._while)), this._while.hasBackReferences && this._cachedCompiledWhilePatterns.setSource(0, t || "￿"), this._cachedCompiledWhilePatterns;
    }
  },
  Sl = class De {
    static createCaptureRule(t, n, r, a, i) {
      return t.registerRule(s => new cc(n, s, r, a, i));
    }
    static getCompiledRuleId(t, n, r) {
      return t.id || n.registerRule(a => {
        if (t.id = a, t.match) return new mc(t.$vscodeTextmateLocation, t.id, t.name, t.match, De._compileCaptures(t.captures, n, r));
        if (typeof t.begin > "u") {
          t.repository && (r = fl({}, r, t.repository));
          let i = t.patterns;
          return typeof i > "u" && t.include && (i = [{
            include: t.include
          }]), new Cs(t.$vscodeTextmateLocation, t.id, t.name, t.contentName, De._compilePatterns(i, n, r));
        }
        return t.while ? new qr(t.$vscodeTextmateLocation, t.id, t.name, t.contentName, t.begin, De._compileCaptures(t.beginCaptures || t.captures, n, r), t.while, De._compileCaptures(t.whileCaptures || t.captures, n, r), De._compilePatterns(t.patterns, n, r)) : new si(t.$vscodeTextmateLocation, t.id, t.name, t.contentName, t.begin, De._compileCaptures(t.beginCaptures || t.captures, n, r), t.end, De._compileCaptures(t.endCaptures || t.captures, n, r), t.applyEndPatternLast, De._compilePatterns(t.patterns, n, r));
      }), t.id;
    }
    static _compileCaptures(t, n, r) {
      let a = [];
      if (t) {
        let i = 0;
        for (const s in t) {
          if (s === "$vscodeTextmateLocation") continue;
          const o = parseInt(s, 10);
          o > i && (i = o);
        }
        for (let s = 0; s <= i; s++) a[s] = null;
        for (const s in t) {
          if (s === "$vscodeTextmateLocation") continue;
          const o = parseInt(s, 10);
          let l = 0;
          t[s].patterns && (l = De.getCompiledRuleId(t[s], n, r)), a[o] = De.createCaptureRule(n, t[s].$vscodeTextmateLocation, t[s].name, t[s].contentName, l);
        }
      }
      return a;
    }
    static _compilePatterns(t, n, r) {
      let a = [];
      if (t) for (let i = 0, s = t.length; i < s; i++) {
        const o = t[i];
        let l = -1;
        if (o.include) {
          const u = $l(o.include);
          switch (u.kind) {
            case 0:
            case 1:
              l = De.getCompiledRuleId(r[o.include], n, r);
              break;
            case 2:
              let c = r[u.ruleName];
              c && (l = De.getCompiledRuleId(c, n, r));
              break;
            case 3:
            case 4:
              const h = u.scopeName,
                f = u.kind === 4 ? u.ruleName : null,
                d = n.getExternalGrammar(h, r);
              if (d) if (f) {
                let b = d.repository[f];
                b && (l = De.getCompiledRuleId(b, n, d.repository));
              } else l = De.getCompiledRuleId(d.repository.$self, n, d.repository);
              break;
          }
        } else l = De.getCompiledRuleId(o, n, r);
        if (l !== -1) {
          const u = n.getRule(l);
          let c = !1;
          if ((u instanceof Cs || u instanceof si || u instanceof qr) && u.hasMissingPatterns && u.patterns.length === 0 && (c = !0), c) continue;
          a.push(l);
        }
      }
      return {
        patterns: a,
        hasMissingPatterns: (t ? t.length : 0) !== a.length
      };
    }
  },
  Yn = class Al {
    source;
    ruleId;
    hasAnchor;
    hasBackReferences;
    _anchorCache;
    constructor(t, n) {
      if (t && typeof t == "string") {
        const r = t.length;
        let a = 0,
          i = [],
          s = !1;
        for (let o = 0; o < r; o++) if (t.charAt(o) === "\\" && o + 1 < r) {
          const u = t.charAt(o + 1);
          u === "z" ? (i.push(t.substring(a, o)), i.push("$(?!\\n)(?<!\\n)"), a = o + 2) : (u === "A" || u === "G") && (s = !0), o++;
        }
        this.hasAnchor = s, a === 0 ? this.source = t : (i.push(t.substring(a, r)), this.source = i.join(""));
      } else this.hasAnchor = !1, this.source = t;
      this.hasAnchor ? this._anchorCache = this._buildAnchorCache() : this._anchorCache = null, this.ruleId = n, typeof this.source == "string" ? this.hasBackReferences = lc.test(this.source) : this.hasBackReferences = !1;
    }
    clone() {
      return new Al(this.source, this.ruleId);
    }
    setSource(t) {
      this.source !== t && (this.source = t, this.hasAnchor && (this._anchorCache = this._buildAnchorCache()));
    }
    resolveBackReferences(t, n) {
      if (typeof this.source != "string") throw new Error("This method should only be called if the source is a string");
      let r = n.map(a => t.substring(a.start, a.end));
      return $s.lastIndex = 0, this.source.replace($s, (a, i) => vl(r[parseInt(i, 10)] || ""));
    }
    _buildAnchorCache() {
      if (typeof this.source != "string") throw new Error("This method should only be called if the source is a string");
      let t = [],
        n = [],
        r = [],
        a = [],
        i,
        s,
        o,
        l;
      for (i = 0, s = this.source.length; i < s; i++) o = this.source.charAt(i), t[i] = o, n[i] = o, r[i] = o, a[i] = o, o === "\\" && i + 1 < s && (l = this.source.charAt(i + 1), l === "A" ? (t[i + 1] = "￿", n[i + 1] = "￿", r[i + 1] = "A", a[i + 1] = "A") : l === "G" ? (t[i + 1] = "￿", n[i + 1] = "G", r[i + 1] = "￿", a[i + 1] = "G") : (t[i + 1] = l, n[i + 1] = l, r[i + 1] = l, a[i + 1] = l), i++);
      return {
        A0_G0: t.join(""),
        A0_G1: n.join(""),
        A1_G0: r.join(""),
        A1_G1: a.join("")
      };
    }
    resolveAnchors(t, n) {
      return !this.hasAnchor || !this._anchorCache || typeof this.source != "string" ? this.source : t ? n ? this._anchorCache.A1_G1 : this._anchorCache.A1_G0 : n ? this._anchorCache.A0_G1 : this._anchorCache.A0_G0;
    }
  },
  Zn = class {
    _items;
    _hasAnchors;
    _cached;
    _anchorCache;
    constructor() {
      this._items = [], this._hasAnchors = !1, this._cached = null, this._anchorCache = {
        A0_G0: null,
        A0_G1: null,
        A1_G0: null,
        A1_G1: null
      };
    }
    dispose() {
      this._disposeCaches();
    }
    _disposeCaches() {
      this._cached && (this._cached.dispose(), this._cached = null), this._anchorCache.A0_G0 && (this._anchorCache.A0_G0.dispose(), this._anchorCache.A0_G0 = null), this._anchorCache.A0_G1 && (this._anchorCache.A0_G1.dispose(), this._anchorCache.A0_G1 = null), this._anchorCache.A1_G0 && (this._anchorCache.A1_G0.dispose(), this._anchorCache.A1_G0 = null), this._anchorCache.A1_G1 && (this._anchorCache.A1_G1.dispose(), this._anchorCache.A1_G1 = null);
    }
    push(e) {
      this._items.push(e), this._hasAnchors = this._hasAnchors || e.hasAnchor;
    }
    unshift(e) {
      this._items.unshift(e), this._hasAnchors = this._hasAnchors || e.hasAnchor;
    }
    length() {
      return this._items.length;
    }
    setSource(e, t) {
      this._items[e].source !== t && (this._disposeCaches(), this._items[e].setSource(t));
    }
    compile(e) {
      if (!this._cached) {
        let t = this._items.map(n => n.source);
        this._cached = new Ss(e, t, this._items.map(n => n.ruleId));
      }
      return this._cached;
    }
    compileAG(e, t, n) {
      return this._hasAnchors ? t ? n ? (this._anchorCache.A1_G1 || (this._anchorCache.A1_G1 = this._resolveAnchors(e, t, n)), this._anchorCache.A1_G1) : (this._anchorCache.A1_G0 || (this._anchorCache.A1_G0 = this._resolveAnchors(e, t, n)), this._anchorCache.A1_G0) : n ? (this._anchorCache.A0_G1 || (this._anchorCache.A0_G1 = this._resolveAnchors(e, t, n)), this._anchorCache.A0_G1) : (this._anchorCache.A0_G0 || (this._anchorCache.A0_G0 = this._resolveAnchors(e, t, n)), this._anchorCache.A0_G0) : this.compile(e);
    }
    _resolveAnchors(e, t, n) {
      let r = this._items.map(a => a.resolveAnchors(t, n));
      return new Ss(e, r, this._items.map(a => a.ruleId));
    }
  },
  Ss = class {
    constructor(e, t, n) {
      this.regExps = t, this.rules = n, this.scanner = e.createOnigScanner(t);
    }
    scanner;
    dispose() {
      typeof this.scanner.dispose == "function" && this.scanner.dispose();
    }
    toString() {
      const e = [];
      for (let t = 0, n = this.rules.length; t < n; t++) e.push("   - " + this.rules[t] + ": " + this.regExps[t]);
      return e.join(`
`);
    }
    findNextMatchSync(e, t, n) {
      const r = this.scanner.findNextMatchSync(e, t, n);
      return r ? {
        ruleId: this.rules[r.index],
        captureIndices: r.captureIndices
      } : null;
    }
  },
  Sa = class {
    constructor(e, t) {
      this.languageId = e, this.tokenType = t;
    }
  },
  hc = class oi {
    _defaultAttributes;
    _embeddedLanguagesMatcher;
    constructor(t, n) {
      this._defaultAttributes = new Sa(t, 8), this._embeddedLanguagesMatcher = new pc(Object.entries(n || {}));
    }
    getDefaultAttributes() {
      return this._defaultAttributes;
    }
    getBasicScopeAttributes(t) {
      return t === null ? oi._NULL_SCOPE_METADATA : this._getBasicScopeAttributes.get(t);
    }
    static _NULL_SCOPE_METADATA = new Sa(0, 0);
    _getBasicScopeAttributes = new wl(t => {
      const n = this._scopeToLanguage(t),
        r = this._toStandardTokenType(t);
      return new Sa(n, r);
    });
    _scopeToLanguage(t) {
      return this._embeddedLanguagesMatcher.match(t) || 0;
    }
    _toStandardTokenType(t) {
      const n = t.match(oi.STANDARD_TOKEN_TYPE_REGEXP);
      if (!n) return 8;
      switch (n[1]) {
        case "comment":
          return 1;
        case "string":
          return 2;
        case "regex":
          return 3;
        case "meta.embedded":
          return 0;
      }
      throw new Error("Unexpected match for standard token type!");
    }
    static STANDARD_TOKEN_TYPE_REGEXP = /\b(comment|string|regex|meta\.embedded)\b/;
  },
  pc = class {
    values;
    scopesRegExp;
    constructor(e) {
      if (e.length === 0) this.values = null, this.scopesRegExp = null;else {
        this.values = new Map(e);
        const t = e.map(([n, r]) => vl(n));
        t.sort(), t.reverse(), this.scopesRegExp = new RegExp(`^((${t.join(")|(")}))($|\\.)`, "");
      }
    }
    match(e) {
      if (!this.scopesRegExp) return;
      const t = e.match(this.scopesRegExp);
      if (t) return this.values.get(t[1]);
    }
  },
  As = class {
    constructor(e, t) {
      this.stack = e, this.stoppedEarly = t;
    }
  };
function Tl(e, t, n, r, a, i, s, o) {
  const l = t.content.length;
  let u = !1,
    c = -1;
  if (s) {
    const d = dc(e, t, n, r, a, i);
    a = d.stack, r = d.linePos, n = d.isFirstLine, c = d.anchorPosition;
  }
  const h = Date.now();
  for (; !u;) {
    if (o !== 0 && Date.now() - h > o) return new As(a, !0);
    f();
  }
  return new As(a, !1);
  function f() {
    const d = fc(e, t, n, r, a, c);
    if (!d) {
      i.produce(a, l), u = !0;
      return;
    }
    const b = d.captureIndices,
      k = d.matchedRuleId,
      A = b && b.length > 0 ? b[0].end > r : !1;
    if (k === uc) {
      const w = a.getRule(e);
      i.produce(a, b[0].start), a = a.withContentNameScopesList(a.nameScopesList), jn(e, t, n, a, i, w.endCaptures, b), i.produce(a, b[0].end);
      const _ = a;
      if (a = a.parent, c = _.getAnchorPos(), !A && _.getEnterPos() === r) {
        a = _, i.produce(a, l), u = !0;
        return;
      }
    } else {
      const w = e.getRule(k);
      i.produce(a, b[0].start);
      const _ = a,
        T = w.getName(t.content, b),
        I = a.contentNameScopesList.pushAttributed(T, e);
      if (a = a.push(k, r, c, b[0].end === l, null, I, I), w instanceof si) {
        const R = w;
        jn(e, t, n, a, i, R.beginCaptures, b), i.produce(a, b[0].end), c = b[0].end;
        const E = R.getContentName(t.content, b),
          O = I.pushAttributed(E, e);
        if (a = a.withContentNameScopesList(O), R.endHasBackReferences && (a = a.withEndRule(R.getEndWithResolvedBackReferences(t.content, b))), !A && _.hasSameRuleAs(a)) {
          a = a.pop(), i.produce(a, l), u = !0;
          return;
        }
      } else if (w instanceof qr) {
        const R = w;
        jn(e, t, n, a, i, R.beginCaptures, b), i.produce(a, b[0].end), c = b[0].end;
        const E = R.getContentName(t.content, b),
          O = I.pushAttributed(E, e);
        if (a = a.withContentNameScopesList(O), R.whileHasBackReferences && (a = a.withEndRule(R.getWhileWithResolvedBackReferences(t.content, b))), !A && _.hasSameRuleAs(a)) {
          a = a.pop(), i.produce(a, l), u = !0;
          return;
        }
      } else if (jn(e, t, n, a, i, w.captures, b), i.produce(a, b[0].end), a = a.pop(), !A) {
        a = a.safePop(), i.produce(a, l), u = !0;
        return;
      }
    }
    b[0].end > r && (r = b[0].end, n = !1);
  }
}
function dc(e, t, n, r, a, i) {
  let s = a.beginRuleCapturedEOL ? 0 : -1;
  const o = [];
  for (let l = a; l; l = l.pop()) {
    const u = l.getRule(e);
    u instanceof qr && o.push({
      rule: u,
      stack: l
    });
  }
  for (let l = o.pop(); l; l = o.pop()) {
    const {
        ruleScanner: u,
        findOptions: c
      } = yc(l.rule, e, l.stack.endRule, n, r === s),
      h = u.findNextMatchSync(t, r, c);
    if (h) {
      if (h.ruleId !== Cl) {
        a = l.stack.pop();
        break;
      }
      h.captureIndices && h.captureIndices.length && (i.produce(l.stack, h.captureIndices[0].start), jn(e, t, n, l.stack, i, l.rule.whileCaptures, h.captureIndices), i.produce(l.stack, h.captureIndices[0].end), s = h.captureIndices[0].end, h.captureIndices[0].end > r && (r = h.captureIndices[0].end, n = !1));
    } else {
      a = l.stack.pop();
      break;
    }
  }
  return {
    stack: a,
    linePos: r,
    anchorPosition: s,
    isFirstLine: n
  };
}
function fc(e, t, n, r, a, i) {
  const s = gc(e, t, n, r, a, i),
    o = e.getInjections();
  if (o.length === 0) return s;
  const l = bc(o, e, t, n, r, a, i);
  if (!l) return s;
  if (!s) return l;
  const u = s.captureIndices[0].start,
    c = l.captureIndices[0].start;
  return c < u || l.priorityMatch && c === u ? l : s;
}
function gc(e, t, n, r, a, i) {
  const s = a.getRule(e),
    {
      ruleScanner: o,
      findOptions: l
    } = El(s, e, a.endRule, n, r === i),
    u = o.findNextMatchSync(t, r, l);
  return u ? {
    captureIndices: u.captureIndices,
    matchedRuleId: u.ruleId
  } : null;
}
function bc(e, t, n, r, a, i, s) {
  let o = Number.MAX_VALUE,
    l = null,
    u,
    c = 0;
  const h = i.contentNameScopesList.getScopeNames();
  for (let f = 0, d = e.length; f < d; f++) {
    const b = e[f];
    if (!b.matcher(h)) continue;
    const k = t.getRule(b.ruleId),
      {
        ruleScanner: A,
        findOptions: w
      } = El(k, t, null, r, a === s),
      _ = A.findNextMatchSync(n, a, w);
    if (!_) continue;
    const T = _.captureIndices[0].start;
    if (!(T >= o) && (o = T, l = _.captureIndices, u = _.ruleId, c = b.priority, o === a)) break;
  }
  return l ? {
    priorityMatch: c === -1,
    captureIndices: l,
    matchedRuleId: u
  } : null;
}
function El(e, t, n, r, a) {
  return {
    ruleScanner: e.compileAG(t, n, r, a),
    findOptions: 0
  };
}
function yc(e, t, n, r, a) {
  return {
    ruleScanner: e.compileWhileAG(t, n, r, a),
    findOptions: 0
  };
}
function jn(e, t, n, r, a, i, s) {
  if (i.length === 0) return;
  const o = t.content,
    l = Math.min(i.length, s.length),
    u = [],
    c = s[0].end;
  for (let h = 0; h < l; h++) {
    const f = i[h];
    if (f === null) continue;
    const d = s[h];
    if (d.length === 0) continue;
    if (d.start > c) break;
    for (; u.length > 0 && u[u.length - 1].endPos <= d.start;) a.produceFromScopes(u[u.length - 1].scopes, u[u.length - 1].endPos), u.pop();
    if (u.length > 0 ? a.produceFromScopes(u[u.length - 1].scopes, d.start) : a.produce(r, d.start), f.retokenizeCapturedWithRuleId) {
      const k = f.getName(o, s),
        A = r.contentNameScopesList.pushAttributed(k, e),
        w = f.getContentName(o, s),
        _ = A.pushAttributed(w, e),
        T = r.push(f.retokenizeCapturedWithRuleId, d.start, -1, !1, null, A, _),
        I = e.createOnigString(o.substring(0, d.end));
      Tl(e, I, n && d.start === 0, d.start, T, a, !1, 0), _l(I);
      continue;
    }
    const b = f.getName(o, s);
    if (b !== null) {
      const A = (u.length > 0 ? u[u.length - 1].scopes : r.contentNameScopesList).pushAttributed(b, e);
      u.push(new vc(A, d.end));
    }
  }
  for (; u.length > 0;) a.produceFromScopes(u[u.length - 1].scopes, u[u.length - 1].endPos), u.pop();
}
var vc = class {
  scopes;
  endPos;
  constructor(e, t) {
    this.scopes = e, this.endPos = t;
  }
};
function wc(e, t, n, r, a, i, s, o) {
  return new kc(e, t, n, r, a, i, s, o);
}
function Ts(e, t, n, r, a) {
  const i = Pr(t, jr),
    s = Sl.getCompiledRuleId(n, r, a.repository);
  for (const o of i) e.push({
    debugSelector: t,
    matcher: o.matcher,
    ruleId: s,
    grammar: a,
    priority: o.priority
  });
}
function jr(e, t) {
  if (t.length < e.length) return !1;
  let n = 0;
  return e.every(r => {
    for (let a = n; a < t.length; a++) if (xc(t[a], r)) return n = a + 1, !0;
    return !1;
  });
}
function xc(e, t) {
  if (!e) return !1;
  if (e === t) return !0;
  const n = t.length;
  return e.length > n && e.substr(0, n) === t && e[n] === ".";
}
var kc = class {
  constructor(e, t, n, r, a, i, s, o) {
    if (this._rootScopeName = e, this.balancedBracketSelectors = i, this._onigLib = o, this._basicScopeAttributesProvider = new hc(n, r), this._rootId = -1, this._lastRuleId = 0, this._ruleId2desc = [null], this._includedGrammars = {}, this._grammarRepository = s, this._grammar = Es(t, null), this._injections = null, this._tokenTypeMatchers = [], a) for (const l of Object.keys(a)) {
      const u = Pr(l, jr);
      for (const c of u) this._tokenTypeMatchers.push({
        matcher: c.matcher,
        type: a[l]
      });
    }
  }
  _rootId;
  _lastRuleId;
  _ruleId2desc;
  _includedGrammars;
  _grammarRepository;
  _grammar;
  _injections;
  _basicScopeAttributesProvider;
  _tokenTypeMatchers;
  get themeProvider() {
    return this._grammarRepository;
  }
  dispose() {
    for (const e of this._ruleId2desc) e && e.dispose();
  }
  createOnigScanner(e) {
    return this._onigLib.createOnigScanner(e);
  }
  createOnigString(e) {
    return this._onigLib.createOnigString(e);
  }
  getMetadataForScope(e) {
    return this._basicScopeAttributesProvider.getBasicScopeAttributes(e);
  }
  _collectInjections() {
    const e = {
        lookup: a => a === this._rootScopeName ? this._grammar : this.getExternalGrammar(a),
        injections: a => this._grammarRepository.injections(a)
      },
      t = [],
      n = this._rootScopeName,
      r = e.lookup(n);
    if (r) {
      const a = r.injections;
      if (a) for (let s in a) Ts(t, s, a[s], this, r);
      const i = this._grammarRepository.injections(n);
      i && i.forEach(s => {
        const o = this.getExternalGrammar(s);
        if (o) {
          const l = o.injectionSelector;
          l && Ts(t, l, o, this, o);
        }
      });
    }
    return t.sort((a, i) => a.priority - i.priority), t;
  }
  getInjections() {
    return this._injections === null && (this._injections = this._collectInjections()), this._injections;
  }
  registerRule(e) {
    const t = ++this._lastRuleId,
      n = e(t);
    return this._ruleId2desc[t] = n, n;
  }
  getRule(e) {
    return this._ruleId2desc[e];
  }
  getExternalGrammar(e, t) {
    if (this._includedGrammars[e]) return this._includedGrammars[e];
    if (this._grammarRepository) {
      const n = this._grammarRepository.lookup(e);
      if (n) return this._includedGrammars[e] = Es(n, t && t.$base), this._includedGrammars[e];
    }
  }
  tokenizeLine(e, t, n = 0) {
    const r = this._tokenize(e, t, !1, n);
    return {
      tokens: r.lineTokens.getResult(r.ruleStack, r.lineLength),
      ruleStack: r.ruleStack,
      stoppedEarly: r.stoppedEarly
    };
  }
  tokenizeLine2(e, t, n = 0) {
    const r = this._tokenize(e, t, !0, n);
    return {
      tokens: r.lineTokens.getBinaryResult(r.ruleStack, r.lineLength),
      ruleStack: r.ruleStack,
      stoppedEarly: r.stoppedEarly
    };
  }
  _tokenize(e, t, n, r) {
    this._rootId === -1 && (this._rootId = Sl.getCompiledRuleId(this._grammar.repository.$self, this, this._grammar.repository), this.getInjections());
    let a;
    if (!t || t === li.NULL) {
      a = !0;
      const u = this._basicScopeAttributesProvider.getDefaultAttributes(),
        c = this.themeProvider.getDefaults(),
        h = cn.set(0, u.languageId, u.tokenType, null, c.fontStyle, c.foregroundId, c.backgroundId),
        f = this.getRule(this._rootId).getName(null, null);
      let d;
      f ? d = Hn.createRootAndLookUpScopeName(f, h, this) : d = Hn.createRoot("unknown", h), t = new li(null, this._rootId, -1, -1, !1, null, d, d);
    } else a = !1, t.reset();
    e = e + `
`;
    const i = this.createOnigString(e),
      s = i.content.length,
      o = new $c(n, e, this._tokenTypeMatchers, this.balancedBracketSelectors),
      l = Tl(this, i, a, 0, t, o, !0, r);
    return _l(i), {
      lineLength: s,
      lineTokens: o,
      ruleStack: l.stack,
      stoppedEarly: l.stoppedEarly
    };
  }
};
function Es(e, t) {
  return e = qu(e), e.repository = e.repository || {}, e.repository.$self = {
    $vscodeTextmateLocation: e.$vscodeTextmateLocation,
    patterns: e.patterns,
    name: e.scopeName
  }, e.repository.$base = t || e.repository.$self, e;
}
var Hn = class bt {
    constructor(t, n, r) {
      this.parent = t, this.scopePath = n, this.tokenAttributes = r;
    }
    static fromExtension(t, n) {
      let r = t,
        a = t?.scopePath ?? null;
      for (const i of n) a = Ca.push(a, i.scopeNames), r = new bt(r, a, i.encodedTokenAttributes);
      return r;
    }
    static createRoot(t, n) {
      return new bt(null, new Ca(null, t), n);
    }
    static createRootAndLookUpScopeName(t, n, r) {
      const a = r.getMetadataForScope(t),
        i = new Ca(null, t),
        s = r.themeProvider.themeMatch(i),
        o = bt.mergeAttributes(n, a, s);
      return new bt(null, i, o);
    }
    get scopeName() {
      return this.scopePath.scopeName;
    }
    toString() {
      return this.getScopeNames().join(" ");
    }
    equals(t) {
      return bt.equals(this, t);
    }
    static equals(t, n) {
      do {
        if (t === n || !t && !n) return !0;
        if (!t || !n || t.scopeName !== n.scopeName || t.tokenAttributes !== n.tokenAttributes) return !1;
        t = t.parent, n = n.parent;
      } while (!0);
    }
    static mergeAttributes(t, n, r) {
      let a = -1,
        i = 0,
        s = 0;
      return r !== null && (a = r.fontStyle, i = r.foregroundId, s = r.backgroundId), cn.set(t, n.languageId, n.tokenType, null, a, i, s);
    }
    pushAttributed(t, n) {
      if (t === null) return this;
      if (t.indexOf(" ") === -1) return bt._pushAttributed(this, t, n);
      const r = t.split(/ /g);
      let a = this;
      for (const i of r) a = bt._pushAttributed(a, i, n);
      return a;
    }
    static _pushAttributed(t, n, r) {
      const a = r.getMetadataForScope(n),
        i = t.scopePath.push(n),
        s = r.themeProvider.themeMatch(i),
        o = bt.mergeAttributes(t.tokenAttributes, a, s);
      return new bt(t, i, o);
    }
    getScopeNames() {
      return this.scopePath.getSegments();
    }
    getExtensionIfDefined(t) {
      const n = [];
      let r = this;
      for (; r && r !== t;) n.push({
        encodedTokenAttributes: r.tokenAttributes,
        scopeNames: r.scopePath.getExtensionIfDefined(r.parent?.scopePath ?? null)
      }), r = r.parent;
      return r === t ? n.reverse() : void 0;
    }
  },
  li = (class an {
    constructor(t, n, r, a, i, s, o, l) {
      this.parent = t, this.ruleId = n, this.beginRuleCapturedEOL = i, this.endRule = s, this.nameScopesList = o, this.contentNameScopesList = l, this.depth = this.parent ? this.parent.depth + 1 : 1, this._enterPos = r, this._anchorPos = a;
    }
    _stackElementBrand = void 0;
    _enterPos;
    _anchorPos;
    depth;
    equals(t) {
      return t === null ? !1 : an._equals(this, t);
    }
    static _equals(t, n) {
      return t === n ? !0 : this._structuralEquals(t, n) ? Hn.equals(t.contentNameScopesList, n.contentNameScopesList) : !1;
    }
    static _structuralEquals(t, n) {
      do {
        if (t === n || !t && !n) return !0;
        if (!t || !n || t.depth !== n.depth || t.ruleId !== n.ruleId || t.endRule !== n.endRule) return !1;
        t = t.parent, n = n.parent;
      } while (!0);
    }
    clone() {
      return this;
    }
    static _reset(t) {
      for (; t;) t._enterPos = -1, t._anchorPos = -1, t = t.parent;
    }
    reset() {
      an._reset(this);
    }
    pop() {
      return this.parent;
    }
    safePop() {
      return this.parent ? this.parent : this;
    }
    push(t, n, r, a, i, s, o) {
      return new an(this, t, n, r, a, i, s, o);
    }
    getEnterPos() {
      return this._enterPos;
    }
    getAnchorPos() {
      return this._anchorPos;
    }
    getRule(t) {
      return t.getRule(this.ruleId);
    }
    toString() {
      const t = [];
      return this._writeString(t, 0), "[" + t.join(",") + "]";
    }
    _writeString(t, n) {
      return this.parent && (n = this.parent._writeString(t, n)), t[n++] = `(${this.ruleId}, ${this.nameScopesList?.toString()}, ${this.contentNameScopesList?.toString()})`, n;
    }
    withContentNameScopesList(t) {
      return this.contentNameScopesList === t ? this : this.parent.push(this.ruleId, this._enterPos, this._anchorPos, this.beginRuleCapturedEOL, this.endRule, this.nameScopesList, t);
    }
    withEndRule(t) {
      return this.endRule === t ? this : new an(this.parent, this.ruleId, this._enterPos, this._anchorPos, this.beginRuleCapturedEOL, t, this.nameScopesList, this.contentNameScopesList);
    }
    hasSameRuleAs(t) {
      let n = this;
      for (; n && n._enterPos === t._enterPos;) {
        if (n.ruleId === t.ruleId) return !0;
        n = n.parent;
      }
      return !1;
    }
    toStateStackFrame() {
      return {
        ruleId: this.ruleId,
        beginRuleCapturedEOL: this.beginRuleCapturedEOL,
        endRule: this.endRule,
        nameScopesList: this.nameScopesList?.getExtensionIfDefined(this.parent?.nameScopesList ?? null) ?? [],
        contentNameScopesList: this.contentNameScopesList?.getExtensionIfDefined(this.nameScopesList) ?? []
      };
    }
    static pushFrame(t, n) {
      const r = Hn.fromExtension(t?.nameScopesList ?? null, n.nameScopesList);
      return new an(t, n.ruleId, n.enterPos ?? -1, n.anchorPos ?? -1, n.beginRuleCapturedEOL, n.endRule, r, Hn.fromExtension(r, n.contentNameScopesList));
    }
    static #_ = _staticBlock = () => (_defineProperty(this, "NULL", new an(null, 0, 0, 0, !1, null, null, null)), this);
  }, _staticBlock()),
  _c = class {
    balancedBracketScopes;
    unbalancedBracketScopes;
    allowAny = !1;
    constructor(e, t) {
      this.balancedBracketScopes = e.flatMap(n => n === "*" ? (this.allowAny = !0, []) : Pr(n, jr).map(r => r.matcher)), this.unbalancedBracketScopes = t.flatMap(n => Pr(n, jr).map(r => r.matcher));
    }
    get matchesAlways() {
      return this.allowAny && this.unbalancedBracketScopes.length === 0;
    }
    get matchesNever() {
      return this.balancedBracketScopes.length === 0 && !this.allowAny;
    }
    match(e) {
      for (const t of this.unbalancedBracketScopes) if (t(e)) return !1;
      for (const t of this.balancedBracketScopes) if (t(e)) return !0;
      return this.allowAny;
    }
  },
  $c = class {
    constructor(e, t, n, r) {
      this.balancedBracketSelectors = r, this._emitBinaryTokens = e, this._tokenTypeOverrides = n, this._lineText = null, this._tokens = [], this._binaryTokens = [], this._lastTokenEndIndex = 0;
    }
    _emitBinaryTokens;
    _lineText;
    _tokens;
    _binaryTokens;
    _lastTokenEndIndex;
    _tokenTypeOverrides;
    produce(e, t) {
      this.produceFromScopes(e.contentNameScopesList, t);
    }
    produceFromScopes(e, t) {
      if (this._lastTokenEndIndex >= t) return;
      if (this._emitBinaryTokens) {
        let r = e?.tokenAttributes ?? 0,
          a = !1;
        if (this.balancedBracketSelectors?.matchesAlways && (a = !0), this._tokenTypeOverrides.length > 0 || this.balancedBracketSelectors && !this.balancedBracketSelectors.matchesAlways && !this.balancedBracketSelectors.matchesNever) {
          const i = e?.getScopeNames() ?? [];
          for (const s of this._tokenTypeOverrides) s.matcher(i) && (r = cn.set(r, 0, s.type, null, -1, 0, 0));
          this.balancedBracketSelectors && (a = this.balancedBracketSelectors.match(i));
        }
        if (a && (r = cn.set(r, 0, 8, a, -1, 0, 0)), this._binaryTokens.length > 0 && this._binaryTokens[this._binaryTokens.length - 1] === r) {
          this._lastTokenEndIndex = t;
          return;
        }
        this._binaryTokens.push(this._lastTokenEndIndex), this._binaryTokens.push(r), this._lastTokenEndIndex = t;
        return;
      }
      const n = e?.getScopeNames() ?? [];
      this._tokens.push({
        startIndex: this._lastTokenEndIndex,
        endIndex: t,
        scopes: n
      }), this._lastTokenEndIndex = t;
    }
    getResult(e, t) {
      return this._tokens.length > 0 && this._tokens[this._tokens.length - 1].startIndex === t - 1 && this._tokens.pop(), this._tokens.length === 0 && (this._lastTokenEndIndex = -1, this.produce(e, t), this._tokens[this._tokens.length - 1].startIndex = 0), this._tokens;
    }
    getBinaryResult(e, t) {
      this._binaryTokens.length > 0 && this._binaryTokens[this._binaryTokens.length - 2] === t - 1 && (this._binaryTokens.pop(), this._binaryTokens.pop()), this._binaryTokens.length === 0 && (this._lastTokenEndIndex = -1, this.produce(e, t), this._binaryTokens[this._binaryTokens.length - 2] = 0);
      const n = new Uint32Array(this._binaryTokens.length);
      for (let r = 0, a = this._binaryTokens.length; r < a; r++) n[r] = this._binaryTokens[r];
      return n;
    }
  },
  Cc = class {
    constructor(e, t) {
      this._onigLib = t, this._theme = e;
    }
    _grammars = new Map();
    _rawGrammars = new Map();
    _injectionGrammars = new Map();
    _theme;
    dispose() {
      for (const e of this._grammars.values()) e.dispose();
    }
    setTheme(e) {
      this._theme = e;
    }
    getColorMap() {
      return this._theme.getColorMap();
    }
    addGrammar(e, t) {
      this._rawGrammars.set(e.scopeName, e), t && this._injectionGrammars.set(e.scopeName, t);
    }
    lookup(e) {
      return this._rawGrammars.get(e);
    }
    injections(e) {
      return this._injectionGrammars.get(e);
    }
    getDefaults() {
      return this._theme.getDefaults();
    }
    themeMatch(e) {
      return this._theme.match(e);
    }
    grammarForScopeName(e, t, n, r, a) {
      if (!this._grammars.has(e)) {
        let i = this._rawGrammars.get(e);
        if (!i) return null;
        this._grammars.set(e, wc(e, i, t, n, r, a, this, this._onigLib));
      }
      return this._grammars.get(e);
    }
  },
  Sc = class {
    _options;
    _syncRegistry;
    _ensureGrammarCache;
    constructor(t) {
      this._options = t, this._syncRegistry = new Cc(Fr.createFromRawTheme(t.theme, t.colorMap), t.onigLib), this._ensureGrammarCache = new Map();
    }
    dispose() {
      this._syncRegistry.dispose();
    }
    setTheme(t, n) {
      this._syncRegistry.setTheme(Fr.createFromRawTheme(t, n));
    }
    getColorMap() {
      return this._syncRegistry.getColorMap();
    }
    loadGrammarWithEmbeddedLanguages(t, n, r) {
      return this.loadGrammarWithConfiguration(t, n, {
        embeddedLanguages: r
      });
    }
    loadGrammarWithConfiguration(t, n, r) {
      return this._loadGrammar(t, n, r.embeddedLanguages, r.tokenTypes, new _c(r.balancedBracketSelectors || [], r.unbalancedBracketSelectors || []));
    }
    loadGrammar(t) {
      return this._loadGrammar(t, 0, null, null, null);
    }
    _loadGrammar(t, n, r, a, i) {
      const s = new tc(this._syncRegistry, t);
      for (; s.Q.length > 0;) s.Q.map(o => this._loadSingleGrammar(o.scopeName)), s.processQueue();
      return this._grammarForScopeName(t, n, r, a, i);
    }
    _loadSingleGrammar(t) {
      this._ensureGrammarCache.has(t) || (this._doLoadSingleGrammar(t), this._ensureGrammarCache.set(t, !0));
    }
    _doLoadSingleGrammar(t) {
      const n = this._options.loadGrammar(t);
      if (n) {
        const r = typeof this._options.getInjections == "function" ? this._options.getInjections(t) : void 0;
        this._syncRegistry.addGrammar(n, r);
      }
    }
    addGrammar(t, n = [], r = 0, a = null) {
      return this._syncRegistry.addGrammar(t, n), this._grammarForScopeName(t.scopeName, r, a);
    }
    _grammarForScopeName(t, n = 0, r = null, a = null, i = null) {
      return this._syncRegistry.grammarForScopeName(t, n, r, a, i);
    }
  },
  ui = li.NULL;
function Gr(e, t) {
  const n = typeof e == "string" ? {} : {
      ...e.colorReplacements
    },
    r = typeof e == "string" ? e : e.name;
  for (const [a, i] of Object.entries(t?.colorReplacements || {})) typeof i == "string" ? n[a] = i : a === r && Object.assign(n, i);
  return n;
}
function Ht(e, t) {
  return e && (t?.[e?.toLowerCase()] || e);
}
function Ac(e) {
  return Array.isArray(e) ? e : [e];
}
async function Ml(e) {
  return Promise.resolve(typeof e == "function" ? e() : e).then(t => t.default || t);
}
function ea(e) {
  return !e || ["plaintext", "txt", "text", "plain"].includes(e);
}
function Tc(e) {
  return e === "ansi" || ea(e);
}
function ta(e) {
  return e === "none";
}
function Ec(e) {
  return ta(e);
}
const Mc = /(\r?\n)/g;
function na(e, t = !1) {
  if (e.length === 0) return [["", 0]];
  const n = e.split(Mc);
  let r = 0;
  const a = [];
  for (let i = 0; i < n.length; i += 2) {
    const s = t ? n[i] + (n[i + 1] || "") : n[i];
    a.push([s, r]), r += n[i].length, r += n[i + 1]?.length || 0;
  }
  return a;
}
const Ms = {
    light: "#333333",
    dark: "#bbbbbb"
  },
  zs = {
    light: "#fffffe",
    dark: "#1e1e1e"
  },
  Is = "__shiki_resolved";
function Wi(e) {
  if (e?.[Is]) return e;
  const t = {
    ...e
  };
  t.tokenColors && !t.settings && (t.settings = t.tokenColors, delete t.tokenColors), t.type ||= "dark", t.colorReplacements = {
    ...t.colorReplacements
  }, t.settings ||= [];
  let {
    bg: n,
    fg: r
  } = t;
  if (!n || !r) {
    const o = t.settings ? t.settings.find(l => !l.name && !l.scope) : void 0;
    o?.settings?.foreground && (r = o.settings.foreground), o?.settings?.background && (n = o.settings.background), !r && t?.colors?.["editor.foreground"] && (r = t.colors["editor.foreground"]), !n && t?.colors?.["editor.background"] && (n = t.colors["editor.background"]), r || (r = t.type === "light" ? Ms.light : Ms.dark), n || (n = t.type === "light" ? zs.light : zs.dark), t.fg = r, t.bg = n;
  }
  t.settings[0] && t.settings[0].settings && !t.settings[0].scope || t.settings.unshift({
    settings: {
      foreground: t.fg,
      background: t.bg
    }
  });
  let a = 0;
  const i = new Map();
  function s(o) {
    if (i.has(o)) return i.get(o);
    a += 1;
    const l = `#${a.toString(16).padStart(8, "0").toLowerCase()}`;
    return t.colorReplacements?.[`#${l}`] ? s(o) : (i.set(o, l), l);
  }
  t.settings = t.settings.map(o => {
    const l = o.settings?.foreground && !o.settings.foreground.startsWith("#"),
      u = o.settings?.background && !o.settings.background.startsWith("#");
    if (!l && !u) return o;
    const c = {
      ...o,
      settings: {
        ...o.settings
      }
    };
    if (l) {
      const h = s(o.settings.foreground);
      t.colorReplacements[h] = o.settings.foreground, c.settings.foreground = h;
    }
    if (u) {
      const h = s(o.settings.background);
      t.colorReplacements[h] = o.settings.background, c.settings.background = h;
    }
    return c;
  });
  for (const o of Object.keys(t.colors || {})) if ((o === "editor.foreground" || o === "editor.background" || o.startsWith("terminal.ansi")) && !t.colors[o]?.startsWith("#")) {
    const l = s(t.colors[o]);
    t.colorReplacements[l] = t.colors[o], t.colors[o] = l;
  }
  return Object.defineProperty(t, Is, {
    enumerable: !1,
    writable: !1,
    value: !0
  }), t;
}
async function zc(e) {
  return [...new Set((await Promise.all(e.filter(t => !Tc(t)).map(async t => await Ml(t).then(n => Array.isArray(n) ? n : [n])))).flat())];
}
async function Ic(e) {
  return (await Promise.all(e.map(async t => Ec(t) ? null : Wi(await Ml(t))))).filter(t => !!t);
}
function zl(e, t) {
  if (!t) return e;
  if (t[e]) {
    const n = new Set([e]);
    for (; t[e];) {
      if (e = t[e], n.has(e)) throw new ge(`Circular alias \`${[...n].join(" -> ")} -> ${e}\``);
      n.add(e);
    }
  }
  return e;
}
var Nc = class extends Sc {
    _resolver;
    _themes;
    _langs;
    _alias;
    _resolvedThemes = new Map();
    _resolvedGrammars = new Map();
    _langMap = new Map();
    _langGraph = new Map();
    _textmateThemeCache = new WeakMap();
    _loadedThemesCache = null;
    _loadedLanguagesCache = null;
    constructor(e, t, n, r = {}) {
      super(e), this._resolver = e, this._themes = t, this._langs = n, this._alias = r, this._themes.map(a => this.loadTheme(a)), this.loadLanguages(this._langs);
    }
    getTheme(e) {
      return typeof e == "string" ? this._resolvedThemes.get(e) : this.loadTheme(e);
    }
    loadTheme(e) {
      const t = Wi(e);
      return t.name && (this._resolvedThemes.set(t.name, t), this._loadedThemesCache = null), t;
    }
    getLoadedThemes() {
      return this._loadedThemesCache || (this._loadedThemesCache = [...this._resolvedThemes.keys()]), this._loadedThemesCache;
    }
    setTheme(e) {
      let t = this._textmateThemeCache.get(e);
      t || (t = Fr.createFromRawTheme(e), this._textmateThemeCache.set(e, t)), this._syncRegistry.setTheme(t);
    }
    getGrammar(e) {
      return e = zl(e, this._alias), this._resolvedGrammars.get(e);
    }
    loadLanguage(e) {
      if (this.getGrammar(e.name)) return;
      const t = new Set([...this._langMap.values()].filter(a => a.embeddedLangsLazy?.includes(e.name)));
      this._resolver.addLanguage(e);
      const n = {
        balancedBracketSelectors: e.balancedBracketSelectors || ["*"],
        unbalancedBracketSelectors: e.unbalancedBracketSelectors || []
      };
      this._syncRegistry._rawGrammars.set(e.scopeName, e);
      const r = this.loadGrammarWithConfiguration(e.scopeName, 1, n);
      if (r.name = e.name, this._resolvedGrammars.set(e.name, r), e.aliases && e.aliases.forEach(a => {
        this._alias[a] = e.name;
      }), this._loadedLanguagesCache = null, t.size) for (const a of t) this._resolvedGrammars.delete(a.name), this._loadedLanguagesCache = null, this._syncRegistry?._injectionGrammars?.delete(a.scopeName), this._syncRegistry?._grammars?.delete(a.scopeName), this.loadLanguage(this._langMap.get(a.name));
    }
    dispose() {
      super.dispose(), this._resolvedThemes.clear(), this._resolvedGrammars.clear(), this._langMap.clear(), this._langGraph.clear(), this._loadedThemesCache = null;
    }
    loadLanguages(e) {
      for (const r of e) this.resolveEmbeddedLanguages(r);
      const t = [...this._langGraph.entries()],
        n = t.filter(([r, a]) => !a);
      if (n.length) {
        const r = t.filter(([a, i]) => i ? (i.embeddedLanguages || i.embeddedLangs)?.some(s => n.map(([o]) => o).includes(s)) : !1).filter(a => !n.includes(a));
        throw new ge(`Missing languages ${n.map(([a]) => `\`${a}\``).join(", ")}, required by ${r.map(([a]) => `\`${a}\``).join(", ")}`);
      }
      for (const [r, a] of t) this._resolver.addLanguage(a);
      for (const [r, a] of t) this.loadLanguage(a);
    }
    getLoadedLanguages() {
      return this._loadedLanguagesCache || (this._loadedLanguagesCache = [...new Set([...this._resolvedGrammars.keys(), ...Object.keys(this._alias)])]), this._loadedLanguagesCache;
    }
    resolveEmbeddedLanguages(e) {
      this._langMap.set(e.name, e), this._langGraph.set(e.name, e);
      const t = e.embeddedLanguages ?? e.embeddedLangs;
      if (t) for (const n of t) this._langGraph.set(n, this._langMap.get(n));
    }
  },
  Rc = class {
    _langs = new Map();
    _scopeToLang = new Map();
    _injections = new Map();
    _onigLib;
    constructor(e, t) {
      this._onigLib = {
        createOnigScanner: n => e.createScanner(n),
        createOnigString: n => e.createString(n)
      }, t.forEach(n => this.addLanguage(n));
    }
    get onigLib() {
      return this._onigLib;
    }
    getLangRegistration(e) {
      return this._langs.get(e);
    }
    loadGrammar(e) {
      return this._scopeToLang.get(e);
    }
    addLanguage(e) {
      this._langs.set(e.name, e), e.aliases && e.aliases.forEach(t => {
        this._langs.set(t, e);
      }), this._scopeToLang.set(e.scopeName, e), e.injectTo && e.injectTo.forEach(t => {
        this._injections.get(t) || this._injections.set(t, []), this._injections.get(t).push(e.scopeName);
      });
    }
    getInjections(e) {
      const t = e.split(".");
      let n = [];
      for (let r = 1; r <= t.length; r++) {
        const a = t.slice(0, r).join(".");
        n = [...n, ...(this._injections.get(a) || [])];
      }
      return n;
    }
  };
let On = 0;
function Bc(e) {
  On += 1, e.warnings !== !1 && On >= 10 && On % 10 === 0 && console.warn(`[Shiki] ${On} instances have been created. Shiki is supposed to be used as a singleton, consider refactoring your code to cache your highlighter instance; Or call \`highlighter.dispose()\` to release unused instances.`);
  let t = !1;
  if (!e.engine) throw new ge("`engine` option is required for synchronous mode");
  const n = (e.langs || []).flat(1),
    r = (e.themes || []).flat(1).map(Wi),
    a = new Nc(new Rc(e.engine, n), r, n, e.langAlias);
  let i;
  function s(_) {
    return zl(_, e.langAlias);
  }
  function o(_) {
    A();
    const T = a.getGrammar(typeof _ == "string" ? _ : _.name);
    if (!T) throw new ge(`Language \`${_}\` not found, you may need to load it first`);
    return T;
  }
  function l(_) {
    if (_ === "none") return {
      bg: "",
      fg: "",
      name: "none",
      settings: [],
      type: "dark"
    };
    A();
    const T = a.getTheme(_);
    if (!T) throw new ge(`Theme \`${_}\` not found, you may need to load it first`);
    return T;
  }
  function u(_) {
    A();
    const T = l(_);
    return i !== _ && (a.setTheme(T), i = _), {
      theme: T,
      colorMap: a.getColorMap()
    };
  }
  function c() {
    return A(), a.getLoadedThemes();
  }
  function h() {
    return A(), a.getLoadedLanguages();
  }
  function f(..._) {
    A(), a.loadLanguages(_.flat(1));
  }
  async function d(..._) {
    return f(await zc(_));
  }
  function b(..._) {
    A();
    for (const T of _.flat(1)) a.loadTheme(T);
  }
  async function k(..._) {
    return A(), b(await Ic(_));
  }
  function A() {
    if (t) throw new ge("Shiki instance has been disposed");
  }
  function w() {
    t || (t = !0, a.dispose(), On -= 1);
  }
  return {
    setTheme: u,
    getTheme: l,
    getLanguage: o,
    getLoadedThemes: c,
    getLoadedLanguages: h,
    resolveLangAlias: s,
    loadLanguage: d,
    loadLanguageSync: f,
    loadTheme: k,
    loadThemeSync: b,
    dispose: w,
    [Symbol.dispose]: w
  };
}
const Il = new WeakMap();
function ra(e, t) {
  Il.set(e, t);
}
function Kn(e) {
  return Il.get(e);
}
var aa = class Nl {
  _stacks = {};
  lang;
  get themes() {
    return Object.keys(this._stacks);
  }
  get theme() {
    return this.themes[0];
  }
  get _stack() {
    return this._stacks[this.theme];
  }
  static initial(t, n) {
    return new Nl(Object.fromEntries(Ac(n).map(r => [r, ui])), t);
  }
  constructor(...t) {
    if (t.length === 2) {
      const [n, r] = t;
      this.lang = r, this._stacks = n;
    } else {
      const [n, r, a] = t;
      this.lang = r, this._stacks = {
        [a]: n
      };
    }
  }
  getInternalStack(t = this.theme) {
    return this._stacks[t];
  }
  getScopes(t = this.theme) {
    return Dc(this._stacks[t]);
  }
  toJSON() {
    return {
      lang: this.lang,
      theme: this.theme,
      themes: this.themes,
      scopes: this.getScopes()
    };
  }
};
function Dc(e) {
  const t = [],
    n = new Set();
  function r(a) {
    if (n.has(a)) return;
    n.add(a);
    const i = a?.nameScopesList?.scopeName;
    i && t.push(i), a.parent && r(a.parent);
  }
  return r(e), t;
}
function Lc(e, t) {
  if (!(e instanceof aa)) throw new ge("Invalid grammar state");
  return e.getInternalStack(t);
}
const Fc = /,/,
  Pc = / /;
function Rl(e, t, n = {}) {
  const {
    theme: r = e.getLoadedThemes()[0]
  } = n;
  if (ea(e.resolveLangAlias(n.lang || "text")) || ta(r)) return na(t).map(o => [{
    content: o[0],
    offset: o[1]
  }]);
  const {
      theme: a,
      colorMap: i
    } = e.setTheme(r),
    s = e.getLanguage(n.lang || "text");
  if (n.grammarState) {
    if (n.grammarState.lang !== s.name) throw new ge(`Grammar state language "${n.grammarState.lang}" does not match highlight language "${s.name}"`);
    if (!n.grammarState.themes.includes(a.name)) throw new ge(`Grammar state themes "${n.grammarState.themes}" do not contain highlight theme "${a.name}"`);
  }
  return qc(t, s, a, i, n);
}
function Oc(...e) {
  if (e.length === 2) return Kn(e[1]);
  const [t, n, r = {}] = e,
    {
      lang: a = "text",
      theme: i = t.getLoadedThemes()[0]
    } = r;
  if (ea(a) || ta(i)) throw new ge("Plain language does not have grammar state");
  if (a === "ansi") throw new ge("ANSI language does not have grammar state");
  const {
      theme: s,
      colorMap: o
    } = t.setTheme(i),
    l = t.getLanguage(a);
  return new aa(Vi(n, l, s, o, r).stateStack, l.name, s.name);
}
function qc(e, t, n, r, a) {
  const i = Vi(e, t, n, r, a),
    s = new aa(i.stateStack, t.name, n.name);
  return ra(i.tokens, s), i.tokens;
}
function Vi(e, t, n, r, a) {
  const i = Gr(n, a),
    {
      tokenizeMaxLineLength: s = 0,
      tokenizeTimeLimit: o = 500,
      includeExplanation: l = !1
    } = a,
    u = na(e);
  let c = a.grammarState ? Lc(a.grammarState, n.name) ?? ui : a.grammarContextCode != null ? Vi(a.grammarContextCode, t, n, r, {
      ...a,
      grammarState: void 0,
      grammarContextCode: void 0
    }).stateStack : ui,
    h = [];
  const f = [];
  for (let d = 0, b = u.length; d < b; d++) {
    const [k, A] = u[d];
    if (k === "") {
      h = [], f.push([]);
      continue;
    }
    if (s > 0 && k.length >= s) {
      h = [], f.push([{
        content: k,
        offset: A,
        color: "",
        fontStyle: 0
      }]);
      continue;
    }
    let w, _, T;
    l && l !== "tokenType" && (w = t.tokenizeLine(k, c, o), _ = w.tokens, T = 0);
    const I = t.tokenizeLine2(k, c, o),
      R = I.tokens.length / 2;
    for (let E = 0; E < R; E++) {
      const O = I.tokens[2 * E],
        W = E + 1 < R ? I.tokens[2 * E + 2] : k.length;
      if (O === W) continue;
      const G = I.tokens[2 * E + 1],
        M = Ht(r[cn.getForeground(G)], i),
        H = cn.getFontStyle(G),
        q = {
          content: k.substring(O, W),
          offset: A + O,
          color: M,
          fontStyle: H
        };
      if (l === "tokenType") q.type = cn.getTokenType(G);else if (l) {
        const ne = [];
        if (l !== "scopeName") for (const Y of n.settings) {
          let le;
          switch (typeof Y.scope) {
            case "string":
              le = Y.scope.split(Fc).map(me => me.trim());
              break;
            case "object":
              le = Y.scope;
              break;
            default:
              continue;
          }
          ne.push({
            settings: Y,
            selectors: le.map(me => me.split(Pc))
          });
        }
        q.explanation = [];
        let se = 0;
        for (; O + se < W;) {
          const Y = _[T],
            le = k.substring(Y.startIndex, Y.endIndex);
          se += le.length, q.explanation.push({
            content: le,
            scopes: l === "scopeName" ? jc(Y.scopes) : Gc(ne, Y.scopes)
          }), T += 1;
        }
      }
      h.push(q);
    }
    f.push(h), h = [], c = I.ruleStack;
  }
  return {
    tokens: f,
    stateStack: c
  };
}
function jc(e) {
  return e.map(t => ({
    scopeName: t
  }));
}
function Gc(e, t) {
  const n = [];
  for (let r = 0, a = t.length; r < a; r++) {
    const i = t[r];
    n[r] = {
      scopeName: i,
      themeMatches: Uc(e, i, t.slice(0, r))
    };
  }
  return n;
}
function Ns(e, t) {
  return e === t || t.substring(0, e.length) === e && t[e.length] === ".";
}
function Hc(e, t, n) {
  if (!Ns(e.at(-1), t)) return !1;
  let r = e.length - 2,
    a = n.length - 1;
  for (; r >= 0 && a >= 0;) Ns(e[r], n[a]) && (r -= 1), a -= 1;
  return r === -1;
}
function Uc(e, t, n) {
  const r = [];
  for (const {
    selectors: a,
    settings: i
  } of e) for (const s of a) if (Hc(s, t, n)) {
    r.push(i);
    break;
  }
  return r;
}
function Bl(e, t, n, r = Rl) {
  const a = Object.entries(n.themes).filter(u => u[1]).map(u => ({
      color: u[0],
      theme: u[1]
    })),
    i = a.map(u => {
      const c = r(e, t, {
        ...n,
        theme: u.theme
      });
      return {
        tokens: c,
        state: Kn(c),
        theme: typeof u.theme == "string" ? u.theme : u.theme.name
      };
    }),
    s = Wc(...i.map(u => u.tokens)),
    o = s[0].map((u, c) => u.map((h, f) => {
      const d = {
        content: h.content,
        variants: {},
        offset: h.offset
      };
      return "includeExplanation" in n && n.includeExplanation && (d.explanation = h.explanation), s.forEach((b, k) => {
        const {
          content: A,
          explanation: w,
          offset: _,
          ...T
        } = b[c][f];
        d.variants[a[k].color] = T;
      }), d;
    })),
    l = i[0].state ? new aa(Object.fromEntries(i.map(u => [u.theme, u.state?.getInternalStack(u.theme)])), i[0].state.lang) : void 0;
  return l && ra(o, l), o;
}
function Wc(...e) {
  const t = e.map(() => []),
    n = e.length;
  for (let r = 0; r < e[0].length; r++) {
    const a = e.map(l => l[r]),
      i = t.map(() => []);
    t.forEach((l, u) => l.push(i[u]));
    const s = a.map(() => 0),
      o = a.map(l => l[0]);
    for (; o.every(l => l);) {
      const l = Math.min(...o.map(u => u.content.length));
      for (let u = 0; u < n; u++) {
        const c = o[u];
        c.content.length === l ? (i[u].push(c), s[u] += 1, o[u] = a[u][s[u]]) : (i[u].push({
          ...c,
          content: c.content.slice(0, l)
        }), o[u] = {
          ...c,
          content: c.content.slice(l),
          offset: c.offset + l
        });
      }
    }
  }
  return t;
}
const Vc = ["area", "base", "basefont", "bgsound", "br", "col", "command", "embed", "frame", "hr", "image", "img", "input", "keygen", "link", "meta", "param", "source", "track", "wbr"];
class ir {
  constructor(t, n, r) {
    this.normal = n, this.property = t, r && (this.space = r);
  }
}
ir.prototype.normal = {};
ir.prototype.property = {};
ir.prototype.space = void 0;
function Dl(e, t) {
  const n = {},
    r = {};
  for (const a of e) Object.assign(n, a.property), Object.assign(r, a.normal);
  return new ir(n, r, t);
}
function ci(e) {
  return e.toLowerCase();
}
class Xe {
  constructor(t, n) {
    this.attribute = n, this.property = t;
  }
}
Xe.prototype.attribute = "";
Xe.prototype.booleanish = !1;
Xe.prototype.boolean = !1;
Xe.prototype.commaOrSpaceSeparated = !1;
Xe.prototype.commaSeparated = !1;
Xe.prototype.defined = !1;
Xe.prototype.mustUseProperty = !1;
Xe.prototype.number = !1;
Xe.prototype.overloadedBoolean = !1;
Xe.prototype.property = "";
Xe.prototype.spaceSeparated = !1;
Xe.prototype.space = void 0;
let Xc = 0;
const J = dn(),
  $e = dn(),
  mi = dn(),
  L = dn(),
  de = dn(),
  mn = dn(),
  Qe = dn();
function dn() {
  return 2 ** ++Xc;
}
const hi = Object.freeze(Object.defineProperty({
    __proto__: null,
    boolean: J,
    booleanish: $e,
    commaOrSpaceSeparated: Qe,
    commaSeparated: mn,
    number: L,
    overloadedBoolean: mi,
    spaceSeparated: de
  }, Symbol.toStringTag, {
    value: "Module"
  })),
  Aa = Object.keys(hi);
class Xi extends Xe {
  constructor(t, n, r, a) {
    let i = -1;
    if (super(t, n), Rs(this, "space", a), typeof r == "number") for (; ++i < Aa.length;) {
      const s = Aa[i];
      Rs(this, Aa[i], (r & hi[s]) === hi[s]);
    }
  }
}
Xi.prototype.defined = !0;
function Rs(e, t, n) {
  n && (e[t] = n);
}
function Mn(e) {
  const t = {},
    n = {};
  for (const [r, a] of Object.entries(e.properties)) {
    const i = new Xi(r, e.transform(e.attributes || {}, r), a, e.space);
    e.mustUseProperty && e.mustUseProperty.includes(r) && (i.mustUseProperty = !0), t[r] = i, n[ci(r)] = r, n[ci(i.attribute)] = r;
  }
  return new ir(t, n, e.space);
}
const Ll = Mn({
  properties: {
    ariaActiveDescendant: null,
    ariaAtomic: $e,
    ariaAutoComplete: null,
    ariaBusy: $e,
    ariaChecked: $e,
    ariaColCount: L,
    ariaColIndex: L,
    ariaColSpan: L,
    ariaControls: de,
    ariaCurrent: null,
    ariaDescribedBy: de,
    ariaDetails: null,
    ariaDisabled: $e,
    ariaDropEffect: de,
    ariaErrorMessage: null,
    ariaExpanded: $e,
    ariaFlowTo: de,
    ariaGrabbed: $e,
    ariaHasPopup: null,
    ariaHidden: $e,
    ariaInvalid: null,
    ariaKeyShortcuts: null,
    ariaLabel: null,
    ariaLabelledBy: de,
    ariaLevel: L,
    ariaLive: null,
    ariaModal: $e,
    ariaMultiLine: $e,
    ariaMultiSelectable: $e,
    ariaOrientation: null,
    ariaOwns: de,
    ariaPlaceholder: null,
    ariaPosInSet: L,
    ariaPressed: $e,
    ariaReadOnly: $e,
    ariaRelevant: null,
    ariaRequired: $e,
    ariaRoleDescription: de,
    ariaRowCount: L,
    ariaRowIndex: L,
    ariaRowSpan: L,
    ariaSelected: $e,
    ariaSetSize: L,
    ariaSort: null,
    ariaValueMax: L,
    ariaValueMin: L,
    ariaValueNow: L,
    ariaValueText: null,
    role: null
  },
  transform(e, t) {
    return t === "role" ? t : "aria-" + t.slice(4).toLowerCase();
  }
});
function Fl(e, t) {
  return t in e ? e[t] : t;
}
function Pl(e, t) {
  return Fl(e, t.toLowerCase());
}
const Yc = Mn({
    attributes: {
      acceptcharset: "accept-charset",
      classname: "class",
      htmlfor: "for",
      httpequiv: "http-equiv"
    },
    mustUseProperty: ["checked", "multiple", "muted", "selected"],
    properties: {
      abbr: null,
      accept: mn,
      acceptCharset: de,
      accessKey: de,
      action: null,
      allow: null,
      allowFullScreen: J,
      allowPaymentRequest: J,
      allowUserMedia: J,
      alpha: J,
      alt: null,
      as: null,
      async: J,
      autoCapitalize: null,
      autoComplete: de,
      autoFocus: J,
      autoPlay: J,
      blocking: de,
      capture: null,
      charSet: null,
      checked: J,
      cite: null,
      className: de,
      closedBy: null,
      colorSpace: null,
      cols: L,
      colSpan: L,
      command: null,
      commandFor: null,
      content: null,
      contentEditable: $e,
      controls: J,
      controlsList: de,
      coords: L | mn,
      crossOrigin: null,
      data: null,
      dateTime: null,
      decoding: null,
      default: J,
      defer: J,
      dir: null,
      dirName: null,
      disabled: J,
      download: mi,
      draggable: $e,
      encType: null,
      enterKeyHint: null,
      fetchPriority: null,
      form: null,
      formAction: null,
      formEncType: null,
      formMethod: null,
      formNoValidate: J,
      formTarget: null,
      headers: de,
      height: L,
      hidden: mi,
      high: L,
      href: null,
      hrefLang: null,
      htmlFor: de,
      httpEquiv: de,
      id: null,
      imageSizes: null,
      imageSrcSet: null,
      inert: J,
      inputMode: null,
      integrity: null,
      is: null,
      isMap: J,
      itemId: null,
      itemProp: de,
      itemRef: de,
      itemScope: J,
      itemType: de,
      kind: null,
      label: null,
      lang: null,
      language: null,
      list: null,
      loading: null,
      loop: J,
      low: L,
      manifest: null,
      max: null,
      maxLength: L,
      media: null,
      method: null,
      min: null,
      minLength: L,
      multiple: J,
      muted: J,
      name: null,
      nonce: null,
      noModule: J,
      noValidate: J,
      onAbort: null,
      onAfterPrint: null,
      onAuxClick: null,
      onBeforeMatch: null,
      onBeforePrint: null,
      onBeforeToggle: null,
      onBeforeUnload: null,
      onBlur: null,
      onCancel: null,
      onCanPlay: null,
      onCanPlayThrough: null,
      onChange: null,
      onClick: null,
      onClose: null,
      onContextLost: null,
      onContextMenu: null,
      onContextRestored: null,
      onCopy: null,
      onCueChange: null,
      onCut: null,
      onDblClick: null,
      onDrag: null,
      onDragEnd: null,
      onDragEnter: null,
      onDragExit: null,
      onDragLeave: null,
      onDragOver: null,
      onDragStart: null,
      onDrop: null,
      onDurationChange: null,
      onEmptied: null,
      onEnded: null,
      onError: null,
      onFocus: null,
      onFormData: null,
      onHashChange: null,
      onInput: null,
      onInvalid: null,
      onKeyDown: null,
      onKeyPress: null,
      onKeyUp: null,
      onLanguageChange: null,
      onLoad: null,
      onLoadedData: null,
      onLoadedMetadata: null,
      onLoadEnd: null,
      onLoadStart: null,
      onMessage: null,
      onMessageError: null,
      onMouseDown: null,
      onMouseEnter: null,
      onMouseLeave: null,
      onMouseMove: null,
      onMouseOut: null,
      onMouseOver: null,
      onMouseUp: null,
      onOffline: null,
      onOnline: null,
      onPageHide: null,
      onPageShow: null,
      onPaste: null,
      onPause: null,
      onPlay: null,
      onPlaying: null,
      onPopState: null,
      onProgress: null,
      onRateChange: null,
      onRejectionHandled: null,
      onReset: null,
      onResize: null,
      onScroll: null,
      onScrollEnd: null,
      onSecurityPolicyViolation: null,
      onSeeked: null,
      onSeeking: null,
      onSelect: null,
      onSlotChange: null,
      onStalled: null,
      onStorage: null,
      onSubmit: null,
      onSuspend: null,
      onTimeUpdate: null,
      onToggle: null,
      onUnhandledRejection: null,
      onUnload: null,
      onVolumeChange: null,
      onWaiting: null,
      onWheel: null,
      open: J,
      optimum: L,
      pattern: null,
      ping: de,
      placeholder: null,
      playsInline: J,
      popover: null,
      popoverTarget: null,
      popoverTargetAction: null,
      poster: null,
      preload: null,
      readOnly: J,
      referrerPolicy: null,
      rel: de,
      required: J,
      reversed: J,
      rows: L,
      rowSpan: L,
      sandbox: de,
      scope: null,
      scoped: J,
      seamless: J,
      selected: J,
      shadowRootClonable: J,
      shadowRootCustomElementRegistry: J,
      shadowRootDelegatesFocus: J,
      shadowRootMode: null,
      shadowRootSerializable: J,
      shape: null,
      size: L,
      sizes: null,
      slot: null,
      span: L,
      spellCheck: $e,
      src: null,
      srcDoc: null,
      srcLang: null,
      srcSet: null,
      start: L,
      step: null,
      style: null,
      tabIndex: L,
      target: null,
      title: null,
      translate: null,
      type: null,
      typeMustMatch: J,
      useMap: null,
      value: $e,
      width: L,
      wrap: null,
      writingSuggestions: null,
      align: null,
      aLink: null,
      archive: de,
      axis: null,
      background: null,
      bgColor: null,
      border: L,
      borderColor: null,
      bottomMargin: L,
      cellPadding: null,
      cellSpacing: null,
      char: null,
      charOff: null,
      classId: null,
      clear: null,
      code: null,
      codeBase: null,
      codeType: null,
      color: null,
      compact: J,
      declare: J,
      event: null,
      face: null,
      frame: null,
      frameBorder: null,
      hSpace: L,
      leftMargin: L,
      link: null,
      longDesc: null,
      lowSrc: null,
      marginHeight: L,
      marginWidth: L,
      noResize: J,
      noHref: J,
      noShade: J,
      noWrap: J,
      object: null,
      profile: null,
      prompt: null,
      rev: null,
      rightMargin: L,
      rules: null,
      scheme: null,
      scrolling: $e,
      standby: null,
      summary: null,
      text: null,
      topMargin: L,
      valueType: null,
      version: null,
      vAlign: null,
      vLink: null,
      vSpace: L,
      allowTransparency: null,
      autoCorrect: null,
      autoSave: null,
      credentialless: J,
      disablePictureInPicture: J,
      disableRemotePlayback: J,
      exportParts: mn,
      part: de,
      prefix: null,
      property: null,
      results: L,
      security: null,
      unselectable: null
    },
    space: "html",
    transform: Pl
  }),
  Zc = Mn({
    attributes: {
      accentHeight: "accent-height",
      alignmentBaseline: "alignment-baseline",
      arabicForm: "arabic-form",
      baselineShift: "baseline-shift",
      capHeight: "cap-height",
      className: "class",
      clipPath: "clip-path",
      clipRule: "clip-rule",
      colorInterpolation: "color-interpolation",
      colorInterpolationFilters: "color-interpolation-filters",
      colorProfile: "color-profile",
      colorRendering: "color-rendering",
      crossOrigin: "crossorigin",
      dataType: "datatype",
      dominantBaseline: "dominant-baseline",
      enableBackground: "enable-background",
      fillOpacity: "fill-opacity",
      fillRule: "fill-rule",
      floodColor: "flood-color",
      floodOpacity: "flood-opacity",
      fontFamily: "font-family",
      fontSize: "font-size",
      fontSizeAdjust: "font-size-adjust",
      fontStretch: "font-stretch",
      fontStyle: "font-style",
      fontVariant: "font-variant",
      fontWeight: "font-weight",
      glyphName: "glyph-name",
      glyphOrientationHorizontal: "glyph-orientation-horizontal",
      glyphOrientationVertical: "glyph-orientation-vertical",
      hrefLang: "hreflang",
      horizAdvX: "horiz-adv-x",
      horizOriginX: "horiz-origin-x",
      horizOriginY: "horiz-origin-y",
      imageRendering: "image-rendering",
      letterSpacing: "letter-spacing",
      lightingColor: "lighting-color",
      markerEnd: "marker-end",
      markerMid: "marker-mid",
      markerStart: "marker-start",
      maskType: "mask-type",
      navDown: "nav-down",
      navDownLeft: "nav-down-left",
      navDownRight: "nav-down-right",
      navLeft: "nav-left",
      navNext: "nav-next",
      navPrev: "nav-prev",
      navRight: "nav-right",
      navUp: "nav-up",
      navUpLeft: "nav-up-left",
      navUpRight: "nav-up-right",
      onAbort: "onabort",
      onActivate: "onactivate",
      onAfterPrint: "onafterprint",
      onBeforePrint: "onbeforeprint",
      onBegin: "onbegin",
      onCancel: "oncancel",
      onCanPlay: "oncanplay",
      onCanPlayThrough: "oncanplaythrough",
      onChange: "onchange",
      onClick: "onclick",
      onClose: "onclose",
      onCopy: "oncopy",
      onCueChange: "oncuechange",
      onCut: "oncut",
      onDblClick: "ondblclick",
      onDrag: "ondrag",
      onDragEnd: "ondragend",
      onDragEnter: "ondragenter",
      onDragExit: "ondragexit",
      onDragLeave: "ondragleave",
      onDragOver: "ondragover",
      onDragStart: "ondragstart",
      onDrop: "ondrop",
      onDurationChange: "ondurationchange",
      onEmptied: "onemptied",
      onEnd: "onend",
      onEnded: "onended",
      onError: "onerror",
      onFocus: "onfocus",
      onFocusIn: "onfocusin",
      onFocusOut: "onfocusout",
      onHashChange: "onhashchange",
      onInput: "oninput",
      onInvalid: "oninvalid",
      onKeyDown: "onkeydown",
      onKeyPress: "onkeypress",
      onKeyUp: "onkeyup",
      onLoad: "onload",
      onLoadedData: "onloadeddata",
      onLoadedMetadata: "onloadedmetadata",
      onLoadStart: "onloadstart",
      onMessage: "onmessage",
      onMouseDown: "onmousedown",
      onMouseEnter: "onmouseenter",
      onMouseLeave: "onmouseleave",
      onMouseMove: "onmousemove",
      onMouseOut: "onmouseout",
      onMouseOver: "onmouseover",
      onMouseUp: "onmouseup",
      onMouseWheel: "onmousewheel",
      onOffline: "onoffline",
      onOnline: "ononline",
      onPageHide: "onpagehide",
      onPageShow: "onpageshow",
      onPaste: "onpaste",
      onPause: "onpause",
      onPlay: "onplay",
      onPlaying: "onplaying",
      onPopState: "onpopstate",
      onProgress: "onprogress",
      onRateChange: "onratechange",
      onRepeat: "onrepeat",
      onReset: "onreset",
      onResize: "onresize",
      onScroll: "onscroll",
      onSeeked: "onseeked",
      onSeeking: "onseeking",
      onSelect: "onselect",
      onShow: "onshow",
      onStalled: "onstalled",
      onStorage: "onstorage",
      onSubmit: "onsubmit",
      onSuspend: "onsuspend",
      onTimeUpdate: "ontimeupdate",
      onToggle: "ontoggle",
      onUnload: "onunload",
      onVolumeChange: "onvolumechange",
      onWaiting: "onwaiting",
      onZoom: "onzoom",
      overlinePosition: "overline-position",
      overlineThickness: "overline-thickness",
      paintOrder: "paint-order",
      panose1: "panose-1",
      pointerEvents: "pointer-events",
      referrerPolicy: "referrerpolicy",
      renderingIntent: "rendering-intent",
      shapeRendering: "shape-rendering",
      stopColor: "stop-color",
      stopOpacity: "stop-opacity",
      strikethroughPosition: "strikethrough-position",
      strikethroughThickness: "strikethrough-thickness",
      strokeDashArray: "stroke-dasharray",
      strokeDashOffset: "stroke-dashoffset",
      strokeLineCap: "stroke-linecap",
      strokeLineJoin: "stroke-linejoin",
      strokeMiterLimit: "stroke-miterlimit",
      strokeOpacity: "stroke-opacity",
      strokeWidth: "stroke-width",
      tabIndex: "tabindex",
      textAnchor: "text-anchor",
      textDecoration: "text-decoration",
      textRendering: "text-rendering",
      transformOrigin: "transform-origin",
      typeOf: "typeof",
      underlinePosition: "underline-position",
      underlineThickness: "underline-thickness",
      unicodeBidi: "unicode-bidi",
      unicodeRange: "unicode-range",
      unitsPerEm: "units-per-em",
      vAlphabetic: "v-alphabetic",
      vHanging: "v-hanging",
      vIdeographic: "v-ideographic",
      vMathematical: "v-mathematical",
      vectorEffect: "vector-effect",
      vertAdvY: "vert-adv-y",
      vertOriginX: "vert-origin-x",
      vertOriginY: "vert-origin-y",
      wordSpacing: "word-spacing",
      writingMode: "writing-mode",
      xHeight: "x-height",
      playbackOrder: "playbackorder",
      timelineBegin: "timelinebegin"
    },
    properties: {
      about: Qe,
      accentHeight: L,
      accumulate: null,
      additive: null,
      alignmentBaseline: null,
      alphabetic: L,
      amplitude: L,
      arabicForm: null,
      ascent: L,
      attributeName: null,
      attributeType: null,
      azimuth: L,
      bandwidth: null,
      baselineShift: null,
      baseFrequency: null,
      baseProfile: null,
      bbox: null,
      begin: null,
      bias: L,
      by: null,
      calcMode: null,
      capHeight: L,
      className: de,
      clip: null,
      clipPath: null,
      clipPathUnits: null,
      clipRule: null,
      color: null,
      colorInterpolation: null,
      colorInterpolationFilters: null,
      colorProfile: null,
      colorRendering: null,
      content: null,
      contentScriptType: null,
      contentStyleType: null,
      crossOrigin: null,
      cursor: null,
      cx: null,
      cy: null,
      d: null,
      dataType: null,
      defaultAction: null,
      descent: L,
      diffuseConstant: L,
      direction: null,
      display: null,
      dur: null,
      divisor: L,
      dominantBaseline: null,
      download: J,
      dx: null,
      dy: null,
      edgeMode: null,
      editable: null,
      elevation: L,
      enableBackground: null,
      end: null,
      event: null,
      exponent: L,
      externalResourcesRequired: null,
      fill: null,
      fillOpacity: L,
      fillRule: null,
      filter: null,
      filterRes: null,
      filterUnits: null,
      floodColor: null,
      floodOpacity: null,
      focusable: null,
      focusHighlight: null,
      fontFamily: null,
      fontSize: null,
      fontSizeAdjust: null,
      fontStretch: null,
      fontStyle: null,
      fontVariant: null,
      fontWeight: null,
      format: null,
      fr: null,
      from: null,
      fx: null,
      fy: null,
      g1: mn,
      g2: mn,
      glyphName: mn,
      glyphOrientationHorizontal: null,
      glyphOrientationVertical: null,
      glyphRef: null,
      gradientTransform: null,
      gradientUnits: null,
      handler: null,
      hanging: L,
      hatchContentUnits: null,
      hatchUnits: null,
      height: null,
      href: null,
      hrefLang: null,
      horizAdvX: L,
      horizOriginX: L,
      horizOriginY: L,
      id: null,
      ideographic: L,
      imageRendering: null,
      initialVisibility: null,
      in: null,
      in2: null,
      intercept: L,
      k: L,
      k1: L,
      k2: L,
      k3: L,
      k4: L,
      kernelMatrix: Qe,
      kernelUnitLength: null,
      keyPoints: null,
      keySplines: null,
      keyTimes: null,
      kerning: null,
      lang: null,
      lengthAdjust: null,
      letterSpacing: null,
      lightingColor: null,
      limitingConeAngle: L,
      local: null,
      markerEnd: null,
      markerMid: null,
      markerStart: null,
      markerHeight: null,
      markerUnits: null,
      markerWidth: null,
      mask: null,
      maskContentUnits: null,
      maskType: null,
      maskUnits: null,
      mathematical: null,
      max: null,
      media: null,
      mediaCharacterEncoding: null,
      mediaContentEncodings: null,
      mediaSize: L,
      mediaTime: null,
      method: null,
      min: null,
      mode: null,
      name: null,
      navDown: null,
      navDownLeft: null,
      navDownRight: null,
      navLeft: null,
      navNext: null,
      navPrev: null,
      navRight: null,
      navUp: null,
      navUpLeft: null,
      navUpRight: null,
      numOctaves: null,
      observer: null,
      offset: null,
      onAbort: null,
      onActivate: null,
      onAfterPrint: null,
      onBeforePrint: null,
      onBegin: null,
      onCancel: null,
      onCanPlay: null,
      onCanPlayThrough: null,
      onChange: null,
      onClick: null,
      onClose: null,
      onCopy: null,
      onCueChange: null,
      onCut: null,
      onDblClick: null,
      onDrag: null,
      onDragEnd: null,
      onDragEnter: null,
      onDragExit: null,
      onDragLeave: null,
      onDragOver: null,
      onDragStart: null,
      onDrop: null,
      onDurationChange: null,
      onEmptied: null,
      onEnd: null,
      onEnded: null,
      onError: null,
      onFocus: null,
      onFocusIn: null,
      onFocusOut: null,
      onHashChange: null,
      onInput: null,
      onInvalid: null,
      onKeyDown: null,
      onKeyPress: null,
      onKeyUp: null,
      onLoad: null,
      onLoadedData: null,
      onLoadedMetadata: null,
      onLoadStart: null,
      onMessage: null,
      onMouseDown: null,
      onMouseEnter: null,
      onMouseLeave: null,
      onMouseMove: null,
      onMouseOut: null,
      onMouseOver: null,
      onMouseUp: null,
      onMouseWheel: null,
      onOffline: null,
      onOnline: null,
      onPageHide: null,
      onPageShow: null,
      onPaste: null,
      onPause: null,
      onPlay: null,
      onPlaying: null,
      onPopState: null,
      onProgress: null,
      onRateChange: null,
      onRepeat: null,
      onReset: null,
      onResize: null,
      onScroll: null,
      onSeeked: null,
      onSeeking: null,
      onSelect: null,
      onShow: null,
      onStalled: null,
      onStorage: null,
      onSubmit: null,
      onSuspend: null,
      onTimeUpdate: null,
      onToggle: null,
      onUnload: null,
      onVolumeChange: null,
      onWaiting: null,
      onZoom: null,
      opacity: null,
      operator: null,
      order: null,
      orient: null,
      orientation: null,
      origin: null,
      overflow: null,
      overlay: null,
      overlinePosition: L,
      overlineThickness: L,
      paintOrder: null,
      panose1: null,
      path: null,
      pathLength: L,
      patternContentUnits: null,
      patternTransform: null,
      patternUnits: null,
      phase: null,
      ping: de,
      pitch: null,
      playbackOrder: null,
      pointerEvents: null,
      points: null,
      pointsAtX: L,
      pointsAtY: L,
      pointsAtZ: L,
      preserveAlpha: null,
      preserveAspectRatio: null,
      primitiveUnits: null,
      propagate: null,
      property: Qe,
      r: null,
      radius: null,
      referrerPolicy: null,
      refX: null,
      refY: null,
      rel: Qe,
      rev: Qe,
      renderingIntent: null,
      repeatCount: null,
      repeatDur: null,
      requiredExtensions: Qe,
      requiredFeatures: Qe,
      requiredFonts: Qe,
      requiredFormats: Qe,
      resource: null,
      restart: null,
      result: null,
      rotate: null,
      rx: null,
      ry: null,
      scale: null,
      seed: null,
      shapeRendering: null,
      side: null,
      slope: null,
      snapshotTime: null,
      specularConstant: L,
      specularExponent: L,
      spreadMethod: null,
      spacing: null,
      startOffset: null,
      stdDeviation: null,
      stemh: null,
      stemv: null,
      stitchTiles: null,
      stopColor: null,
      stopOpacity: null,
      strikethroughPosition: L,
      strikethroughThickness: L,
      string: null,
      stroke: null,
      strokeDashArray: Qe,
      strokeDashOffset: null,
      strokeLineCap: null,
      strokeLineJoin: null,
      strokeMiterLimit: L,
      strokeOpacity: L,
      strokeWidth: null,
      style: null,
      surfaceScale: L,
      syncBehavior: null,
      syncBehaviorDefault: null,
      syncMaster: null,
      syncTolerance: null,
      syncToleranceDefault: null,
      systemLanguage: Qe,
      tabIndex: L,
      tableValues: null,
      target: null,
      targetX: L,
      targetY: L,
      textAnchor: null,
      textDecoration: null,
      textRendering: null,
      textLength: null,
      timelineBegin: null,
      title: null,
      transformBehavior: null,
      type: null,
      typeOf: Qe,
      to: null,
      transform: null,
      transformOrigin: null,
      u1: null,
      u2: null,
      underlinePosition: L,
      underlineThickness: L,
      unicode: null,
      unicodeBidi: null,
      unicodeRange: null,
      unitsPerEm: L,
      values: null,
      vAlphabetic: L,
      vMathematical: L,
      vectorEffect: null,
      vHanging: L,
      vIdeographic: L,
      version: null,
      vertAdvY: L,
      vertOriginX: L,
      vertOriginY: L,
      viewBox: null,
      viewTarget: null,
      visibility: null,
      width: null,
      widths: null,
      wordSpacing: null,
      writingMode: null,
      x: null,
      x1: null,
      x2: null,
      xChannelSelector: null,
      xHeight: L,
      y: null,
      y1: null,
      y2: null,
      yChannelSelector: null,
      z: null,
      zoomAndPan: null
    },
    space: "svg",
    transform: Fl
  }),
  Ol = Mn({
    properties: {
      xLinkActuate: null,
      xLinkArcRole: null,
      xLinkHref: null,
      xLinkRole: null,
      xLinkShow: null,
      xLinkTitle: null,
      xLinkType: null
    },
    space: "xlink",
    transform(e, t) {
      return "xlink:" + t.slice(5).toLowerCase();
    }
  }),
  ql = Mn({
    attributes: {
      xmlnsxlink: "xmlns:xlink"
    },
    properties: {
      xmlnsXLink: null,
      xmlns: null
    },
    space: "xmlns",
    transform: Pl
  }),
  jl = Mn({
    properties: {
      xmlBase: null,
      xmlLang: null,
      xmlSpace: null
    },
    space: "xml",
    transform(e, t) {
      return "xml:" + t.slice(3).toLowerCase();
    }
  }),
  Kc = /[A-Z]/g,
  Bs = /-[a-z]/g,
  Qc = /^data[-\w.:]+$/i;
function Jc(e, t) {
  const n = ci(t);
  let r = t,
    a = Xe;
  if (n in e.normal) return e.property[e.normal[n]];
  if (n.length > 4 && n.slice(0, 4) === "data" && Qc.test(t)) {
    if (t.charAt(4) === "-") {
      const i = t.slice(5).replace(Bs, tm);
      r = "data" + i.charAt(0).toUpperCase() + i.slice(1);
    } else {
      const i = t.slice(4);
      if (!Bs.test(i)) {
        let s = i.replace(Kc, em);
        s.charAt(0) !== "-" && (s = "-" + s), t = "data" + s;
      }
    }
    a = Xi;
  }
  return new a(r, t);
}
function em(e) {
  return "-" + e.toLowerCase();
}
function tm(e) {
  return e.charAt(1).toUpperCase();
}
const nm = Dl([Ll, Yc, Ol, ql, jl], "html"),
  Gl = Dl([Ll, Zc, Ol, ql, jl], "svg"),
  Ds = {}.hasOwnProperty;
function rm(e, t) {
  const n = t || {};
  function r(a, ...i) {
    let s = r.invalid;
    const o = r.handlers;
    if (a && Ds.call(a, e)) {
      const l = String(a[e]);
      s = Ds.call(o, l) ? o[l] : r.unknown;
    }
    if (s) return s.call(this, a, ...i);
  }
  return r.handlers = n.handlers || {}, r.invalid = n.invalid, r.unknown = n.unknown, r;
}
const am = /["&'<>`]/g,
  im = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g,
  sm = /[\x01-\t\v\f\x0E-\x1F\x7F\x81\x8D\x8F\x90\x9D\xA0-\uFFFF]/g,
  om = /[|\\{}()[\]^$+*?.]/g,
  Ls = new WeakMap();
function lm(e, t) {
  if (e = e.replace(t.subset ? um(t.subset) : am, r), t.subset || t.escapeOnly) return e;
  return e.replace(im, n).replace(sm, r);
  function n(a, i, s) {
    return t.format((a.charCodeAt(0) - 55296) * 1024 + a.charCodeAt(1) - 56320 + 65536, s.charCodeAt(i + 2), t);
  }
  function r(a, i, s) {
    return t.format(a.charCodeAt(0), s.charCodeAt(i + 1), t);
  }
}
function um(e) {
  let t = Ls.get(e);
  return t || (t = cm(e), Ls.set(e, t)), t;
}
function cm(e) {
  const t = [];
  let n = -1;
  for (; ++n < e.length;) t.push(e[n].replace(om, "\\$&"));
  return new RegExp("(?:" + t.join("|") + ")", "g");
}
const mm = /[\dA-Fa-f]/;
function hm(e, t, n) {
  const r = "&#x" + e.toString(16).toUpperCase();
  return n && t && !mm.test(String.fromCharCode(t)) ? r : r + ";";
}
const pm = /\d/;
function dm(e, t, n) {
  const r = "&#" + String(e);
  return n && t && !pm.test(String.fromCharCode(t)) ? r : r + ";";
}
const fm = ["AElig", "AMP", "Aacute", "Acirc", "Agrave", "Aring", "Atilde", "Auml", "COPY", "Ccedil", "ETH", "Eacute", "Ecirc", "Egrave", "Euml", "GT", "Iacute", "Icirc", "Igrave", "Iuml", "LT", "Ntilde", "Oacute", "Ocirc", "Ograve", "Oslash", "Otilde", "Ouml", "QUOT", "REG", "THORN", "Uacute", "Ucirc", "Ugrave", "Uuml", "Yacute", "aacute", "acirc", "acute", "aelig", "agrave", "amp", "aring", "atilde", "auml", "brvbar", "ccedil", "cedil", "cent", "copy", "curren", "deg", "divide", "eacute", "ecirc", "egrave", "eth", "euml", "frac12", "frac14", "frac34", "gt", "iacute", "icirc", "iexcl", "igrave", "iquest", "iuml", "laquo", "lt", "macr", "micro", "middot", "nbsp", "not", "ntilde", "oacute", "ocirc", "ograve", "ordf", "ordm", "oslash", "otilde", "ouml", "para", "plusmn", "pound", "quot", "raquo", "reg", "sect", "shy", "sup1", "sup2", "sup3", "szlig", "thorn", "times", "uacute", "ucirc", "ugrave", "uml", "uuml", "yacute", "yen", "yuml"],
  Ta = {
    nbsp: " ",
    iexcl: "¡",
    cent: "¢",
    pound: "£",
    curren: "¤",
    yen: "¥",
    brvbar: "¦",
    sect: "§",
    uml: "¨",
    copy: "©",
    ordf: "ª",
    laquo: "«",
    not: "¬",
    shy: "­",
    reg: "®",
    macr: "¯",
    deg: "°",
    plusmn: "±",
    sup2: "²",
    sup3: "³",
    acute: "´",
    micro: "µ",
    para: "¶",
    middot: "·",
    cedil: "¸",
    sup1: "¹",
    ordm: "º",
    raquo: "»",
    frac14: "¼",
    frac12: "½",
    frac34: "¾",
    iquest: "¿",
    Agrave: "À",
    Aacute: "Á",
    Acirc: "Â",
    Atilde: "Ã",
    Auml: "Ä",
    Aring: "Å",
    AElig: "Æ",
    Ccedil: "Ç",
    Egrave: "È",
    Eacute: "É",
    Ecirc: "Ê",
    Euml: "Ë",
    Igrave: "Ì",
    Iacute: "Í",
    Icirc: "Î",
    Iuml: "Ï",
    ETH: "Ð",
    Ntilde: "Ñ",
    Ograve: "Ò",
    Oacute: "Ó",
    Ocirc: "Ô",
    Otilde: "Õ",
    Ouml: "Ö",
    times: "×",
    Oslash: "Ø",
    Ugrave: "Ù",
    Uacute: "Ú",
    Ucirc: "Û",
    Uuml: "Ü",
    Yacute: "Ý",
    THORN: "Þ",
    szlig: "ß",
    agrave: "à",
    aacute: "á",
    acirc: "â",
    atilde: "ã",
    auml: "ä",
    aring: "å",
    aelig: "æ",
    ccedil: "ç",
    egrave: "è",
    eacute: "é",
    ecirc: "ê",
    euml: "ë",
    igrave: "ì",
    iacute: "í",
    icirc: "î",
    iuml: "ï",
    eth: "ð",
    ntilde: "ñ",
    ograve: "ò",
    oacute: "ó",
    ocirc: "ô",
    otilde: "õ",
    ouml: "ö",
    divide: "÷",
    oslash: "ø",
    ugrave: "ù",
    uacute: "ú",
    ucirc: "û",
    uuml: "ü",
    yacute: "ý",
    thorn: "þ",
    yuml: "ÿ",
    fnof: "ƒ",
    Alpha: "Α",
    Beta: "Β",
    Gamma: "Γ",
    Delta: "Δ",
    Epsilon: "Ε",
    Zeta: "Ζ",
    Eta: "Η",
    Theta: "Θ",
    Iota: "Ι",
    Kappa: "Κ",
    Lambda: "Λ",
    Mu: "Μ",
    Nu: "Ν",
    Xi: "Ξ",
    Omicron: "Ο",
    Pi: "Π",
    Rho: "Ρ",
    Sigma: "Σ",
    Tau: "Τ",
    Upsilon: "Υ",
    Phi: "Φ",
    Chi: "Χ",
    Psi: "Ψ",
    Omega: "Ω",
    alpha: "α",
    beta: "β",
    gamma: "γ",
    delta: "δ",
    epsilon: "ε",
    zeta: "ζ",
    eta: "η",
    theta: "θ",
    iota: "ι",
    kappa: "κ",
    lambda: "λ",
    mu: "μ",
    nu: "ν",
    xi: "ξ",
    omicron: "ο",
    pi: "π",
    rho: "ρ",
    sigmaf: "ς",
    sigma: "σ",
    tau: "τ",
    upsilon: "υ",
    phi: "φ",
    chi: "χ",
    psi: "ψ",
    omega: "ω",
    thetasym: "ϑ",
    upsih: "ϒ",
    piv: "ϖ",
    bull: "•",
    hellip: "…",
    prime: "′",
    Prime: "″",
    oline: "‾",
    frasl: "⁄",
    weierp: "℘",
    image: "ℑ",
    real: "ℜ",
    trade: "™",
    alefsym: "ℵ",
    larr: "←",
    uarr: "↑",
    rarr: "→",
    darr: "↓",
    harr: "↔",
    crarr: "↵",
    lArr: "⇐",
    uArr: "⇑",
    rArr: "⇒",
    dArr: "⇓",
    hArr: "⇔",
    forall: "∀",
    part: "∂",
    exist: "∃",
    empty: "∅",
    nabla: "∇",
    isin: "∈",
    notin: "∉",
    ni: "∋",
    prod: "∏",
    sum: "∑",
    minus: "−",
    lowast: "∗",
    radic: "√",
    prop: "∝",
    infin: "∞",
    ang: "∠",
    and: "∧",
    or: "∨",
    cap: "∩",
    cup: "∪",
    int: "∫",
    there4: "∴",
    sim: "∼",
    cong: "≅",
    asymp: "≈",
    ne: "≠",
    equiv: "≡",
    le: "≤",
    ge: "≥",
    sub: "⊂",
    sup: "⊃",
    nsub: "⊄",
    sube: "⊆",
    supe: "⊇",
    oplus: "⊕",
    otimes: "⊗",
    perp: "⊥",
    sdot: "⋅",
    lceil: "⌈",
    rceil: "⌉",
    lfloor: "⌊",
    rfloor: "⌋",
    lang: "〈",
    rang: "〉",
    loz: "◊",
    spades: "♠",
    clubs: "♣",
    hearts: "♥",
    diams: "♦",
    quot: '"',
    amp: "&",
    lt: "<",
    gt: ">",
    OElig: "Œ",
    oelig: "œ",
    Scaron: "Š",
    scaron: "š",
    Yuml: "Ÿ",
    circ: "ˆ",
    tilde: "˜",
    ensp: " ",
    emsp: " ",
    thinsp: " ",
    zwnj: "‌",
    zwj: "‍",
    lrm: "‎",
    rlm: "‏",
    ndash: "–",
    mdash: "—",
    lsquo: "‘",
    rsquo: "’",
    sbquo: "‚",
    ldquo: "“",
    rdquo: "”",
    bdquo: "„",
    dagger: "†",
    Dagger: "‡",
    permil: "‰",
    lsaquo: "‹",
    rsaquo: "›",
    euro: "€"
  },
  gm = ["cent", "copy", "divide", "gt", "lt", "not", "para", "times"],
  Hl = {}.hasOwnProperty,
  pi = {};
let yr;
for (yr in Ta) Hl.call(Ta, yr) && (pi[Ta[yr]] = yr);
const bm = /[^\dA-Za-z]/;
function ym(e, t, n, r) {
  const a = String.fromCharCode(e);
  if (Hl.call(pi, a)) {
    const i = pi[a],
      s = "&" + i;
    return n && fm.includes(i) && !gm.includes(i) && (!r || t && t !== 61 && bm.test(String.fromCharCode(t))) ? s : s + ";";
  }
  return "";
}
function vm(e, t, n) {
  let r = hm(e, t, n.omitOptionalSemicolons),
    a;
  if ((n.useNamedReferences || n.useShortestReferences) && (a = ym(e, t, n.omitOptionalSemicolons, n.attribute)), (n.useShortestReferences || !a) && n.useShortestReferences) {
    const i = dm(e, t, n.omitOptionalSemicolons);
    i.length < r.length && (r = i);
  }
  return a && (!n.useShortestReferences || a.length < r.length) ? a : r;
}
function Cn(e, t) {
  return lm(e, Object.assign({
    format: vm
  }, t));
}
const wm = /^>|^->|<!--|-->|--!>|<!-$/g,
  xm = [">"],
  km = ["<", ">"];
function _m(e, t, n, r) {
  return r.settings.bogusComments ? "<?" + Cn(e.value, Object.assign({}, r.settings.characterReferences, {
    subset: xm
  })) + ">" : "<!--" + e.value.replace(wm, a) + "-->";
  function a(i) {
    return Cn(i, Object.assign({}, r.settings.characterReferences, {
      subset: km
    }));
  }
}
function $m(e, t, n, r) {
  return "<!" + (r.settings.upperDoctype ? "DOCTYPE" : "doctype") + (r.settings.tightDoctype ? "" : " ") + "html>";
}
function Hr(e, t) {
  const n = String(e);
  if (typeof t != "string") throw new TypeError("Expected character");
  let r = 0,
    a = n.indexOf(t);
  for (; a !== -1;) r++, a = n.indexOf(t, a + t.length);
  return r;
}
function Cm(e, t) {
  const n = t || {};
  return (e[e.length - 1] === "" ? [...e, ""] : e).join((n.padRight ? " " : "") + "," + (n.padLeft === !1 ? "" : " ")).trim();
}
function Sm(e) {
  return e.join(" ").trim();
}
const Am = /[ \t\n\f\r]/g;
function Yi(e) {
  return typeof e == "object" ? e.type === "text" ? Fs(e.value) : !1 : Fs(e);
}
function Fs(e) {
  return e.replace(Am, "") === "";
}
const Ie = Wl(1),
  Ul = Wl(-1),
  Tm = [];
function Wl(e) {
  return t;
  function t(n, r, a) {
    const i = n ? n.children : Tm;
    let s = (r || 0) + e,
      o = i[s];
    if (!a) for (; o && Yi(o);) s += e, o = i[s];
    return o;
  }
}
const Em = {}.hasOwnProperty;
function Vl(e) {
  return t;
  function t(n, r, a) {
    return Em.call(e, n.tagName) && e[n.tagName](n, r, a);
  }
}
const Zi = Vl({
  body: zm,
  caption: Ea,
  colgroup: Ea,
  dd: Bm,
  dt: Rm,
  head: Ea,
  html: Mm,
  li: Nm,
  optgroup: Dm,
  option: Lm,
  p: Im,
  rp: Ps,
  rt: Ps,
  tbody: Pm,
  td: Os,
  tfoot: Om,
  th: Os,
  thead: Fm,
  tr: qm
});
function Ea(e, t, n) {
  const r = Ie(n, t, !0);
  return !r || r.type !== "comment" && !(r.type === "text" && Yi(r.value.charAt(0)));
}
function Mm(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type !== "comment";
}
function zm(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type !== "comment";
}
function Im(e, t, n) {
  const r = Ie(n, t);
  return r ? r.type === "element" && (r.tagName === "address" || r.tagName === "article" || r.tagName === "aside" || r.tagName === "blockquote" || r.tagName === "details" || r.tagName === "div" || r.tagName === "dl" || r.tagName === "fieldset" || r.tagName === "figcaption" || r.tagName === "figure" || r.tagName === "footer" || r.tagName === "form" || r.tagName === "h1" || r.tagName === "h2" || r.tagName === "h3" || r.tagName === "h4" || r.tagName === "h5" || r.tagName === "h6" || r.tagName === "header" || r.tagName === "hgroup" || r.tagName === "hr" || r.tagName === "main" || r.tagName === "menu" || r.tagName === "nav" || r.tagName === "ol" || r.tagName === "p" || r.tagName === "pre" || r.tagName === "section" || r.tagName === "table" || r.tagName === "ul") : !n || !(n.type === "element" && (n.tagName === "a" || n.tagName === "audio" || n.tagName === "del" || n.tagName === "ins" || n.tagName === "map" || n.tagName === "noscript" || n.tagName === "video"));
}
function Nm(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type === "element" && r.tagName === "li";
}
function Rm(e, t, n) {
  const r = Ie(n, t);
  return !!(r && r.type === "element" && (r.tagName === "dt" || r.tagName === "dd"));
}
function Bm(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type === "element" && (r.tagName === "dt" || r.tagName === "dd");
}
function Ps(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type === "element" && (r.tagName === "rp" || r.tagName === "rt");
}
function Dm(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type === "element" && r.tagName === "optgroup";
}
function Lm(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type === "element" && (r.tagName === "option" || r.tagName === "optgroup");
}
function Fm(e, t, n) {
  const r = Ie(n, t);
  return !!(r && r.type === "element" && (r.tagName === "tbody" || r.tagName === "tfoot"));
}
function Pm(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type === "element" && (r.tagName === "tbody" || r.tagName === "tfoot");
}
function Om(e, t, n) {
  return !Ie(n, t);
}
function qm(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type === "element" && r.tagName === "tr";
}
function Os(e, t, n) {
  const r = Ie(n, t);
  return !r || r.type === "element" && (r.tagName === "td" || r.tagName === "th");
}
const jm = Vl({
  body: Um,
  colgroup: Wm,
  head: Hm,
  html: Gm,
  tbody: Vm
});
function Gm(e) {
  const t = Ie(e, -1);
  return !t || t.type !== "comment";
}
function Hm(e) {
  const t = new Set();
  for (const r of e.children) if (r.type === "element" && (r.tagName === "base" || r.tagName === "title")) {
    if (t.has(r.tagName)) return !1;
    t.add(r.tagName);
  }
  const n = e.children[0];
  return !n || n.type === "element";
}
function Um(e) {
  const t = Ie(e, -1, !0);
  return !t || t.type !== "comment" && !(t.type === "text" && Yi(t.value.charAt(0))) && !(t.type === "element" && (t.tagName === "meta" || t.tagName === "link" || t.tagName === "script" || t.tagName === "style" || t.tagName === "template"));
}
function Wm(e, t, n) {
  const r = Ul(n, t),
    a = Ie(e, -1, !0);
  return n && r && r.type === "element" && r.tagName === "colgroup" && Zi(r, n.children.indexOf(r), n) ? !1 : !!(a && a.type === "element" && a.tagName === "col");
}
function Vm(e, t, n) {
  const r = Ul(n, t),
    a = Ie(e, -1);
  return n && r && r.type === "element" && (r.tagName === "thead" || r.tagName === "tbody") && Zi(r, n.children.indexOf(r), n) ? !1 : !!(a && a.type === "element" && a.tagName === "tr");
}
const vr = {
  name: [[`	
\f\r &/=>`.split(""), `	
\f\r "&'/=>\``.split("")], [`\0	
\f\r "&'/<=>`.split(""), `\0	
\f\r "&'/<=>\``.split("")]],
  unquoted: [[`	
\f\r &>`.split(""), `\0	
\f\r "&'<=>\``.split("")], [`\0	
\f\r "&'<=>\``.split(""), `\0	
\f\r "&'<=>\``.split("")]],
  single: [["&'".split(""), "\"&'`".split("")], ["\0&'".split(""), "\0\"&'`".split("")]],
  double: [['"&'.split(""), "\"&'`".split("")], ['\0"&'.split(""), "\0\"&'`".split("")]]
};
function Xm(e, t, n, r) {
  const a = r.schema,
    i = a.space === "svg" ? !1 : r.settings.omitOptionalTags;
  let s = a.space === "svg" ? r.settings.closeEmptyElements : r.settings.voids.includes(e.tagName.toLowerCase());
  const o = [];
  let l;
  a.space === "html" && e.tagName === "svg" && (r.schema = Gl);
  const u = Ym(r, e.properties),
    c = r.all(a.space === "html" && e.tagName === "template" ? e.content : e);
  return r.schema = a, c && (s = !1), (u || !i || !jm(e, t, n)) && (o.push("<", e.tagName, u ? " " + u : ""), s && (a.space === "svg" || r.settings.closeSelfClosing) && (l = u.charAt(u.length - 1), (!r.settings.tightSelfClosing || l === "/" || l && l !== '"' && l !== "'") && o.push(" "), o.push("/")), o.push(">")), o.push(c), !s && (!i || !Zi(e, t, n)) && o.push("</" + e.tagName + ">"), o.join("");
}
function Ym(e, t) {
  const n = [];
  let r = -1,
    a;
  if (t) {
    for (a in t) if (t[a] !== null && t[a] !== void 0) {
      const i = Zm(e, a, t[a]);
      i && n.push(i);
    }
  }
  for (; ++r < n.length;) {
    const i = e.settings.tightAttributes ? n[r].charAt(n[r].length - 1) : void 0;
    r !== n.length - 1 && i !== '"' && i !== "'" && (n[r] += " ");
  }
  return n.join("");
}
function Zm(e, t, n) {
  const r = Jc(e.schema, t),
    a = e.settings.allowParseErrors && e.schema.space === "html" ? 0 : 1,
    i = e.settings.allowDangerousCharacters ? 0 : 1;
  let s = e.quote,
    o;
  if (r.overloadedBoolean && (n === r.attribute || n === "") ? n = !0 : (r.boolean || r.overloadedBoolean) && (typeof n != "string" || n === r.attribute || n === "") && (n = !!n), n == null || n === !1 || typeof n == "number" && Number.isNaN(n)) return "";
  const l = Cn(r.attribute, Object.assign({}, e.settings.characterReferences, {
    subset: vr.name[a][i]
  }));
  return n === !0 || (n = Array.isArray(n) ? (r.commaSeparated ? Cm : Sm)(n, {
    padLeft: !e.settings.tightCommaSeparatedLists
  }) : String(n), e.settings.collapseEmptyAttributes && !n) ? l : (e.settings.preferUnquoted && (o = Cn(n, Object.assign({}, e.settings.characterReferences, {
    attribute: !0,
    subset: vr.unquoted[a][i]
  }))), o !== n && (e.settings.quoteSmart && Hr(n, s) > Hr(n, e.alternative) && (s = e.alternative), o = s + Cn(n, Object.assign({}, e.settings.characterReferences, {
    subset: (s === "'" ? vr.single : vr.double)[a][i],
    attribute: !0
  })) + s), l + (o && "=" + o));
}
const Km = ["<", "&"];
function Xl(e, t, n, r) {
  return n && n.type === "element" && (n.tagName === "script" || n.tagName === "style") ? e.value : Cn(e.value, Object.assign({}, r.settings.characterReferences, {
    subset: Km
  }));
}
function Qm(e, t, n, r) {
  return r.settings.allowDangerousHtml ? e.value : Xl(e, t, n, r);
}
function Jm(e, t, n, r) {
  return r.all(e);
}
const eh = rm("type", {
  invalid: th,
  unknown: nh,
  handlers: {
    comment: _m,
    doctype: $m,
    element: Xm,
    raw: Qm,
    root: Jm,
    text: Xl
  }
});
function th(e) {
  throw new Error("Expected node, not `" + e + "`");
}
function nh(e) {
  const t = e;
  throw new Error("Cannot compile unknown node `" + t.type + "`");
}
const rh = {},
  ah = {},
  ih = [];
function sh(e, t) {
  const n = t || rh,
    r = n.quote || '"',
    a = r === '"' ? "'" : '"';
  if (r !== '"' && r !== "'") throw new Error("Invalid quote `" + r + "`, expected `'` or `\"`");
  return {
    one: oh,
    all: lh,
    settings: {
      omitOptionalTags: n.omitOptionalTags || !1,
      allowParseErrors: n.allowParseErrors || !1,
      allowDangerousCharacters: n.allowDangerousCharacters || !1,
      quoteSmart: n.quoteSmart || !1,
      preferUnquoted: n.preferUnquoted || !1,
      tightAttributes: n.tightAttributes || !1,
      upperDoctype: n.upperDoctype || !1,
      tightDoctype: n.tightDoctype || !1,
      bogusComments: n.bogusComments || !1,
      tightCommaSeparatedLists: n.tightCommaSeparatedLists || !1,
      tightSelfClosing: n.tightSelfClosing || !1,
      collapseEmptyAttributes: n.collapseEmptyAttributes || !1,
      allowDangerousHtml: n.allowDangerousHtml || !1,
      voids: n.voids || Vc,
      characterReferences: n.characterReferences || ah,
      closeSelfClosing: n.closeSelfClosing || !1,
      closeEmptyElements: n.closeEmptyElements || !1
    },
    schema: n.space === "svg" ? Gl : nm,
    quote: r,
    alternative: a
  }.one(Array.isArray(e) ? {
    type: "root",
    children: e
  } : e, void 0, void 0);
}
function oh(e, t, n) {
  return eh(e, t, n, this);
}
function lh(e) {
  const t = [],
    n = e && e.children || ih;
  let r = -1;
  for (; ++r < n.length;) t[r] = this.one(n[r], r, e);
  return t.join("");
}
const qs = /\s+/g;
function Yl(e, t) {
  if (!t) return e;
  e.properties ||= {}, e.properties.class ||= [], typeof e.properties.class == "string" && (e.properties.class = e.properties.class.split(qs)), Array.isArray(e.properties.class) || (e.properties.class = []);
  const n = Array.isArray(t) ? t : t.split(qs);
  for (const r of n) r && !e.properties.class.includes(r) && e.properties.class.push(r);
  return e;
}
function uh(e) {
  const t = na(e, !0).map(([a]) => a);
  function n(a) {
    if (a === e.length) return {
      line: t.length - 1,
      character: t.at(-1).length
    };
    let i = a,
      s = 0;
    for (const o of t) {
      if (i < o.length) break;
      i -= o.length, s++;
    }
    return {
      line: s,
      character: i
    };
  }
  function r(a, i) {
    let s = 0;
    for (let o = 0; o < a; o++) s += t[o].length;
    return s += i, s;
  }
  return {
    lines: t,
    indexToPos: n,
    posToIndex: r
  };
}
const ch = ["color", "background-color"];
function mh(e, t) {
  let n = 0;
  const r = [];
  for (const a of t) a > n && r.push({
    ...e,
    content: e.content.slice(n, a),
    offset: e.offset + n
  }), n = a;
  return n < e.content.length && r.push({
    ...e,
    content: e.content.slice(n),
    offset: e.offset + n
  }), r;
}
function hh(e, t) {
  let n = 0,
    r = e.length;
  for (; n < r;) {
    const a = n + (r - n >> 1);
    e[a] <= t ? n = a + 1 : r = a;
  }
  return n;
}
function ph(e, t) {
  const n = [...(t instanceof Set ? t : new Set(t))].sort((r, a) => r - a);
  return n.length ? e.map(r => r.flatMap(a => {
    const i = a.offset + a.content.length,
      s = hh(n, a.offset);
    let o = s;
    for (; o < n.length && n[o] < i;) o++;
    if (s === o) return a;
    const l = n.slice(s, o);
    for (let u = 0; u < l.length; u++) l[u] -= a.offset;
    return mh(a, l);
  })) : e;
}
function dh(e, t, n, r, a = "css-vars") {
  const i = {
      content: e.content,
      explanation: e.explanation,
      offset: e.offset
    },
    s = t.map(c => Ur(e.variants[c])),
    o = new Set(s.flatMap(c => Object.keys(c))),
    l = {},
    u = (c, h) => {
      const f = h === "color" ? "" : h === "background-color" ? "-bg" : `-${h}`;
      return n + t[c] + (h === "color" ? "" : f);
    };
  return s.forEach((c, h) => {
    for (const f of o) {
      const d = c[f] || "inherit";
      if (h === 0 && r && ch.includes(f)) {
        if (r === "light-dark()" && s.length > 1) {
          const b = t.findIndex(_ => _ === "light"),
            k = t.findIndex(_ => _ === "dark");
          if (b === -1 || k === -1) throw new ge('When using `defaultColor: "light-dark()"`, you must provide both `light` and `dark` themes');
          const A = s[b][f] || "inherit",
            w = s[k][f] || "inherit";
          l[f] = `light-dark(${A}, ${w})`, a === "css-vars" && (l[u(h, f)] = d);
        } else l[f] = d;
      } else a === "css-vars" && (l[u(h, f)] = d);
    }
  }), i.htmlStyle = l, i;
}
function Ur(e) {
  const t = {};
  if (e.color && (t.color = e.color), e.bgColor && (t["background-color"] = e.bgColor), e.fontStyle) {
    e.fontStyle & Le.Italic && (t["font-style"] = "italic"), e.fontStyle & Le.Bold && (t["font-weight"] = "bold");
    const n = [];
    e.fontStyle & Le.Underline && n.push("underline"), e.fontStyle & Le.Strikethrough && n.push("line-through"), n.length && (t["text-decoration"] = n.join(" "));
  }
  return t;
}
function di(e) {
  return typeof e == "string" ? e : Object.entries(e).map(([t, n]) => `${t}:${n}`).join(";");
}
function fh() {
  const e = new WeakMap();
  function t(n) {
    if (!e.has(n.meta)) {
      let a = function (s) {
        if (typeof s == "number") {
          if (s < 0 || s > n.source.length) throw new ge(`Invalid decoration offset: ${s}. Code length: ${n.source.length}`);
          return {
            ...r.indexToPos(s),
            offset: s
          };
        } else {
          const o = r.lines[s.line];
          if (o === void 0) throw new ge(`Invalid decoration position ${JSON.stringify(s)}. Lines length: ${r.lines.length}`);
          let l = s.character;
          if (l < 0 && (l = o.length + l), l < 0 || l > o.length) throw new ge(`Invalid decoration position ${JSON.stringify(s)}. Line ${s.line} length: ${o.length}`);
          return {
            ...s,
            character: l,
            offset: r.posToIndex(s.line, l)
          };
        }
      };
      const r = uh(n.source),
        i = (n.options.decorations || []).map(s => ({
          ...s,
          start: a(s.start),
          end: a(s.end)
        }));
      gh(i), e.set(n.meta, {
        decorations: i,
        converter: r,
        source: n.source
      });
    }
    return e.get(n.meta);
  }
  return {
    name: "shiki:decorations",
    tokens(n) {
      if (this.options.decorations?.length) return ph(n, t(this).decorations.flatMap(r => [r.start.offset, r.end.offset]));
    },
    code(n) {
      if (!this.options.decorations?.length) return;
      const r = t(this),
        a = [...n.children].filter(c => c.type === "element" && c.tagName === "span");
      if (a.length !== r.converter.lines.length) throw new ge(`Number of lines in code element (${a.length}) does not match the number of lines in the source (${r.converter.lines.length}). Failed to apply decorations.`);
      function i(c, h, f, d) {
        const b = a[c];
        let k = "",
          A = -1,
          w = -1;
        if (h === 0 && (A = 0), f === 0 && (w = 0), f === Number.POSITIVE_INFINITY && (w = b.children.length), A === -1 || w === -1) for (let T = 0; T < b.children.length; T++) k += Zl(b.children[T]), A === -1 && k.length === h && (A = T + 1), w === -1 && k.length === f && (w = T + 1);
        if (A === -1) throw new ge(`Failed to find start index for decoration ${JSON.stringify(d.start)}`);
        if (w === -1) throw new ge(`Failed to find end index for decoration ${JSON.stringify(d.end)}`);
        const _ = b.children.slice(A, w);
        if (!d.alwaysWrap && _.length === b.children.length) o(b, d, "line");else if (!d.alwaysWrap && _.length === 1 && _[0].type === "element") o(_[0], d, "token");else {
          const T = {
            type: "element",
            tagName: "span",
            properties: {},
            children: _
          };
          o(T, d, "wrapper"), b.children.splice(A, _.length, T);
        }
      }
      function s(c, h) {
        a[c] = o(a[c], h, "line");
      }
      function o(c, h, f) {
        const d = h.properties || {},
          b = h.transform || (k => k);
        return c.tagName = h.tagName || "span", c.properties = {
          ...c.properties,
          ...d,
          class: c.properties.class
        }, h.properties?.class && Yl(c, h.properties.class), c = b(c, f) || c, c;
      }
      const l = [],
        u = r.decorations.sort((c, h) => h.start.offset - c.start.offset || c.end.offset - h.end.offset);
      for (const c of u) {
        const {
          start: h,
          end: f
        } = c;
        if (h.line === f.line) i(h.line, h.character, f.character, c);else if (h.line < f.line) {
          i(h.line, h.character, Number.POSITIVE_INFINITY, c);
          for (let d = h.line + 1; d < f.line; d++) l.unshift(() => s(d, c));
          i(f.line, 0, f.character, c);
        }
      }
      l.forEach(c => c());
    }
  };
}
function gh(e) {
  for (let t = 0; t < e.length; t++) {
    const n = e[t];
    if (n.start.offset > n.end.offset) throw new ge(`Invalid decoration range: ${JSON.stringify(n.start)} - ${JSON.stringify(n.end)}`);
    for (let r = t + 1; r < e.length; r++) {
      const a = e[r],
        i = n.start.offset <= a.start.offset && a.start.offset < n.end.offset,
        s = n.start.offset < a.end.offset && a.end.offset <= n.end.offset,
        o = a.start.offset <= n.start.offset && n.start.offset < a.end.offset,
        l = a.start.offset < n.end.offset && n.end.offset <= a.end.offset;
      if (i || s || o || l) {
        if (i && s || o && l || o && n.start.offset === n.end.offset || s && a.start.offset === a.end.offset) continue;
        throw new ge(`Decorations ${JSON.stringify(n.start)} and ${JSON.stringify(a.start)} intersect.`);
      }
    }
  }
}
function Zl(e) {
  return e.type === "text" ? e.value : e.type === "element" ? e.children.map(Zl).join("") : "";
}
const bh = [fh()];
function Wr(e) {
  const t = yh(e.transformers || []);
  return [...t.pre, ...t.normal, ...t.post, ...bh];
}
function yh(e) {
  const t = [],
    n = [],
    r = [];
  for (const a of e) switch (a.enforce) {
    case "pre":
      t.push(a);
      break;
    case "post":
      n.push(a);
      break;
    default:
      r.push(a);
  }
  return {
    pre: t,
    post: n,
    normal: r
  };
}
var ln = ["black", "red", "green", "yellow", "blue", "magenta", "cyan", "white", "brightBlack", "brightRed", "brightGreen", "brightYellow", "brightBlue", "brightMagenta", "brightCyan", "brightWhite"],
  Ma = {
    1: "bold",
    2: "dim",
    3: "italic",
    4: "underline",
    7: "reverse",
    8: "hidden",
    9: "strikethrough"
  };
function vh(e, t) {
  const n = e.indexOf("\x1B", t);
  if (n !== -1 && e[n + 1] === "[") {
    const r = e.indexOf("m", n);
    if (r !== -1) return {
      sequence: e.substring(n + 2, r).split(";"),
      startPosition: n,
      position: r + 1
    };
  }
  return {
    position: e.length
  };
}
function js(e) {
  const t = e.shift();
  if (t === "2") {
    const n = e.splice(0, 3).map(r => Number.parseInt(r));
    return n.length !== 3 || n.some(r => Number.isNaN(r)) ? void 0 : {
      type: "rgb",
      rgb: n
    };
  } else if (t === "5") {
    const n = e.shift();
    if (n) return {
      type: "table",
      index: Number(n)
    };
  }
}
function wh(e) {
  const t = [];
  for (; e.length > 0;) {
    const n = e.shift();
    if (!n) continue;
    const r = Number.parseInt(n);
    if (!Number.isNaN(r)) if (r === 0) t.push({
      type: "resetAll"
    });else if (r <= 9) Ma[r] && t.push({
      type: "setDecoration",
      value: Ma[r]
    });else if (r <= 29) {
      const a = Ma[r - 20];
      a && (t.push({
        type: "resetDecoration",
        value: a
      }), a === "dim" && t.push({
        type: "resetDecoration",
        value: "bold"
      }));
    } else if (r <= 37) t.push({
      type: "setForegroundColor",
      value: {
        type: "named",
        name: ln[r - 30]
      }
    });else if (r === 38) {
      const a = js(e);
      a && t.push({
        type: "setForegroundColor",
        value: a
      });
    } else if (r === 39) t.push({
      type: "resetForegroundColor"
    });else if (r <= 47) t.push({
      type: "setBackgroundColor",
      value: {
        type: "named",
        name: ln[r - 40]
      }
    });else if (r === 48) {
      const a = js(e);
      a && t.push({
        type: "setBackgroundColor",
        value: a
      });
    } else r === 49 ? t.push({
      type: "resetBackgroundColor"
    }) : r === 53 ? t.push({
      type: "setDecoration",
      value: "overline"
    }) : r === 55 ? t.push({
      type: "resetDecoration",
      value: "overline"
    }) : r >= 90 && r <= 97 ? t.push({
      type: "setForegroundColor",
      value: {
        type: "named",
        name: ln[r - 90 + 8]
      }
    }) : r >= 100 && r <= 107 && t.push({
      type: "setBackgroundColor",
      value: {
        type: "named",
        name: ln[r - 100 + 8]
      }
    });
  }
  return t;
}
function xh() {
  let e = null,
    t = null,
    n = new Set();
  return {
    parse(r) {
      const a = [];
      let i = 0;
      do {
        const s = vh(r, i),
          o = s.sequence ? r.substring(i, s.startPosition) : r.substring(i);
        if (o.length > 0 && a.push({
          value: o,
          foreground: e,
          background: t,
          decorations: new Set(n)
        }), s.sequence) {
          const l = wh(s.sequence);
          for (const u of l) u.type === "resetAll" ? (e = null, t = null, n.clear()) : u.type === "resetForegroundColor" ? e = null : u.type === "resetBackgroundColor" ? t = null : u.type === "resetDecoration" && n.delete(u.value);
          for (const u of l) u.type === "setForegroundColor" ? e = u.value : u.type === "setBackgroundColor" ? t = u.value : u.type === "setDecoration" && n.add(u.value);
        }
        i = s.position;
      } while (i < r.length);
      return a;
    }
  };
}
var kh = {
  black: "#000000",
  red: "#bb0000",
  green: "#00bb00",
  yellow: "#bbbb00",
  blue: "#0000bb",
  magenta: "#ff00ff",
  cyan: "#00bbbb",
  white: "#eeeeee",
  brightBlack: "#555555",
  brightRed: "#ff5555",
  brightGreen: "#00ff00",
  brightYellow: "#ffff55",
  brightBlue: "#5555ff",
  brightMagenta: "#ff55ff",
  brightCyan: "#55ffff",
  brightWhite: "#ffffff"
};
function _h(e = kh) {
  function t(o) {
    return e[o];
  }
  function n(o) {
    return `#${o.map(l => Math.max(0, Math.min(l, 255)).toString(16).padStart(2, "0")).join("")}`;
  }
  let r;
  function a() {
    if (r) return r;
    r = [];
    for (let u = 0; u < ln.length; u++) r.push(t(ln[u]));
    let o = [0, 95, 135, 175, 215, 255];
    for (let u = 0; u < 6; u++) for (let c = 0; c < 6; c++) for (let h = 0; h < 6; h++) r.push(n([o[u], o[c], o[h]]));
    let l = 8;
    for (let u = 0; u < 24; u++, l += 10) r.push(n([l, l, l]));
    return r;
  }
  function i(o) {
    return a()[o];
  }
  function s(o) {
    switch (o.type) {
      case "named":
        return t(o.name);
      case "rgb":
        return n(o.rgb);
      case "table":
        return i(o.index);
    }
  }
  return {
    value: s
  };
}
const $h = /#([0-9a-f]{3,8})/i,
  Ch = /var\((--[\w-]+-ansi-[\w-]+)\)/,
  Sh = {
    black: "#000000",
    red: "#cd3131",
    green: "#0DBC79",
    yellow: "#E5E510",
    blue: "#2472C8",
    magenta: "#BC3FBC",
    cyan: "#11A8CD",
    white: "#E5E5E5",
    brightBlack: "#666666",
    brightRed: "#F14C4C",
    brightGreen: "#23D18B",
    brightYellow: "#F5F543",
    brightBlue: "#3B8EEA",
    brightMagenta: "#D670D6",
    brightCyan: "#29B8DB",
    brightWhite: "#FFFFFF"
  };
function Ah(e, t, n) {
  const r = Gr(e, n),
    a = na(t),
    i = _h(Object.fromEntries(ln.map(o => {
      const l = `terminal.ansi${o[0].toUpperCase()}${o.substring(1)}`;
      return [o, e.colors?.[l] || Sh[o]];
    }))),
    s = xh();
  return a.map(o => s.parse(o[0]).map(l => {
    let u, c;
    l.decorations.has("reverse") ? (u = l.background ? i.value(l.background) : e.bg, c = l.foreground ? i.value(l.foreground) : e.fg) : (u = l.foreground ? i.value(l.foreground) : e.fg, c = l.background ? i.value(l.background) : void 0), u = Ht(u, r), c = Ht(c, r), l.decorations.has("dim") && (u = Th(u));
    let h = Le.None;
    return l.decorations.has("bold") && (h |= Le.Bold), l.decorations.has("italic") && (h |= Le.Italic), l.decorations.has("underline") && (h |= Le.Underline), l.decorations.has("strikethrough") && (h |= Le.Strikethrough), {
      content: l.value,
      offset: o[1],
      color: u,
      bgColor: c,
      fontStyle: h
    };
  }));
}
function Th(e) {
  const t = e.match($h);
  if (t) {
    const r = t[1];
    if (r.length === 8) {
      const a = Math.round(Number.parseInt(r.slice(6, 8), 16) / 2).toString(16).padStart(2, "0");
      return `#${r.slice(0, 6)}${a}`;
    } else {
      if (r.length === 6) return `#${r}80`;
      if (r.length === 4) {
        const a = r[0],
          i = r[1],
          s = r[2],
          o = r[3];
        return `#${a}${a}${i}${i}${s}${s}${Math.round(Number.parseInt(`${o}${o}`, 16) / 2).toString(16).padStart(2, "0")}`;
      } else if (r.length === 3) {
        const a = r[0],
          i = r[1],
          s = r[2];
        return `#${a}${a}${i}${i}${s}${s}80`;
      }
    }
  }
  const n = e.match(Ch);
  return n ? `var(${n[1]}-dim)` : e;
}
function fi(e, t, n = {}) {
  const r = e.resolveLangAlias(n.lang || "text"),
    {
      theme: a = e.getLoadedThemes()[0]
    } = n;
  if (!ea(r) && !ta(a) && r === "ansi") {
    const {
      theme: i
    } = e.setTheme(a);
    return Ah(i, t, n);
  }
  return Rl(e, t, n);
}
function Vr(e, t, n) {
  let r, a, i, s, o, l;
  if ("themes" in n) {
    const {
        defaultColor: u = "light",
        cssVariablePrefix: c = "--shiki-",
        colorsRendering: h = "css-vars"
      } = n,
      f = Object.entries(n.themes).filter(w => w[1]).map(w => ({
        color: w[0],
        theme: w[1]
      })).sort((w, _) => w.color === u ? -1 : _.color === u ? 1 : 0);
    if (f.length === 0) throw new ge("`themes` option must not be empty");
    const d = Bl(e, t, n, fi);
    if (l = Kn(d), u && u !== "light-dark()" && !f.some(w => w.color === u)) throw new ge(`\`themes\` option must contain the defaultColor key \`${u}\``);
    const b = f.map(w => e.getTheme(w.theme)),
      k = f.map(w => w.color);
    i = d.map(w => w.map(_ => dh(_, k, c, u, h))), l && ra(i, l);
    const A = f.map(w => Gr(w.theme, n));
    a = Gs(f, b, A, c, u, "fg", h), r = Gs(f, b, A, c, u, "bg", h), s = `shiki-themes ${b.map(w => w.name).join(" ")}`, o = u ? void 0 : [a, r].join(";");
  } else if ("theme" in n) {
    const u = Gr(n.theme, n);
    i = fi(e, t, n);
    const c = e.getTheme(n.theme);
    r = Ht(c.bg, u), a = Ht(c.fg, u), s = c.name, l = Kn(i);
  } else throw new ge("Invalid options, either `theme` or `themes` must be provided");
  return {
    tokens: i,
    fg: a,
    bg: r,
    themeName: s,
    rootStyle: o,
    grammarState: l
  };
}
function Gs(e, t, n, r, a, i, s) {
  return e.map((o, l) => {
    const u = Ht(t[l][i], n[l]) || "inherit",
      c = `${r + o.color}${i === "bg" ? "-bg" : ""}:${u}`;
    if (l === 0 && a) {
      if (a === "light-dark()" && e.length > 1) {
        const h = e.findIndex(d => d.color === "light"),
          f = e.findIndex(d => d.color === "dark");
        if (h === -1 || f === -1) throw new ge('When using `defaultColor: "light-dark()"`, you must provide both `light` and `dark` themes');
        return `light-dark(${Ht(t[h][i], n[h]) || "inherit"}, ${Ht(t[f][i], n[f]) || "inherit"});${c}`;
      }
      return u;
    }
    return s === "css-vars" ? c : null;
  }).filter(o => !!o).join(";");
}
const Kl = /^\s+$/,
  Eh = /^(\s*)(.*?)(\s*)$/;
function Xr(e, t, n, r = {
  meta: {},
  options: n,
  codeToHast: (a, i) => Xr(e, a, i),
  codeToTokens: (a, i) => Vr(e, a, i)
}) {
  let a = t;
  for (const b of Wr(n)) a = b.preprocess?.call(r, a, n) || a;
  let {
    tokens: i,
    fg: s,
    bg: o,
    themeName: l,
    rootStyle: u,
    grammarState: c
  } = Vr(e, a, n);
  const {
    mergeWhitespaces: h = !0,
    mergeSameStyleTokens: f = !1
  } = n;
  h === !0 ? i = zh(i) : h === "never" && (i = Ih(i)), f && (i = Nh(i));
  const d = {
    ...r,
    get source() {
      return a;
    }
  };
  for (const b of Wr(n)) i = b.tokens?.call(d, i) || i;
  return Mh(i, {
    ...n,
    fg: s,
    bg: o,
    themeName: l,
    rootStyle: n.rootStyle === !1 ? !1 : n.rootStyle ?? u
  }, d, c);
}
function Mh(e, t, n, r = Kn(e)) {
  const a = Wr(t),
    i = [],
    s = {
      type: "root",
      children: []
    },
    {
      structure: o = "classic",
      tabindex: l = "0"
    } = t,
    u = {
      class: `shiki ${t.themeName || ""}`
    };
  t.rootStyle !== !1 && (t.rootStyle != null ? u.style = t.rootStyle : u.style = `background-color:${t.bg};color:${t.fg}`), l !== !1 && l != null && (u.tabindex = l.toString());
  for (const [k, A] of Object.entries(t.meta || {})) k.startsWith("_") || (u[k] = A);
  let c = {
      type: "element",
      tagName: "pre",
      properties: u,
      children: [],
      data: t.data
    },
    h = {
      type: "element",
      tagName: "code",
      properties: {},
      children: i
    };
  const f = [],
    d = {
      ...n,
      structure: o,
      addClassToHast: Yl,
      get source() {
        return n.source;
      },
      get tokens() {
        return e;
      },
      get options() {
        return t;
      },
      get root() {
        return s;
      },
      get pre() {
        return c;
      },
      get code() {
        return h;
      },
      get lines() {
        return f;
      }
    };
  if (e.forEach((k, A) => {
    A && (o === "inline" ? s.children.push({
      type: "element",
      tagName: "br",
      properties: {},
      children: []
    }) : o === "classic" && i.push({
      type: "text",
      value: `
`
    }));
    let w = {
        type: "element",
        tagName: "span",
        properties: {
          class: "line"
        },
        children: []
      },
      _ = 0;
    for (const T of k) {
      let I = {
        type: "element",
        tagName: "span",
        properties: {
          ...T.htmlAttrs
        },
        children: [{
          type: "text",
          value: T.content
        }]
      };
      const R = di(T.htmlStyle || Ur(T));
      R && (I.properties.style = R);
      for (const E of a) I = E?.span?.call(d, I, A + 1, _, w, T) || I;
      o === "inline" ? s.children.push(I) : o === "classic" && w.children.push(I), _ += T.content.length;
    }
    if (o === "classic") {
      for (const T of a) w = T?.line?.call(d, w, A + 1) || w;
      f.push(w), i.push(w);
    } else o === "inline" && f.push(w);
  }), o === "classic") {
    for (const k of a) h = k?.code?.call(d, h) || h;
    c.children.push(h);
    for (const k of a) c = k?.pre?.call(d, c) || c;
    s.children.push(c);
  } else if (o === "inline") {
    const k = [];
    let A = {
      type: "element",
      tagName: "span",
      properties: {
        class: "line"
      },
      children: []
    };
    for (const _ of s.children) _.type === "element" && _.tagName === "br" ? (k.push(A), A = {
      type: "element",
      tagName: "span",
      properties: {
        class: "line"
      },
      children: []
    }) : (_.type === "element" || _.type === "text") && A.children.push(_);
    k.push(A);
    let w = {
      type: "element",
      tagName: "code",
      properties: {},
      children: k
    };
    for (const _ of a) w = _?.code?.call(d, w) || w;
    s.children = [];
    for (let _ = 0; _ < w.children.length; _++) {
      _ > 0 && s.children.push({
        type: "element",
        tagName: "br",
        properties: {},
        children: []
      });
      const T = w.children[_];
      T.type === "element" && s.children.push(...T.children);
    }
  }
  let b = s;
  for (const k of a) b = k?.root?.call(d, b) || b;
  return r && ra(b, r), b;
}
function zh(e) {
  return e.map(t => {
    const n = [];
    let r = "",
      a;
    return t.forEach((i, s) => {
      const o = !(i.fontStyle && (i.fontStyle & Le.Underline || i.fontStyle & Le.Strikethrough));
      o && Kl.test(i.content) && t[s + 1] ? (a === void 0 && (a = i.offset), r += i.content) : r ? (o ? n.push({
        ...i,
        offset: a,
        content: r + i.content
      }) : n.push({
        content: r,
        offset: a
      }, i), a = void 0, r = "") : n.push(i);
    }), n;
  });
}
function Ih(e) {
  return e.map(t => t.flatMap(n => {
    if (Kl.test(n.content)) return n;
    const r = n.content.match(Eh);
    if (!r) return n;
    const [, a, i, s] = r;
    if (!a && !s) return n;
    const o = [{
      ...n,
      offset: n.offset + a.length,
      content: i
    }];
    return a && o.unshift({
      content: a,
      offset: n.offset
    }), s && o.push({
      content: s,
      offset: n.offset + a.length + i.length
    }), o;
  }));
}
function Nh(e) {
  return e.map(t => {
    const n = [];
    for (const r of t) {
      if (n.length === 0) {
        n.push({
          ...r
        });
        continue;
      }
      const a = n.at(-1),
        i = di(a.htmlStyle || Ur(a)),
        s = di(r.htmlStyle || Ur(r)),
        o = a.fontStyle && (a.fontStyle & Le.Underline || a.fontStyle & Le.Strikethrough),
        l = r.fontStyle && (r.fontStyle & Le.Underline || r.fontStyle & Le.Strikethrough);
      !o && !l && i === s ? a.content += r.content : n.push({
        ...r
      });
    }
    return n;
  });
}
const Rh = sh;
function Bh(e, t, n) {
  const r = {
    meta: {},
    options: n,
    codeToHast: (i, s) => Xr(e, i, s),
    codeToTokens: (i, s) => Vr(e, i, s)
  };
  let a = Rh(Xr(e, t, n, r));
  for (const i of Wr(n)) a = i.postprocess?.call(r, a, n) || a;
  return a;
}
function m5(e) {
  const t = Bc(e);
  return {
    getLastGrammarState: (...n) => Oc(t, ...n),
    codeToTokensBase: (n, r) => fi(t, n, r),
    codeToTokensWithThemes: (n, r) => Bl(t, n, r),
    codeToTokens: (n, r) => Vr(t, n, r),
    codeToHast: (n, r) => Xr(t, n, r),
    codeToHtml: (n, r) => Bh(t, n, r),
    getBundledLanguages: () => ({}),
    getBundledThemes: () => ({}),
    ...t,
    getInternalContext: () => t
  };
}
function h5(e = {}) {
  const {
      name: t = "css-variables",
      variablePrefix: n = "--shiki-",
      fontStyle: r = !0
    } = e,
    a = s => e.variableDefaults?.[s] ? `var(${n}${s}, ${e.variableDefaults[s]})` : `var(${n}${s})`,
    i = {
      name: t,
      type: "dark",
      colors: {
        "editor.foreground": a("foreground"),
        "editor.background": a("background"),
        "terminal.ansiBlack": a("ansi-black"),
        "terminal.ansiRed": a("ansi-red"),
        "terminal.ansiGreen": a("ansi-green"),
        "terminal.ansiYellow": a("ansi-yellow"),
        "terminal.ansiBlue": a("ansi-blue"),
        "terminal.ansiMagenta": a("ansi-magenta"),
        "terminal.ansiCyan": a("ansi-cyan"),
        "terminal.ansiWhite": a("ansi-white"),
        "terminal.ansiBrightBlack": a("ansi-bright-black"),
        "terminal.ansiBrightRed": a("ansi-bright-red"),
        "terminal.ansiBrightGreen": a("ansi-bright-green"),
        "terminal.ansiBrightYellow": a("ansi-bright-yellow"),
        "terminal.ansiBrightBlue": a("ansi-bright-blue"),
        "terminal.ansiBrightMagenta": a("ansi-bright-magenta"),
        "terminal.ansiBrightCyan": a("ansi-bright-cyan"),
        "terminal.ansiBrightWhite": a("ansi-bright-white")
      },
      tokenColors: [{
        scope: ["keyword.operator.accessor", "meta.group.braces.round.function.arguments", "meta.template.expression", "markup.fenced_code meta.embedded.block"],
        settings: {
          foreground: a("foreground")
        }
      }, {
        scope: "emphasis",
        settings: {
          fontStyle: "italic"
        }
      }, {
        scope: ["strong", "markup.heading.markdown", "markup.bold.markdown"],
        settings: {
          fontStyle: "bold"
        }
      }, {
        scope: ["markup.italic.markdown"],
        settings: {
          fontStyle: "italic"
        }
      }, {
        scope: "meta.link.inline.markdown",
        settings: {
          fontStyle: "underline",
          foreground: a("token-link")
        }
      }, {
        scope: ["string", "markup.fenced_code", "markup.inline"],
        settings: {
          foreground: a("token-string")
        }
      }, {
        scope: ["comment", "string.quoted.docstring.multi"],
        settings: {
          foreground: a("token-comment")
        }
      }, {
        scope: ["constant.numeric", "constant.language", "constant.other.placeholder", "constant.character.format.placeholder", "variable.language.this", "variable.other.object", "variable.other.class", "variable.other.constant", "meta.property-name", "meta.property-value", "support"],
        settings: {
          foreground: a("token-constant")
        }
      }, {
        scope: ["keyword", "storage.modifier", "storage.type", "storage.control.clojure", "entity.name.function.clojure", "entity.name.tag.yaml", "support.function.node", "support.type.property-name.json", "punctuation.separator.key-value", "punctuation.definition.template-expression"],
        settings: {
          foreground: a("token-keyword")
        }
      }, {
        scope: "variable.parameter.function",
        settings: {
          foreground: a("token-parameter")
        }
      }, {
        scope: ["support.function", "entity.name.type", "entity.other.inherited-class", "meta.function-call", "meta.instance.constructor", "entity.other.attribute-name", "entity.name.function", "constant.keyword.clojure"],
        settings: {
          foreground: a("token-function")
        }
      }, {
        scope: ["entity.name.tag", "string.quoted", "string.regexp", "string.interpolated", "string.template", "string.unquoted.plain.out.yaml", "keyword.other.template"],
        settings: {
          foreground: a("token-string-expression")
        }
      }, {
        scope: ["punctuation.definition.arguments", "punctuation.definition.dict", "punctuation.separator", "meta.function-call.arguments"],
        settings: {
          foreground: a("token-punctuation")
        }
      }, {
        scope: ["markup.underline.link", "punctuation.definition.metadata.markdown"],
        settings: {
          foreground: a("token-link")
        }
      }, {
        scope: ["beginning.punctuation.definition.list.markdown"],
        settings: {
          foreground: a("token-string")
        }
      }, {
        scope: ["punctuation.definition.string.begin.markdown", "punctuation.definition.string.end.markdown", "string.other.link.title.markdown", "string.other.link.description.markdown"],
        settings: {
          foreground: a("token-keyword")
        }
      }, {
        scope: ["markup.inserted", "meta.diff.header.to-file", "punctuation.definition.inserted"],
        settings: {
          foreground: a("token-inserted")
        }
      }, {
        scope: ["markup.deleted", "meta.diff.header.from-file", "punctuation.definition.deleted"],
        settings: {
          foreground: a("token-deleted")
        }
      }, {
        scope: ["markup.changed", "punctuation.definition.changed"],
        settings: {
          foreground: a("token-changed")
        }
      }]
    };
  return r || (i.tokenColors = i.tokenColors?.map(s => (s.settings?.fontStyle && delete s.settings.fontStyle, s))), i;
}
const Hs = 4294967295;
var Dh = class {
  patterns;
  options;
  regexps;
  constructor(e, t = {}) {
    this.patterns = e, this.options = t;
    const {
      forgiving: n = !1,
      cache: r,
      regexConstructor: a
    } = t;
    if (!a) throw new Error("Option `regexConstructor` is not provided");
    this.regexps = e.map(i => {
      if (typeof i != "string") return i;
      const s = r?.get(i);
      if (s) {
        if (s instanceof RegExp) return s;
        if (n) return null;
        throw s;
      }
      try {
        const o = a(i);
        return r?.set(i, o), o;
      } catch (o) {
        if (r?.set(i, o), n) return null;
        throw o;
      }
    });
  }
  findNextMatchSync(e, t, n) {
    const r = typeof e == "string" ? e : e.content,
      a = [];
    function i(s, o, l = 0) {
      return {
        index: s,
        captureIndices: o.indices.map(u => u == null ? {
          start: Hs,
          end: Hs,
          length: 0
        } : {
          start: u[0] + l,
          end: u[1] + l,
          length: u[1] - u[0]
        })
      };
    }
    for (let s = 0; s < this.regexps.length; s++) {
      const o = this.regexps[s];
      if (o) try {
        o.lastIndex = t;
        const l = o.exec(r);
        if (!l) continue;
        if (l.index === t) return i(s, l, 0);
        a.push([s, l, 0]);
      } catch (l) {
        if (this.options.forgiving) continue;
        throw l;
      }
    }
    if (a.length) {
      const s = Math.min(...a.map(o => o[1].index));
      for (const [o, l, u] of a) if (l.index === s) return i(o, l, u);
    }
    return null;
  }
};
function zn(e) {
  if ([...e].length !== 1) throw new Error(`Expected "${e}" to be a single code point`);
  return e.codePointAt(0);
}
function Lh(e, t, n) {
  return e.has(t) || e.set(t, n), e.get(t);
}
const Ki = new Set(["alnum", "alpha", "ascii", "blank", "cntrl", "digit", "graph", "lower", "print", "punct", "space", "upper", "word", "xdigit"]),
  Re = String.raw;
function In(e, t) {
  if (e == null) throw new Error(t ?? "Value expected");
  return e;
}
const Ql = Re`\[\^?`,
  Jl = `c.? | C(?:-.?)?|${Re`[pP]\{(?:\^?[-\x20_]*[A-Za-z][-\x20\w]*\})?`}|${Re`x[89A-Fa-f]\p{AHex}(?:\\x[89A-Fa-f]\p{AHex})*`}|${Re`u(?:\p{AHex}{4})? | x\{[^\}]*\}? | x\p{AHex}{0,2}`}|${Re`o\{[^\}]*\}?`}|${Re`\d{1,3}`}`,
  Qi = /[?*+][?+]?|\{(?:\d+(?:,\d*)?|,\d+)\}\??/,
  wr = new RegExp(Re`
  \\ (?:
    ${Jl}
    | [gk]<[^>]*>?
    | [gk]'[^']*'?
    | .
  )
  | \( (?:
    \? (?:
      [:=!>({]
      | <[=!]
      | <[^>]*>
      | '[^']*'
      | ~\|?
      | #(?:[^)\\]|\\.?)*
      | [^:)]*[:)]
    )?
    | \*[^\)]*\)?
  )?
  | (?:${Qi.source})+
  | ${Ql}
  | .
`.replace(/\s+/g, ""), "gsu"),
  za = new RegExp(Re`
  \\ (?:
    ${Jl}
    | .
  )
  | \[:(?:\^?\p{Alpha}+|\^):\]
  | ${Ql}
  | &&
  | .
`.replace(/\s+/g, ""), "gsu");
function Fh(e, t = {}) {
  const n = {
    flags: "",
    ...t,
    rules: {
      captureGroup: !1,
      singleline: !1,
      ...t.rules
    }
  };
  if (typeof e != "string") throw new Error("String expected as pattern");
  const r = rp(n.flags),
    a = [r.extended],
    i = {
      captureGroup: n.rules.captureGroup,
      getCurrentModX() {
        return a.at(-1);
      },
      numOpenGroups: 0,
      popModX() {
        a.pop();
      },
      pushModX(h) {
        a.push(h);
      },
      replaceCurrentModX(h) {
        a[a.length - 1] = h;
      },
      singleline: n.rules.singleline
    };
  let s = [],
    o;
  for (wr.lastIndex = 0; o = wr.exec(e);) {
    const h = Ph(i, e, o[0], wr.lastIndex);
    h.tokens ? s.push(...h.tokens) : h.token && s.push(h.token), h.lastIndex !== void 0 && (wr.lastIndex = h.lastIndex);
  }
  const l = [];
  let u = 0;
  s.filter(h => h.type === "GroupOpen").forEach(h => {
    h.kind === "capturing" ? h.number = ++u : h.raw === "(" && l.push(h);
  }), u || l.forEach((h, f) => {
    h.kind = "capturing", h.number = f + 1;
  });
  const c = u || l.length;
  return {
    tokens: s.map(h => h.type === "EscapedNumber" ? ip(h, c) : h).flat(),
    flags: r
  };
}
function Ph(e, t, n, r) {
  const [a, i] = n;
  if (n === "[" || n === "[^") {
    const s = Oh(t, n, r);
    return {
      tokens: s.tokens,
      lastIndex: s.lastIndex
    };
  }
  if (a === "\\") {
    if ("AbBGyYzZ".includes(i)) return {
      token: Us(n, n)
    };
    if (/^\\g[<']/.test(n)) {
      if (!/^\\g(?:<[^>]+>|'[^']+')$/.test(n)) throw new Error(`Invalid group name "${n}"`);
      return {
        token: Zh(n)
      };
    }
    if (/^\\k[<']/.test(n)) {
      if (!/^\\k(?:<[^>]+>|'[^']+')$/.test(n)) throw new Error(`Invalid group name "${n}"`);
      return {
        token: t0(n)
      };
    }
    if (i === "K") return {
      token: n0("keep", n)
    };
    if (i === "N" || i === "R") return {
      token: un("newline", n, {
        negate: i === "N"
      })
    };
    if (i === "O") return {
      token: un("any", n)
    };
    if (i === "X") return {
      token: un("text_segment", n)
    };
    const s = e0(n, {
      inCharClass: !1
    });
    return Array.isArray(s) ? {
      tokens: s
    } : {
      token: s
    };
  }
  if (a === "(") {
    if (i === "*") return {
      token: ep(n)
    };
    if (n === "(?{") throw new Error(`Unsupported callout "${n}"`);
    if (n.startsWith("(?#")) {
      if (t[r] !== ")") throw new Error('Unclosed comment group "(?#"');
      return {
        lastIndex: r + 1
      };
    }
    if (/^\(\?[-imx]+[:)]$/.test(n)) return {
      token: Jh(n, e)
    };
    if (e.pushModX(e.getCurrentModX()), e.numOpenGroups++, n === "(" && !e.captureGroup || n === "(?:") return {
      token: kn("group", n)
    };
    if (n === "(?>") return {
      token: kn("atomic", n)
    };
    if (n === "(?=" || n === "(?!" || n === "(?<=" || n === "(?<!") return {
      token: kn(n[2] === "<" ? "lookbehind" : "lookahead", n, {
        negate: n.endsWith("!")
      })
    };
    if (n === "(" && e.captureGroup || n.startsWith("(?<") && n.endsWith(">") || n.startsWith("(?'") && n.endsWith("'")) return {
      token: kn("capturing", n, {
        ...(n !== "(" && {
          name: n.slice(3, -1)
        })
      })
    };
    if (n.startsWith("(?~")) {
      if (n === "(?~|") throw new Error(`Unsupported absence function kind "${n}"`);
      return {
        token: kn("absence_repeater", n)
      };
    }
    throw n === "(?(" ? new Error(`Unsupported conditional "${n}"`) : new Error(`Invalid or unsupported group option "${n}"`);
  }
  if (n === ")") {
    if (e.popModX(), e.numOpenGroups--, e.numOpenGroups < 0) throw new Error('Unmatched ")"');
    return {
      token: Vh(n)
    };
  }
  if (e.getCurrentModX()) {
    if (n === "#") {
      const s = t.indexOf(`
`, r);
      return {
        lastIndex: s === -1 ? t.length : s
      };
    }
    if (/^\s$/.test(n)) {
      const s = /\s+/y;
      return s.lastIndex = r, {
        lastIndex: s.exec(t) ? s.lastIndex : r
      };
    }
  }
  if (n === ".") return {
    token: un("dot", n)
  };
  if (n === "^" || n === "$") {
    const s = e.singleline ? {
      "^": Re`\A`,
      $: Re`\Z`
    }[n] : n;
    return {
      token: Us(s, n)
    };
  }
  return n === "|" ? {
    token: jh(n)
  } : Qi.test(n) ? {
    tokens: sp(n)
  } : {
    token: zt(zn(n), n)
  };
}
function Oh(e, t, n) {
  const r = [Ws(t[1] === "^", t)];
  let a = 1,
    i;
  for (za.lastIndex = n; i = za.exec(e);) {
    const s = i[0];
    if (s[0] === "[" && s[1] !== ":") a++, r.push(Ws(s[1] === "^", s));else if (s === "]") {
      if (r.at(-1).type === "CharacterClassOpen") r.push(zt(93, s));else if (a--, r.push(Gh(s)), !a) break;
    } else {
      const o = qh(s);
      Array.isArray(o) ? r.push(...o) : r.push(o);
    }
  }
  return {
    tokens: r,
    lastIndex: za.lastIndex || e.length
  };
}
function qh(e) {
  if (e[0] === "\\") return e0(e, {
    inCharClass: !0
  });
  if (e[0] === "[") {
    const t = /\[:(?<negate>\^?)(?<name>[a-z]+):\]/.exec(e);
    if (!t || !Ki.has(t.groups.name)) throw new Error(`Invalid POSIX class "${e}"`);
    return un("posix", e, {
      value: t.groups.name,
      negate: !!t.groups.negate
    });
  }
  return e === "-" ? Hh(e) : e === "&&" ? Uh(e) : zt(zn(e), e);
}
function e0(e, {
  inCharClass: t
}) {
  const n = e[1];
  if (n === "c" || n === "C") return Qh(e);
  if ("dDhHsSwW".includes(n)) return tp(e);
  if (e.startsWith(Re`\o{`)) throw new Error(`Incomplete, invalid, or unsupported octal code point "${e}"`);
  if (/^\\[pP]\{/.test(e)) {
    if (e.length === 3) throw new Error(`Incomplete or invalid Unicode property "${e}"`);
    return np(e);
  }
  if (/^\\x[89A-Fa-f]\p{AHex}/u.test(e)) try {
    const r = e.split(/\\x/).slice(1).map(s => parseInt(s, 16)),
      a = new TextDecoder("utf-8", {
        ignoreBOM: !0,
        fatal: !0
      }).decode(new Uint8Array(r)),
      i = new TextEncoder();
    return [...a].map(s => {
      const o = [...i.encode(s)].map(l => `\\x${l.toString(16)}`).join("");
      return zt(zn(s), o);
    });
  } catch {
    throw new Error(`Multibyte code "${e}" incomplete or invalid in Oniguruma`);
  }
  if (n === "u" || n === "x") return zt(ap(e), e);
  if (Vs.has(n)) return zt(Vs.get(n), e);
  if (/\d/.test(n)) return Wh(t, e);
  if (e === "\\") throw new Error(Re`Incomplete escape "\"`);
  if (n === "M") throw new Error(`Unsupported meta "${e}"`);
  if ([...e].length === 2) return zt(e.codePointAt(1), e);
  throw new Error(`Unexpected escape "${e}"`);
}
function jh(e) {
  return {
    type: "Alternator",
    raw: e
  };
}
function Us(e, t) {
  return {
    type: "Assertion",
    kind: e,
    raw: t
  };
}
function t0(e) {
  return {
    type: "Backreference",
    raw: e
  };
}
function zt(e, t) {
  return {
    type: "Character",
    value: e,
    raw: t
  };
}
function Gh(e) {
  return {
    type: "CharacterClassClose",
    raw: e
  };
}
function Hh(e) {
  return {
    type: "CharacterClassHyphen",
    raw: e
  };
}
function Uh(e) {
  return {
    type: "CharacterClassIntersector",
    raw: e
  };
}
function Ws(e, t) {
  return {
    type: "CharacterClassOpen",
    negate: e,
    raw: t
  };
}
function un(e, t, n = {}) {
  return {
    type: "CharacterSet",
    kind: e,
    ...n,
    raw: t
  };
}
function n0(e, t, n = {}) {
  return e === "keep" ? {
    type: "Directive",
    kind: e,
    raw: t
  } : {
    type: "Directive",
    kind: e,
    flags: In(n.flags),
    raw: t
  };
}
function Wh(e, t) {
  return {
    type: "EscapedNumber",
    inCharClass: e,
    raw: t
  };
}
function Vh(e) {
  return {
    type: "GroupClose",
    raw: e
  };
}
function kn(e, t, n = {}) {
  return {
    type: "GroupOpen",
    kind: e,
    ...n,
    raw: t
  };
}
function Xh(e, t, n, r) {
  return {
    type: "NamedCallout",
    kind: e,
    tag: t,
    arguments: n,
    raw: r
  };
}
function Yh(e, t, n, r) {
  return {
    type: "Quantifier",
    kind: e,
    min: t,
    max: n,
    raw: r
  };
}
function Zh(e) {
  return {
    type: "Subroutine",
    raw: e
  };
}
const Kh = new Set(["COUNT", "CMP", "ERROR", "FAIL", "MAX", "MISMATCH", "SKIP", "TOTAL_COUNT"]),
  Vs = new Map([["a", 7], ["b", 8], ["e", 27], ["f", 12], ["n", 10], ["r", 13], ["t", 9], ["v", 11]]);
function Qh(e) {
  const t = e[1] === "c" ? e[2] : e[3];
  if (!t || !/[A-Za-z]/.test(t)) throw new Error(`Unsupported control character "${e}"`);
  return zt(zn(t.toUpperCase()) - 64, e);
}
function Jh(e, t) {
  let {
    on: n,
    off: r
  } = /^\(\?(?<on>[imx]*)(?:-(?<off>[-imx]*))?/.exec(e).groups;
  r ??= "";
  const a = (t.getCurrentModX() || n.includes("x")) && !r.includes("x"),
    i = Ys(n),
    s = Ys(r),
    o = {};
  if (i && (o.enable = i), s && (o.disable = s), e.endsWith(")")) return t.replaceCurrentModX(a), n0("flags", e, {
    flags: o
  });
  if (e.endsWith(":")) return t.pushModX(a), t.numOpenGroups++, kn("group", e, {
    ...((i || s) && {
      flags: o
    })
  });
  throw new Error(`Unexpected flag modifier "${e}"`);
}
function ep(e) {
  const t = /\(\*(?<name>[A-Za-z_]\w*)?(?:\[(?<tag>(?:[A-Za-z_]\w*)?)\])?(?:\{(?<args>[^}]*)\})?\)/.exec(e);
  if (!t) throw new Error(`Incomplete or invalid named callout "${e}"`);
  const {
    name: n,
    tag: r,
    args: a
  } = t.groups;
  if (!n) throw new Error(`Invalid named callout "${e}"`);
  if (r === "") throw new Error(`Named callout tag with empty value not allowed "${e}"`);
  const i = a ? a.split(",").filter(c => c !== "").map(c => /^[+-]?\d+$/.test(c) ? +c : c) : [],
    [s, o, l] = i,
    u = Kh.has(n) ? n.toLowerCase() : "custom";
  switch (u) {
    case "fail":
    case "mismatch":
    case "skip":
      if (i.length > 0) throw new Error(`Named callout arguments not allowed "${i}"`);
      break;
    case "error":
      if (i.length > 1) throw new Error(`Named callout allows only one argument "${i}"`);
      if (typeof s == "string") throw new Error(`Named callout argument must be a number "${s}"`);
      break;
    case "max":
      if (!i.length || i.length > 2) throw new Error(`Named callout must have one or two arguments "${i}"`);
      if (typeof s == "string" && !/^[A-Za-z_]\w*$/.test(s)) throw new Error(`Named callout argument one must be a tag or number "${s}"`);
      if (i.length === 2 && (typeof o == "number" || !/^[<>X]$/.test(o))) throw new Error(`Named callout optional argument two must be '<', '>', or 'X' "${o}"`);
      break;
    case "count":
    case "total_count":
      if (i.length > 1) throw new Error(`Named callout allows only one argument "${i}"`);
      if (i.length === 1 && (typeof s == "number" || !/^[<>X]$/.test(s))) throw new Error(`Named callout optional argument must be '<', '>', or 'X' "${s}"`);
      break;
    case "cmp":
      if (i.length !== 3) throw new Error(`Named callout must have three arguments "${i}"`);
      if (typeof s == "string" && !/^[A-Za-z_]\w*$/.test(s)) throw new Error(`Named callout argument one must be a tag or number "${s}"`);
      if (typeof o == "number" || !/^(?:[<>!=]=|[<>])$/.test(o)) throw new Error(`Named callout argument two must be '==', '!=', '>', '<', '>=', or '<=' "${o}"`);
      if (typeof l == "string" && !/^[A-Za-z_]\w*$/.test(l)) throw new Error(`Named callout argument three must be a tag or number "${l}"`);
      break;
    case "custom":
      throw new Error(`Undefined callout name "${n}"`);
    default:
      throw new Error(`Unexpected named callout kind "${u}"`);
  }
  return Xh(u, r ?? null, a?.split(",") ?? null, e);
}
function Xs(e) {
  let t = null,
    n,
    r;
  if (e[0] === "{") {
    const {
        minStr: a,
        maxStr: i
      } = /^\{(?<minStr>\d*)(?:,(?<maxStr>\d*))?/.exec(e).groups,
      s = 1e5;
    if (+a > s || i && +i > s) throw new Error("Quantifier value unsupported in Oniguruma");
    if (n = +a, r = i === void 0 ? +a : i === "" ? 1 / 0 : +i, n > r && (t = "possessive", [n, r] = [r, n]), e.endsWith("?")) {
      if (t === "possessive") throw new Error('Unsupported possessive interval quantifier chain with "?"');
      t = "lazy";
    } else t || (t = "greedy");
  } else n = e[0] === "+" ? 1 : 0, r = e[0] === "?" ? 1 : 1 / 0, t = e[1] === "+" ? "possessive" : e[1] === "?" ? "lazy" : "greedy";
  return Yh(t, n, r, e);
}
function tp(e) {
  const t = e[1].toLowerCase();
  return un({
    d: "digit",
    h: "hex",
    s: "space",
    w: "word"
  }[t], e, {
    negate: e[1] !== t
  });
}
function np(e) {
  const {
    p: t,
    neg: n,
    value: r
  } = /^\\(?<p>[pP])\{(?<neg>\^?)(?<value>[^}]+)/.exec(e).groups;
  return un("property", e, {
    value: r,
    negate: t === "P" && !n || t === "p" && !!n
  });
}
function Ys(e) {
  const t = {};
  return e.includes("i") && (t.ignoreCase = !0), e.includes("m") && (t.dotAll = !0), e.includes("x") && (t.extended = !0), Object.keys(t).length ? t : null;
}
function rp(e) {
  const t = {
    ignoreCase: !1,
    dotAll: !1,
    extended: !1,
    digitIsAscii: !1,
    posixIsAscii: !1,
    spaceIsAscii: !1,
    wordIsAscii: !1,
    textSegmentMode: null
  };
  for (let n = 0; n < e.length; n++) {
    const r = e[n];
    if (!"imxDPSWy".includes(r)) throw new Error(`Invalid flag "${r}"`);
    if (r === "y") {
      if (!/^y{[gw]}/.test(e.slice(n))) throw new Error('Invalid or unspecified flag "y" mode');
      t.textSegmentMode = e[n + 2] === "g" ? "grapheme" : "word", n += 3;
      continue;
    }
    t[{
      i: "ignoreCase",
      m: "dotAll",
      x: "extended",
      D: "digitIsAscii",
      P: "posixIsAscii",
      S: "spaceIsAscii",
      W: "wordIsAscii"
    }[r]] = !0;
  }
  return t;
}
function ap(e) {
  if (/^(?:\\u(?!\p{AHex}{4})|\\x(?!\p{AHex}{1,2}|\{\p{AHex}{1,8}\}))/u.test(e)) throw new Error(`Incomplete or invalid escape "${e}"`);
  const t = e[2] === "{" ? /^\\x\{\s*(?<hex>\p{AHex}+)/u.exec(e).groups.hex : e.slice(2);
  return parseInt(t, 16);
}
function ip(e, t) {
  const {
      raw: n,
      inCharClass: r
    } = e,
    a = n.slice(1);
  if (!r && (a !== "0" && a.length === 1 || a[0] !== "0" && +a <= t)) return [t0(n)];
  const i = [],
    s = a.match(/^[0-7]+|\d/g);
  for (let o = 0; o < s.length; o++) {
    const l = s[o];
    let u;
    if (o === 0 && l !== "8" && l !== "9") {
      if (u = parseInt(l, 8), u > 127) throw new Error(Re`Octal encoded byte above 177 unsupported "${n}"`);
    } else u = zn(l);
    i.push(zt(u, (o === 0 ? "\\" : "") + l));
  }
  return i;
}
function sp(e) {
  const t = [],
    n = new RegExp(Qi, "gy");
  let r;
  for (; r = n.exec(e);) {
    const a = r[0];
    if (a[0] === "{") {
      const i = /^\{(?<min>\d+),(?<max>\d+)\}\??$/.exec(a);
      if (i) {
        const {
          min: s,
          max: o
        } = i.groups;
        if (+s > +o && a.endsWith("?")) {
          n.lastIndex--, t.push(Xs(a.slice(0, -1)));
          continue;
        }
      }
    }
    t.push(Xs(a));
  }
  return t;
}
function r0(e, t) {
  if (!Array.isArray(e.body)) throw new Error("Expected node with body array");
  if (e.body.length !== 1) return !1;
  const n = e.body[0];
  return !t || Object.keys(t).every(r => t[r] === n[r]);
}
function op(e) {
  return lp.has(e.type);
}
const lp = new Set(["AbsenceFunction", "Backreference", "CapturingGroup", "Character", "CharacterClass", "CharacterSet", "Group", "Quantifier", "Subroutine"]);
function a0(e, t = {}) {
  const n = {
      flags: "",
      normalizeUnknownPropertyNames: !1,
      skipBackrefValidation: !1,
      skipLookbehindValidation: !1,
      skipPropertyNameValidation: !1,
      unicodePropertyMap: null,
      ...t,
      rules: {
        captureGroup: !1,
        singleline: !1,
        ...t.rules
      }
    },
    r = Fh(e, {
      flags: n.flags,
      rules: {
        captureGroup: n.rules.captureGroup,
        singleline: n.rules.singleline
      }
    }),
    a = (f, d) => {
      const b = r.tokens[i.nextIndex];
      switch (i.parent = f, i.nextIndex++, b.type) {
        case "Alternator":
          return hn();
        case "Assertion":
          return up(b);
        case "Backreference":
          return cp(b, i);
        case "Character":
          return ia(b.value, {
            useLastValid: !!d.isCheckingRangeEnd
          });
        case "CharacterClassHyphen":
          return mp(b, i, d);
        case "CharacterClassOpen":
          return hp(b, i, d);
        case "CharacterSet":
          return pp(b, i);
        case "Directive":
          return vp(b.kind, {
            flags: b.flags
          });
        case "GroupOpen":
          return dp(b, i, d);
        case "NamedCallout":
          return xp(b.kind, b.tag, b.arguments);
        case "Quantifier":
          return fp(b, i);
        case "Subroutine":
          return gp(b, i);
        default:
          throw new Error(`Unexpected token type "${b.type}"`);
      }
    },
    i = {
      capturingGroups: [],
      hasNumberedRef: !1,
      namedGroupsByName: new Map(),
      nextIndex: 0,
      normalizeUnknownPropertyNames: n.normalizeUnknownPropertyNames,
      parent: null,
      skipBackrefValidation: n.skipBackrefValidation,
      skipLookbehindValidation: n.skipLookbehindValidation,
      skipPropertyNameValidation: n.skipPropertyNameValidation,
      subroutines: [],
      tokens: r.tokens,
      unicodePropertyMap: n.unicodePropertyMap,
      walk: a
    },
    s = _p(wp(r.flags));
  let o = s.body[0];
  for (; i.nextIndex < r.tokens.length;) {
    const f = a(o, {});
    f.type === "Alternative" ? (s.body.push(f), o = f) : o.body.push(f);
  }
  const {
    capturingGroups: l,
    hasNumberedRef: u,
    namedGroupsByName: c,
    subroutines: h
  } = i;
  if (u && c.size && !n.rules.captureGroup) throw new Error("Numbered backref/subroutine not allowed when using named capture");
  for (const {
    ref: f
  } of h) if (typeof f == "number") {
    if (f > l.length) throw new Error("Subroutine uses a group number that's not defined");
    f && (l[f - 1].isSubroutined = !0);
  } else if (c.has(f)) {
    if (c.get(f).length > 1) throw new Error(Re`Subroutine uses a duplicate group name "\g<${f}>"`);
    c.get(f)[0].isSubroutined = !0;
  } else throw new Error(Re`Subroutine uses a group name that's not defined "\g<${f}>"`);
  return s;
}
function up({
  kind: e
}) {
  return gi(In({
    "^": "line_start",
    $: "line_end",
    "\\A": "string_start",
    "\\b": "word_boundary",
    "\\B": "word_boundary",
    "\\G": "search_start",
    "\\y": "text_segment_boundary",
    "\\Y": "text_segment_boundary",
    "\\z": "string_end",
    "\\Z": "string_end_newline"
  }[e], `Unexpected assertion kind "${e}"`), {
    negate: e === Re`\B` || e === Re`\Y`
  });
}
function cp({
  raw: e
}, t) {
  const n = /^\\k[<']/.test(e),
    r = n ? e.slice(3, -1) : e.slice(1),
    a = (i, s = !1) => {
      const o = t.capturingGroups.length;
      let l = !1;
      if (i > o) if (t.skipBackrefValidation) l = !0;else throw new Error(`Not enough capturing groups defined to the left "${e}"`);
      return t.hasNumberedRef = !0, bi(s ? o + 1 - i : i, {
        orphan: l
      });
    };
  if (n) {
    const i = /^(?<sign>-?)0*(?<num>[1-9]\d*)$/.exec(r);
    if (i) return a(+i.groups.num, !!i.groups.sign);
    if (/[-+]/.test(r)) throw new Error(`Invalid backref name "${e}"`);
    if (!t.namedGroupsByName.has(r)) throw new Error(`Group name not defined to the left "${e}"`);
    return bi(r);
  }
  return a(+r);
}
function mp(e, t, n) {
  const {
      tokens: r,
      walk: a
    } = t,
    i = t.parent,
    s = i.body.at(-1),
    o = r[t.nextIndex];
  if (!n.isCheckingRangeEnd && s && s.type !== "CharacterClass" && s.type !== "CharacterClassRange" && o && o.type !== "CharacterClassOpen" && o.type !== "CharacterClassClose" && o.type !== "CharacterClassIntersector") {
    const l = a(i, {
      ...n,
      isCheckingRangeEnd: !0
    });
    if (s.type === "Character" && l.type === "Character") return i.body.pop(), yp(s, l);
    throw new Error("Invalid character class range");
  }
  return ia(zn("-"));
}
function hp({
  negate: e
}, t, n) {
  const {
      tokens: r,
      walk: a
    } = t,
    i = [Nr()],
    s = r[t.nextIndex];
  let o = Qs(s);
  for (; o.type !== "CharacterClassClose";) {
    if (o.type === "CharacterClassIntersector") i.push(Nr()), t.nextIndex++;else {
      const u = i.at(-1);
      u.body.push(a(u, n));
    }
    o = Qs(r[t.nextIndex], s);
  }
  const l = Nr({
    negate: e
  });
  return i.length === 1 ? l.body = i[0].body : (l.kind = "intersection", l.body = i.map(u => u.body.length === 1 ? u.body[0] : u)), t.nextIndex++, l;
}
function pp({
  kind: e,
  negate: t,
  value: n
}, r) {
  const {
    normalizeUnknownPropertyNames: a,
    skipPropertyNameValidation: i,
    unicodePropertyMap: s
  } = r;
  if (e === "property") {
    const o = sa(n);
    if (Ki.has(o) && !s?.has(o)) e = "posix", n = o;else return _n(n, {
      negate: t,
      normalizeUnknownPropertyNames: a,
      skipPropertyNameValidation: i,
      unicodePropertyMap: s
    });
  }
  return e === "posix" ? kp(n, {
    negate: t
  }) : yi(e, {
    negate: t
  });
}
function dp(e, t, n) {
  const {
      tokens: r,
      capturingGroups: a,
      namedGroupsByName: i,
      skipLookbehindValidation: s,
      walk: o
    } = t,
    l = $p(e),
    u = l.type === "AbsenceFunction",
    c = Ks(l),
    h = c && l.negate;
  if (l.type === "CapturingGroup" && (a.push(l), l.name && Lh(i, l.name, []).push(l)), u && n.isInAbsenceFunction) throw new Error("Nested absence function not supported by Oniguruma");
  let f = Js(r[t.nextIndex]);
  for (; f.type !== "GroupClose";) {
    if (f.type === "Alternator") l.body.push(hn()), t.nextIndex++;else {
      const d = l.body.at(-1),
        b = o(d, {
          ...n,
          isInAbsenceFunction: n.isInAbsenceFunction || u,
          isInLookbehind: n.isInLookbehind || c,
          isInNegLookbehind: n.isInNegLookbehind || h
        });
      if (d.body.push(b), (c || n.isInLookbehind) && !s) {
        const k = "Lookbehind includes a pattern not allowed by Oniguruma";
        if (h || n.isInNegLookbehind) {
          if (Zs(b) || b.type === "CapturingGroup") throw new Error(k);
        } else if (Zs(b) || Ks(b) && b.negate) throw new Error(k);
      }
    }
    f = Js(r[t.nextIndex]);
  }
  return t.nextIndex++, l;
}
function fp({
  kind: e,
  min: t,
  max: n
}, r) {
  const a = r.parent,
    i = a.body.at(-1);
  if (!i || !op(i)) throw new Error("Quantifier requires a repeatable token");
  const s = s0(e, t, n, i);
  return a.body.pop(), s;
}
function gp({
  raw: e
}, t) {
  const {
    capturingGroups: n,
    subroutines: r
  } = t;
  let a = e.slice(3, -1);
  const i = /^(?<sign>[-+]?)0*(?<num>[1-9]\d*)$/.exec(a);
  if (i) {
    const o = +i.groups.num,
      l = n.length;
    if (t.hasNumberedRef = !0, a = {
      "": o,
      "+": l + o,
      "-": l + 1 - o
    }[i.groups.sign], a < 1) throw new Error("Invalid subroutine number");
  } else a === "0" && (a = 0);
  const s = o0(a);
  return r.push(s), s;
}
function bp(e, t) {
  return {
    type: "AbsenceFunction",
    kind: e,
    body: sr(t?.body)
  };
}
function hn(e) {
  return {
    type: "Alternative",
    body: l0(e?.body)
  };
}
function gi(e, t) {
  const n = {
    type: "Assertion",
    kind: e
  };
  return (e === "word_boundary" || e === "text_segment_boundary") && (n.negate = !!t?.negate), n;
}
function bi(e, t) {
  const n = !!t?.orphan;
  return {
    type: "Backreference",
    ref: e,
    ...(n && {
      orphan: n
    })
  };
}
function i0(e, t) {
  const n = {
    name: void 0,
    isSubroutined: !1,
    ...t
  };
  if (n.name !== void 0 && !Cp(n.name)) throw new Error(`Group name "${n.name}" invalid in Oniguruma`);
  return {
    type: "CapturingGroup",
    number: e,
    ...(n.name && {
      name: n.name
    }),
    ...(n.isSubroutined && {
      isSubroutined: n.isSubroutined
    }),
    body: sr(t?.body)
  };
}
function ia(e, t) {
  const n = {
    useLastValid: !1,
    ...t
  };
  if (e > 1114111) {
    const r = e.toString(16);
    if (n.useLastValid) e = 1114111;else throw e > 1310719 ? new Error(`Invalid code point out of range "\\x{${r}}"`) : new Error(`Invalid code point out of range in JS "\\x{${r}}"`);
  }
  return {
    type: "Character",
    value: e
  };
}
function Nr(e) {
  const t = {
    kind: "union",
    negate: !1,
    ...e
  };
  return {
    type: "CharacterClass",
    kind: t.kind,
    negate: t.negate,
    body: l0(e?.body)
  };
}
function yp(e, t) {
  if (t.value < e.value) throw new Error("Character class range out of order");
  return {
    type: "CharacterClassRange",
    min: e,
    max: t
  };
}
function yi(e, t) {
  const n = !!t?.negate,
    r = {
      type: "CharacterSet",
      kind: e
    };
  return (e === "digit" || e === "hex" || e === "newline" || e === "space" || e === "word") && (r.negate = n), (e === "text_segment" || e === "newline" && !n) && (r.variableLength = !0), r;
}
function vp(e, t = {}) {
  if (e === "keep") return {
    type: "Directive",
    kind: e
  };
  if (e === "flags") return {
    type: "Directive",
    kind: e,
    flags: In(t.flags)
  };
  throw new Error(`Unexpected directive kind "${e}"`);
}
function wp(e) {
  return {
    type: "Flags",
    ...e
  };
}
function pt(e) {
  const t = e?.atomic,
    n = e?.flags;
  if (t && n) throw new Error("Atomic group cannot have flags");
  return {
    type: "Group",
    ...(t && {
      atomic: t
    }),
    ...(n && {
      flags: n
    }),
    body: sr(e?.body)
  };
}
function sn(e) {
  const t = {
    behind: !1,
    negate: !1,
    ...e
  };
  return {
    type: "LookaroundAssertion",
    kind: t.behind ? "lookbehind" : "lookahead",
    negate: t.negate,
    body: sr(e?.body)
  };
}
function xp(e, t, n) {
  return {
    type: "NamedCallout",
    kind: e,
    tag: t,
    arguments: n
  };
}
function kp(e, t) {
  const n = !!t?.negate;
  if (!Ki.has(e)) throw new Error(`Invalid POSIX class "${e}"`);
  return {
    type: "CharacterSet",
    kind: "posix",
    value: e,
    negate: n
  };
}
function s0(e, t, n, r) {
  if (t > n) throw new Error("Invalid reversed quantifier range");
  return {
    type: "Quantifier",
    kind: e,
    min: t,
    max: n,
    body: r
  };
}
function _p(e, t) {
  return {
    type: "Regex",
    body: sr(t?.body),
    flags: e
  };
}
function o0(e) {
  return {
    type: "Subroutine",
    ref: e
  };
}
function _n(e, t) {
  const n = {
    negate: !1,
    normalizeUnknownPropertyNames: !1,
    skipPropertyNameValidation: !1,
    unicodePropertyMap: null,
    ...t
  };
  let r = n.unicodePropertyMap?.get(sa(e));
  if (!r) {
    if (n.normalizeUnknownPropertyNames) r = Sp(e);else if (n.unicodePropertyMap && !n.skipPropertyNameValidation) throw new Error(Re`Invalid Unicode property "\p{${e}}"`);
  }
  return {
    type: "CharacterSet",
    kind: "property",
    value: r ?? e,
    negate: n.negate
  };
}
function $p({
  flags: e,
  kind: t,
  name: n,
  negate: r,
  number: a
}) {
  switch (t) {
    case "absence_repeater":
      return bp("repeater");
    case "atomic":
      return pt({
        atomic: !0
      });
    case "capturing":
      return i0(a, {
        name: n
      });
    case "group":
      return pt({
        flags: e
      });
    case "lookahead":
    case "lookbehind":
      return sn({
        behind: t === "lookbehind",
        negate: r
      });
    default:
      throw new Error(`Unexpected group kind "${t}"`);
  }
}
function sr(e) {
  if (e === void 0) e = [hn()];else if (!Array.isArray(e) || !e.length || !e.every(t => t.type === "Alternative")) throw new Error("Invalid body; expected array of one or more Alternative nodes");
  return e;
}
function l0(e) {
  if (e === void 0) e = [];else if (!Array.isArray(e) || !e.every(t => !!t.type)) throw new Error("Invalid body; expected array of nodes");
  return e;
}
function Zs(e) {
  return e.type === "LookaroundAssertion" && e.kind === "lookahead";
}
function Ks(e) {
  return e.type === "LookaroundAssertion" && e.kind === "lookbehind";
}
function Cp(e) {
  return /^[\p{Alpha}\p{Pc}][^)]*$/u.test(e);
}
function Sp(e) {
  return e.trim().replace(/[- _]+/g, "_").replace(/[A-Z][a-z]+(?=[A-Z])/g, "$&_").replace(/[A-Za-z]+/g, t => t[0].toUpperCase() + t.slice(1).toLowerCase());
}
function sa(e) {
  return e.replace(/[- _]+/g, "").toLowerCase();
}
function Qs(e, t) {
  const n = t;
  return In(e, `Unclosed character class${n?.type === "Character" && n.value === 93 && n.raw === "]" ? ' (started with "]")' : ""}`);
}
function Js(e) {
  return In(e, "Unclosed group");
}
function Un(e, t, n = null) {
  function r(i, s) {
    for (let o = 0; o < i.length; o++) {
      const l = a(i[o], s, o, i);
      o = Math.max(-1, o + l);
    }
  }
  function a(i, s = null, o = null, l = null) {
    let u = 0,
      c = !1;
    const h = {
        node: i,
        parent: s,
        key: o,
        container: l,
        root: e,
        remove() {
          xr(l).splice(Math.max(0, vn(o) + u), 1), u--, c = !0;
        },
        removeAllNextSiblings() {
          return xr(l).splice(vn(o) + 1);
        },
        removeAllPrevSiblings() {
          const w = vn(o) + u;
          return u -= w, xr(l).splice(0, Math.max(0, w));
        },
        replaceWith(w, _ = {}) {
          const T = !!_.traverse;
          l ? l[Math.max(0, vn(o) + u)] = w : In(s, "Can't replace root node")[o] = w, T && a(w, s, o, l), c = !0;
        },
        replaceWithMultiple(w, _ = {}) {
          const T = !!_.traverse;
          if (xr(l).splice(Math.max(0, vn(o) + u), 1, ...w), u += w.length - 1, T) {
            let I = 0;
            for (let R = 0; R < w.length; R++) I += a(w[R], s, vn(o) + R + I, l);
          }
          c = !0;
        },
        skip() {
          c = !0;
        }
      },
      {
        type: f
      } = i,
      d = t["*"],
      b = t[f],
      k = typeof d == "function" ? d : d?.enter,
      A = typeof b == "function" ? b : b?.enter;
    if (k?.(h, n), A?.(h, n), !c) switch (f) {
      case "AbsenceFunction":
      case "Alternative":
      case "CapturingGroup":
      case "CharacterClass":
      case "Group":
      case "LookaroundAssertion":
        r(i.body, i);
        break;
      case "Assertion":
      case "Backreference":
      case "Character":
      case "CharacterSet":
      case "Directive":
      case "Flags":
      case "NamedCallout":
      case "Subroutine":
        break;
      case "CharacterClassRange":
        a(i.min, i, "min"), a(i.max, i, "max");
        break;
      case "Quantifier":
        a(i.body, i, "body");
        break;
      case "Regex":
        r(i.body, i), a(i.flags, i, "flags");
        break;
      default:
        throw new Error(`Unexpected node type "${f}"`);
    }
    return b?.exit?.(h, n), d?.exit?.(h, n), u;
  }
  return a(e), e;
}
function xr(e) {
  if (!Array.isArray(e)) throw new Error("Container expected");
  return e;
}
function vn(e) {
  if (typeof e != "number") throw new Error("Numeric key expected");
  return e;
}
const Ap = String.raw`\(\?(?:[:=!>A-Za-z\-]|<[=!]|\(DEFINE\))`;
function Tp(e, t) {
  for (let n = 0; n < e.length; n++) e[n] >= t && e[n]++;
}
function Ep(e, t, n, r) {
  return e.slice(0, t) + r + e.slice(t + n.length);
}
const lt = Object.freeze({
  DEFAULT: "DEFAULT",
  CHAR_CLASS: "CHAR_CLASS"
});
function Ji(e, t, n, r) {
  const a = new RegExp(String.raw`${t}|(?<$skip>\[\^?|\\?.)`, "gsu"),
    i = [!1];
  let s = 0,
    o = "";
  for (const l of e.matchAll(a)) {
    const {
      0: u,
      groups: {
        $skip: c
      }
    } = l;
    if (!c && (!r || r === lt.DEFAULT == !s)) {
      n instanceof Function ? o += n(l, {
        context: s ? lt.CHAR_CLASS : lt.DEFAULT,
        negated: i[i.length - 1]
      }) : o += n;
      continue;
    }
    u[0] === "[" ? (s++, i.push(u[1] === "^")) : u === "]" && s && (s--, i.pop()), o += u;
  }
  return o;
}
function u0(e, t, n, r) {
  Ji(e, t, n, r);
}
function Mp(e, t, n = 0, r) {
  if (!new RegExp(t, "su").test(e)) return null;
  const a = new RegExp(`${t}|(?<$skip>\\\\?.)`, "gsu");
  a.lastIndex = n;
  let i = 0,
    s;
  for (; s = a.exec(e);) {
    const {
      0: o,
      groups: {
        $skip: l
      }
    } = s;
    if (!l && (!r || r === lt.DEFAULT == !i)) return s;
    o === "[" ? i++ : o === "]" && i && i--, a.lastIndex == s.index && a.lastIndex++;
  }
  return null;
}
function kr(e, t, n) {
  return !!Mp(e, t, 0, n);
}
function zp(e, t) {
  const n = /\\?./gsu;
  n.lastIndex = t;
  let r = e.length,
    a = 0,
    i = 1,
    s;
  for (; s = n.exec(e);) {
    const [o] = s;
    if (o === "[") a++;else if (a) o === "]" && a--;else if (o === "(") i++;else if (o === ")" && (i--, !i)) {
      r = s.index;
      break;
    }
  }
  return e.slice(t, r);
}
const eo = new RegExp(String.raw`(?<noncapturingStart>${Ap})|(?<capturingStart>\((?:\?<[^>]+>)?)|\\?.`, "gsu");
function Ip(e, t) {
  const n = t?.hiddenCaptures ?? [];
  let r = t?.captureTransfers ?? new Map();
  if (!/\(\?>/.test(e)) return {
    pattern: e,
    captureTransfers: r,
    hiddenCaptures: n
  };
  const a = "(?>",
    i = "(?:(?=(",
    s = [0],
    o = [];
  let l = 0,
    u = 0,
    c = NaN,
    h;
  do {
    h = !1;
    let f = 0,
      d = 0,
      b = !1,
      k;
    for (eo.lastIndex = Number.isNaN(c) ? 0 : c + i.length; k = eo.exec(e);) {
      const {
        0: A,
        index: w,
        groups: {
          capturingStart: _,
          noncapturingStart: T
        }
      } = k;
      if (A === "[") f++;else if (f) A === "]" && f--;else if (A === a && !b) c = w, b = !0;else if (b && T) d++;else if (_) b ? d++ : (l++, s.push(l + u));else if (A === ")" && b) {
        if (!d) {
          u++;
          const I = l + u;
          if (e = `${e.slice(0, c)}${i}${e.slice(c + a.length, w)}))<$$${I}>)${e.slice(w + 1)}`, h = !0, o.push(I), Tp(n, I), r.size) {
            const R = new Map();
            r.forEach((E, O) => {
              R.set(O >= I ? O + 1 : O, E.map(W => W >= I ? W + 1 : W));
            }), r = R;
          }
          break;
        }
        d--;
      }
    }
  } while (h);
  return n.push(...o), e = Ji(e, String.raw`\\(?<backrefNum>[1-9]\d*)|<\$\$(?<wrappedBackrefNum>\d+)>`, ({
    0: f,
    groups: {
      backrefNum: d,
      wrappedBackrefNum: b
    }
  }) => {
    if (d) {
      const k = +d;
      if (k > s.length - 1) throw new Error(`Backref "${f}" greater than number of captures`);
      return `\\${s[k]}`;
    }
    return `\\${b}`;
  }, lt.DEFAULT), {
    pattern: e,
    captureTransfers: r,
    hiddenCaptures: n
  };
}
const c0 = String.raw`(?:[?*+]|\{\d+(?:,\d*)?\})`,
  Ia = new RegExp(String.raw`
\\(?: \d+
  | c[A-Za-z]
  | [gk]<[^>]+>
  | [pPu]\{[^\}]+\}
  | u[A-Fa-f\d]{4}
  | x[A-Fa-f\d]{2}
  )
| \((?: \? (?: [:=!>]
  | <(?:[=!]|[^>]+>)
  | [A-Za-z\-]+:
  | \(DEFINE\)
  ))?
| (?<qBase>${c0})(?<qMod>[?+]?)(?<invalidQ>[?*+\{]?)
| \\?.
`.replace(/\s+/g, ""), "gsu");
function Np(e) {
  if (!new RegExp(`${c0}\\+`).test(e)) return {
    pattern: e
  };
  const t = [];
  let n = null,
    r = null,
    a = "",
    i = 0,
    s;
  for (Ia.lastIndex = 0; s = Ia.exec(e);) {
    const {
      0: o,
      index: l,
      groups: {
        qBase: u,
        qMod: c,
        invalidQ: h
      }
    } = s;
    if (o === "[") i || (r = l), i++;else if (o === "]") i ? i-- : r = null;else if (!i) if (c === "+" && a && !a.startsWith("(")) {
      if (h) throw new Error(`Invalid quantifier "${o}"`);
      let f = -1;
      if (/^\{\d+\}$/.test(u)) e = Ep(e, l + u.length, c, "");else {
        if (a === ")" || a === "]") {
          const d = a === ")" ? n : r;
          if (d === null) throw new Error(`Invalid unmatched "${a}"`);
          e = `${e.slice(0, d)}(?>${e.slice(d, l)}${u})${e.slice(l + o.length)}`;
        } else e = `${e.slice(0, l - a.length)}(?>${a}${u})${e.slice(l + o.length)}`;
        f += 4;
      }
      Ia.lastIndex += f;
    } else o[0] === "(" ? t.push(l) : o === ")" && (n = t.length ? t.pop() : null);
    a = o;
  }
  return {
    pattern: e
  };
}
const ot = String.raw,
  Rp = ot`\\g<(?<gRNameOrNum>[^>&]+)&R=(?<gRDepth>[^>]+)>`,
  vi = ot`\(\?R=(?<rDepth>[^\)]+)\)|${Rp}`,
  oa = ot`\(\?<(?![=!])(?<captureName>[^>]+)>`,
  m0 = ot`${oa}|(?<unnamed>\()(?!\?)`,
  en = new RegExp(ot`${oa}|${vi}|\(\?|\\?.`, "gsu"),
  Na = "Cannot use multiple overlapping recursions";
function Bp(e, t) {
  const {
    hiddenCaptures: n,
    mode: r
  } = {
    hiddenCaptures: [],
    mode: "plugin",
    ...t
  };
  let a = t?.captureTransfers ?? new Map();
  if (!new RegExp(vi, "su").test(e)) return {
    pattern: e,
    captureTransfers: a,
    hiddenCaptures: n
  };
  if (r === "plugin" && kr(e, ot`\(\?\(DEFINE\)`, lt.DEFAULT)) throw new Error("DEFINE groups cannot be used with recursion");
  const i = [],
    s = kr(e, ot`\\[1-9]`, lt.DEFAULT),
    o = new Map(),
    l = [];
  let u = !1,
    c = 0,
    h = 0,
    f;
  for (en.lastIndex = 0; f = en.exec(e);) {
    const {
      0: d,
      groups: {
        captureName: b,
        rDepth: k,
        gRNameOrNum: A,
        gRDepth: w
      }
    } = f;
    if (d === "[") c++;else if (c) d === "]" && c--;else if (k) {
      if (to(k), u) throw new Error(Na);
      if (s) throw new Error(`${r === "external" ? "Backrefs" : "Numbered backrefs"} cannot be used with global recursion`);
      const _ = e.slice(0, f.index),
        T = e.slice(en.lastIndex);
      if (kr(T, vi, lt.DEFAULT)) throw new Error(Na);
      const I = +k - 1;
      e = no(_, T, I, !1, n, i, h), a = ao(a, _, I, i.length, 0, h);
      break;
    } else if (A) {
      to(w);
      let _ = !1;
      for (const q of l) if (q.name === A || q.num === +A) {
        if (_ = !0, q.hasRecursedWithin) throw new Error(Na);
        break;
      }
      if (!_) throw new Error(ot`Recursive \g cannot be used outside the referenced group "${r === "external" ? A : ot`\g<${A}&R=${w}>`}"`);
      const T = o.get(A),
        I = zp(e, T);
      if (s && kr(I, ot`${oa}|\((?!\?)`, lt.DEFAULT)) throw new Error(`${r === "external" ? "Backrefs" : "Numbered backrefs"} cannot be used with recursion of capturing groups`);
      const R = e.slice(T, f.index),
        E = I.slice(R.length + d.length),
        O = i.length,
        W = +w - 1,
        G = no(R, E, W, !0, n, i, h);
      a = ao(a, R, W, i.length - O, O, h);
      const M = e.slice(0, T),
        H = e.slice(T + I.length);
      e = `${M}${G}${H}`, en.lastIndex += G.length - d.length - R.length - E.length, l.forEach(q => q.hasRecursedWithin = !0), u = !0;
    } else if (b) h++, o.set(String(h), en.lastIndex), o.set(b, en.lastIndex), l.push({
      num: h,
      name: b
    });else if (d[0] === "(") {
      const _ = d === "(";
      _ && (h++, o.set(String(h), en.lastIndex)), l.push(_ ? {
        num: h
      } : {});
    } else d === ")" && l.pop();
  }
  return n.push(...i), {
    pattern: e,
    captureTransfers: a,
    hiddenCaptures: n
  };
}
function to(e) {
  const t = `Max depth must be integer between 2 and 100; used ${e}`;
  if (!/^[1-9]\d*$/.test(e)) throw new Error(t);
  if (e = +e, e < 2 || e > 100) throw new Error(t);
}
function no(e, t, n, r, a, i, s) {
  const o = new Set();
  r && u0(e + t, oa, ({
    groups: {
      captureName: u
    }
  }) => {
    o.add(u);
  }, lt.DEFAULT);
  const l = [n, r ? o : null, a, i, s];
  return `${e}${ro(`(?:${e}`, "forward", ...l)}(?:)${ro(`${t})`, "backward", ...l)}${t}`;
}
function ro(e, t, n, r, a, i, s) {
  const l = c => t === "forward" ? c + 2 : n - c + 2 - 1;
  let u = "";
  for (let c = 0; c < n; c++) {
    const h = l(c);
    u += Ji(e, ot`${m0}|\\k<(?<backref>[^>]+)>`, ({
      0: f,
      groups: {
        captureName: d,
        unnamed: b,
        backref: k
      }
    }) => {
      if (k && r && !r.has(k)) return f;
      const A = `_$${h}`;
      if (b || d) {
        const w = s + i.length + 1;
        return i.push(w), Dp(a, w), b ? f : `(?<${d}${A}>`;
      }
      return ot`\k<${k}${A}>`;
    }, lt.DEFAULT);
  }
  return u;
}
function Dp(e, t) {
  for (let n = 0; n < e.length; n++) e[n] >= t && e[n]++;
}
function ao(e, t, n, r, a, i) {
  if (e.size && r) {
    let s = 0;
    u0(t, m0, () => s++, lt.DEFAULT);
    const o = i - s + a,
      l = new Map();
    return e.forEach((u, c) => {
      const h = (r - s * n) / n,
        f = s * n,
        d = c > o + s ? c + r : c,
        b = [];
      for (const k of u) if (k <= o) b.push(k);else if (k > o + s + h) b.push(k + r);else if (k <= o + s) for (let A = 0; A <= n; A++) b.push(k + s * A);else for (let A = 0; A <= n; A++) b.push(k + f + h * A);
      l.set(d, b);
    }), l;
  }
  return e;
}
var Me = String.fromCodePoint,
  te = String.raw,
  dt = {},
  la = globalThis.RegExp;
dt.flagGroups = (() => {
  try {
    new la("(?i:)");
  } catch {
    return !1;
  }
  return !0;
})();
dt.unicodeSets = (() => {
  try {
    new la("[[]]", "v");
  } catch {
    return !1;
  }
  return !0;
})();
dt.bugFlagVLiteralHyphenIsRange = dt.unicodeSets ? (() => {
  try {
    new la(te`[\d\-a]`, "v");
  } catch {
    return !0;
  }
  return !1;
})() : !1;
dt.bugNestedClassIgnoresNegation = dt.unicodeSets && new la("[[^a]]", "v").test("a");
function Yr(e, {
  enable: t,
  disable: n
}) {
  return {
    dotAll: !n?.dotAll && !!(t?.dotAll || e.dotAll),
    ignoreCase: !n?.ignoreCase && !!(t?.ignoreCase || e.ignoreCase)
  };
}
function Qn(e, t, n) {
  return e.has(t) || e.set(t, n), e.get(t);
}
function wi(e, t) {
  return io[e] >= io[t];
}
function Lp(e, t) {
  if (e == null) throw new Error(t ?? "Value expected");
  return e;
}
var io = {
    ES2025: 2025,
    ES2024: 2024,
    ES2018: 2018
  },
  Fp = {
    auto: "auto",
    ES2025: "ES2025",
    ES2024: "ES2024",
    ES2018: "ES2018"
  };
function h0(e = {}) {
  if ({}.toString.call(e) !== "[object Object]") throw new Error("Unexpected options");
  if (e.target !== void 0 && !Fp[e.target]) throw new Error(`Unexpected target "${e.target}"`);
  const t = {
    accuracy: "default",
    avoidSubclass: !1,
    flags: "",
    global: !1,
    hasIndices: !1,
    lazyCompileLength: 1 / 0,
    target: "auto",
    verbose: !1,
    ...e,
    rules: {
      allowOrphanBackrefs: !1,
      asciiWordBoundaries: !1,
      captureGroup: !1,
      recursionLimit: 20,
      singleline: !1,
      ...e.rules
    }
  };
  return t.target === "auto" && (t.target = dt.flagGroups ? "ES2025" : dt.unicodeSets ? "ES2024" : "ES2018"), t;
}
var Pp = "[	-\r ]",
  Op = new Set([Me(304), Me(305)]),
  At = te`[\p{L}\p{M}\p{N}\p{Pc}]`;
function p0(e) {
  if (Op.has(e)) return [e];
  const t = new Set(),
    n = e.toLowerCase(),
    r = n.toUpperCase(),
    a = Gp.get(n),
    i = qp.get(n),
    s = jp.get(n);
  return [...r].length === 1 && t.add(r), s && t.add(s), a && t.add(a), t.add(n), i && t.add(i), [...t];
}
var es = new Map(`C Other
Cc Control cntrl
Cf Format
Cn Unassigned
Co Private_Use
Cs Surrogate
L Letter
LC Cased_Letter
Ll Lowercase_Letter
Lm Modifier_Letter
Lo Other_Letter
Lt Titlecase_Letter
Lu Uppercase_Letter
M Mark Combining_Mark
Mc Spacing_Mark
Me Enclosing_Mark
Mn Nonspacing_Mark
N Number
Nd Decimal_Number digit
Nl Letter_Number
No Other_Number
P Punctuation punct
Pc Connector_Punctuation
Pd Dash_Punctuation
Pe Close_Punctuation
Pf Final_Punctuation
Pi Initial_Punctuation
Po Other_Punctuation
Ps Open_Punctuation
S Symbol
Sc Currency_Symbol
Sk Modifier_Symbol
Sm Math_Symbol
So Other_Symbol
Z Separator
Zl Line_Separator
Zp Paragraph_Separator
Zs Space_Separator
ASCII
ASCII_Hex_Digit AHex
Alphabetic Alpha
Any
Assigned
Bidi_Control Bidi_C
Bidi_Mirrored Bidi_M
Case_Ignorable CI
Cased
Changes_When_Casefolded CWCF
Changes_When_Casemapped CWCM
Changes_When_Lowercased CWL
Changes_When_NFKC_Casefolded CWKCF
Changes_When_Titlecased CWT
Changes_When_Uppercased CWU
Dash
Default_Ignorable_Code_Point DI
Deprecated Dep
Diacritic Dia
Emoji
Emoji_Component EComp
Emoji_Modifier EMod
Emoji_Modifier_Base EBase
Emoji_Presentation EPres
Extended_Pictographic ExtPict
Extender Ext
Grapheme_Base Gr_Base
Grapheme_Extend Gr_Ext
Hex_Digit Hex
IDS_Binary_Operator IDSB
IDS_Trinary_Operator IDST
ID_Continue IDC
ID_Start IDS
Ideographic Ideo
Join_Control Join_C
Logical_Order_Exception LOE
Lowercase Lower
Math
Noncharacter_Code_Point NChar
Pattern_Syntax Pat_Syn
Pattern_White_Space Pat_WS
Quotation_Mark QMark
Radical
Regional_Indicator RI
Sentence_Terminal STerm
Soft_Dotted SD
Terminal_Punctuation Term
Unified_Ideograph UIdeo
Uppercase Upper
Variation_Selector VS
White_Space space
XID_Continue XIDC
XID_Start XIDS`.split(/\s/).map(e => [sa(e), e])),
  qp = new Map([["s", Me(383)], [Me(383), "s"]]),
  jp = new Map([[Me(223), Me(7838)], [Me(107), Me(8490)], [Me(229), Me(8491)], [Me(969), Me(8486)]]),
  Gp = new Map([qt(453), qt(456), qt(459), qt(498), ...Ra(8072, 8079), ...Ra(8088, 8095), ...Ra(8104, 8111), qt(8124), qt(8140), qt(8188)]),
  Hp = new Map([["alnum", te`[\p{Alpha}\p{Nd}]`], ["alpha", te`\p{Alpha}`], ["ascii", te`\p{ASCII}`], ["blank", te`[\p{Zs}\t]`], ["cntrl", te`\p{Cc}`], ["digit", te`\p{Nd}`], ["graph", te`[\P{space}&&\P{Cc}&&\P{Cn}&&\P{Cs}]`], ["lower", te`\p{Lower}`], ["print", te`[[\P{space}&&\P{Cc}&&\P{Cn}&&\P{Cs}]\p{Zs}]`], ["punct", te`[\p{P}\p{S}]`], ["space", te`\p{space}`], ["upper", te`\p{Upper}`], ["word", te`[\p{Alpha}\p{M}\p{Nd}\p{Pc}]`], ["xdigit", te`\p{AHex}`]]);
function Up(e, t) {
  const n = [];
  for (let r = e; r <= t; r++) n.push(r);
  return n;
}
function qt(e) {
  const t = Me(e);
  return [t.toLowerCase(), t];
}
function Ra(e, t) {
  return Up(e, t).map(n => qt(n));
}
var d0 = new Set(["Lower", "Lowercase", "Upper", "Uppercase", "Ll", "Lowercase_Letter", "Lt", "Titlecase_Letter", "Lu", "Uppercase_Letter"]);
function Wp(e, t) {
  const n = {
    accuracy: "default",
    asciiWordBoundaries: !1,
    avoidSubclass: !1,
    bestEffortTarget: "ES2025",
    ...t
  };
  f0(e);
  const r = {
    accuracy: n.accuracy,
    asciiWordBoundaries: n.asciiWordBoundaries,
    avoidSubclass: n.avoidSubclass,
    flagDirectivesByAlt: new Map(),
    jsGroupNameMap: new Map(),
    minTargetEs2024: wi(n.bestEffortTarget, "ES2024"),
    passedLookbehind: !1,
    strategy: null,
    subroutineRefMap: new Map(),
    supportedGNodes: new Set(),
    digitIsAscii: e.flags.digitIsAscii,
    spaceIsAscii: e.flags.spaceIsAscii,
    wordIsAscii: e.flags.wordIsAscii
  };
  Un(e, Vp, r);
  const a = {
      dotAll: e.flags.dotAll,
      ignoreCase: e.flags.ignoreCase
    },
    i = {
      currentFlags: a,
      prevFlags: null,
      globalFlags: a,
      groupOriginByCopy: new Map(),
      groupsByName: new Map(),
      multiplexCapturesToLeftByRef: new Map(),
      openRefs: new Map(),
      reffedNodesByReferencer: new Map(),
      subroutineRefMap: r.subroutineRefMap
    };
  Un(e, Xp, i);
  const s = {
    groupsByName: i.groupsByName,
    highestOrphanBackref: 0,
    numCapturesToLeft: 0,
    reffedNodesByReferencer: i.reffedNodesByReferencer
  };
  return Un(e, Yp, s), e._originMap = i.groupOriginByCopy, e._strategy = r.strategy, e;
}
var Vp = {
    AbsenceFunction({
      node: e,
      parent: t,
      replaceWith: n
    }) {
      const {
        body: r,
        kind: a
      } = e;
      if (a === "repeater") {
        const i = pt();
        i.body[0].body.push(sn({
          negate: !0,
          body: r
        }), _n("Any"));
        const s = pt();
        s.body[0].body.push(s0("greedy", 0, 1 / 0, i)), n(ke(s, t), {
          traverse: !0
        });
      } else throw new Error('Unsupported absence function "(?~|"');
    },
    Alternative: {
      enter({
        node: e,
        parent: t,
        key: n
      }, {
        flagDirectivesByAlt: r
      }) {
        const a = e.body.filter(i => i.kind === "flags");
        for (let i = n + 1; i < t.body.length; i++) {
          const s = t.body[i];
          Qn(r, s, []).push(...a);
        }
      },
      exit({
        node: e
      }, {
        flagDirectivesByAlt: t
      }) {
        if (t.get(e)?.length) {
          const n = b0(t.get(e));
          if (n) {
            const r = pt({
              flags: n
            });
            r.body[0].body = e.body, e.body = [ke(r, e)];
          }
        }
      }
    },
    Assertion({
      node: e,
      parent: t,
      key: n,
      container: r,
      root: a,
      remove: i,
      replaceWith: s
    }, o) {
      const {
          kind: l,
          negate: u
        } = e,
        {
          asciiWordBoundaries: c,
          avoidSubclass: h,
          supportedGNodes: f,
          wordIsAscii: d
        } = o;
      if (l === "text_segment_boundary") throw new Error(`Unsupported text segment boundary "\\${u ? "Y" : "y"}"`);
      if (l === "line_end") s(ke(sn({
        body: [hn({
          body: [gi("string_end")]
        }), hn({
          body: [ia(10)]
        })]
      }), t));else if (l === "line_start") s(ke(Tt(te`(?<=\A|\n(?!\z))`, {
        skipLookbehindValidation: !0
      }), t));else if (l === "search_start") {
        if (f.has(e)) a.flags.sticky = !0, i();else {
          const b = r[n - 1];
          if (b && td(b)) s(ke(sn({
            negate: !0
          }), t));else {
            if (h) throw new Error(te`Uses "\G" in a way that requires a subclass`);
            s(jt(gi("string_start"), t)), o.strategy = "clip_search";
          }
        }
      } else if (!(l === "string_end" || l === "string_start")) if (l === "string_end_newline") s(ke(Tt(te`(?=\n?\z)`), t));else if (l === "word_boundary") {
        if (!d && !c) {
          const b = `(?:(?<=${At})(?!${At})|(?<!${At})(?=${At}))`,
            k = `(?:(?<=${At})(?=${At})|(?<!${At})(?!${At}))`;
          s(ke(Tt(u ? k : b), t));
        }
      } else throw new Error(`Unexpected assertion kind "${l}"`);
    },
    Backreference({
      node: e
    }, {
      jsGroupNameMap: t
    }) {
      let {
        ref: n
      } = e;
      typeof n == "string" && !Da(n) && (n = Ba(n, t), e.ref = n);
    },
    CapturingGroup({
      node: e
    }, {
      jsGroupNameMap: t,
      subroutineRefMap: n
    }) {
      let {
        name: r
      } = e;
      r && !Da(r) && (r = Ba(r, t), e.name = r), n.set(e.number, e), r && n.set(r, e);
    },
    CharacterClassRange({
      node: e,
      parent: t,
      replaceWith: n
    }) {
      if (t.kind === "intersection") {
        const r = Nr({
          body: [e]
        });
        n(ke(r, t), {
          traverse: !0
        });
      }
    },
    CharacterSet({
      node: e,
      parent: t,
      replaceWith: n
    }, {
      accuracy: r,
      minTargetEs2024: a,
      digitIsAscii: i,
      spaceIsAscii: s,
      wordIsAscii: o
    }) {
      const {
        kind: l,
        negate: u,
        value: c
      } = e;
      if (i && (l === "digit" || c === "digit")) {
        n(jt(yi("digit", {
          negate: u
        }), t));
        return;
      }
      if (s && (l === "space" || c === "space")) {
        n(ke(La(Tt(Pp), u), t));
        return;
      }
      if (o && (l === "word" || c === "word")) {
        n(jt(yi("word", {
          negate: u
        }), t));
        return;
      }
      if (l === "any") n(jt(_n("Any"), t));else if (l === "digit") n(jt(_n("Nd", {
        negate: u
      }), t));else if (l !== "dot") if (l === "text_segment") {
        if (r === "strict") throw new Error(te`Use of "\X" requires non-strict accuracy`);
        const h = "\\p{Emoji}(?:\\p{EMod}|\\uFE0F\\u20E3?|[\\x{E0020}-\\x{E007E}]+\\x{E007F})?",
          f = te`\p{RI}{2}|${h}(?:\u200D${h})*`;
        n(ke(Tt(te`(?>\r\n|${a ? te`\p{RGI_Emoji}` : f}|\P{M}\p{M}*)`, {
          skipPropertyNameValidation: !0
        }), t));
      } else if (l === "hex") n(jt(_n("AHex", {
        negate: u
      }), t));else if (l === "newline") n(ke(Tt(u ? `[^
]` : `(?>\r
?|[
\v\f\u2028\u2029])`), t));else if (l === "posix") {
        if (!a && (c === "graph" || c === "print")) {
          if (r === "strict") throw new Error(`POSIX class "${c}" requires min target ES2024 or non-strict accuracy`);
          let h = {
            graph: "!-~",
            print: " -~"
          }[c];
          u && (h = `\0-${Me(h.codePointAt(0) - 1)}${Me(h.codePointAt(2) + 1)}-􏿿`), n(ke(Tt(`[${h}]`), t));
        } else n(ke(La(Tt(Hp.get(c)), u), t));
      } else if (l === "property") es.has(sa(c)) || (e.key = "sc");else if (l === "space") n(jt(_n("space", {
        negate: u
      }), t));else if (l === "word") n(ke(La(Tt(At), u), t));else throw new Error(`Unexpected character set kind "${l}"`);
    },
    Directive({
      node: e,
      parent: t,
      root: n,
      remove: r,
      replaceWith: a,
      removeAllPrevSiblings: i,
      removeAllNextSiblings: s
    }) {
      const {
        kind: o,
        flags: l
      } = e;
      if (o === "flags") {
        if (!l.enable && !l.disable) r();else {
          const u = pt({
            flags: l
          });
          u.body[0].body = s(), a(ke(u, t), {
            traverse: !0
          });
        }
      } else if (o === "keep") {
        const u = n.body[0],
          h = n.body.length === 1 && r0(u, {
            type: "Group"
          }) && u.body[0].body.length === 1 ? u.body[0] : n;
        if (t.parent !== h || h.body.length > 1) throw new Error(te`Uses "\K" in a way that's unsupported`);
        const f = sn({
          behind: !0
        });
        f.body[0].body = i(), a(ke(f, t));
      } else throw new Error(`Unexpected directive kind "${o}"`);
    },
    Flags({
      node: e,
      parent: t
    }) {
      if (e.posixIsAscii) throw new Error('Unsupported flag "P"');
      if (e.textSegmentMode === "word") throw new Error('Unsupported flag "y{w}"');
      ["digitIsAscii", "extended", "posixIsAscii", "spaceIsAscii", "wordIsAscii", "textSegmentMode"].forEach(n => delete e[n]), Object.assign(e, {
        global: !1,
        hasIndices: !1,
        multiline: !1,
        sticky: e.sticky ?? !1
      }), t.options = {
        disable: {
          x: !0,
          n: !0
        },
        force: {
          v: !0
        }
      };
    },
    Group({
      node: e
    }) {
      if (!e.flags) return;
      const {
        enable: t,
        disable: n
      } = e.flags;
      t?.extended && delete t.extended, n?.extended && delete n.extended, t?.dotAll && n?.dotAll && delete t.dotAll, t?.ignoreCase && n?.ignoreCase && delete t.ignoreCase, t && !Object.keys(t).length && delete e.flags.enable, n && !Object.keys(n).length && delete e.flags.disable, !e.flags.enable && !e.flags.disable && delete e.flags;
    },
    LookaroundAssertion({
      node: e
    }, t) {
      const {
        kind: n
      } = e;
      n === "lookbehind" && (t.passedLookbehind = !0);
    },
    NamedCallout({
      node: e,
      parent: t,
      replaceWith: n
    }) {
      const {
        kind: r
      } = e;
      if (r === "fail") n(ke(sn({
        negate: !0
      }), t));else throw new Error(`Unsupported named callout "(*${r.toUpperCase()}"`);
    },
    Quantifier({
      node: e
    }) {
      if (e.body.type === "Quantifier") {
        const t = pt();
        t.body[0].body.push(e.body), e.body = ke(t, e);
      }
    },
    Regex: {
      enter({
        node: e
      }, {
        supportedGNodes: t
      }) {
        const n = [];
        let r = !1,
          a = !1;
        for (const i of e.body) if (i.body.length === 1 && i.body[0].kind === "search_start") i.body.pop();else {
          const s = v0(i.body);
          s ? (r = !0, Array.isArray(s) ? n.push(...s) : n.push(s)) : a = !0;
        }
        r && !a && n.forEach(i => t.add(i));
      },
      exit(e, {
        accuracy: t,
        passedLookbehind: n,
        strategy: r
      }) {
        if (t === "strict" && n && r) throw new Error(te`Uses "\G" in a way that requires non-strict accuracy`);
      }
    },
    Subroutine({
      node: e
    }, {
      jsGroupNameMap: t
    }) {
      let {
        ref: n
      } = e;
      typeof n == "string" && !Da(n) && (n = Ba(n, t), e.ref = n);
    }
  },
  Xp = {
    Backreference({
      node: e
    }, {
      multiplexCapturesToLeftByRef: t,
      reffedNodesByReferencer: n
    }) {
      const {
        orphan: r,
        ref: a
      } = e;
      r || n.set(e, [...t.get(a).map(({
        node: i
      }) => i)]);
    },
    CapturingGroup: {
      enter({
        node: e,
        parent: t,
        replaceWith: n,
        skip: r
      }, {
        groupOriginByCopy: a,
        groupsByName: i,
        multiplexCapturesToLeftByRef: s,
        openRefs: o,
        reffedNodesByReferencer: l
      }) {
        const u = a.get(e);
        if (u && o.has(e.number)) {
          const h = jt(so(e.number), t);
          l.set(h, o.get(e.number)), n(h);
          return;
        }
        o.set(e.number, e), s.set(e.number, []), e.name && Qn(s, e.name, []);
        const c = s.get(e.name ?? e.number);
        for (let h = 0; h < c.length; h++) {
          const f = c[h];
          if (u === f.node || u && u === f.origin || e === f.origin) {
            c.splice(h, 1);
            break;
          }
        }
        if (s.get(e.number).push({
          node: e,
          origin: u
        }), e.name && s.get(e.name).push({
          node: e,
          origin: u
        }), e.name) {
          const h = Qn(i, e.name, new Map());
          let f = !1;
          if (u) f = !0;else for (const d of h.values()) if (!d.hasDuplicateNameToRemove) {
            f = !0;
            break;
          }
          i.get(e.name).set(e, {
            node: e,
            hasDuplicateNameToRemove: f
          });
        }
      },
      exit({
        node: e
      }, {
        openRefs: t
      }) {
        t.get(e.number) === e && t.delete(e.number);
      }
    },
    Group: {
      enter({
        node: e
      }, t) {
        t.prevFlags = t.currentFlags, e.flags && (t.currentFlags = Yr(t.currentFlags, e.flags));
      },
      exit(e, t) {
        t.currentFlags = t.prevFlags;
      }
    },
    Subroutine({
      node: e,
      parent: t,
      replaceWith: n
    }, r) {
      const {
        isRecursive: a,
        ref: i
      } = e;
      if (a) {
        let c = t;
        for (; (c = c.parent) && !(c.type === "CapturingGroup" && (c.name === i || c.number === i)););
        r.reffedNodesByReferencer.set(e, c);
        return;
      }
      const s = r.subroutineRefMap.get(i),
        o = i === 0,
        l = o ? so(0) : g0(s, r.groupOriginByCopy, null);
      let u = l;
      if (!o) {
        const c = b0(Qp(s, f => f.type === "Group" && !!f.flags)),
          h = c ? Yr(r.globalFlags, c) : r.globalFlags;
        Zp(h, r.currentFlags) || (u = pt({
          flags: Jp(h)
        }), u.body[0].body.push(l));
      }
      n(ke(u, t), {
        traverse: !o
      });
    }
  },
  Yp = {
    Backreference({
      node: e,
      parent: t,
      replaceWith: n
    }, r) {
      if (e.orphan) {
        r.highestOrphanBackref = Math.max(r.highestOrphanBackref, e.ref);
        return;
      }
      const i = r.reffedNodesByReferencer.get(e).filter(s => Kp(s, e));
      if (!i.length) n(ke(sn({
        negate: !0
      }), t));else if (i.length > 1) {
        const s = pt({
          atomic: !0,
          body: i.reverse().map(o => hn({
            body: [bi(o.number)]
          }))
        });
        n(ke(s, t));
      } else e.ref = i[0].number;
    },
    CapturingGroup({
      node: e
    }, t) {
      e.number = ++t.numCapturesToLeft, e.name && t.groupsByName.get(e.name).get(e).hasDuplicateNameToRemove && delete e.name;
    },
    Regex: {
      exit({
        node: e
      }, t) {
        const n = Math.max(t.highestOrphanBackref - t.numCapturesToLeft, 0);
        for (let r = 0; r < n; r++) {
          const a = i0();
          e.body.at(-1).body.push(a);
        }
      }
    },
    Subroutine({
      node: e
    }, t) {
      !e.isRecursive || e.ref === 0 || (e.ref = t.reffedNodesByReferencer.get(e).number);
    }
  };
function f0(e) {
  Un(e, {
    "*"({
      node: t,
      parent: n
    }) {
      t.parent = n;
    }
  });
}
function Zp(e, t) {
  return e.dotAll === t.dotAll && e.ignoreCase === t.ignoreCase;
}
function Kp(e, t) {
  let n = t;
  do {
    if (n.type === "Regex") return !1;
    if (n.type === "Alternative") continue;
    if (n === e) return !1;
    const r = y0(n.parent);
    for (const a of r) {
      if (a === n) break;
      if (a === e || w0(a, e)) return !0;
    }
  } while (n = n.parent);
  throw new Error("Unexpected path");
}
function g0(e, t, n, r) {
  const a = Array.isArray(e) ? [] : {};
  for (const [i, s] of Object.entries(e)) i === "parent" ? a.parent = Array.isArray(n) ? r : n : s && typeof s == "object" ? a[i] = g0(s, t, a, n) : (i === "type" && s === "CapturingGroup" && t.set(a, t.get(e) ?? e), a[i] = s);
  return a;
}
function so(e) {
  const t = o0(e);
  return t.isRecursive = !0, t;
}
function Qp(e, t) {
  const n = [];
  for (; e = e.parent;) (!t || t(e)) && n.push(e);
  return n;
}
function Ba(e, t) {
  if (t.has(e)) return t.get(e);
  const n = `$${t.size}_${e.replace(/^[^$_\p{IDS}]|[^$\u200C\u200D\p{IDC}]/ug, "_")}`;
  return t.set(e, n), n;
}
function b0(e) {
  const t = ["dotAll", "ignoreCase"],
    n = {
      enable: {},
      disable: {}
    };
  return e.forEach(({
    flags: r
  }) => {
    t.forEach(a => {
      r.enable?.[a] && (delete n.disable[a], n.enable[a] = !0), r.disable?.[a] && (n.disable[a] = !0);
    });
  }), Object.keys(n.enable).length || delete n.enable, Object.keys(n.disable).length || delete n.disable, n.enable || n.disable ? n : null;
}
function Jp({
  dotAll: e,
  ignoreCase: t
}) {
  const n = {};
  return (e || t) && (n.enable = {}, e && (n.enable.dotAll = !0), t && (n.enable.ignoreCase = !0)), (!e || !t) && (n.disable = {}, !e && (n.disable.dotAll = !0), !t && (n.disable.ignoreCase = !0)), n;
}
function y0(e) {
  if (!e) throw new Error("Node expected");
  const {
    body: t
  } = e;
  return Array.isArray(t) ? t : t ? [t] : null;
}
function v0(e) {
  const t = e.find(n => n.kind === "search_start" || nd(n, {
    negate: !1
  }) || !ed(n));
  if (!t) return null;
  if (t.kind === "search_start") return t;
  if (t.type === "LookaroundAssertion") return t.body[0].body[0];
  if (t.type === "CapturingGroup" || t.type === "Group") {
    const n = [];
    for (const r of t.body) {
      const a = v0(r.body);
      if (!a) return null;
      Array.isArray(a) ? n.push(...a) : n.push(a);
    }
    return n;
  }
  return null;
}
function w0(e, t) {
  const n = y0(e) ?? [];
  for (const r of n) if (r === t || w0(r, t)) return !0;
  return !1;
}
function ed({
  type: e
}) {
  return e === "Assertion" || e === "Directive" || e === "LookaroundAssertion";
}
function td(e) {
  const t = ["Character", "CharacterClass", "CharacterSet"];
  return t.includes(e.type) || e.type === "Quantifier" && e.min && t.includes(e.body.type);
}
function nd(e, t) {
  const n = {
    negate: null,
    ...t
  };
  return e.type === "LookaroundAssertion" && (n.negate === null || e.negate === n.negate) && e.body.length === 1 && r0(e.body[0], {
    type: "Assertion",
    kind: "search_start"
  });
}
function Da(e) {
  return /^[$_\p{IDS}][$\u200C\u200D\p{IDC}]*$/u.test(e);
}
function Tt(e, t) {
  const r = a0(e, {
    ...t,
    unicodePropertyMap: es
  }).body;
  return r.length > 1 || r[0].body.length > 1 ? pt({
    body: r
  }) : r[0].body[0];
}
function La(e, t) {
  return e.negate = t, e;
}
function jt(e, t) {
  return e.parent = t, e;
}
function ke(e, t) {
  return f0(e), e.parent = t, e;
}
function rd(e, t) {
  const n = h0(t),
    r = wi(n.target, "ES2024"),
    a = wi(n.target, "ES2025"),
    i = n.rules.recursionLimit;
  if (!Number.isInteger(i) || i < 2 || i > 20) throw new Error("Invalid recursionLimit; use 2-20");
  let s = null,
    o = null;
  if (!a) {
    const d = [e.flags.ignoreCase];
    Un(e, ad, {
      getCurrentModI: () => d.at(-1),
      popModI() {
        d.pop();
      },
      pushModI(b) {
        d.push(b);
      },
      setHasCasedChar() {
        d.at(-1) ? s = !0 : o = !0;
      }
    });
  }
  const l = {
    dotAll: e.flags.dotAll,
    ignoreCase: !!((e.flags.ignoreCase || s) && !o)
  };
  let u = e;
  const c = {
    accuracy: n.accuracy,
    appliedGlobalFlags: l,
    captureMap: new Map(),
    currentFlags: {
      dotAll: e.flags.dotAll,
      ignoreCase: e.flags.ignoreCase
    },
    inCharClass: !1,
    lastNode: u,
    originMap: e._originMap,
    recursionLimit: i,
    useAppliedIgnoreCase: !!(!a && s && o),
    useFlagMods: a,
    useFlagV: r,
    verbose: n.verbose
  };
  function h(d) {
    return c.lastNode = u, u = d, Lp(id[d.type], `Unexpected node type "${d.type}"`)(d, c, h);
  }
  const f = {
    pattern: e.body.map(h).join("|"),
    flags: h(e.flags),
    options: {
      ...e.options
    }
  };
  return r || (delete f.options.force.v, f.options.disable.v = !0, f.options.unicodeSetsPlugin = null), f._captureTransfers = new Map(), f._hiddenCaptures = [], c.captureMap.forEach((d, b) => {
    d.hidden && f._hiddenCaptures.push(b), d.transferTo && Qn(f._captureTransfers, d.transferTo, []).push(b);
  }), f;
}
var ad = {
    "*": {
      enter({
        node: e
      }, t) {
        if (lo(e)) {
          const n = t.getCurrentModI();
          t.pushModI(e.flags ? Yr({
            ignoreCase: n
          }, e.flags).ignoreCase : n);
        }
      },
      exit({
        node: e
      }, t) {
        lo(e) && t.popModI();
      }
    },
    Backreference(e, t) {
      t.setHasCasedChar();
    },
    Character({
      node: e
    }, t) {
      ts(Me(e.value)) && t.setHasCasedChar();
    },
    CharacterClassRange({
      node: e,
      skip: t
    }, n) {
      t(), x0(e, {
        firstOnly: !0
      }).length && n.setHasCasedChar();
    },
    CharacterSet({
      node: e
    }, t) {
      e.kind === "property" && d0.has(e.value) && t.setHasCasedChar();
    }
  },
  id = {
    Alternative({
      body: e
    }, t, n) {
      return e.map(n).join("");
    },
    Assertion({
      kind: e,
      negate: t
    }) {
      if (e === "string_end") return "$";
      if (e === "string_start") return "^";
      if (e === "word_boundary") return t ? te`\B` : te`\b`;
      throw new Error(`Unexpected assertion kind "${e}"`);
    },
    Backreference({
      ref: e
    }, t) {
      if (typeof e != "number") throw new Error("Unexpected named backref in transformed AST");
      if (!t.useFlagMods && t.accuracy === "strict" && t.currentFlags.ignoreCase && !t.captureMap.get(e).ignoreCase) throw new Error("Use of case-insensitive backref to case-sensitive group requires target ES2025 or non-strict accuracy");
      return "\\" + e;
    },
    CapturingGroup(e, t, n) {
      const {
          body: r,
          name: a,
          number: i
        } = e,
        s = {
          ignoreCase: t.currentFlags.ignoreCase
        },
        o = t.originMap.get(e);
      return o && (s.hidden = !0, i > o.number && (s.transferTo = o.number)), t.captureMap.set(i, s), `(${a ? `?<${a}>` : ""}${r.map(n).join("|")})`;
    },
    Character({
      value: e
    }, t) {
      const n = Me(e),
        r = wn(e, {
          escDigit: t.lastNode.type === "Backreference",
          inCharClass: t.inCharClass,
          useFlagV: t.useFlagV
        });
      if (r !== n) return r;
      if (t.useAppliedIgnoreCase && t.currentFlags.ignoreCase && ts(n)) {
        const a = p0(n);
        return t.inCharClass ? a.join("") : a.length > 1 ? `[${a.join("")}]` : a[0];
      }
      return n;
    },
    CharacterClass(e, t, n) {
      const {
        kind: r,
        negate: a,
        parent: i
      } = e;
      let {
        body: s
      } = e;
      if (r === "intersection" && !t.useFlagV) throw new Error("Use of character class intersection requires min target ES2024");
      dt.bugFlagVLiteralHyphenIsRange && t.useFlagV && s.some(uo) && (s = [ia(45), ...s.filter(u => !uo(u))]);
      const o = () => `[${a ? "^" : ""}${s.map(n).join(r === "intersection" ? "&&" : "")}]`;
      if (!t.inCharClass) {
        if ((!t.useFlagV || dt.bugNestedClassIgnoresNegation) && !a) {
          const c = s.filter(h => h.type === "CharacterClass" && h.kind === "union" && h.negate);
          if (c.length) {
            const h = pt(),
              f = h.body[0];
            return h.parent = i, f.parent = h, s = s.filter(d => !c.includes(d)), e.body = s, s.length ? (e.parent = f, f.body.push(e)) : h.body.pop(), c.forEach(d => {
              const b = hn({
                body: [d]
              });
              d.parent = b, b.parent = h, h.body.push(b);
            }), n(h);
          }
        }
        t.inCharClass = !0;
        const u = o();
        return t.inCharClass = !1, u;
      }
      const l = s[0];
      if (r === "union" && !a && l && ((!t.useFlagV || !t.verbose) && i.kind === "union" && !(dt.bugFlagVLiteralHyphenIsRange && t.useFlagV) || !t.verbose && i.kind === "intersection" && s.length === 1 && l.type !== "CharacterClassRange")) return s.map(n).join("");
      if (!t.useFlagV && i.type === "CharacterClass") throw new Error("Uses nested character class in a way that requires min target ES2024");
      return o();
    },
    CharacterClassRange(e, t) {
      const n = e.min.value,
        r = e.max.value,
        a = {
          escDigit: !1,
          inCharClass: !0,
          useFlagV: t.useFlagV
        },
        i = wn(n, a),
        s = wn(r, a),
        o = new Set();
      if (t.useAppliedIgnoreCase && t.currentFlags.ignoreCase) {
        const l = x0(e);
        cd(l).forEach(c => {
          o.add(Array.isArray(c) ? `${wn(c[0], a)}-${wn(c[1], a)}` : wn(c, a));
        });
      }
      return `${i}-${s}${[...o].join("")}`;
    },
    CharacterSet({
      kind: e,
      negate: t,
      value: n,
      key: r
    }, a) {
      if (e === "dot") return a.currentFlags.dotAll ? a.appliedGlobalFlags.dotAll || a.useFlagMods ? "." : "[^]" : te`[^\n]`;
      if (e === "digit") return t ? te`\D` : te`\d`;
      if (e === "property") {
        if (a.useAppliedIgnoreCase && a.currentFlags.ignoreCase && d0.has(n)) throw new Error(`Unicode property "${n}" can't be case-insensitive when other chars have specific case`);
        return `${t ? te`\P` : te`\p`}{${r ? `${r}=` : ""}${n}}`;
      }
      if (e === "word") return t ? te`\W` : te`\w`;
      throw new Error(`Unexpected character set kind "${e}"`);
    },
    Flags(e, t) {
      return (t.appliedGlobalFlags.ignoreCase ? "i" : "") + (e.dotAll ? "s" : "") + (e.sticky ? "y" : "");
    },
    Group({
      atomic: e,
      body: t,
      flags: n,
      parent: r
    }, a, i) {
      const s = a.currentFlags;
      n && (a.currentFlags = Yr(s, n));
      const o = t.map(i).join("|"),
        l = !a.verbose && t.length === 1 && r.type !== "Quantifier" && !e && (!a.useFlagMods || !n) ? o : `(?${md(e, n, a.useFlagMods)}${o})`;
      return a.currentFlags = s, l;
    },
    LookaroundAssertion({
      body: e,
      kind: t,
      negate: n
    }, r, a) {
      return `(?${`${t === "lookahead" ? "" : "<"}${n ? "!" : "="}`}${e.map(a).join("|")})`;
    },
    Quantifier(e, t, n) {
      return n(e.body) + hd(e);
    },
    Subroutine({
      isRecursive: e,
      ref: t
    }, n) {
      if (!e) throw new Error("Unexpected non-recursive subroutine in transformed AST");
      const r = n.recursionLimit;
      return t === 0 ? `(?R=${r})` : te`\g<${t}&R=${r}>`;
    }
  },
  sd = new Set(["$", "(", ")", "*", "+", ".", "?", "[", "\\", "]", "^", "{", "|", "}"]),
  od = new Set(["-", "\\", "]", "^", "["]),
  ld = new Set(["(", ")", "-", "/", "[", "\\", "]", "^", "{", "|", "}", "!", "#", "$", "%", "&", "*", "+", ",", ".", ":", ";", "<", "=", ">", "?", "@", "`", "~"]),
  oo = new Map([[9, te`\t`], [10, te`\n`], [11, te`\v`], [12, te`\f`], [13, te`\r`], [8232, te`\u2028`], [8233, te`\u2029`], [65279, te`\uFEFF`]]),
  ud = /^\p{Cased}$/u;
function ts(e) {
  return ud.test(e);
}
function x0(e, t) {
  const n = !!t?.firstOnly,
    r = e.min.value,
    a = e.max.value,
    i = [];
  if (r < 65 && (a === 65535 || a >= 131071) || r === 65536 && a >= 131071) return i;
  for (let s = r; s <= a; s++) {
    const o = Me(s);
    if (!ts(o)) continue;
    const l = p0(o).filter(u => {
      const c = u.codePointAt(0);
      return c < r || c > a;
    });
    if (l.length && (i.push(...l), n)) break;
  }
  return i;
}
function wn(e, {
  escDigit: t,
  inCharClass: n,
  useFlagV: r
}) {
  if (oo.has(e)) return oo.get(e);
  if (e < 32 || e > 126 && e < 160 || e > 262143 || t && pd(e)) return e > 255 ? `\\u{${e.toString(16).toUpperCase()}}` : `\\x${e.toString(16).toUpperCase().padStart(2, "0")}`;
  const a = n ? r ? ld : od : sd,
    i = Me(e);
  return (a.has(i) ? "\\" : "") + i;
}
function cd(e) {
  const t = e.map(a => a.codePointAt(0)).sort((a, i) => a - i),
    n = [];
  let r = null;
  for (let a = 0; a < t.length; a++) t[a + 1] === t[a] + 1 ? r ??= t[a] : r === null ? n.push(t[a]) : (n.push([r, t[a]]), r = null);
  return n;
}
function md(e, t, n) {
  if (e) return ">";
  let r = "";
  if (t && n) {
    const {
      enable: a,
      disable: i
    } = t;
    r = (a?.ignoreCase ? "i" : "") + (a?.dotAll ? "s" : "") + (i ? "-" : "") + (i?.ignoreCase ? "i" : "") + (i?.dotAll ? "s" : "");
  }
  return `${r}:`;
}
function hd({
  kind: e,
  max: t,
  min: n
}) {
  let r;
  return !n && t === 1 ? r = "?" : !n && t === 1 / 0 ? r = "*" : n === 1 && t === 1 / 0 ? r = "+" : n === t ? r = `{${n}}` : r = `{${n},${t === 1 / 0 ? "" : t}}`, r + {
    greedy: "",
    lazy: "?",
    possessive: "+"
  }[e];
}
function lo({
  type: e
}) {
  return e === "CapturingGroup" || e === "Group" || e === "LookaroundAssertion";
}
function pd(e) {
  return e > 47 && e < 58;
}
function uo({
  type: e,
  value: t
}) {
  return e === "Character" && t === 45;
}
var dd = class xi extends RegExp {
  #t = new Map();
  #e = null;
  #r;
  #n = null;
  #a = null;
  rawOptions = {};
  get source() {
    return this.#r || "(?:)";
  }
  constructor(t, n, r) {
    const a = !!r?.lazyCompile;
    if (t instanceof RegExp) {
      if (r) throw new Error("Cannot provide options when copying a regexp");
      const i = t;
      super(i, n), this.#r = i.source, i instanceof xi && (this.#t = i.#t, this.#n = i.#n, this.#a = i.#a, this.rawOptions = i.rawOptions);
    } else {
      const i = {
        hiddenCaptures: [],
        strategy: null,
        transfers: [],
        ...r
      };
      super(a ? "" : t, n), this.#r = t, this.#t = gd(i.hiddenCaptures, i.transfers), this.#a = i.strategy, this.rawOptions = r ?? {};
    }
    a || (this.#e = this);
  }
  exec(t) {
    if (!this.#e) {
      const {
        lazyCompile: a,
        ...i
      } = this.rawOptions;
      this.#e = new xi(this.#r, this.flags, i);
    }
    const n = this.global || this.sticky,
      r = this.lastIndex;
    if (this.#a === "clip_search" && n && r) {
      this.lastIndex = 0;
      const a = this.#i(t.slice(r));
      return a && (fd(a, r, t, this.hasIndices), this.lastIndex += r), a;
    }
    return this.#i(t);
  }
  #i(t) {
    this.#e.lastIndex = this.lastIndex;
    const n = super.exec.call(this.#e, t);
    if (this.lastIndex = this.#e.lastIndex, !n || !this.#t.size) return n;
    const r = [...n];
    n.length = 1;
    let a;
    this.hasIndices && (a = [...n.indices], n.indices.length = 1);
    const i = [0];
    for (let s = 1; s < r.length; s++) {
      const {
        hidden: o,
        transferTo: l
      } = this.#t.get(s) ?? {};
      if (o ? i.push(null) : (i.push(n.length), n.push(r[s]), this.hasIndices && n.indices.push(a[s])), l && r[s] !== void 0) {
        const u = i[l];
        if (!u) throw new Error(`Invalid capture transfer to "${u}"`);
        if (n[u] = r[s], this.hasIndices && (n.indices[u] = a[s]), n.groups) {
          this.#n || (this.#n = bd(this.source));
          const c = this.#n.get(l);
          c && (n.groups[c] = r[s], this.hasIndices && (n.indices.groups[c] = a[s]));
        }
      }
    }
    return n;
  }
};
function fd(e, t, n, r) {
  if (e.index += t, e.input = n, r) {
    const a = e.indices;
    for (let s = 0; s < a.length; s++) {
      const o = a[s];
      o && (a[s] = [o[0] + t, o[1] + t]);
    }
    const i = a.groups;
    i && Object.keys(i).forEach(s => {
      const o = i[s];
      o && (i[s] = [o[0] + t, o[1] + t]);
    });
  }
}
function gd(e, t) {
  const n = new Map();
  for (const r of e) n.set(r, {
    hidden: !0
  });
  for (const [r, a] of t) for (const i of a) Qn(n, i, {}).transferTo = r;
  return n;
}
function bd(e) {
  const t = /(?<capture>\((?:\?<(?![=!])(?<name>[^>]+)>|(?!\?)))|\\?./gsu,
    n = new Map();
  let r = 0,
    a = 0,
    i;
  for (; i = t.exec(e);) {
    const {
      0: s,
      groups: {
        capture: o,
        name: l
      }
    } = i;
    s === "[" ? r++ : r ? s === "]" && r-- : o && (a++, l && n.set(a, l));
  }
  return n;
}
function yd(e, t) {
  const n = vd(e, t);
  return n.options ? new dd(n.pattern, n.flags, n.options) : new RegExp(n.pattern, n.flags);
}
function vd(e, t) {
  const n = h0(t),
    r = a0(e, {
      flags: n.flags,
      normalizeUnknownPropertyNames: !0,
      rules: {
        captureGroup: n.rules.captureGroup,
        singleline: n.rules.singleline
      },
      skipBackrefValidation: n.rules.allowOrphanBackrefs,
      unicodePropertyMap: es
    }),
    a = Wp(r, {
      accuracy: n.accuracy,
      asciiWordBoundaries: n.rules.asciiWordBoundaries,
      avoidSubclass: n.avoidSubclass,
      bestEffortTarget: n.target
    }),
    i = rd(a, n),
    s = Bp(i.pattern, {
      captureTransfers: i._captureTransfers,
      hiddenCaptures: i._hiddenCaptures,
      mode: "external"
    }),
    o = Np(s.pattern),
    l = Ip(o.pattern, {
      captureTransfers: s.captureTransfers,
      hiddenCaptures: s.hiddenCaptures
    }),
    u = {
      pattern: l.pattern,
      flags: `${n.hasIndices ? "d" : ""}${n.global ? "g" : ""}${i.flags}${i.options.disable.v ? "u" : "v"}`
    };
  if (n.avoidSubclass) {
    if (n.lazyCompileLength !== 1 / 0) throw new Error("Lazy compilation requires subclass");
  } else {
    const c = l.hiddenCaptures.sort((b, k) => b - k),
      h = Array.from(l.captureTransfers),
      f = a._strategy,
      d = u.pattern.length >= n.lazyCompileLength;
    (c.length || h.length || f || d) && (u.options = {
      ...(c.length && {
        hiddenCaptures: c
      }),
      ...(h.length && {
        transfers: h
      }),
      ...(f && {
        strategy: f
      }),
      ...(d && {
        lazyCompile: d
      })
    });
  }
  return u;
}
function wd(e, t) {
  return yd(e, {
    global: !0,
    hasIndices: !0,
    lazyCompileLength: 3e3,
    rules: {
      allowOrphanBackrefs: !0,
      asciiWordBoundaries: !0,
      captureGroup: !0,
      recursionLimit: 5,
      singleline: !0
    },
    ...t
  });
}
function p5(e = {}) {
  const t = {
    target: "auto",
    cache: new Map(),
    ...e
  };
  return t.regexConstructor ||= n => wd(n, {
    target: t.target
  }), {
    createScanner(n) {
      return new Dh(n, t);
    },
    createString(n) {
      return {
        content: n
      };
    }
  };
}
const xd = Object.freeze(JSON.parse('{"displayName":"TypeScript","name":"typescript","patterns":[{"include":"#directives"},{"include":"#statements"},{"include":"#shebang"}],"repository":{"access-modifier":{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(abstract|declare|override|public|protected|private|readonly|static)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"storage.modifier.ts"},"after-operator-block-as-object-literal":{"begin":"(?<!\\\\+\\\\+|--)(?<=[!(+,:=>?\\\\[]|^await|[^$._[:alnum:]]await|^return|[^$._[:alnum:]]return|^yield|[^$._[:alnum:]]yield|^throw|[^$._[:alnum:]]throw|^in|[^$._[:alnum:]]in|^of|[^$._[:alnum:]]of|^typeof|[^$._[:alnum:]]typeof|&&|\\\\|\\\\||\\\\*)\\\\s*(\\\\{)","beginCaptures":{"1":{"name":"punctuation.definition.block.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"name":"meta.objectliteral.ts","patterns":[{"include":"#object-member"}]},"array-binding-pattern":{"begin":"(?:(\\\\.\\\\.\\\\.)\\\\s*)?(\\\\[)","beginCaptures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"punctuation.definition.binding-pattern.array.ts"}},"end":"]","endCaptures":{"0":{"name":"punctuation.definition.binding-pattern.array.ts"}},"patterns":[{"include":"#binding-element"},{"include":"#punctuation-comma"}]},"array-binding-pattern-const":{"begin":"(?:(\\\\.\\\\.\\\\.)\\\\s*)?(\\\\[)","beginCaptures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"punctuation.definition.binding-pattern.array.ts"}},"end":"]","endCaptures":{"0":{"name":"punctuation.definition.binding-pattern.array.ts"}},"patterns":[{"include":"#binding-element-const"},{"include":"#punctuation-comma"}]},"array-literal":{"begin":"\\\\s*(\\\\[)","beginCaptures":{"1":{"name":"meta.brace.square.ts"}},"end":"]","endCaptures":{"0":{"name":"meta.brace.square.ts"}},"name":"meta.array.literal.ts","patterns":[{"include":"#expression"},{"include":"#punctuation-comma"}]},"arrow-function":{"patterns":[{"captures":{"1":{"name":"storage.modifier.async.ts"},"2":{"name":"variable.parameter.ts"}},"match":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))\\\\b(async)\\\\s+)?([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(?==>)","name":"meta.arrow.ts"},{"begin":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))\\\\b(async))?((?<![]!)}])\\\\s*(?=((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>)))","beginCaptures":{"1":{"name":"storage.modifier.async.ts"}},"end":"(?==>|\\\\{|^(\\\\s*(export|function|class|interface|let|var|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|const|import|enum|namespace|module|type|abstract|declare)\\\\s+))","name":"meta.arrow.ts","patterns":[{"include":"#comment"},{"include":"#type-parameters"},{"include":"#function-parameters"},{"include":"#arrow-return-type"},{"include":"#possibly-arrow-return-type"}]},{"begin":"=>","beginCaptures":{"0":{"name":"storage.type.function.arrow.ts"}},"end":"((?<=[}\\\\S])(?<!=>)|((?!\\\\{)(?=\\\\S)))(?!/[*/])","name":"meta.arrow.ts","patterns":[{"include":"#single-line-comment-consuming-line-ending"},{"include":"#decl-block"},{"include":"#expression"}]}]},"arrow-return-type":{"begin":"(?<=\\\\))\\\\s*(:)","beginCaptures":{"1":{"name":"keyword.operator.type.annotation.ts"}},"end":"(?==>|\\\\{|^(\\\\s*(export|function|class|interface|let|var|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|const|import|enum|namespace|module|type|abstract|declare)\\\\s+))","name":"meta.return.type.arrow.ts","patterns":[{"include":"#arrow-return-type-body"}]},"arrow-return-type-body":{"patterns":[{"begin":"(?<=:)(?=\\\\s*\\\\{)","end":"(?<=})","patterns":[{"include":"#type-object"}]},{"include":"#type-predicate-operator"},{"include":"#type"}]},"async-modifier":{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(async)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"storage.modifier.async.ts"},"binding-element":{"patterns":[{"include":"#comment"},{"include":"#string"},{"include":"#numeric-literal"},{"include":"#regex"},{"include":"#object-binding-pattern"},{"include":"#array-binding-pattern"},{"include":"#destructuring-variable-rest"},{"include":"#variable-initializer"}]},"binding-element-const":{"patterns":[{"include":"#comment"},{"include":"#string"},{"include":"#numeric-literal"},{"include":"#regex"},{"include":"#object-binding-pattern-const"},{"include":"#array-binding-pattern-const"},{"include":"#destructuring-variable-rest-const"},{"include":"#variable-initializer"}]},"boolean-literal":{"patterns":[{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))true(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"constant.language.boolean.true.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))false(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"constant.language.boolean.false.ts"}]},"brackets":{"patterns":[{"begin":"\\\\{","end":"}|(?=\\\\*/)","patterns":[{"include":"#brackets"}]},{"begin":"\\\\[","end":"]|(?=\\\\*/)","patterns":[{"include":"#brackets"}]}]},"cast":{"patterns":[{"captures":{"1":{"name":"meta.brace.angle.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"meta.brace.angle.ts"}},"match":"\\\\s*(<)\\\\s*(const)\\\\s*(>)","name":"cast.expr.ts"},{"begin":"(?<!\\\\+\\\\+|--)(?<=^return|[^$._[:alnum:]]return|^throw|[^$._[:alnum:]]throw|^yield|[^$._[:alnum:]]yield|^await|[^$._[:alnum:]]await|^default|[^$._[:alnum:]]default|[\\\\&(*,:=>?^|]|[^$_[:alnum:]](?:\\\\+\\\\+|--)|[^+]\\\\+|[^-]-)\\\\s*(<)(?!<?=)(?!\\\\s*$)","beginCaptures":{"1":{"name":"meta.brace.angle.ts"}},"end":"(>)","endCaptures":{"1":{"name":"meta.brace.angle.ts"}},"name":"cast.expr.ts","patterns":[{"include":"#type"}]},{"begin":"(?<=^)\\\\s*(<)(?=[$_[:alpha:]][$_[:alnum:]]*\\\\s*>)","beginCaptures":{"1":{"name":"meta.brace.angle.ts"}},"end":"(>)","endCaptures":{"1":{"name":"meta.brace.angle.ts"}},"name":"cast.expr.ts","patterns":[{"include":"#type"}]}]},"class-declaration":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(?:(abstract)\\\\s+)?\\\\b(class)\\\\b(?=\\\\s+|/[*/])","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.modifier.ts"},"4":{"name":"storage.type.class.ts"}},"end":"(?<=})","name":"meta.class.ts","patterns":[{"include":"#class-declaration-or-expression-patterns"}]},"class-declaration-or-expression-patterns":{"patterns":[{"include":"#comment"},{"include":"#class-or-interface-heritage"},{"captures":{"0":{"name":"entity.name.type.class.ts"}},"match":"[$_[:alpha:]][$_[:alnum:]]*"},{"include":"#type-parameters"},{"include":"#class-or-interface-body"}]},"class-expression":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(abstract)\\\\s+)?(class)\\\\b(?=\\\\s+|[<{]|/[*/])","beginCaptures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"storage.type.class.ts"}},"end":"(?<=})","name":"meta.class.ts","patterns":[{"include":"#class-declaration-or-expression-patterns"}]},"class-or-interface-body":{"begin":"\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"patterns":[{"include":"#comment"},{"include":"#decorator"},{"begin":"(?<=:)\\\\s*","end":"(?=[-\\\\])+,:;}\\\\s]|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)","patterns":[{"include":"#expression"}]},{"include":"#method-declaration"},{"include":"#indexer-declaration"},{"include":"#field-declaration"},{"include":"#string"},{"include":"#type-annotation"},{"include":"#variable-initializer"},{"include":"#access-modifier"},{"include":"#property-accessor"},{"include":"#async-modifier"},{"include":"#after-operator-block-as-object-literal"},{"include":"#decl-block"},{"include":"#expression"},{"include":"#punctuation-comma"},{"include":"#punctuation-semicolon"}]},"class-or-interface-heritage":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))\\\\b(extends|implements)\\\\b(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","beginCaptures":{"1":{"name":"storage.modifier.ts"}},"end":"(?=\\\\{)","patterns":[{"include":"#comment"},{"include":"#class-or-interface-heritage"},{"include":"#type-parameters"},{"include":"#expressionWithoutIdentifiers"},{"captures":{"1":{"name":"entity.name.type.module.ts"},"2":{"name":"punctuation.accessor.ts"},"3":{"name":"punctuation.accessor.optional.ts"}},"match":"([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))(?=\\\\s*[$_[:alpha:]][$_[:alnum:]]*(\\\\s*\\\\??\\\\.\\\\s*[$_[:alpha:]][$_[:alnum:]]*)*\\\\s*)"},{"captures":{"1":{"name":"entity.other.inherited-class.ts"}},"match":"([$_[:alpha:]][$_[:alnum:]]*)"},{"include":"#expressionPunctuations"}]},"comment":{"patterns":[{"begin":"/\\\\*\\\\*(?!/)","beginCaptures":{"0":{"name":"punctuation.definition.comment.ts"}},"end":"\\\\*/","endCaptures":{"0":{"name":"punctuation.definition.comment.ts"}},"name":"comment.block.documentation.ts","patterns":[{"include":"#docblock"}]},{"begin":"(/\\\\*)(?:\\\\s*((@)internal)(?=\\\\s|(\\\\*/)))?","beginCaptures":{"1":{"name":"punctuation.definition.comment.ts"},"2":{"name":"storage.type.internaldeclaration.ts"},"3":{"name":"punctuation.decorator.internaldeclaration.ts"}},"end":"\\\\*/","endCaptures":{"0":{"name":"punctuation.definition.comment.ts"}},"name":"comment.block.ts"},{"begin":"(^[\\\\t ]+)?((//)(?:\\\\s*((@)internal)(?=\\\\s|$))?)","beginCaptures":{"1":{"name":"punctuation.whitespace.comment.leading.ts"},"2":{"name":"comment.line.double-slash.ts"},"3":{"name":"punctuation.definition.comment.ts"},"4":{"name":"storage.type.internaldeclaration.ts"},"5":{"name":"punctuation.decorator.internaldeclaration.ts"}},"contentName":"comment.line.double-slash.ts","end":"(?=$)"}]},"control-statement":{"patterns":[{"include":"#switch-statement"},{"include":"#for-loop"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(catch|finally|throw|try)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.control.trycatch.ts"},{"captures":{"1":{"name":"keyword.control.loop.ts"},"2":{"name":"entity.name.label.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(break|continue|goto)\\\\s+([$_[:alpha:]][$_[:alnum:]]*)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(break|continue|do|goto|while)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.control.loop.ts"},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(return)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","beginCaptures":{"0":{"name":"keyword.control.flow.ts"}},"end":"(?=[;}]|$|;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)","patterns":[{"include":"#expression"}]},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(case|default|switch)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.control.switch.ts"},{"include":"#if-statement"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(else|if)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.control.conditional.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(with)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.control.with.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(package)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.control.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(debugger)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.other.debugger.ts"}]},"decl-block":{"begin":"\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"name":"meta.block.ts","patterns":[{"include":"#statements"}]},"declaration":{"patterns":[{"include":"#decorator"},{"include":"#var-expr"},{"include":"#function-declaration"},{"include":"#class-declaration"},{"include":"#interface-declaration"},{"include":"#enum-declaration"},{"include":"#namespace-declaration"},{"include":"#type-alias-declaration"},{"include":"#import-equals-declaration"},{"include":"#import-declaration"},{"include":"#export-declaration"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(declare|export)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"storage.modifier.ts"}]},"decorator":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))@","beginCaptures":{"0":{"name":"punctuation.decorator.ts"}},"end":"(?=\\\\s)","name":"meta.decorator.ts","patterns":[{"include":"#expression"}]},"destructuring-const":{"patterns":[{"begin":"(?<![:=]|^of|[^$._[:alnum:]]of|^in|[^$._[:alnum:]]in)\\\\s*(?=\\\\{)","end":"(?=$|^|[,;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+))","name":"meta.object-binding-pattern-variable.ts","patterns":[{"include":"#object-binding-pattern-const"},{"include":"#type-annotation"},{"include":"#comment"}]},{"begin":"(?<![:=]|^of|[^$._[:alnum:]]of|^in|[^$._[:alnum:]]in)\\\\s*(?=\\\\[)","end":"(?=$|^|[,;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+))","name":"meta.array-binding-pattern-variable.ts","patterns":[{"include":"#array-binding-pattern-const"},{"include":"#type-annotation"},{"include":"#comment"}]}]},"destructuring-parameter":{"patterns":[{"begin":"(?<![:=])\\\\s*(?:(\\\\.\\\\.\\\\.)\\\\s*)?(\\\\{)","beginCaptures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"punctuation.definition.binding-pattern.object.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.binding-pattern.object.ts"}},"name":"meta.parameter.object-binding-pattern.ts","patterns":[{"include":"#parameter-object-binding-element"}]},{"begin":"(?<![:=])\\\\s*(?:(\\\\.\\\\.\\\\.)\\\\s*)?(\\\\[)","beginCaptures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"punctuation.definition.binding-pattern.array.ts"}},"end":"]","endCaptures":{"0":{"name":"punctuation.definition.binding-pattern.array.ts"}},"name":"meta.paramter.array-binding-pattern.ts","patterns":[{"include":"#parameter-binding-element"},{"include":"#punctuation-comma"}]}]},"destructuring-parameter-rest":{"captures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"variable.parameter.ts"}},"match":"(?:(\\\\.\\\\.\\\\.)\\\\s*)?([$_[:alpha:]][$_[:alnum:]]*)"},"destructuring-variable":{"patterns":[{"begin":"(?<![:=]|^of|[^$._[:alnum:]]of|^in|[^$._[:alnum:]]in)\\\\s*(?=\\\\{)","end":"(?=$|^|[,;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+))","name":"meta.object-binding-pattern-variable.ts","patterns":[{"include":"#object-binding-pattern"},{"include":"#type-annotation"},{"include":"#comment"}]},{"begin":"(?<![:=]|^of|[^$._[:alnum:]]of|^in|[^$._[:alnum:]]in)\\\\s*(?=\\\\[)","end":"(?=$|^|[,;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+))","name":"meta.array-binding-pattern-variable.ts","patterns":[{"include":"#array-binding-pattern"},{"include":"#type-annotation"},{"include":"#comment"}]}]},"destructuring-variable-rest":{"captures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"meta.definition.variable.ts variable.other.readwrite.ts"}},"match":"(?:(\\\\.\\\\.\\\\.)\\\\s*)?([$_[:alpha:]][$_[:alnum:]]*)"},"destructuring-variable-rest-const":{"captures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"meta.definition.variable.ts variable.other.constant.ts"}},"match":"(?:(\\\\.\\\\.\\\\.)\\\\s*)?([$_[:alpha:]][$_[:alnum:]]*)"},"directives":{"begin":"^(///)\\\\s*(?=<(reference|amd-dependency|amd-module)(\\\\s+(path|types|no-default-lib|lib|name|resolution-mode)\\\\s*=\\\\s*((\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)))+\\\\s*/>\\\\s*$)","beginCaptures":{"1":{"name":"punctuation.definition.comment.ts"}},"end":"(?=$)","name":"comment.line.triple-slash.directive.ts","patterns":[{"begin":"(<)(reference|amd-dependency|amd-module)","beginCaptures":{"1":{"name":"punctuation.definition.tag.directive.ts"},"2":{"name":"entity.name.tag.directive.ts"}},"end":"/>","endCaptures":{"0":{"name":"punctuation.definition.tag.directive.ts"}},"name":"meta.tag.ts","patterns":[{"match":"path|types|no-default-lib|lib|name|resolution-mode","name":"entity.other.attribute-name.directive.ts"},{"match":"=","name":"keyword.operator.assignment.ts"},{"include":"#string"}]}]},"docblock":{"patterns":[{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"constant.language.access-type.jsdoc"}},"match":"((@)a(?:ccess|pi))\\\\s+(p(?:rivate|rotected|ublic))\\\\b"},{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"entity.name.type.instance.jsdoc"},"4":{"name":"punctuation.definition.bracket.angle.begin.jsdoc"},"5":{"name":"constant.other.email.link.underline.jsdoc"},"6":{"name":"punctuation.definition.bracket.angle.end.jsdoc"}},"match":"((@)author)\\\\s+([^*/<>@\\\\s](?:[^*/<>@]|\\\\*[^/])*)(?:\\\\s*(<)([^>\\\\s]+)(>))?"},{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"entity.name.type.instance.jsdoc"},"4":{"name":"keyword.operator.control.jsdoc"},"5":{"name":"entity.name.type.instance.jsdoc"}},"match":"((@)borrows)\\\\s+((?:[^*/@\\\\s]|\\\\*[^/])+)\\\\s+(as)\\\\s+((?:[^*/@\\\\s]|\\\\*[^/])+)"},{"begin":"((@)example)\\\\s+","beginCaptures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"}},"end":"(?=@|\\\\*/)","name":"meta.example.jsdoc","patterns":[{"match":"^\\\\s\\\\*\\\\s+"},{"begin":"\\\\G(<)caption(>)","beginCaptures":{"0":{"name":"entity.name.tag.inline.jsdoc"},"1":{"name":"punctuation.definition.bracket.angle.begin.jsdoc"},"2":{"name":"punctuation.definition.bracket.angle.end.jsdoc"}},"contentName":"constant.other.description.jsdoc","end":"(</)caption(>)|(?=\\\\*/)","endCaptures":{"0":{"name":"entity.name.tag.inline.jsdoc"},"1":{"name":"punctuation.definition.bracket.angle.begin.jsdoc"},"2":{"name":"punctuation.definition.bracket.angle.end.jsdoc"}}},{"captures":{"0":{"name":"source.embedded.ts"}},"match":"[^*@\\\\s](?:[^*]|\\\\*[^/])*"}]},{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"constant.language.symbol-type.jsdoc"}},"match":"((@)kind)\\\\s+(class|constant|event|external|file|function|member|mixin|module|namespace|typedef)\\\\b"},{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"variable.other.link.underline.jsdoc"},"4":{"name":"entity.name.type.instance.jsdoc"}},"match":"((@)see)\\\\s+(?:((?=https?://)(?:[^*\\\\s]|\\\\*[^/])+)|((?!https?://|(?:\\\\[[^]\\\\[]*])?\\\\{@(?:link|linkcode|linkplain|tutorial)\\\\b)(?:[^*/@\\\\s]|\\\\*[^/])+))"},{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"variable.other.jsdoc"}},"match":"((@)template)\\\\s+([$A-Z_a-z][]$.\\\\[\\\\w]*(?:\\\\s*,\\\\s*[$A-Z_a-z][]$.\\\\[\\\\w]*)*)"},{"begin":"((@)template)\\\\s+(?=\\\\{)","beginCaptures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"}},"end":"(?=\\\\s|\\\\*/|[^]$A-\\\\[_a-{}])","patterns":[{"include":"#jsdoctype"},{"match":"([$A-Z_a-z][]$.\\\\[\\\\w]*)","name":"variable.other.jsdoc"}]},{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"variable.other.jsdoc"}},"match":"((@)(?:arg|argument|const|constant|member|namespace|param|var))\\\\s+([$A-Z_a-z][]$.\\\\[\\\\w]*)"},{"begin":"((@)typedef)\\\\s+(?=\\\\{)","beginCaptures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"}},"end":"(?=\\\\s|\\\\*/|[^]$A-\\\\[_a-{}])","patterns":[{"include":"#jsdoctype"},{"match":"(?:[^*/@\\\\s]|\\\\*[^/])+","name":"entity.name.type.instance.jsdoc"}]},{"begin":"((@)(?:arg|argument|const|constant|member|namespace|param|prop|property|var))\\\\s+(?=\\\\{)","beginCaptures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"}},"end":"(?=\\\\s|\\\\*/|[^]$A-\\\\[_a-{}])","patterns":[{"include":"#jsdoctype"},{"match":"([$A-Z_a-z][]$.\\\\[\\\\w]*)","name":"variable.other.jsdoc"},{"captures":{"1":{"name":"punctuation.definition.optional-value.begin.bracket.square.jsdoc"},"2":{"name":"keyword.operator.assignment.jsdoc"},"3":{"name":"source.embedded.ts"},"4":{"name":"punctuation.definition.optional-value.end.bracket.square.jsdoc"},"5":{"name":"invalid.illegal.syntax.jsdoc"}},"match":"(\\\\[)\\\\s*[$\\\\w]+(?:(?:\\\\[])?\\\\.[$\\\\w]+)*(?:\\\\s*(=)\\\\s*((?>\\"(?:\\\\*(?!/)|\\\\\\\\(?!\\")|[^*\\\\\\\\])*?\\"|\'(?:\\\\*(?!/)|\\\\\\\\(?!\')|[^*\\\\\\\\])*?\'|\\\\[(?:\\\\*(?!/)|[^*])*?]|(?:\\\\*(?!/)|\\\\s(?!\\\\s*])|\\\\[.*?(?:]|(?=\\\\*/))|[^]*\\\\[\\\\s])*)*))?\\\\s*(?:(])((?:[^*\\\\s]|\\\\*[^/\\\\s])+)?|(?=\\\\*/))","name":"variable.other.jsdoc"}]},{"begin":"((@)(?:define|enum|exception|export|extends|lends|implements|modifies|namespace|private|protected|returns?|satisfies|suppress|this|throws|type|yields?))\\\\s+(?=\\\\{)","beginCaptures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"}},"end":"(?=\\\\s|\\\\*/|[^]$A-\\\\[_a-{}])","patterns":[{"include":"#jsdoctype"}]},{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"entity.name.type.instance.jsdoc"}},"match":"((@)(?:alias|augments|callback|constructs|emits|event|fires|exports?|extends|external|function|func|host|lends|listens|interface|memberof!?|method|module|mixes|mixin|name|requires|see|this|typedef|uses))\\\\s+((?:[^*@{}\\\\s]|\\\\*[^/])+)"},{"begin":"((@)(?:default(?:value)?|license|version))\\\\s+(([\\"\']))","beginCaptures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"variable.other.jsdoc"},"4":{"name":"punctuation.definition.string.begin.jsdoc"}},"contentName":"variable.other.jsdoc","end":"(\\\\3)|(?=$|\\\\*/)","endCaptures":{"0":{"name":"variable.other.jsdoc"},"1":{"name":"punctuation.definition.string.end.jsdoc"}}},{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"},"3":{"name":"variable.other.jsdoc"}},"match":"((@)(?:default(?:value)?|license|tutorial|variation|version))\\\\s+([^*\\\\s]+)"},{"captures":{"1":{"name":"punctuation.definition.block.tag.jsdoc"}},"match":"(@)(?:abstract|access|alias|api|arg|argument|async|attribute|augments|author|beta|borrows|bubbles|callback|chainable|class|classdesc|code|config|const|constant|constructor|constructs|copyright|default|defaultvalue|define|deprecated|desc|description|dict|emits|enum|event|example|exception|exports?|extends|extension(?:_?for)?|external|externs|file|fileoverview|final|fires|for|func|function|generator|global|hideconstructor|host|ignore|implements|implicitCast|inherit[Dd]oc|inner|instance|interface|internal|kind|lends|license|listens|main|member|memberof!?|method|mixes|mixins?|modifies|module|name|namespace|noalias|nocollapse|nocompile|nosideeffects|override|overview|package|param|polymer(?:Behavior)?|preserve|private|prop|property|protected|public|read[Oo]nly|record|require[ds]|returns?|see|since|static|struct|submodule|summary|suppress|template|this|throws|todo|tutorial|type|typedef|unrestricted|uses|var|variation|version|virtual|writeOnce|yields?)\\\\b","name":"storage.type.class.jsdoc"},{"include":"#inline-tags"},{"captures":{"1":{"name":"storage.type.class.jsdoc"},"2":{"name":"punctuation.definition.block.tag.jsdoc"}},"match":"((@)[$_[:alpha:]][$_[:alnum:]]*)(?=\\\\s+)"}]},"enum-declaration":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?(?:\\\\b(const)\\\\s+)?\\\\b(enum)\\\\s+([$_[:alpha:]][$_[:alnum:]]*)","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.modifier.ts"},"4":{"name":"storage.type.enum.ts"},"5":{"name":"entity.name.type.enum.ts"}},"end":"(?<=})","name":"meta.enum.declaration.ts","patterns":[{"include":"#comment"},{"begin":"\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"patterns":[{"include":"#comment"},{"begin":"([$_[:alpha:]][$_[:alnum:]]*)","beginCaptures":{"0":{"name":"variable.other.enummember.ts"}},"end":"(?=[,}]|$)","patterns":[{"include":"#comment"},{"include":"#variable-initializer"}]},{"begin":"(?=((\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+])))","end":"(?=[,}]|$)","patterns":[{"include":"#string"},{"include":"#array-literal"},{"include":"#comment"},{"include":"#variable-initializer"}]},{"include":"#punctuation-comma"}]}]},"export-declaration":{"patterns":[{"captures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"keyword.control.as.ts"},"3":{"name":"storage.type.namespace.ts"},"4":{"name":"entity.name.type.module.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(export)\\\\s+(as)\\\\s+(namespace)\\\\s+([$_[:alpha:]][$_[:alnum:]]*)"},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(export)(?:\\\\s+(type))?(?:\\\\s*(=)|\\\\s+(default)(?=\\\\s+))","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"keyword.control.type.ts"},"3":{"name":"keyword.operator.assignment.ts"},"4":{"name":"keyword.control.default.ts"}},"end":"(?=$|;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)","name":"meta.export.default.ts","patterns":[{"include":"#interface-declaration"},{"include":"#expression"}]},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(export)(?:\\\\s+(type))?\\\\b(?!(\\\\$)|(\\\\s*:))((?=\\\\s*[*{])|((?=\\\\s*[$_[:alpha:]][$_[:alnum:]]*([,\\\\s]))(?!\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)))","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"keyword.control.type.ts"}},"end":"(?=$|;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)","name":"meta.export.ts","patterns":[{"include":"#import-export-declaration"}]}]},"expression":{"patterns":[{"include":"#expressionWithoutIdentifiers"},{"include":"#identifiers"},{"include":"#expressionPunctuations"}]},"expression-inside-possibly-arrow-parens":{"patterns":[{"include":"#expressionWithoutIdentifiers"},{"include":"#comment"},{"include":"#string"},{"include":"#decorator"},{"include":"#destructuring-parameter"},{"captures":{"1":{"name":"storage.modifier.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(override|public|protected|private|readonly)\\\\s+(?=(override|public|protected|private|readonly)\\\\s+)"},{"captures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"keyword.operator.rest.ts"},"3":{"name":"entity.name.function.ts variable.language.this.ts"},"4":{"name":"entity.name.function.ts"},"5":{"name":"keyword.operator.optional.ts"}},"match":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(override|public|private|protected|readonly)\\\\s+)?(?:(\\\\.\\\\.\\\\.)\\\\s*)?(?<![:=])(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(this)|([$_[:alpha:]][$_[:alnum:]]*))(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))\\\\s*(\\\\??)(?=\\\\s*(=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>)))))|(:\\\\s*((<)|(\\\\(\\\\s*((\\\\))|(\\\\.\\\\.\\\\.)|([$_[:alnum:]]+\\\\s*(([,:=?])|(\\\\)\\\\s*=>)))))))|(:\\\\s*(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))Function(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))|(:\\\\s*((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))))))|(:\\\\s*(=>|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(<[^<>]*>)|[^(),<=>])+=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>))))))"},{"captures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"keyword.operator.rest.ts"},"3":{"name":"variable.parameter.ts variable.language.this.ts"},"4":{"name":"variable.parameter.ts"},"5":{"name":"keyword.operator.optional.ts"}},"match":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(override|public|private|protected|readonly)\\\\s+)?(?:(\\\\.\\\\.\\\\.)\\\\s*)?(?<![:=])(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(this)|([$_[:alpha:]][$_[:alnum:]]*))(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))\\\\s*(\\\\??)(?=\\\\s*[,:]|$)"},{"include":"#type-annotation"},{"include":"#variable-initializer"},{"match":",","name":"punctuation.separator.parameter.ts"},{"include":"#identifiers"},{"include":"#expressionPunctuations"}]},"expression-operators":{"patterns":[{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(await)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.control.flow.ts"},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(yield)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))(?=\\\\s*/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*\\\\*)","beginCaptures":{"1":{"name":"keyword.control.flow.ts"}},"end":"\\\\*","endCaptures":{"0":{"name":"keyword.generator.asterisk.ts"}},"patterns":[{"include":"#comment"}]},{"captures":{"1":{"name":"keyword.control.flow.ts"},"2":{"name":"keyword.generator.asterisk.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(yield)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))(?:\\\\s*(\\\\*))?"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))delete(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.operator.expression.delete.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))in(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))(?!\\\\()","name":"keyword.operator.expression.in.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))of(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))(?!\\\\()","name":"keyword.operator.expression.of.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))instanceof(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.operator.expression.instanceof.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))new(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.operator.new.ts"},{"include":"#typeof-operator"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))void(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.operator.expression.void.ts"},{"captures":{"1":{"name":"keyword.control.as.ts"},"2":{"name":"storage.modifier.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(as)\\\\s+(const)(?=\\\\s*($|[]),:;}]))"},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(as)|(satisfies))\\\\s+","beginCaptures":{"1":{"name":"keyword.control.as.ts"},"2":{"name":"keyword.control.satisfies.ts"}},"end":"(?=^|[-\\\\])+,:;>?}]|\\\\|\\\\||&&|!==|$|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(as|satisfies)\\\\s+)|(\\\\s+<))","patterns":[{"include":"#type"}]},{"match":"\\\\.\\\\.\\\\.","name":"keyword.operator.spread.ts"},{"match":"(?:\\\\*|(?<!\\\\()/|[-%+])=","name":"keyword.operator.assignment.compound.ts"},{"match":"(?:[\\\\&^]|<<|>>>??|\\\\|)=","name":"keyword.operator.assignment.compound.bitwise.ts"},{"match":"<<|>>>?","name":"keyword.operator.bitwise.shift.ts"},{"match":"[!=]==?","name":"keyword.operator.comparison.ts"},{"match":"<=|>=|<>|[<>]","name":"keyword.operator.relational.ts"},{"captures":{"1":{"name":"keyword.operator.logical.ts"},"2":{"name":"keyword.operator.assignment.compound.ts"},"3":{"name":"keyword.operator.arithmetic.ts"}},"match":"(?<=[$_[:alnum:]])(!)\\\\s*(?:(/=)|(/)(?![*/]))"},{"match":"!|&&|\\\\|\\\\||\\\\?\\\\?","name":"keyword.operator.logical.ts"},{"match":"[\\\\&^|~]","name":"keyword.operator.bitwise.ts"},{"match":"=","name":"keyword.operator.assignment.ts"},{"match":"--","name":"keyword.operator.decrement.ts"},{"match":"\\\\+\\\\+","name":"keyword.operator.increment.ts"},{"match":"[-%*+/]","name":"keyword.operator.arithmetic.ts"},{"begin":"(?<=[]$)_[:alnum:]])\\\\s*(?=(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)+(?:(/=)|(/)(?![*/])))","end":"(/=)|(/)(?!\\\\*([^*]|(\\\\*[^/]))*\\\\*/)","endCaptures":{"1":{"name":"keyword.operator.assignment.compound.ts"},"2":{"name":"keyword.operator.arithmetic.ts"}},"patterns":[{"include":"#comment"}]},{"captures":{"1":{"name":"keyword.operator.assignment.compound.ts"},"2":{"name":"keyword.operator.arithmetic.ts"}},"match":"(?<=[]$)_[:alnum:]])\\\\s*(?:(/=)|(/)(?![*/]))"}]},"expressionPunctuations":{"patterns":[{"include":"#punctuation-comma"},{"include":"#punctuation-accessor"}]},"expressionWithoutIdentifiers":{"patterns":[{"include":"#string"},{"include":"#regex"},{"include":"#comment"},{"include":"#function-expression"},{"include":"#class-expression"},{"include":"#arrow-function"},{"include":"#paren-expression-possibly-arrow"},{"include":"#cast"},{"include":"#ternary-expression"},{"include":"#new-expr"},{"include":"#instanceof-expr"},{"include":"#object-literal"},{"include":"#expression-operators"},{"include":"#function-call"},{"include":"#literal"},{"include":"#support-objects"},{"include":"#paren-expression"}]},"field-declaration":{"begin":"(?<!\\\\()(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(readonly)\\\\s+)?(?=\\\\s*(\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|(#?[$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(?:(?:(\\\\?)|(!))\\\\s*)?([,:;=}]|$))","beginCaptures":{"1":{"name":"storage.modifier.ts"}},"end":"(?=[,;}]|$|^((?!\\\\s*(\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|(#?[$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(?:(?:(\\\\?)|(!))\\\\s*)?([,:;=]|$))))|(?<=})","name":"meta.field.declaration.ts","patterns":[{"include":"#variable-initializer"},{"include":"#type-annotation"},{"include":"#string"},{"include":"#array-literal"},{"include":"#numeric-literal"},{"include":"#comment"},{"captures":{"1":{"name":"meta.definition.property.ts entity.name.function.ts"},"2":{"name":"keyword.operator.optional.ts"},"3":{"name":"keyword.operator.definiteassignment.ts"}},"match":"(#?[$_[:alpha:]][$_[:alnum:]]*)(?:(\\\\?)|(!))?(?=\\\\s*\\\\s*(=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>)))))|(:\\\\s*((<)|(\\\\(\\\\s*((\\\\))|(\\\\.\\\\.\\\\.)|([$_[:alnum:]]+\\\\s*(([,:=?])|(\\\\)\\\\s*=>)))))))|(:\\\\s*(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))Function(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))|(:\\\\s*((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))))))|(:\\\\s*(=>|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(<[^<>]*>)|[^(),<=>])+=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>))))))"},{"match":"#?[$_[:alpha:]][$_[:alnum:]]*","name":"meta.definition.property.ts variable.object.property.ts"},{"match":"\\\\?","name":"keyword.operator.optional.ts"},{"match":"!","name":"keyword.operator.definiteassignment.ts"}]},"for-loop":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))for(?=((\\\\s+|(\\\\s*/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*))await)?\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)?(\\\\())","beginCaptures":{"0":{"name":"keyword.control.loop.ts"}},"end":"(?<=\\\\))","patterns":[{"include":"#comment"},{"match":"await","name":"keyword.control.loop.ts"},{"begin":"\\\\(","beginCaptures":{"0":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"patterns":[{"include":"#var-expr"},{"include":"#expression"},{"include":"#punctuation-semicolon"}]}]},"function-body":{"patterns":[{"include":"#comment"},{"include":"#type-parameters"},{"include":"#function-parameters"},{"include":"#return-type"},{"include":"#type-function-return-type"},{"include":"#decl-block"},{"match":"\\\\*","name":"keyword.generator.asterisk.ts"}]},"function-call":{"patterns":[{"begin":"(?=(((([$_[:alpha:]][$_[:alnum:]]*)(\\\\s*\\\\??\\\\.\\\\s*(#?[$_[:alpha:]][$_[:alnum:]]*))*)|(\\\\??\\\\.\\\\s*#?[$_[:alpha:]][$_[:alnum:]]*))|(?<=\\\\)))\\\\s*(?:(\\\\?\\\\.\\\\s*)|(!))?((<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))(([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>)*(?<!=)>))*(?<!=)>)*(?<!=)>\\\\s*)?\\\\())","end":"(?<=\\\\))(?!(((([$_[:alpha:]][$_[:alnum:]]*)(\\\\s*\\\\??\\\\.\\\\s*(#?[$_[:alpha:]][$_[:alnum:]]*))*)|(\\\\??\\\\.\\\\s*#?[$_[:alpha:]][$_[:alnum:]]*))|(?<=\\\\)))\\\\s*(?:(\\\\?\\\\.\\\\s*)|(!))?((<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))(([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>)*(?<!=)>))*(?<!=)>)*(?<!=)>\\\\s*)?\\\\())","patterns":[{"begin":"(?=(([$_[:alpha:]][$_[:alnum:]]*)(\\\\s*\\\\??\\\\.\\\\s*(#?[$_[:alpha:]][$_[:alnum:]]*))*)|(\\\\??\\\\.\\\\s*#?[$_[:alpha:]][$_[:alnum:]]*))","end":"(?=\\\\s*(?:(\\\\?\\\\.\\\\s*)|(!))?((<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))(([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>)*(?<!=)>))*(?<!=)>)*(?<!=)>\\\\s*)?\\\\())","name":"meta.function-call.ts","patterns":[{"include":"#function-call-target"}]},{"include":"#comment"},{"include":"#function-call-optionals"},{"include":"#type-arguments"},{"include":"#paren-expression"}]},{"begin":"(?=(((([$_[:alpha:]][$_[:alnum:]]*)(\\\\s*\\\\??\\\\.\\\\s*(#?[$_[:alpha:]][$_[:alnum:]]*))*)|(\\\\??\\\\.\\\\s*#?[$_[:alpha:]][$_[:alnum:]]*))|(?<=\\\\)))(<\\\\s*[(\\\\[{]\\\\s*)$)","end":"(?<=>)(?!(((([$_[:alpha:]][$_[:alnum:]]*)(\\\\s*\\\\??\\\\.\\\\s*(#?[$_[:alpha:]][$_[:alnum:]]*))*)|(\\\\??\\\\.\\\\s*#?[$_[:alpha:]][$_[:alnum:]]*))|(?<=\\\\)))(<\\\\s*[(\\\\[{]\\\\s*)$)","patterns":[{"begin":"(?=(([$_[:alpha:]][$_[:alnum:]]*)(\\\\s*\\\\??\\\\.\\\\s*(#?[$_[:alpha:]][$_[:alnum:]]*))*)|(\\\\??\\\\.\\\\s*#?[$_[:alpha:]][$_[:alnum:]]*))","end":"(?=(<\\\\s*[(\\\\[{]\\\\s*)$)","name":"meta.function-call.ts","patterns":[{"include":"#function-call-target"}]},{"include":"#comment"},{"include":"#function-call-optionals"},{"include":"#type-arguments"}]}]},"function-call-optionals":{"patterns":[{"match":"\\\\?\\\\.","name":"meta.function-call.ts punctuation.accessor.optional.ts"},{"match":"!","name":"meta.function-call.ts keyword.operator.definiteassignment.ts"}]},"function-call-target":{"patterns":[{"include":"#support-function-call-identifiers"},{"match":"(#?[$_[:alpha:]][$_[:alnum:]]*)","name":"entity.name.function.ts"}]},"function-declaration":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?(?:(async)\\\\s+)?(function)\\\\b(?:\\\\s*(\\\\*))?(?:(?:\\\\s+|(?<=\\\\*))([$_[:alpha:]][$_[:alnum:]]*))?\\\\s*","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.modifier.async.ts"},"4":{"name":"storage.type.function.ts"},"5":{"name":"keyword.generator.asterisk.ts"},"6":{"name":"meta.definition.function.ts entity.name.function.ts"}},"end":"(?=;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)|(?<=})","name":"meta.function.ts","patterns":[{"include":"#function-name"},{"include":"#function-body"}]},"function-expression":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(async)\\\\s+)?(function)\\\\b(?:\\\\s*(\\\\*))?(?:(?:\\\\s+|(?<=\\\\*))([$_[:alpha:]][$_[:alnum:]]*))?\\\\s*","beginCaptures":{"1":{"name":"storage.modifier.async.ts"},"2":{"name":"storage.type.function.ts"},"3":{"name":"keyword.generator.asterisk.ts"},"4":{"name":"meta.definition.function.ts entity.name.function.ts"}},"end":"(?=;)|(?<=})","name":"meta.function.expression.ts","patterns":[{"include":"#function-name"},{"include":"#single-line-comment-consuming-line-ending"},{"include":"#function-body"}]},"function-name":{"match":"[$_[:alpha:]][$_[:alnum:]]*","name":"meta.definition.function.ts entity.name.function.ts"},"function-parameters":{"begin":"\\\\(","beginCaptures":{"0":{"name":"punctuation.definition.parameters.begin.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.definition.parameters.end.ts"}},"name":"meta.parameters.ts","patterns":[{"include":"#function-parameters-body"}]},"function-parameters-body":{"patterns":[{"include":"#comment"},{"include":"#string"},{"include":"#decorator"},{"include":"#destructuring-parameter"},{"include":"#parameter-name"},{"include":"#parameter-type-annotation"},{"include":"#variable-initializer"},{"match":",","name":"punctuation.separator.parameter.ts"}]},"identifiers":{"patterns":[{"include":"#object-identifiers"},{"captures":{"1":{"name":"punctuation.accessor.ts"},"2":{"name":"punctuation.accessor.optional.ts"},"3":{"name":"entity.name.function.ts"}},"match":"(?:(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))\\\\s*)?([$_[:alpha:]][$_[:alnum:]]*)(?=\\\\s*=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>)))))"},{"captures":{"1":{"name":"punctuation.accessor.ts"},"2":{"name":"punctuation.accessor.optional.ts"},"3":{"name":"variable.other.constant.property.ts"}},"match":"(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))\\\\s*(#?\\\\p{upper}[$_\\\\d[:upper:]]*)(?![$_[:alnum:]])"},{"captures":{"1":{"name":"punctuation.accessor.ts"},"2":{"name":"punctuation.accessor.optional.ts"},"3":{"name":"variable.other.property.ts"}},"match":"(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))\\\\s*(#?[$_[:alpha:]][$_[:alnum:]]*)"},{"match":"(\\\\p{upper}[$_\\\\d[:upper:]]*)(?![$_[:alnum:]])","name":"variable.other.constant.ts"},{"match":"[$_[:alpha:]][$_[:alnum:]]*","name":"variable.other.readwrite.ts"}]},"if-statement":{"patterns":[{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?=\\\\bif\\\\s*(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))\\\\s*(?!\\\\{))","end":"(?=;|$|})","patterns":[{"include":"#comment"},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(if)\\\\s*(\\\\()","beginCaptures":{"1":{"name":"keyword.control.conditional.ts"},"2":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"patterns":[{"include":"#expression"}]},{"begin":"(?<=\\\\))\\\\s*/(?![*/])(?=(?:[^/\\\\[\\\\\\\\]|\\\\\\\\.|\\\\[([^]\\\\\\\\]|\\\\\\\\.)*])+/([dgimsuvy]+|(?![*/])|(?=/\\\\*))(?!\\\\s*[$0-9A-Z_a-z]))","beginCaptures":{"0":{"name":"punctuation.definition.string.begin.ts"}},"end":"(/)([dgimsuvy]*)","endCaptures":{"1":{"name":"punctuation.definition.string.end.ts"},"2":{"name":"keyword.other.ts"}},"name":"string.regexp.ts","patterns":[{"include":"#regexp"}]},{"include":"#statements"}]}]},"import-declaration":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(import)(?:\\\\s+(type)(?!\\\\s+from))?(?!\\\\s*[(:])(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"keyword.control.import.ts"},"4":{"name":"keyword.control.type.ts"}},"end":"(?<!(?:^|[^$._[:alnum:]])import)(?=;|$|^)","name":"meta.import.ts","patterns":[{"include":"#single-line-comment-consuming-line-ending"},{"include":"#comment"},{"include":"#string"},{"begin":"(?<=(?:^|[^$._[:alnum:]])import)(?!\\\\s*[\\"\'])","end":"\\\\bfrom\\\\b","endCaptures":{"0":{"name":"keyword.control.from.ts"}},"patterns":[{"include":"#import-export-declaration"}]},{"include":"#import-export-declaration"}]},"import-equals-declaration":{"patterns":[{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(import)(?:\\\\s+(type))?\\\\s+([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(=)\\\\s*(require)\\\\s*(\\\\()","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"keyword.control.import.ts"},"4":{"name":"keyword.control.type.ts"},"5":{"name":"variable.other.readwrite.alias.ts"},"6":{"name":"keyword.operator.assignment.ts"},"7":{"name":"keyword.control.require.ts"},"8":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"name":"meta.import-equals.external.ts","patterns":[{"include":"#comment"},{"include":"#string"}]},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(import)(?:\\\\s+(type))?\\\\s+([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(=)\\\\s*(?!require\\\\b)","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"keyword.control.import.ts"},"4":{"name":"keyword.control.type.ts"},"5":{"name":"variable.other.readwrite.alias.ts"},"6":{"name":"keyword.operator.assignment.ts"}},"end":"(?=;|$|^)","name":"meta.import-equals.internal.ts","patterns":[{"include":"#single-line-comment-consuming-line-ending"},{"include":"#comment"},{"captures":{"1":{"name":"entity.name.type.module.ts"},"2":{"name":"punctuation.accessor.ts"},"3":{"name":"punctuation.accessor.optional.ts"}},"match":"([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))"},{"match":"([$_[:alpha:]][$_[:alnum:]]*)","name":"variable.other.readwrite.ts"}]}]},"import-export-assert-clause":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(with)|(assert))\\\\s*(\\\\{)","beginCaptures":{"1":{"name":"keyword.control.with.ts"},"2":{"name":"keyword.control.assert.ts"},"3":{"name":"punctuation.definition.block.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"patterns":[{"include":"#comment"},{"include":"#string"},{"match":"[$_[:alpha:]][$_[:alnum:]]*\\\\s*(?=(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*:)","name":"meta.object-literal.key.ts"},{"match":":","name":"punctuation.separator.key-value.ts"}]},"import-export-block":{"begin":"\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"name":"meta.block.ts","patterns":[{"include":"#import-export-clause"}]},"import-export-clause":{"patterns":[{"include":"#comment"},{"captures":{"1":{"name":"keyword.control.type.ts"},"2":{"name":"keyword.control.default.ts"},"3":{"name":"constant.language.import-export-all.ts"},"4":{"name":"variable.other.readwrite.ts"},"5":{"name":"string.quoted.alias.ts"},"12":{"name":"keyword.control.as.ts"},"13":{"name":"keyword.control.default.ts"},"14":{"name":"variable.other.readwrite.alias.ts"},"15":{"name":"string.quoted.alias.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(type)\\\\s+)?(?:\\\\b(default)|(\\\\*)|\\\\b([$_[:alpha:]][$_[:alnum:]]*)|((\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)))\\\\s+(as)\\\\s+(?:(default(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))|([$_[:alpha:]][$_[:alnum:]]*)|((\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)))"},{"include":"#punctuation-comma"},{"match":"\\\\*","name":"constant.language.import-export-all.ts"},{"match":"\\\\b(default)\\\\b","name":"keyword.control.default.ts"},{"captures":{"1":{"name":"keyword.control.type.ts"},"2":{"name":"variable.other.readwrite.alias.ts"},"3":{"name":"string.quoted.alias.ts"}},"match":"(?:\\\\b(type)\\\\s+)?(?:([$_[:alpha:]][$_[:alnum:]]*)|((\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)))"}]},"import-export-declaration":{"patterns":[{"include":"#comment"},{"include":"#string"},{"include":"#import-export-block"},{"match":"\\\\bfrom\\\\b","name":"keyword.control.from.ts"},{"include":"#import-export-assert-clause"},{"include":"#import-export-clause"}]},"indexer-declaration":{"begin":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(readonly)\\\\s*)?\\\\s*(\\\\[)\\\\s*([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(?=:)","beginCaptures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"meta.brace.square.ts"},"3":{"name":"variable.parameter.ts"}},"end":"(])\\\\s*(\\\\?\\\\s*)?|$","endCaptures":{"1":{"name":"meta.brace.square.ts"},"2":{"name":"keyword.operator.optional.ts"}},"name":"meta.indexer.declaration.ts","patterns":[{"include":"#type-annotation"}]},"indexer-mapped-type-declaration":{"begin":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))([-+])?(readonly)\\\\s*)?\\\\s*(\\\\[)\\\\s*([$_[:alpha:]][$_[:alnum:]]*)\\\\s+(in)\\\\s+","beginCaptures":{"1":{"name":"keyword.operator.type.modifier.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"meta.brace.square.ts"},"4":{"name":"entity.name.type.ts"},"5":{"name":"keyword.operator.expression.in.ts"}},"end":"(])([-+])?\\\\s*(\\\\?\\\\s*)?|$","endCaptures":{"1":{"name":"meta.brace.square.ts"},"2":{"name":"keyword.operator.type.modifier.ts"},"3":{"name":"keyword.operator.optional.ts"}},"name":"meta.indexer.mappedtype.declaration.ts","patterns":[{"captures":{"1":{"name":"keyword.control.as.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(as)\\\\s+"},{"include":"#type"}]},"inline-tags":{"patterns":[{"captures":{"1":{"name":"punctuation.definition.bracket.square.begin.jsdoc"},"2":{"name":"punctuation.definition.bracket.square.end.jsdoc"}},"match":"(\\\\[)[^]]+(])(?=\\\\{@(?:link|linkcode|linkplain|tutorial))","name":"constant.other.description.jsdoc"},{"begin":"(\\\\{)((@)(?:link(?:code|plain)?|tutorial))\\\\s*","beginCaptures":{"1":{"name":"punctuation.definition.bracket.curly.begin.jsdoc"},"2":{"name":"storage.type.class.jsdoc"},"3":{"name":"punctuation.definition.inline.tag.jsdoc"}},"end":"}|(?=\\\\*/)","endCaptures":{"0":{"name":"punctuation.definition.bracket.curly.end.jsdoc"}},"name":"entity.name.type.instance.jsdoc","patterns":[{"captures":{"1":{"name":"variable.other.link.underline.jsdoc"},"2":{"name":"punctuation.separator.pipe.jsdoc"}},"match":"\\\\G((?=https?://)(?:[^*|}\\\\s]|\\\\*/)+)(\\\\|)?"},{"captures":{"1":{"name":"variable.other.description.jsdoc"},"2":{"name":"punctuation.separator.pipe.jsdoc"}},"match":"\\\\G((?:[^*@{|}\\\\s]|\\\\*[^/])+)(\\\\|)?"}]}]},"instanceof-expr":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(instanceof)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","beginCaptures":{"1":{"name":"keyword.operator.expression.instanceof.ts"}},"end":"(?<=\\\\))|(?=[-\\\\])+,:;>?}]|\\\\|\\\\||&&|!==|$|([!=]==?)|(([\\\\&^|~]\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s+instanceof(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))function((\\\\s+[$_[:alpha:]][$_[:alnum:]]*)|(\\\\s*\\\\())))","patterns":[{"include":"#type"}]},"interface-declaration":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(?:(abstract)\\\\s+)?\\\\b(interface)\\\\b(?=\\\\s+|/[*/])","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.modifier.ts"},"4":{"name":"storage.type.interface.ts"}},"end":"(?<=})","name":"meta.interface.ts","patterns":[{"include":"#comment"},{"include":"#class-or-interface-heritage"},{"captures":{"0":{"name":"entity.name.type.interface.ts"}},"match":"[$_[:alpha:]][$_[:alnum:]]*"},{"include":"#type-parameters"},{"include":"#class-or-interface-body"}]},"jsdoctype":{"patterns":[{"begin":"\\\\G(\\\\{)","beginCaptures":{"0":{"name":"entity.name.type.instance.jsdoc"},"1":{"name":"punctuation.definition.bracket.curly.begin.jsdoc"}},"contentName":"entity.name.type.instance.jsdoc","end":"((}))\\\\s*|(?=\\\\*/)","endCaptures":{"1":{"name":"entity.name.type.instance.jsdoc"},"2":{"name":"punctuation.definition.bracket.curly.end.jsdoc"}},"patterns":[{"include":"#brackets"}]}]},"label":{"patterns":[{"begin":"([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(:)(?=\\\\s*\\\\{)","beginCaptures":{"1":{"name":"entity.name.label.ts"},"2":{"name":"punctuation.separator.label.ts"}},"end":"(?<=})","patterns":[{"include":"#decl-block"}]},{"captures":{"1":{"name":"entity.name.label.ts"},"2":{"name":"punctuation.separator.label.ts"}},"match":"([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(:)"}]},"literal":{"patterns":[{"include":"#numeric-literal"},{"include":"#boolean-literal"},{"include":"#null-literal"},{"include":"#undefined-literal"},{"include":"#numericConstant-literal"},{"include":"#array-literal"},{"include":"#this-literal"},{"include":"#super-literal"}]},"method-declaration":{"patterns":[{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(override)\\\\s+)?(?:\\\\b(p(?:ublic|rivate|rotected))\\\\s+)?(?:\\\\b(abstract)\\\\s+)?(?:\\\\b(async)\\\\s+)?\\\\s*\\\\b(constructor)\\\\b(?!:)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","beginCaptures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.modifier.ts"},"4":{"name":"storage.modifier.async.ts"},"5":{"name":"storage.type.ts"}},"end":"(?=[,;}]|$)|(?<=})","name":"meta.method.declaration.ts","patterns":[{"include":"#method-declaration-name"},{"include":"#function-body"}]},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(override)\\\\s+)?(?:\\\\b(p(?:ublic|rivate|rotected))\\\\s+)?(?:\\\\b(abstract)\\\\s+)?(?:\\\\b(async)\\\\s+)?(?:\\\\s*\\\\b(new)\\\\b(?!:)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))|(?:(\\\\*)\\\\s*)?)(?=\\\\s*((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*))?\\\\()","beginCaptures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.modifier.ts"},"4":{"name":"storage.modifier.async.ts"},"5":{"name":"keyword.operator.new.ts"},"6":{"name":"keyword.generator.asterisk.ts"}},"end":"(?=[,;}]|$)|(?<=})","name":"meta.method.declaration.ts","patterns":[{"include":"#method-declaration-name"},{"include":"#function-body"}]},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(override)\\\\s+)?(?:\\\\b(p(?:ublic|rivate|rotected))\\\\s+)?(?:\\\\b(abstract)\\\\s+)?(?:\\\\b(async)\\\\s+)?(?:\\\\b([gs]et)\\\\s+)?(?:(\\\\*)\\\\s*)?(?=\\\\s*((\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|([$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(\\\\??))\\\\s*((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*))?\\\\()","beginCaptures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.modifier.ts"},"4":{"name":"storage.modifier.async.ts"},"5":{"name":"storage.type.property.ts"},"6":{"name":"keyword.generator.asterisk.ts"}},"end":"(?=[,;}]|$)|(?<=})","name":"meta.method.declaration.ts","patterns":[{"include":"#method-declaration-name"},{"include":"#function-body"}]}]},"method-declaration-name":{"begin":"(?=(\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|([$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(\\\\??)\\\\s*[(<])","end":"(?=[(<])","patterns":[{"include":"#string"},{"include":"#array-literal"},{"include":"#numeric-literal"},{"match":"[$_[:alpha:]][$_[:alnum:]]*","name":"meta.definition.method.ts entity.name.function.ts"},{"match":"\\\\?","name":"keyword.operator.optional.ts"}]},"namespace-declaration":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(namespace|module)\\\\s+(?=[\\"$\'_`[:alpha:]])","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.type.namespace.ts"}},"end":"(?<=})|(?=;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)","name":"meta.namespace.declaration.ts","patterns":[{"include":"#comment"},{"include":"#string"},{"match":"([$_[:alpha:]][$_[:alnum:]]*)","name":"entity.name.type.module.ts"},{"include":"#punctuation-accessor"},{"include":"#decl-block"}]},"new-expr":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(new)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","beginCaptures":{"1":{"name":"keyword.operator.new.ts"}},"end":"(?<=\\\\))|(?=[-\\\\])+,:;>?}]|\\\\|\\\\||&&|!==|$|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))new(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))function((\\\\s+[$_[:alpha:]][$_[:alnum:]]*)|(\\\\s*\\\\())))","name":"new.expr.ts","patterns":[{"include":"#expression"}]},"null-literal":{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))null(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"constant.language.null.ts"},"numeric-literal":{"patterns":[{"captures":{"1":{"name":"storage.type.numeric.bigint.ts"}},"match":"\\\\b(?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$)","name":"constant.numeric.hex.ts"},{"captures":{"1":{"name":"storage.type.numeric.bigint.ts"}},"match":"\\\\b(?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$)","name":"constant.numeric.binary.ts"},{"captures":{"1":{"name":"storage.type.numeric.bigint.ts"}},"match":"\\\\b(?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$)","name":"constant.numeric.octal.ts"},{"captures":{"0":{"name":"constant.numeric.decimal.ts"},"1":{"name":"meta.delimiter.decimal.period.ts"},"2":{"name":"storage.type.numeric.bigint.ts"},"3":{"name":"meta.delimiter.decimal.period.ts"},"4":{"name":"storage.type.numeric.bigint.ts"},"5":{"name":"meta.delimiter.decimal.period.ts"},"6":{"name":"storage.type.numeric.bigint.ts"},"7":{"name":"storage.type.numeric.bigint.ts"},"8":{"name":"meta.delimiter.decimal.period.ts"},"9":{"name":"storage.type.numeric.bigint.ts"},"10":{"name":"meta.delimiter.decimal.period.ts"},"11":{"name":"storage.type.numeric.bigint.ts"},"12":{"name":"meta.delimiter.decimal.period.ts"},"13":{"name":"storage.type.numeric.bigint.ts"},"14":{"name":"storage.type.numeric.bigint.ts"}},"match":"(?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$)"}]},"numericConstant-literal":{"patterns":[{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))NaN(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"constant.language.nan.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))Infinity(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"constant.language.infinity.ts"}]},"object-binding-element":{"patterns":[{"include":"#comment"},{"begin":"(?=(\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|([$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(:))","end":"(?=[,}])","patterns":[{"include":"#object-binding-element-propertyName"},{"include":"#binding-element"}]},{"include":"#object-binding-pattern"},{"include":"#destructuring-variable-rest"},{"include":"#variable-initializer"},{"include":"#punctuation-comma"}]},"object-binding-element-const":{"patterns":[{"include":"#comment"},{"begin":"(?=(\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|([$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(:))","end":"(?=[,}])","patterns":[{"include":"#object-binding-element-propertyName"},{"include":"#binding-element-const"}]},{"include":"#object-binding-pattern-const"},{"include":"#destructuring-variable-rest-const"},{"include":"#variable-initializer"},{"include":"#punctuation-comma"}]},"object-binding-element-propertyName":{"begin":"(?=(\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|([$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(:))","end":"(:)","endCaptures":{"0":{"name":"punctuation.destructuring.ts"}},"patterns":[{"include":"#string"},{"include":"#array-literal"},{"include":"#numeric-literal"},{"match":"([$_[:alpha:]][$_[:alnum:]]*)","name":"variable.object.property.ts"}]},"object-binding-pattern":{"begin":"(?:(\\\\.\\\\.\\\\.)\\\\s*)?(\\\\{)","beginCaptures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"punctuation.definition.binding-pattern.object.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.binding-pattern.object.ts"}},"patterns":[{"include":"#object-binding-element"}]},"object-binding-pattern-const":{"begin":"(?:(\\\\.\\\\.\\\\.)\\\\s*)?(\\\\{)","beginCaptures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"punctuation.definition.binding-pattern.object.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.binding-pattern.object.ts"}},"patterns":[{"include":"#object-binding-element-const"}]},"object-identifiers":{"patterns":[{"match":"([$_[:alpha:]][$_[:alnum:]]*)(?=\\\\s*\\\\??\\\\.\\\\s*prototype\\\\b(?!\\\\$))","name":"support.class.ts"},{"captures":{"1":{"name":"punctuation.accessor.ts"},"2":{"name":"punctuation.accessor.optional.ts"},"3":{"name":"variable.other.constant.object.property.ts"},"4":{"name":"variable.other.object.property.ts"}},"match":"(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))\\\\s*(?:(#?\\\\p{upper}[$_\\\\d[:upper:]]*)|(#?[$_[:alpha:]][$_[:alnum:]]*))(?=\\\\s*\\\\??\\\\.\\\\s*#?[$_[:alpha:]][$_[:alnum:]]*)"},{"captures":{"1":{"name":"variable.other.constant.object.ts"},"2":{"name":"variable.other.object.ts"}},"match":"(?:(\\\\p{upper}[$_\\\\d[:upper:]]*)|([$_[:alpha:]][$_[:alnum:]]*))(?=\\\\s*\\\\??\\\\.\\\\s*#?[$_[:alpha:]][$_[:alnum:]]*)"}]},"object-literal":{"begin":"\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"name":"meta.objectliteral.ts","patterns":[{"include":"#object-member"}]},"object-literal-method-declaration":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(async)\\\\s+)?(?:\\\\b([gs]et)\\\\s+)?(?:(\\\\*)\\\\s*)?(?=\\\\s*((\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|([$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(\\\\??))\\\\s*((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*))?\\\\()","beginCaptures":{"1":{"name":"storage.modifier.async.ts"},"2":{"name":"storage.type.property.ts"},"3":{"name":"keyword.generator.asterisk.ts"}},"end":"(?=[,;}])|(?<=})","name":"meta.method.declaration.ts","patterns":[{"include":"#method-declaration-name"},{"include":"#function-body"},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(async)\\\\s+)?(?:\\\\b([gs]et)\\\\s+)?(?:(\\\\*)\\\\s*)?(?=\\\\s*((\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|([$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(\\\\??))\\\\s*((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*))?\\\\()","beginCaptures":{"1":{"name":"storage.modifier.async.ts"},"2":{"name":"storage.type.property.ts"},"3":{"name":"keyword.generator.asterisk.ts"}},"end":"(?=[(<])","patterns":[{"include":"#method-declaration-name"}]}]},"object-member":{"patterns":[{"include":"#comment"},{"include":"#object-literal-method-declaration"},{"begin":"(?=\\\\[)","end":"(?=:)|((?<=])(?=\\\\s*[(<]))","name":"meta.object.member.ts meta.object-literal.key.ts","patterns":[{"include":"#comment"},{"include":"#array-literal"}]},{"begin":"(?=[\\"\'`])","end":"(?=:)|((?<=[\\"\'`])(?=((\\\\s*[(,<}])|(\\\\s+(as|satisifies)\\\\s+))))","name":"meta.object.member.ts meta.object-literal.key.ts","patterns":[{"include":"#comment"},{"include":"#string"}]},{"begin":"(?=\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$)))","end":"(?=:)|(?=\\\\s*([(,<}])|(\\\\s+as|satisifies\\\\s+))","name":"meta.object.member.ts meta.object-literal.key.ts","patterns":[{"include":"#comment"},{"include":"#numeric-literal"}]},{"begin":"(?<=[]\\"\'`])(?=\\\\s*[(<])","end":"(?=[,;}])|(?<=})","name":"meta.method.declaration.ts","patterns":[{"include":"#function-body"}]},{"captures":{"0":{"name":"meta.object-literal.key.ts"},"1":{"name":"constant.numeric.decimal.ts"}},"match":"(?![$_[:alpha:]])(\\\\d+)\\\\s*(?=(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*:)","name":"meta.object.member.ts"},{"captures":{"0":{"name":"meta.object-literal.key.ts"},"1":{"name":"entity.name.function.ts"}},"match":"([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(?=(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*:(\\\\s*/\\\\*([^*]|(\\\\*[^/]))*\\\\*/)*\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>)))))","name":"meta.object.member.ts"},{"captures":{"0":{"name":"meta.object-literal.key.ts"}},"match":"[$_[:alpha:]][$_[:alnum:]]*\\\\s*(?=(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*:)","name":"meta.object.member.ts"},{"begin":"\\\\.\\\\.\\\\.","beginCaptures":{"0":{"name":"keyword.operator.spread.ts"}},"end":"(?=[,}])","name":"meta.object.member.ts","patterns":[{"include":"#expression"}]},{"captures":{"1":{"name":"variable.other.readwrite.ts"}},"match":"([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(?=[,}]|$|//|/\\\\*)","name":"meta.object.member.ts"},{"captures":{"1":{"name":"keyword.control.as.ts"},"2":{"name":"storage.modifier.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(as)\\\\s+(const)(?=\\\\s*([,}]|$))","name":"meta.object.member.ts"},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(as)|(satisfies))\\\\s+","beginCaptures":{"1":{"name":"keyword.control.as.ts"},"2":{"name":"keyword.control.satisfies.ts"}},"end":"(?=[-\\\\])+,:;>?}]|\\\\|\\\\||&&|!==|$|^|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(as|satisifies)\\\\s+))","name":"meta.object.member.ts","patterns":[{"include":"#type"}]},{"begin":"(?=[$_[:alpha:]][$_[:alnum:]]*\\\\s*=)","end":"(?=[,}]|$|//|/\\\\*)","name":"meta.object.member.ts","patterns":[{"include":"#expression"}]},{"begin":":","beginCaptures":{"0":{"name":"meta.object-literal.key.ts punctuation.separator.key-value.ts"}},"end":"(?=[,}])","name":"meta.object.member.ts","patterns":[{"begin":"(?<=:)\\\\s*(async)?(?=\\\\s*(<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))))","beginCaptures":{"1":{"name":"storage.modifier.async.ts"}},"end":"(?<=\\\\))","patterns":[{"include":"#type-parameters"},{"begin":"\\\\(","beginCaptures":{"0":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"patterns":[{"include":"#expression-inside-possibly-arrow-parens"}]}]},{"begin":"(?<=:)\\\\s*(async)?\\\\s*(\\\\()(?=\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))))","beginCaptures":{"1":{"name":"storage.modifier.async.ts"},"2":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"patterns":[{"include":"#expression-inside-possibly-arrow-parens"}]},{"begin":"(?<=:)\\\\s*(async)?\\\\s*(?=<\\\\s*$)","beginCaptures":{"1":{"name":"storage.modifier.async.ts"}},"end":"(?<=>)","patterns":[{"include":"#type-parameters"}]},{"begin":"(?<=>)\\\\s*(\\\\()(?=\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))))","beginCaptures":{"1":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"patterns":[{"include":"#expression-inside-possibly-arrow-parens"}]},{"include":"#possibly-arrow-return-type"},{"include":"#expression"}]},{"include":"#punctuation-comma"},{"include":"#decl-block"}]},"parameter-array-binding-pattern":{"begin":"(?:(\\\\.\\\\.\\\\.)\\\\s*)?(\\\\[)","beginCaptures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"punctuation.definition.binding-pattern.array.ts"}},"end":"]","endCaptures":{"0":{"name":"punctuation.definition.binding-pattern.array.ts"}},"patterns":[{"include":"#parameter-binding-element"},{"include":"#punctuation-comma"}]},"parameter-binding-element":{"patterns":[{"include":"#comment"},{"include":"#string"},{"include":"#numeric-literal"},{"include":"#regex"},{"include":"#parameter-object-binding-pattern"},{"include":"#parameter-array-binding-pattern"},{"include":"#destructuring-parameter-rest"},{"include":"#variable-initializer"}]},"parameter-name":{"patterns":[{"captures":{"1":{"name":"storage.modifier.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(override|public|protected|private|readonly)\\\\s+(?=(override|public|protected|private|readonly)\\\\s+)"},{"captures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"keyword.operator.rest.ts"},"3":{"name":"entity.name.function.ts variable.language.this.ts"},"4":{"name":"entity.name.function.ts"},"5":{"name":"keyword.operator.optional.ts"}},"match":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(override|public|private|protected|readonly)\\\\s+)?(?:(\\\\.\\\\.\\\\.)\\\\s*)?(?<![:=])(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(this)|([$_[:alpha:]][$_[:alnum:]]*))(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))\\\\s*(\\\\??)(?=\\\\s*(=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>)))))|(:\\\\s*((<)|(\\\\(\\\\s*((\\\\))|(\\\\.\\\\.\\\\.)|([$_[:alnum:]]+\\\\s*(([,:=?])|(\\\\)\\\\s*=>)))))))|(:\\\\s*(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))Function(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))|(:\\\\s*((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))))))|(:\\\\s*(=>|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(<[^<>]*>)|[^(),<=>])+=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>))))))"},{"captures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"keyword.operator.rest.ts"},"3":{"name":"variable.parameter.ts variable.language.this.ts"},"4":{"name":"variable.parameter.ts"},"5":{"name":"keyword.operator.optional.ts"}},"match":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(override|public|private|protected|readonly)\\\\s+)?(?:(\\\\.\\\\.\\\\.)\\\\s*)?(?<![:=])(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(this)|([$_[:alpha:]][$_[:alnum:]]*))(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))\\\\s*(\\\\??)"}]},"parameter-object-binding-element":{"patterns":[{"include":"#comment"},{"begin":"(?=(\\\\b((?<!\\\\$)0[Xx]\\\\h[_\\\\h]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Bb][01][01_]*(n)?\\\\b(?!\\\\$))|\\\\b((?<!\\\\$)0[Oo]?[0-7][0-7_]*(n)?\\\\b(?!\\\\$))|((?<!\\\\$)(?:\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\B(\\\\.)[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*[Ee][-+]?[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(\\\\.)(n)?\\\\B|\\\\B(\\\\.)[0-9][0-9_]*(n)?\\\\b|\\\\b[0-9][0-9_]*(n)?\\\\b(?!\\\\.))(?!\\\\$))|([$_[:alpha:]][$_[:alnum:]]*)|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`)|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])+]))\\\\s*(:))","end":"(?=[,}])","patterns":[{"include":"#object-binding-element-propertyName"},{"include":"#parameter-binding-element"},{"include":"#paren-expression"}]},{"include":"#parameter-object-binding-pattern"},{"include":"#destructuring-parameter-rest"},{"include":"#variable-initializer"},{"include":"#punctuation-comma"}]},"parameter-object-binding-pattern":{"begin":"(?:(\\\\.\\\\.\\\\.)\\\\s*)?(\\\\{)","beginCaptures":{"1":{"name":"keyword.operator.rest.ts"},"2":{"name":"punctuation.definition.binding-pattern.object.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.binding-pattern.object.ts"}},"patterns":[{"include":"#parameter-object-binding-element"}]},"parameter-type-annotation":{"patterns":[{"begin":"(:)","beginCaptures":{"1":{"name":"keyword.operator.type.annotation.ts"}},"end":"(?=[),])|(?==[^>])","name":"meta.type.annotation.ts","patterns":[{"include":"#type"}]}]},"paren-expression":{"begin":"\\\\(","beginCaptures":{"0":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"patterns":[{"include":"#expression"}]},"paren-expression-possibly-arrow":{"patterns":[{"begin":"(?<=[(,=])\\\\s*(async)?(?=\\\\s*((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*))?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))))","beginCaptures":{"1":{"name":"storage.modifier.async.ts"}},"end":"(?<=\\\\))","patterns":[{"include":"#paren-expression-possibly-arrow-with-typeparameters"}]},{"begin":"(?<=[(,=]|=>|^return|[^$._[:alnum:]]return)\\\\s*(async)?(?=\\\\s*((((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*))?\\\\()|(<)|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)))\\\\s*$)","beginCaptures":{"1":{"name":"storage.modifier.async.ts"}},"end":"(?<=\\\\))","patterns":[{"include":"#paren-expression-possibly-arrow-with-typeparameters"}]},{"include":"#possibly-arrow-return-type"}]},"paren-expression-possibly-arrow-with-typeparameters":{"patterns":[{"include":"#type-parameters"},{"begin":"\\\\(","beginCaptures":{"0":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"patterns":[{"include":"#expression-inside-possibly-arrow-parens"}]}]},"possibly-arrow-return-type":{"begin":"(?<=\\\\)|^)\\\\s*(:)(?=\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*=>)","beginCaptures":{"1":{"name":"meta.arrow.ts meta.return.type.arrow.ts keyword.operator.type.annotation.ts"}},"contentName":"meta.arrow.ts meta.return.type.arrow.ts","end":"(?==>|\\\\{|^(\\\\s*(export|function|class|interface|let|var|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|const|import|enum|namespace|module|type|abstract|declare)\\\\s+))","patterns":[{"include":"#arrow-return-type-body"}]},"property-accessor":{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(accessor|get|set)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"storage.type.property.ts"},"punctuation-accessor":{"captures":{"1":{"name":"punctuation.accessor.ts"},"2":{"name":"punctuation.accessor.optional.ts"}},"match":"(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d))"},"punctuation-comma":{"match":",","name":"punctuation.separator.comma.ts"},"punctuation-semicolon":{"match":";","name":"punctuation.terminator.statement.ts"},"qstring-double":{"begin":"\\"","beginCaptures":{"0":{"name":"punctuation.definition.string.begin.ts"}},"end":"(\\")|([^\\\\n\\\\\\\\])$","endCaptures":{"1":{"name":"punctuation.definition.string.end.ts"},"2":{"name":"invalid.illegal.newline.ts"}},"name":"string.quoted.double.ts","patterns":[{"include":"#string-character-escape"}]},"qstring-single":{"begin":"\'","beginCaptures":{"0":{"name":"punctuation.definition.string.begin.ts"}},"end":"(\')|([^\\\\n\\\\\\\\])$","endCaptures":{"1":{"name":"punctuation.definition.string.end.ts"},"2":{"name":"invalid.illegal.newline.ts"}},"name":"string.quoted.single.ts","patterns":[{"include":"#string-character-escape"}]},"regex":{"patterns":[{"begin":"(?<!\\\\+\\\\+|--|})(?<=[!(+,:=?\\\\[]|^return|[^$._[:alnum:]]return|^case|[^$._[:alnum:]]case|=>|&&|\\\\|\\\\||\\\\*/)\\\\s*(/)(?![*/])(?=(?:[^()/\\\\[\\\\\\\\]|\\\\\\\\.|\\\\[([^]\\\\\\\\]|\\\\\\\\.)+]|\\\\(([^)\\\\\\\\]|\\\\\\\\.)+\\\\))+/([dgimsuvy]+|(?![*/])|(?=/\\\\*))(?!\\\\s*[$0-9A-Z_a-z]))","beginCaptures":{"1":{"name":"punctuation.definition.string.begin.ts"}},"end":"(/)([dgimsuvy]*)","endCaptures":{"1":{"name":"punctuation.definition.string.end.ts"},"2":{"name":"keyword.other.ts"}},"name":"string.regexp.ts","patterns":[{"include":"#regexp"}]},{"begin":"((?<![]$)_[:alnum:]]|\\\\+\\\\+|--|}|\\\\*/)|((?<=^return|[^$._[:alnum:]]return|^case|[^$._[:alnum:]]case))\\\\s*)/(?![*/])(?=(?:[^/\\\\[\\\\\\\\]|\\\\\\\\.|\\\\[([^]\\\\\\\\]|\\\\\\\\.)*])+/([dgimsuvy]+|(?![*/])|(?=/\\\\*))(?!\\\\s*[$0-9A-Z_a-z]))","beginCaptures":{"0":{"name":"punctuation.definition.string.begin.ts"}},"end":"(/)([dgimsuvy]*)","endCaptures":{"1":{"name":"punctuation.definition.string.end.ts"},"2":{"name":"keyword.other.ts"}},"name":"string.regexp.ts","patterns":[{"include":"#regexp"}]}]},"regex-character-class":{"patterns":[{"match":"\\\\\\\\[DSWdfnrstvw]|\\\\.","name":"constant.other.character-class.regexp"},{"match":"\\\\\\\\([0-7]{3}|x\\\\h{2}|u\\\\h{4})","name":"constant.character.numeric.regexp"},{"match":"\\\\\\\\c[A-Z]","name":"constant.character.control.regexp"},{"match":"\\\\\\\\.","name":"constant.character.escape.backslash.regexp"}]},"regexp":{"patterns":[{"match":"\\\\\\\\[Bb]|[$^]","name":"keyword.control.anchor.regexp"},{"captures":{"0":{"name":"keyword.other.back-reference.regexp"},"1":{"name":"variable.other.regexp"}},"match":"\\\\\\\\(?:[1-9]\\\\d*|k<([$A-Z_a-z][$\\\\w]*)>)"},{"match":"[*+?]|\\\\{(\\\\d+,\\\\d+|\\\\d+,|,\\\\d+|\\\\d+)}\\\\??","name":"keyword.operator.quantifier.regexp"},{"match":"\\\\|","name":"keyword.operator.or.regexp"},{"begin":"(\\\\()((\\\\?=)|(\\\\?!)|(\\\\?<=)|(\\\\?<!))","beginCaptures":{"1":{"name":"punctuation.definition.group.regexp"},"2":{"name":"punctuation.definition.group.assertion.regexp"},"3":{"name":"meta.assertion.look-ahead.regexp"},"4":{"name":"meta.assertion.negative-look-ahead.regexp"},"5":{"name":"meta.assertion.look-behind.regexp"},"6":{"name":"meta.assertion.negative-look-behind.regexp"}},"end":"(\\\\))","endCaptures":{"1":{"name":"punctuation.definition.group.regexp"}},"name":"meta.group.assertion.regexp","patterns":[{"include":"#regexp"}]},{"begin":"\\\\((?:(\\\\?:)|\\\\?<([$A-Z_a-z][$\\\\w]*)>)?","beginCaptures":{"0":{"name":"punctuation.definition.group.regexp"},"1":{"name":"punctuation.definition.group.no-capture.regexp"},"2":{"name":"variable.other.regexp"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.definition.group.regexp"}},"name":"meta.group.regexp","patterns":[{"include":"#regexp"}]},{"begin":"(\\\\[)(\\\\^)?","beginCaptures":{"1":{"name":"punctuation.definition.character-class.regexp"},"2":{"name":"keyword.operator.negation.regexp"}},"end":"(])","endCaptures":{"1":{"name":"punctuation.definition.character-class.regexp"}},"name":"constant.other.character-class.set.regexp","patterns":[{"captures":{"1":{"name":"constant.character.numeric.regexp"},"2":{"name":"constant.character.control.regexp"},"3":{"name":"constant.character.escape.backslash.regexp"},"4":{"name":"constant.character.numeric.regexp"},"5":{"name":"constant.character.control.regexp"},"6":{"name":"constant.character.escape.backslash.regexp"}},"match":"(?:.|(\\\\\\\\(?:[0-7]{3}|x\\\\h{2}|u\\\\h{4}))|(\\\\\\\\c[A-Z])|(\\\\\\\\.))-(?:[^]\\\\\\\\]|(\\\\\\\\(?:[0-7]{3}|x\\\\h{2}|u\\\\h{4}))|(\\\\\\\\c[A-Z])|(\\\\\\\\.))","name":"constant.other.character-class.range.regexp"},{"include":"#regex-character-class"}]},{"include":"#regex-character-class"}]},"return-type":{"patterns":[{"begin":"(?<=\\\\))\\\\s*(:)(?=\\\\s*\\\\S)","beginCaptures":{"1":{"name":"keyword.operator.type.annotation.ts"}},"end":"(?<![\\\\&:|])(?=$|^|[,;{}]|//)","name":"meta.return.type.ts","patterns":[{"include":"#return-type-core"}]},{"begin":"(?<=\\\\))\\\\s*(:)","beginCaptures":{"1":{"name":"keyword.operator.type.annotation.ts"}},"end":"(?<![\\\\&:|])((?=[,;{}]|//|^\\\\s*$)|((?<=\\\\S)(?=\\\\s*$)))","name":"meta.return.type.ts","patterns":[{"include":"#return-type-core"}]}]},"return-type-core":{"patterns":[{"include":"#comment"},{"begin":"(?<=[\\\\&:|])(?=\\\\s*\\\\{)","end":"(?<=})","patterns":[{"include":"#type-object"}]},{"include":"#type-predicate-operator"},{"include":"#type"}]},"shebang":{"captures":{"1":{"name":"punctuation.definition.comment.ts"}},"match":"\\\\A(#!).*(?=$)","name":"comment.line.shebang.ts"},"single-line-comment-consuming-line-ending":{"begin":"(^[\\\\t ]+)?((//)(?:\\\\s*((@)internal)(?=\\\\s|$))?)","beginCaptures":{"1":{"name":"punctuation.whitespace.comment.leading.ts"},"2":{"name":"comment.line.double-slash.ts"},"3":{"name":"punctuation.definition.comment.ts"},"4":{"name":"storage.type.internaldeclaration.ts"},"5":{"name":"punctuation.decorator.internaldeclaration.ts"}},"contentName":"comment.line.double-slash.ts","end":"(?=^)"},"statements":{"patterns":[{"include":"#declaration"},{"include":"#control-statement"},{"include":"#after-operator-block-as-object-literal"},{"include":"#decl-block"},{"include":"#label"},{"include":"#expression"},{"include":"#punctuation-semicolon"},{"include":"#string"},{"include":"#comment"}]},"string":{"patterns":[{"include":"#qstring-single"},{"include":"#qstring-double"},{"include":"#template"}]},"string-character-escape":{"match":"\\\\\\\\(x\\\\h{2}|u\\\\h{4}|u\\\\{\\\\h+}|[012][0-7]{0,2}|3[0-6][0-7]?|37[0-7]?|[4-7][0-7]?|.|$)","name":"constant.character.escape.ts"},"super-literal":{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))super\\\\b(?!\\\\$)","name":"variable.language.super.ts"},"support-function-call-identifiers":{"patterns":[{"include":"#literal"},{"include":"#support-objects"},{"include":"#object-identifiers"},{"include":"#punctuation-accessor"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))import(?=\\\\s*\\\\(\\\\s*[\\"\'`])","name":"keyword.operator.expression.import.ts"}]},"support-objects":{"patterns":[{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(arguments)\\\\b(?!\\\\$)","name":"variable.language.arguments.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(Promise)\\\\b(?!\\\\$)","name":"support.class.promise.ts"},{"captures":{"1":{"name":"keyword.control.import.ts"},"2":{"name":"punctuation.accessor.ts"},"3":{"name":"punctuation.accessor.optional.ts"},"4":{"name":"support.variable.property.importmeta.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(import)\\\\s*(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))\\\\s*(meta)\\\\b(?!\\\\$)"},{"captures":{"1":{"name":"keyword.operator.new.ts"},"2":{"name":"punctuation.accessor.ts"},"3":{"name":"punctuation.accessor.optional.ts"},"4":{"name":"support.variable.property.target.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(new)\\\\s*(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))\\\\s*(target)\\\\b(?!\\\\$)"},{"captures":{"1":{"name":"punctuation.accessor.ts"},"2":{"name":"punctuation.accessor.optional.ts"},"3":{"name":"support.variable.property.ts"},"4":{"name":"support.constant.ts"}},"match":"(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))\\\\s*(?:(constructor|length|prototype|__proto__)\\\\b(?!\\\\$|\\\\s*(<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\()|(EPSILON|MAX_SAFE_INTEGER|MAX_VALUE|MIN_SAFE_INTEGER|MIN_VALUE|NEGATIVE_INFINITY|POSITIVE_INFINITY)\\\\b(?!\\\\$))"},{"captures":{"1":{"name":"support.type.object.module.ts"},"2":{"name":"support.type.object.module.ts"},"3":{"name":"punctuation.accessor.ts"},"4":{"name":"punctuation.accessor.optional.ts"},"5":{"name":"support.type.object.module.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(exports)|(module)(?:(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))(exports|id|filename|loaded|parent|children))?)\\\\b(?!\\\\$)"}]},"switch-statement":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?=\\\\bswitch\\\\s*\\\\()","end":"}","endCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"name":"switch-statement.expr.ts","patterns":[{"include":"#comment"},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(switch)\\\\s*(\\\\()","beginCaptures":{"1":{"name":"keyword.control.switch.ts"},"2":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"name":"switch-expression.expr.ts","patterns":[{"include":"#expression"}]},{"begin":"\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"end":"(?=})","name":"switch-block.expr.ts","patterns":[{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(case|default(?=:))(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","beginCaptures":{"1":{"name":"keyword.control.switch.ts"}},"end":"(?=:)","name":"case-clause.expr.ts","patterns":[{"include":"#expression"}]},{"begin":"(:)\\\\s*(\\\\{)","beginCaptures":{"1":{"name":"case-clause.expr.ts punctuation.definition.section.case-statement.ts"},"2":{"name":"meta.block.ts punctuation.definition.block.ts"}},"contentName":"meta.block.ts","end":"}","endCaptures":{"0":{"name":"meta.block.ts punctuation.definition.block.ts"}},"patterns":[{"include":"#statements"}]},{"captures":{"0":{"name":"case-clause.expr.ts punctuation.definition.section.case-statement.ts"}},"match":"(:)"},{"include":"#statements"}]}]},"template":{"patterns":[{"include":"#template-call"},{"begin":"([$_[:alpha:]][$_[:alnum:]]*)?(`)","beginCaptures":{"1":{"name":"entity.name.function.tagged-template.ts"},"2":{"name":"string.template.ts punctuation.definition.string.template.begin.ts"}},"contentName":"string.template.ts","end":"`","endCaptures":{"0":{"name":"string.template.ts punctuation.definition.string.template.end.ts"}},"patterns":[{"include":"#template-substitution-element"},{"include":"#string-character-escape"}]}]},"template-call":{"patterns":[{"begin":"(?=(([$_[:alpha:]][$_[:alnum:]]*\\\\s*\\\\??\\\\.\\\\s*)*|(\\\\??\\\\.\\\\s*)?)([$_[:alpha:]][$_[:alnum:]]*)(<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))(([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>)*(?<!=)>))*(?<!=)>)*(?<!=)>\\\\s*)?`)","end":"(?=`)","patterns":[{"begin":"(?=(([$_[:alpha:]][$_[:alnum:]]*\\\\s*\\\\??\\\\.\\\\s*)*|(\\\\??\\\\.\\\\s*)?)([$_[:alpha:]][$_[:alnum:]]*))","end":"(?=(<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))(([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>)*(?<!=)>))*(?<!=)>)*(?<!=)>\\\\s*)?`)","patterns":[{"include":"#support-function-call-identifiers"},{"match":"([$_[:alpha:]][$_[:alnum:]]*)","name":"entity.name.function.tagged-template.ts"}]},{"include":"#type-arguments"}]},{"begin":"([$_[:alpha:]][$_[:alnum:]]*)?\\\\s*(?=(<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))(([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>|<\\\\s*(((keyof|infer|typeof|readonly)\\\\s+)|(([$_[:alpha:]][$_[:alnum:]]*|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))(?=\\\\s*([,.<>\\\\[]|=>|&(?!&)|\\\\|(?!\\\\|)))))([^(<>]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(?<==)>)*(?<!=)>))*(?<!=)>)*(?<!=)>\\\\s*)`)","beginCaptures":{"1":{"name":"entity.name.function.tagged-template.ts"}},"end":"(?=`)","patterns":[{"include":"#type-arguments"}]}]},"template-substitution-element":{"begin":"\\\\$\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.template-expression.begin.ts"}},"contentName":"meta.embedded.line.ts","end":"}","endCaptures":{"0":{"name":"punctuation.definition.template-expression.end.ts"}},"name":"meta.template.expression.ts","patterns":[{"include":"#expression"}]},"template-type":{"patterns":[{"include":"#template-call"},{"begin":"([$_[:alpha:]][$_[:alnum:]]*)?(`)","beginCaptures":{"1":{"name":"entity.name.function.tagged-template.ts"},"2":{"name":"string.template.ts punctuation.definition.string.template.begin.ts"}},"contentName":"string.template.ts","end":"`","endCaptures":{"0":{"name":"string.template.ts punctuation.definition.string.template.end.ts"}},"patterns":[{"include":"#template-type-substitution-element"},{"include":"#string-character-escape"}]}]},"template-type-substitution-element":{"begin":"\\\\$\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.template-expression.begin.ts"}},"contentName":"meta.embedded.line.ts","end":"}","endCaptures":{"0":{"name":"punctuation.definition.template-expression.end.ts"}},"name":"meta.template.expression.ts","patterns":[{"include":"#type"}]},"ternary-expression":{"begin":"(?!\\\\?\\\\.\\\\s*\\\\D)(\\\\?)(?!\\\\?)","beginCaptures":{"1":{"name":"keyword.operator.ternary.ts"}},"end":"\\\\s*(:)","endCaptures":{"1":{"name":"keyword.operator.ternary.ts"}},"patterns":[{"include":"#expression"}]},"this-literal":{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))this\\\\b(?!\\\\$)","name":"variable.language.this.ts"},"type":{"patterns":[{"include":"#comment"},{"include":"#type-string"},{"include":"#numeric-literal"},{"include":"#type-primitive"},{"include":"#type-builtin-literals"},{"include":"#type-parameters"},{"include":"#type-tuple"},{"include":"#type-object"},{"include":"#type-operators"},{"include":"#type-conditional"},{"include":"#type-fn-type-parameters"},{"include":"#type-paren-or-function-parameters"},{"include":"#type-function-return-type"},{"captures":{"1":{"name":"storage.modifier.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(readonly)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))\\\\s*"},{"include":"#type-name"}]},"type-alias-declaration":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(type)\\\\b\\\\s+([$_[:alpha:]][$_[:alnum:]]*)\\\\s*","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.type.type.ts"},"4":{"name":"entity.name.type.alias.ts"}},"end":"(?=[;}]|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)","name":"meta.type.declaration.ts","patterns":[{"include":"#comment"},{"include":"#type-parameters"},{"begin":"(=)\\\\s*(intrinsic)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","beginCaptures":{"1":{"name":"keyword.operator.assignment.ts"},"2":{"name":"keyword.control.intrinsic.ts"}},"end":"(?=[;}]|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)","patterns":[{"include":"#type"}]},{"begin":"(=)\\\\s*","beginCaptures":{"1":{"name":"keyword.operator.assignment.ts"}},"end":"(?=[;}]|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)","patterns":[{"include":"#type"}]}]},"type-annotation":{"patterns":[{"begin":"(:)(?=\\\\s*\\\\S)","beginCaptures":{"1":{"name":"keyword.operator.type.annotation.ts"}},"end":"(?<![\\\\&:|])(?!\\\\s*[\\\\&|]\\\\s+)((?=^|[]),;}]|//)|(?==[^>])|((?<=[]$)>_}[:alpha:]])\\\\s*(?=\\\\{)))","name":"meta.type.annotation.ts","patterns":[{"include":"#type"}]},{"begin":"(:)","beginCaptures":{"1":{"name":"keyword.operator.type.annotation.ts"}},"end":"(?<![\\\\&:|])((?=[]),;}]|//)|(?==[^>])|(?=^\\\\s*$)|((?<=[]$)>_}[:alpha:]])\\\\s*(?=\\\\{)))","name":"meta.type.annotation.ts","patterns":[{"include":"#type"}]}]},"type-arguments":{"begin":"<","beginCaptures":{"0":{"name":"punctuation.definition.typeparameters.begin.ts"}},"end":">","endCaptures":{"0":{"name":"punctuation.definition.typeparameters.end.ts"}},"name":"meta.type.parameters.ts","patterns":[{"include":"#type-arguments-body"}]},"type-arguments-body":{"patterns":[{"captures":{"0":{"name":"keyword.operator.type.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(_)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))"},{"include":"#type"},{"include":"#punctuation-comma"}]},"type-builtin-literals":{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(this|true|false|undefined|null|object)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"support.type.builtin.ts"},"type-conditional":{"patterns":[{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(extends)\\\\s+","beginCaptures":{"1":{"name":"storage.modifier.ts"}},"end":"(?<=:)","patterns":[{"begin":"\\\\?","beginCaptures":{"0":{"name":"keyword.operator.ternary.ts"}},"end":":","endCaptures":{"0":{"name":"keyword.operator.ternary.ts"}},"patterns":[{"include":"#type"}]},{"include":"#type"}]}]},"type-fn-type-parameters":{"patterns":[{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(abstract)\\\\s+)?(new)\\\\b(?=\\\\s*<)","beginCaptures":{"1":{"name":"meta.type.constructor.ts storage.modifier.ts"},"2":{"name":"meta.type.constructor.ts keyword.control.new.ts"}},"end":"(?<=>)","patterns":[{"include":"#comment"},{"include":"#type-parameters"}]},{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(abstract)\\\\s+)?(new)\\\\b\\\\s*(?=\\\\()","beginCaptures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"keyword.control.new.ts"}},"end":"(?<=\\\\))","name":"meta.type.constructor.ts","patterns":[{"include":"#function-parameters"}]},{"begin":"((?=\\\\(\\\\s*((\\\\))|(\\\\.\\\\.\\\\.)|([$_[:alnum:]]+\\\\s*(([,:=?])|(\\\\)\\\\s*=>))))))","end":"(?<=\\\\))","name":"meta.type.function.ts","patterns":[{"include":"#function-parameters"}]}]},"type-function-return-type":{"patterns":[{"begin":"(=>)(?=\\\\s*\\\\S)","beginCaptures":{"1":{"name":"storage.type.function.arrow.ts"}},"end":"(?<!=>)(?<![\\\\&|])(?=[]),:;=>?{}]|//|$)","name":"meta.type.function.return.ts","patterns":[{"include":"#type-function-return-type-core"}]},{"begin":"=>","beginCaptures":{"0":{"name":"storage.type.function.arrow.ts"}},"end":"(?<!=>)(?<![\\\\&|])((?=[]),:;=>?{}]|//|^\\\\s*$)|((?<=\\\\S)(?=\\\\s*$)))","name":"meta.type.function.return.ts","patterns":[{"include":"#type-function-return-type-core"}]}]},"type-function-return-type-core":{"patterns":[{"include":"#comment"},{"begin":"(?<==>)(?=\\\\s*\\\\{)","end":"(?<=})","patterns":[{"include":"#type-object"}]},{"include":"#type-predicate-operator"},{"include":"#type"}]},"type-infer":{"patterns":[{"captures":{"1":{"name":"keyword.operator.expression.infer.ts"},"2":{"name":"entity.name.type.ts"},"3":{"name":"keyword.operator.expression.extends.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(infer)\\\\s+([$_[:alpha:]][$_[:alnum:]]*)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))(?:\\\\s+(extends)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))?","name":"meta.type.infer.ts"}]},"type-name":{"patterns":[{"begin":"([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))\\\\s*(<)","captures":{"1":{"name":"entity.name.type.module.ts"},"2":{"name":"punctuation.accessor.ts"},"3":{"name":"punctuation.accessor.optional.ts"},"4":{"name":"meta.type.parameters.ts punctuation.definition.typeparameters.begin.ts"}},"contentName":"meta.type.parameters.ts","end":"(>)","endCaptures":{"1":{"name":"meta.type.parameters.ts punctuation.definition.typeparameters.end.ts"}},"patterns":[{"include":"#type-arguments-body"}]},{"begin":"([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(<)","beginCaptures":{"1":{"name":"entity.name.type.ts"},"2":{"name":"meta.type.parameters.ts punctuation.definition.typeparameters.begin.ts"}},"contentName":"meta.type.parameters.ts","end":"(>)","endCaptures":{"1":{"name":"meta.type.parameters.ts punctuation.definition.typeparameters.end.ts"}},"patterns":[{"include":"#type-arguments-body"}]},{"captures":{"1":{"name":"entity.name.type.module.ts"},"2":{"name":"punctuation.accessor.ts"},"3":{"name":"punctuation.accessor.optional.ts"}},"match":"([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(?:(\\\\.)|(\\\\?\\\\.(?!\\\\s*\\\\d)))"},{"match":"[$_[:alpha:]][$_[:alnum:]]*","name":"entity.name.type.ts"}]},"type-object":{"begin":"\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.block.ts"}},"name":"meta.object.type.ts","patterns":[{"include":"#comment"},{"include":"#method-declaration"},{"include":"#indexer-declaration"},{"include":"#indexer-mapped-type-declaration"},{"include":"#field-declaration"},{"include":"#type-annotation"},{"begin":"\\\\.\\\\.\\\\.","beginCaptures":{"0":{"name":"keyword.operator.spread.ts"}},"end":"(?=[,;}]|$)|(?<=})","patterns":[{"include":"#type"}]},{"include":"#punctuation-comma"},{"include":"#punctuation-semicolon"},{"include":"#type"}]},"type-operators":{"patterns":[{"include":"#typeof-operator"},{"include":"#type-infer"},{"begin":"([\\\\&|])(?=\\\\s*\\\\{)","beginCaptures":{"0":{"name":"keyword.operator.type.ts"}},"end":"(?<=})","patterns":[{"include":"#type-object"}]},{"begin":"[\\\\&|]","beginCaptures":{"0":{"name":"keyword.operator.type.ts"}},"end":"(?=\\\\S)"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))keyof(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.operator.expression.keyof.ts"},{"match":"([:?])","name":"keyword.operator.ternary.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))import(?=\\\\s*\\\\()","name":"keyword.operator.expression.import.ts"}]},"type-parameters":{"begin":"(<)","beginCaptures":{"1":{"name":"punctuation.definition.typeparameters.begin.ts"}},"end":"(>)","endCaptures":{"1":{"name":"punctuation.definition.typeparameters.end.ts"}},"name":"meta.type.parameters.ts","patterns":[{"include":"#comment"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(extends|in|out|const)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"storage.modifier.ts"},{"include":"#type"},{"include":"#punctuation-comma"},{"match":"(=)(?!>)","name":"keyword.operator.assignment.ts"}]},"type-paren-or-function-parameters":{"begin":"\\\\(","beginCaptures":{"0":{"name":"meta.brace.round.ts"}},"end":"\\\\)","endCaptures":{"0":{"name":"meta.brace.round.ts"}},"name":"meta.type.paren.cover.ts","patterns":[{"captures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"keyword.operator.rest.ts"},"3":{"name":"entity.name.function.ts variable.language.this.ts"},"4":{"name":"entity.name.function.ts"},"5":{"name":"keyword.operator.optional.ts"}},"match":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(public|private|protected|readonly)\\\\s+)?(?:(\\\\.\\\\.\\\\.)\\\\s*)?(?<![:=])(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(this)|([$_[:alpha:]][$_[:alnum:]]*))\\\\s*(\\\\??)(?=\\\\s*(:\\\\s*((<)|(\\\\(\\\\s*((\\\\))|(\\\\.\\\\.\\\\.)|([$_[:alnum:]]+\\\\s*(([,:=?])|(\\\\)\\\\s*=>)))))))|(:\\\\s*(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))Function(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))|(:\\\\s*((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))))"},{"captures":{"1":{"name":"storage.modifier.ts"},"2":{"name":"keyword.operator.rest.ts"},"3":{"name":"variable.parameter.ts variable.language.this.ts"},"4":{"name":"variable.parameter.ts"},"5":{"name":"keyword.operator.optional.ts"}},"match":"(?:(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(public|private|protected|readonly)\\\\s+)?(?:(\\\\.\\\\.\\\\.)\\\\s*)?(?<![:=])(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(this)|([$_[:alpha:]][$_[:alnum:]]*))\\\\s*(\\\\??)(?=:)"},{"include":"#type-annotation"},{"match":",","name":"punctuation.separator.parameter.ts"},{"include":"#type"}]},"type-predicate-operator":{"patterns":[{"captures":{"1":{"name":"keyword.operator.type.asserts.ts"},"2":{"name":"variable.parameter.ts variable.language.this.ts"},"3":{"name":"variable.parameter.ts"},"4":{"name":"keyword.operator.expression.is.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:(asserts)\\\\s+)?(?!asserts)(?:(this)|([$_[:alpha:]][$_[:alnum:]]*))\\\\s(is)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))"},{"captures":{"1":{"name":"keyword.operator.type.asserts.ts"},"2":{"name":"variable.parameter.ts variable.language.this.ts"},"3":{"name":"variable.parameter.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(asserts)\\\\s+(?!is)(?:(this)|([$_[:alpha:]][$_[:alnum:]]*))(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))asserts(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.operator.type.asserts.ts"},{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))is(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"keyword.operator.expression.is.ts"}]},"type-primitive":{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(string|number|bigint|boolean|symbol|any|void|never|unknown)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"support.type.primitive.ts"},"type-string":{"patterns":[{"include":"#qstring-single"},{"include":"#qstring-double"},{"include":"#template-type"}]},"type-tuple":{"begin":"\\\\[","beginCaptures":{"0":{"name":"meta.brace.square.ts"}},"end":"]","endCaptures":{"0":{"name":"meta.brace.square.ts"}},"name":"meta.type.tuple.ts","patterns":[{"match":"\\\\.\\\\.\\\\.","name":"keyword.operator.rest.ts"},{"captures":{"1":{"name":"entity.name.label.ts"},"2":{"name":"keyword.operator.optional.ts"},"3":{"name":"punctuation.separator.label.ts"}},"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))([$_[:alpha:]][$_[:alnum:]]*)\\\\s*(\\\\?)?\\\\s*(:)"},{"include":"#type"},{"include":"#punctuation-comma"}]},"typeof-operator":{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))typeof(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","beginCaptures":{"0":{"name":"keyword.operator.expression.typeof.ts"}},"end":"(?=[]\\\\&),:;=>?{|}]|(extends\\\\s+)|$|;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)","patterns":[{"include":"#type-arguments"},{"include":"#expression"}]},"undefined-literal":{"match":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))undefined(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))","name":"constant.language.undefined.ts"},"var-expr":{"patterns":[{"begin":"(?=(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(var|let)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))","end":"(?!(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(var|let)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))((?=^|[;}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)|((?<!^let|[^$._[:alnum:]]let|^var|[^$._[:alnum:]]var)(?=\\\\s*$)))","name":"meta.var.expr.ts","patterns":[{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(var|let)(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))\\\\s*","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.type.ts"}},"end":"(?=\\\\S)"},{"include":"#destructuring-variable"},{"include":"#var-single-variable"},{"include":"#variable-initializer"},{"include":"#comment"},{"begin":"(,)\\\\s*(?=$|//)","beginCaptures":{"1":{"name":"punctuation.separator.comma.ts"}},"end":"(?<!,)(((?=[;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|^\\\\s*$))|((?<=\\\\S)(?=\\\\s*$)))","patterns":[{"include":"#single-line-comment-consuming-line-ending"},{"include":"#comment"},{"include":"#destructuring-variable"},{"include":"#var-single-variable"},{"include":"#punctuation-comma"}]},{"include":"#punctuation-comma"}]},{"begin":"(?=(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(const(?!\\\\s+enum\\\\b))(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.type.ts"}},"end":"(?!(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(const(?!\\\\s+enum\\\\b))(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))((?=^|[;}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)|((?<!(?:^|[^$._[:alnum:]])const)(?=\\\\s*$)))","name":"meta.var.expr.ts","patterns":[{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b(const(?!\\\\s+enum\\\\b))(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))\\\\s*","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.type.ts"}},"end":"(?=\\\\S)"},{"include":"#destructuring-const"},{"include":"#var-single-const"},{"include":"#variable-initializer"},{"include":"#comment"},{"begin":"(,)\\\\s*(?=$|//)","beginCaptures":{"1":{"name":"punctuation.separator.comma.ts"}},"end":"(?<!,)(((?=[;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|^\\\\s*$))|((?<=\\\\S)(?=\\\\s*$)))","patterns":[{"include":"#single-line-comment-consuming-line-ending"},{"include":"#comment"},{"include":"#destructuring-const"},{"include":"#var-single-const"},{"include":"#punctuation-comma"}]},{"include":"#punctuation-comma"}]},{"begin":"(?=(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b\\\\b(using(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])|await\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b)\\\\b(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.type.ts"}},"end":"(?!(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b\\\\b(using(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])|await\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b)\\\\b(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))((?=[;}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b)|((?<!(?:^|[^$._[:alnum:]]|^await\\\\s+|[^$._[:alnum:]]await\\\\s+)using)(?=\\\\s*$)))","name":"meta.var.expr.ts","patterns":[{"begin":"(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(?:\\\\b(export)\\\\s+)?(?:\\\\b(declare)\\\\s+)?\\\\b\\\\b(using(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])|await\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b)\\\\b(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.))\\\\s*","beginCaptures":{"1":{"name":"keyword.control.export.ts"},"2":{"name":"storage.modifier.ts"},"3":{"name":"storage.type.ts"}},"end":"(?=\\\\S)"},{"include":"#var-single-const"},{"include":"#variable-initializer"},{"include":"#comment"},{"begin":"(,)\\\\s*((?!\\\\S)|(?=//))","beginCaptures":{"1":{"name":"punctuation.separator.comma.ts"}},"end":"(?<!,)(((?=[;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|^\\\\s*$))|((?<=\\\\S)(?=\\\\s*$)))","patterns":[{"include":"#single-line-comment-consuming-line-ending"},{"include":"#comment"},{"include":"#var-single-const"},{"include":"#punctuation-comma"}]},{"include":"#punctuation-comma"}]}]},"var-single-const":{"patterns":[{"begin":"([$_[:alpha:]][$_[:alnum:]]*)(?=\\\\s*(=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>)))))|(:\\\\s*((<)|(\\\\(\\\\s*((\\\\))|(\\\\.\\\\.\\\\.)|([$_[:alnum:]]+\\\\s*(([,:=?])|(\\\\)\\\\s*=>)))))))|(:\\\\s*(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))Function(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))|(:\\\\s*((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))))))|(:\\\\s*(=>|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(<[^<>]*>)|[^(),<=>])+=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>))))))","beginCaptures":{"1":{"name":"meta.definition.variable.ts variable.other.constant.ts entity.name.function.ts"}},"end":"(?=$|^|[,;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|(;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b))","name":"meta.var-single-variable.expr.ts","patterns":[{"include":"#var-single-variable-type-annotation"}]},{"begin":"([$_[:alpha:]][$_[:alnum:]]*)","beginCaptures":{"1":{"name":"meta.definition.variable.ts variable.other.constant.ts"}},"end":"(?=$|^|[,;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|(;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b))","name":"meta.var-single-variable.expr.ts","patterns":[{"include":"#var-single-variable-type-annotation"}]}]},"var-single-variable":{"patterns":[{"begin":"([$_[:alpha:]][$_[:alnum:]]*)(!)?(?=\\\\s*(=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>)))))|(:\\\\s*((<)|(\\\\(\\\\s*((\\\\))|(\\\\.\\\\.\\\\.)|([$_[:alnum:]]+\\\\s*(([,:=?])|(\\\\)\\\\s*=>)))))))|(:\\\\s*(?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))Function(?![$_[:alnum:]])(?:(?=\\\\.\\\\.\\\\.)|(?!\\\\.)))|(:\\\\s*((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))))))|(:\\\\s*(=>|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(<[^<>]*>)|[^(),<=>])+=\\\\s*(((async\\\\s+)?((function\\\\s*[(*<])|(function\\\\s+)|([$_[:alpha:]][$_[:alnum:]]*\\\\s*=>)))|((async\\\\s*)?(((<\\\\s*)$|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*((([\\\\[{]\\\\s*)?)$|((\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})\\\\s*((:\\\\s*\\\\{?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*)))|((\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])\\\\s*((:\\\\s*\\\\[?)$|((\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+\\\\s*)?=\\\\s*))))))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*((\\\\)\\\\s*:)|((\\\\.\\\\.\\\\.\\\\s*)?[$_[:alpha:]][$_[:alnum:]]*\\\\s*:)))|((<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<]|<\\\\s*(((const\\\\s+)?[$_[:alpha:]])|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*]))([^<=>]|=[^<])*>)*>)*>\\\\s*)?\\\\(\\\\s*(/\\\\*([^*]|(\\\\*[^/]))*\\\\*/\\\\s*)*(([$_[:alpha:]]|(\\\\{([^{}]|(\\\\{([^{}]|\\\\{[^{}]*})*}))*})|(\\\\[([^]\\\\[]|(\\\\[([^]\\\\[]|\\\\[[^]\\\\[]*])*]))*])|(\\\\.\\\\.\\\\.\\\\s*[$_[:alpha:]]))([^\\"\'()`]|(\\\\(([^()]|(\\\\(([^()]|\\\\([^()]*\\\\))*\\\\)))*\\\\))|(\'([^\'\\\\\\\\]|\\\\\\\\.)*\')|(\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\")|(`([^\\\\\\\\`]|\\\\\\\\.)*`))*)?\\\\)(\\\\s*:\\\\s*([^()<>{}]|<([^<>]|<([^<>]|<[^<>]+>)+>)+>|\\\\([^()]+\\\\)|\\\\{[^{}]+})+)?\\\\s*=>))))))","beginCaptures":{"1":{"name":"meta.definition.variable.ts entity.name.function.ts"},"2":{"name":"keyword.operator.definiteassignment.ts"}},"end":"(?=$|^|[,;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|(;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b))","name":"meta.var-single-variable.expr.ts","patterns":[{"include":"#var-single-variable-type-annotation"}]},{"begin":"(\\\\p{upper}[$_\\\\d[:upper:]]*)(?![$_[:alnum:]])(!)?","beginCaptures":{"1":{"name":"meta.definition.variable.ts variable.other.constant.ts"},"2":{"name":"keyword.operator.definiteassignment.ts"}},"end":"(?=$|^|[,;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|(;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b))","name":"meta.var-single-variable.expr.ts","patterns":[{"include":"#var-single-variable-type-annotation"}]},{"begin":"([$_[:alpha:]][$_[:alnum:]]*)(!)?","beginCaptures":{"1":{"name":"meta.definition.variable.ts variable.other.readwrite.ts"},"2":{"name":"keyword.operator.definiteassignment.ts"}},"end":"(?=$|^|[,;=}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+)|(;|^\\\\s*$|^\\\\s*(?:abstract|async|\\\\bawait\\\\s+\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b\\\\b|break|case|catch|class|const|continue|declare|do|else|enum|export|finally|function|for|goto|if|import|interface|let|module|namespace|switch|return|throw|try|type|\\\\busing(?=\\\\s+(?!in\\\\b|of\\\\b(?!\\\\s*(?:of\\\\b|=)))[$_[:alpha:]])\\\\b|var|while)\\\\b))","name":"meta.var-single-variable.expr.ts","patterns":[{"include":"#var-single-variable-type-annotation"}]}]},"var-single-variable-type-annotation":{"patterns":[{"include":"#type-annotation"},{"include":"#string"},{"include":"#comment"}]},"variable-initializer":{"patterns":[{"begin":"(?<![!=])(=)(?!=)(?=\\\\s*\\\\S)(?!\\\\s*.*=>\\\\s*$)","beginCaptures":{"1":{"name":"keyword.operator.assignment.ts"}},"end":"(?=$|^|[]),;}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+))","patterns":[{"include":"#expression"}]},{"begin":"(?<![!=])(=)(?!=)","beginCaptures":{"1":{"name":"keyword.operator.assignment.ts"}},"end":"(?=[]),;}]|((?<![$_[:alnum:]])(?:(?<=\\\\.\\\\.\\\\.)|(?<!\\\\.))(of|in)\\\\s+))|(?=^\\\\s*$)|(?<![-\\\\&*+/|])(?<=\\\\S)(?<!=)(?=\\\\s*$)","patterns":[{"include":"#expression"}]}]}},"scopeName":"source.ts","aliases":["ts","cts","mts"]}')),
  d5 = [xd],
  kd = Object.freeze(JSON.parse(`{"displayName":"Shell","name":"shellscript","patterns":[{"include":"#initial_context"}],"repository":{"alias_statement":{"begin":"[\\\\t ]*+(alias)[\\\\t ]*+((?:((?<!\\\\w)-\\\\w+)\\\\b[\\\\t ]*+)*)[\\\\t ]*+((?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w))(?:(\\\\[)((?:(?:\\\\$?(?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w)|@)|\\\\*)|(-?\\\\d+))(]))?(?:(?:(=)|(\\\\+=))|(-=))","beginCaptures":{"1":{"name":"storage.type.alias.shell"},"2":{"patterns":[{"match":"(?<!\\\\w)-\\\\w+\\\\b","name":"string.unquoted.argument.shell constant.other.option.shell"}]},"3":{"name":"string.unquoted.argument.shell constant.other.option.shell"},"4":{"name":"variable.other.assignment.shell"},"5":{"name":"punctuation.definition.array.access.shell"},"6":{"name":"variable.other.assignment.shell"},"7":{"name":"constant.numeric.shell constant.numeric.integer.shell"},"8":{"name":"punctuation.definition.array.access.shell"},"9":{"name":"keyword.operator.assignment.shell"},"10":{"name":"keyword.operator.assignment.compound.shell"},"11":{"name":"keyword.operator.assignment.compound.shell"}},"end":"(?=[\\\\t ]|$)|(?:(?:(?:(;)|(&&))|(\\\\|\\\\|))|(&))","endCaptures":{"1":{"name":"punctuation.terminator.statement.semicolon.shell"},"2":{"name":"punctuation.separator.statement.and.shell"},"3":{"name":"punctuation.separator.statement.or.shell"},"4":{"name":"punctuation.separator.statement.background.shell"}},"name":"meta.expression.assignment.alias.shell","patterns":[{"include":"#normal_context"}]},"argument":{"begin":"[\\\\t ]++(?![\\\\n#\\\\&(\\\\[|]|$|;)","beginCaptures":{},"end":"(?=[\\\\t \\\\&;|]|$|[\\\\n)\`])","endCaptures":{},"name":"meta.argument.shell","patterns":[{"include":"#argument_context"},{"include":"#line_continuation"}]},"argument_context":{"patterns":[{"captures":{"1":{"name":"string.unquoted.argument.shell","patterns":[{"match":"\\\\*","name":"variable.language.special.wildcard.shell"},{"include":"#variable"},{"include":"#numeric_literal"},{"captures":{"1":{"name":"constant.language.$1.shell"}},"match":"(?<!\\\\w)\\\\b(true|false)\\\\b(?!\\\\w)"}]}},"match":"[\\\\t ]*+([^\\\\t\\\\n \\"$\\\\&-);<>\\\\\\\\\`|]+(?!>))"},{"include":"#normal_context"}]},"arithmetic_double":{"patterns":[{"begin":"\\\\(\\\\(","beginCaptures":{"0":{"name":"punctuation.section.arithmetic.double.shell"}},"end":"\\\\)\\\\s*\\\\)","endCaptures":{"0":{"name":"punctuation.section.arithmetic.double.shell"}},"name":"meta.arithmetic.shell","patterns":[{"include":"#math"},{"include":"#string"}]}]},"arithmetic_no_dollar":{"patterns":[{"begin":"\\\\(","beginCaptures":{"0":{"name":"punctuation.section.arithmetic.single.shell"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.section.arithmetic.single.shell"}},"name":"meta.arithmetic.shell","patterns":[{"include":"#math"},{"include":"#string"}]}]},"array_access_inline":{"captures":{"1":{"name":"punctuation.section.array.shell"},"2":{"patterns":[{"include":"#special_expansion"},{"include":"#string"},{"include":"#variable"}]},"3":{"name":"punctuation.section.array.shell"}},"match":"(\\\\[)([^]\\\\[]+)(])"},"array_value":{"begin":"[\\\\t ]*+((?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w))(?:(\\\\[)((?:(?:\\\\$?(?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w)|@)|\\\\*)|(-?\\\\d+))(]))?(?:(?:(=)|(\\\\+=))|(-=))[\\\\t ]*+(\\\\()","beginCaptures":{"1":{"name":"variable.other.assignment.shell"},"2":{"name":"punctuation.definition.array.access.shell"},"3":{"name":"variable.other.assignment.shell"},"4":{"name":"constant.numeric.shell constant.numeric.integer.shell"},"5":{"name":"punctuation.definition.array.access.shell"},"6":{"name":"keyword.operator.assignment.shell"},"7":{"name":"keyword.operator.assignment.compound.shell"},"8":{"name":"keyword.operator.assignment.compound.shell"},"9":{"name":"punctuation.definition.array.shell"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.definition.array.shell"}},"patterns":[{"include":"#comment"},{"captures":{"1":{"name":"variable.other.assignment.array.shell entity.other.attribute-name.shell"},"2":{"name":"keyword.operator.assignment.shell punctuation.definition.assignment.shell"}},"match":"((?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w))(=)"},{"captures":{"1":{"name":"punctuation.definition.bracket.named-array.shell"},"2":{"name":"string.unquoted.shell entity.other.attribute-name.bracket.shell"},"3":{"name":"punctuation.definition.bracket.named-array.shell"},"4":{"name":"punctuation.definition.assignment.shell"}},"match":"(\\\\[)(.+?)(])(=)"},{"include":"#normal_context"},{"include":"#simple_unquoted"}]},"assignment_statement":{"patterns":[{"include":"#array_value"},{"include":"#modified_assignment_statement"},{"include":"#normal_assignment_statement"}]},"basic_command_name":{"captures":{"1":{"name":"storage.modifier.$1.shell"},"2":{"name":"entity.name.function.call.shell entity.name.command.shell","patterns":[{"match":"(?<!\\\\w)(?:continue|return|break)(?!\\\\w)","name":"keyword.control.$0.shell"},{"match":"(?<!\\\\w)(?:unfunction|continue|autoload|unsetopt|bindkey|builtin|getopts|command|declare|unalias|history|unlimit|typeset|suspend|source|printf|unhash|disown|ulimit|return|which|alias|break|false|print|shift|times|umask|unset|read|type|exec|eval|wait|echo|dirs|jobs|kill|hash|stat|exit|test|trap|true|let|set|pwd|cd|fg|bg|fc|[.:])(?!/)(?!\\\\w)(?!-)","name":"support.function.builtin.shell"},{"include":"#variable"}]}},"match":"(?![\\\\n!#\\\\&()<>\\\\[{|]|$|[\\\\t ;])(?!nocorrect |nocorrect\\\\t|nocorrect$|readonly |readonly\\\\t|readonly$|function |function\\\\t|function$|foreach |foreach\\\\t|foreach$|coproc |coproc\\\\t|coproc$|logout |logout\\\\t|logout$|export |export\\\\t|export$|select |select\\\\t|select$|repeat |repeat\\\\t|repeat$|pushd |pushd\\\\t|pushd$|until |until\\\\t|until$|while |while\\\\t|while$|local |local\\\\t|local$|case |case\\\\t|case$|done |done\\\\t|done$|elif |elif\\\\t|elif$|else |else\\\\t|else$|esac |esac\\\\t|esac$|popd |popd\\\\t|popd$|then |then\\\\t|then$|time |time\\\\t|time$|for |for\\\\t|for$|end |end\\\\t|end$|fi |fi\\\\t|fi$|do |do\\\\t|do$|in |in\\\\t|in$|if |if\\\\t|if$)(?:((?<=^|[\\\\t \\\\&;])(?:readonly|declare|typeset|export|local)(?=[\\\\t \\\\&;]|$))|((?![\\"']|\\\\\\\\\\\\n?$)[^\\\\t\\\\n\\\\r !\\"'<>]+?))(?:(?=[\\\\t ])|(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\))","name":"meta.statement.command.name.basic.shell"},"block_comment":{"begin":"\\\\s*+(/\\\\*)","beginCaptures":{"1":{"name":"punctuation.definition.comment.begin.shell"}},"end":"\\\\*/","endCaptures":{"0":{"name":"punctuation.definition.comment.end.shell"}},"name":"comment.block.shell"},"boolean":{"match":"\\\\b(?:true|false)\\\\b","name":"constant.language.$0.shell"},"case_statement":{"begin":"\\\\b(case)\\\\b[\\\\t ]*+(.+?)[\\\\t ]*+\\\\b(in)\\\\b","beginCaptures":{"1":{"name":"keyword.control.case.shell"},"2":{"patterns":[{"include":"#initial_context"}]},"3":{"name":"keyword.control.in.shell"}},"end":"\\\\besac\\\\b","endCaptures":{"0":{"name":"keyword.control.esac.shell"}},"name":"meta.case.shell","patterns":[{"include":"#comment"},{"captures":{"1":{"name":"keyword.operator.pattern.case.default.shell"}},"match":"[\\\\t ]*+(\\\\* *\\\\))"},{"begin":"(?<!\\\\))(?![\\\\t ]*+(?:esac\\\\b|$))","beginCaptures":{},"end":"(?=\\\\besac\\\\b)|(\\\\))","endCaptures":{"1":{"name":"keyword.operator.pattern.case.shell"}},"name":"meta.case.entry.pattern.shell","patterns":[{"include":"#case_statement_context"}]},{"begin":"(?<=\\\\))","beginCaptures":{},"end":"(;;)|(?=\\\\besac\\\\b)","endCaptures":{"1":{"name":"punctuation.terminator.statement.case.shell"}},"name":"meta.case.entry.body.shell","patterns":[{"include":"#typical_statements"},{"include":"#initial_context"}]}]},"case_statement_context":{"patterns":[{"match":"\\\\*","name":"variable.language.special.quantifier.star.shell keyword.operator.quantifier.star.shell punctuation.definition.arbitrary-repetition.shell punctuation.definition.regex.arbitrary-repetition.shell"},{"match":"\\\\+","name":"variable.language.special.quantifier.plus.shell keyword.operator.quantifier.plus.shell punctuation.definition.arbitrary-repetition.shell punctuation.definition.regex.arbitrary-repetition.shell"},{"match":"\\\\?","name":"variable.language.special.quantifier.question.shell keyword.operator.quantifier.question.shell punctuation.definition.arbitrary-repetition.shell punctuation.definition.regex.arbitrary-repetition.shell"},{"match":"@","name":"variable.language.special.at.shell keyword.operator.at.shell punctuation.definition.regex.at.shell"},{"match":"\\\\|","name":"keyword.operator.orvariable.language.special.or.shell keyword.operator.alternation.ruby.shell punctuation.definition.regex.alternation.shell punctuation.separator.regex.alternation.shell"},{"match":"\\\\\\\\.","name":"constant.character.escape.shell"},{"match":"(?<=\\\\tin| in|[\\\\t ]|;;)\\\\(","name":"keyword.operator.pattern.case.shell"},{"begin":"(?<=\\\\S)(\\\\()","beginCaptures":{"1":{"name":"punctuation.definition.group.shell punctuation.definition.regex.group.shell"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.definition.group.shell punctuation.definition.regex.group.shell"}},"name":"meta.parenthese.shell","patterns":[{"include":"#case_statement_context"}]},{"begin":"\\\\[","beginCaptures":{"0":{"name":"punctuation.definition.character-class.shell"}},"end":"]","endCaptures":{"0":{"name":"punctuation.definition.character-class.shell"}},"name":"string.regexp.character-class.shell","patterns":[{"match":"\\\\\\\\.","name":"constant.character.escape.shell"}]},{"include":"#string"},{"match":"[^\\\\t\\\\n )*?@\\\\[|]","name":"string.unquoted.pattern.shell string.regexp.unquoted.shell"}]},"command_name_range":{"begin":"\\\\G","beginCaptures":{},"end":"(?=[\\\\t \\\\&;|]|$|[\\\\n)\`])|(?=<)","endCaptures":{},"name":"meta.statement.command.name.shell","patterns":[{"match":"(?<!\\\\w)(?:continue|return|break)(?!\\\\w)","name":"entity.name.function.call.shell entity.name.command.shell keyword.control.$0.shell"},{"match":"(?<!\\\\w)(?:unfunction|continue|autoload|unsetopt|bindkey|builtin|getopts|command|declare|unalias|history|unlimit|typeset|suspend|source|printf|unhash|disown|ulimit|return|which|alias|break|false|print|shift|times|umask|unset|read|type|exec|eval|wait|echo|dirs|jobs|kill|hash|stat|exit|test|trap|true|let|set|pwd|cd|fg|bg|fc|[.:])(?!/)(?!\\\\w)(?!-)","name":"entity.name.function.call.shell entity.name.command.shell support.function.builtin.shell"},{"include":"#variable"},{"captures":{"1":{"name":"entity.name.function.call.shell entity.name.command.shell"}},"match":"(?<!\\\\w)(?<=\\\\G|[\\"')}])([^\\\\t\\\\n\\\\r \\"\\\\&');->\`{|]+)"},{"begin":"(?:\\\\G|(?<![\\\\t\\\\n #\\\\&;{|]))(\\\\$?)((\\")|('))","beginCaptures":{"1":{"name":"meta.statement.command.name.quoted.shell punctuation.definition.string.shell entity.name.function.call.shell entity.name.command.shell"},"2":{},"3":{"name":"meta.statement.command.name.quoted.shell string.quoted.double.shell punctuation.definition.string.begin.shell entity.name.function.call.shell entity.name.command.shell"},"4":{"name":"meta.statement.command.name.quoted.shell string.quoted.single.shell punctuation.definition.string.begin.shell entity.name.function.call.shell entity.name.command.shell"}},"end":"(?<!\\\\G)(?<=\\\\2)","endCaptures":{},"patterns":[{"include":"#continuation_of_single_quoted_command_name"},{"include":"#continuation_of_double_quoted_command_name"}]},{"include":"#line_continuation"},{"include":"#simple_unquoted"}]},"command_statement":{"begin":"[\\\\t ]*+(?![\\\\n!#\\\\&()<>\\\\[{|]|$|[\\\\t ;])(?!nocorrect |nocorrect\\\\t|nocorrect$|readonly |readonly\\\\t|readonly$|function |function\\\\t|function$|foreach |foreach\\\\t|foreach$|coproc |coproc\\\\t|coproc$|logout |logout\\\\t|logout$|export |export\\\\t|export$|select |select\\\\t|select$|repeat |repeat\\\\t|repeat$|pushd |pushd\\\\t|pushd$|until |until\\\\t|until$|while |while\\\\t|while$|local |local\\\\t|local$|case |case\\\\t|case$|done |done\\\\t|done$|elif |elif\\\\t|elif$|else |else\\\\t|else$|esac |esac\\\\t|esac$|popd |popd\\\\t|popd$|then |then\\\\t|then$|time |time\\\\t|time$|for |for\\\\t|for$|end |end\\\\t|end$|fi |fi\\\\t|fi$|do |do\\\\t|do$|in |in\\\\t|in$|if |if\\\\t|if$)(?!\\\\\\\\\\\\n?$)","beginCaptures":{},"end":"(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\)","endCaptures":{},"name":"meta.statement.command.shell","patterns":[{"include":"#command_name_range"},{"include":"#line_continuation"},{"include":"#option"},{"include":"#argument"},{"include":"#string"},{"include":"#heredoc"}]},"comment":{"captures":{"1":{"name":"comment.line.number-sign.shell meta.shebang.shell"},"2":{"name":"punctuation.definition.comment.shebang.shell"},"3":{"name":"comment.line.number-sign.shell"},"4":{"name":"punctuation.definition.comment.shell"}},"match":"(?:^|[\\\\t ]++)(?:((#!).*)|((#).*))"},"comments":{"patterns":[{"include":"#block_comment"},{"include":"#line_comment"}]},"compound-command":{"patterns":[{"begin":"\\\\[","beginCaptures":{"0":{"name":"punctuation.definition.logical-expression.shell"}},"end":"]","endCaptures":{"0":{"name":"punctuation.definition.logical-expression.shell"}},"name":"meta.scope.logical-expression.shell","patterns":[{"include":"#logical-expression"},{"include":"#initial_context"}]},{"begin":"(?<=\\\\s|^)\\\\{(?=\\\\s|$)","beginCaptures":{"0":{"name":"punctuation.definition.group.shell"}},"end":"(?<=^|;)\\\\s*(})","endCaptures":{"1":{"name":"punctuation.definition.group.shell"}},"name":"meta.scope.group.shell","patterns":[{"include":"#initial_context"}]}]},"continuation_of_double_quoted_command_name":{"begin":"\\\\G(?<=\\")","beginCaptures":{},"contentName":"meta.statement.command.name.continuation string.quoted.double entity.name.function.call entity.name.command","end":"\\"","endCaptures":{"0":{"name":"string.quoted.double.shell punctuation.definition.string.end.shell entity.name.function.call.shell entity.name.command.shell"}},"patterns":[{"match":"\\\\\\\\[\\\\n\\"$\\\\\\\\\`]","name":"constant.character.escape.shell"},{"include":"#variable"},{"include":"#interpolation"}]},"continuation_of_single_quoted_command_name":{"begin":"\\\\G(?<=')","beginCaptures":{},"contentName":"meta.statement.command.name.continuation string.quoted.single entity.name.function.call entity.name.command","end":"'","endCaptures":{"0":{"name":"string.quoted.single.shell punctuation.definition.string.end.shell entity.name.function.call.shell entity.name.command.shell"}}},"custom_command_names":{"patterns":[]},"custom_commands":{"patterns":[]},"double_quote_context":{"patterns":[{"match":"\\\\\\\\[\\\\n\\"$\\\\\\\\\`]","name":"constant.character.escape.shell"},{"include":"#variable"},{"include":"#interpolation"}]},"double_quote_escape_char":{"match":"\\\\\\\\[\\\\n\\"$\\\\\\\\\`]","name":"constant.character.escape.shell"},"floating_keyword":{"patterns":[{"match":"(?<=^|[\\\\t \\\\&;])(?:then|elif|else|done|end|do|if|fi)(?=[\\\\t \\\\&;]|$)","name":"keyword.control.$0.shell"}]},"for_statement":{"patterns":[{"begin":"\\\\b(for)\\\\b[\\\\t ]*+((?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w))[\\\\t ]*+\\\\b(in)\\\\b","beginCaptures":{"1":{"name":"keyword.control.for.shell"},"2":{"name":"variable.other.for.shell"},"3":{"name":"keyword.control.in.shell"}},"end":"(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\)","endCaptures":{},"name":"meta.for.in.shell","patterns":[{"include":"#string"},{"include":"#simple_unquoted"},{"include":"#normal_context"}]},{"begin":"\\\\b(for)\\\\b","beginCaptures":{"1":{"name":"keyword.control.for.shell"}},"end":"(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\)","endCaptures":{},"name":"meta.for.shell","patterns":[{"include":"#arithmetic_double"},{"include":"#normal_context"}]}]},"function_definition":{"applyEndPatternLast":1,"begin":"[\\\\t ]*+(?:\\\\b(function)\\\\b[\\\\t ]*+([^\\\\t\\\\n\\\\r \\"'()=]+)(?:(\\\\()[\\\\t ]*+(\\\\)))?|([^\\\\t\\\\n\\\\r \\"'()=]+)[\\\\t ]*+(\\\\()[\\\\t ]*+(\\\\)))","beginCaptures":{"1":{"name":"storage.type.function.shell"},"2":{"name":"entity.name.function.shell"},"3":{"name":"punctuation.definition.arguments.shell"},"4":{"name":"punctuation.definition.arguments.shell"},"5":{"name":"entity.name.function.shell"},"6":{"name":"punctuation.definition.arguments.shell"},"7":{"name":"punctuation.definition.arguments.shell"}},"end":"(?<=[)}])","endCaptures":{},"name":"meta.function.shell","patterns":[{"match":"\\\\G[\\\\t\\\\n ]"},{"begin":"\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.group.shell punctuation.section.function.definition.shell"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.group.shell punctuation.section.function.definition.shell"}},"name":"meta.function.body.shell","patterns":[{"include":"#initial_context"}]},{"begin":"\\\\(","beginCaptures":{"0":{"name":"punctuation.definition.group.shell punctuation.section.function.definition.shell"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.definition.group.shell punctuation.section.function.definition.shell"}},"name":"meta.function.body.shell","patterns":[{"include":"#initial_context"}]},{"include":"#initial_context"}]},"heredoc":{"patterns":[{"begin":"((?<!<)<<-)[\\\\t ]*+([\\"'])[\\\\t ]*+([^\\"']+?)(?=[\\"\\\\&';<\\\\s])(\\\\2)(.*)","beginCaptures":{"1":{"name":"keyword.operator.heredoc.shell"},"2":{"name":"punctuation.definition.string.heredoc.quote.shell"},"3":{"name":"punctuation.definition.string.heredoc.delimiter.shell"},"4":{"name":"punctuation.definition.string.heredoc.quote.shell"},"5":{"patterns":[{"include":"#redirect_fix"},{"include":"#typical_statements"}]}},"contentName":"string.quoted.heredoc.indent.$3","end":"^\\\\t*\\\\3(?=[\\\\&;\\\\s]|$)","endCaptures":{"0":{"name":"punctuation.definition.string.heredoc.$0.shell"}},"patterns":[]},{"begin":"((?<!<)<<(?!<))[\\\\t ]*+([\\"'])[\\\\t ]*+([^\\"']+?)(?=[\\"\\\\&';<\\\\s])(\\\\2)(.*)","beginCaptures":{"1":{"name":"keyword.operator.heredoc.shell"},"2":{"name":"punctuation.definition.string.heredoc.quote.shell"},"3":{"name":"punctuation.definition.string.heredoc.delimiter.shell"},"4":{"name":"punctuation.definition.string.heredoc.quote.shell"},"5":{"patterns":[{"include":"#redirect_fix"},{"include":"#typical_statements"}]}},"contentName":"string.quoted.heredoc.no-indent.$3","end":"^\\\\3(?=[\\\\&;\\\\s]|$)","endCaptures":{"0":{"name":"punctuation.definition.string.heredoc.delimiter.shell"}},"patterns":[]},{"begin":"((?<!<)<<-)[\\\\t ]*+([^\\\\t \\"']+)(?=[\\"\\\\&';<\\\\s])(.*)","beginCaptures":{"1":{"name":"keyword.operator.heredoc.shell"},"2":{"name":"punctuation.definition.string.heredoc.delimiter.shell"},"3":{"patterns":[{"include":"#redirect_fix"},{"include":"#typical_statements"}]}},"contentName":"string.unquoted.heredoc.indent.$2","end":"^\\\\t*\\\\2(?=[\\\\&;\\\\s]|$)","endCaptures":{"0":{"name":"punctuation.definition.string.heredoc.delimiter.shell"}},"patterns":[{"include":"#double_quote_escape_char"},{"include":"#variable"},{"include":"#interpolation"}]},{"begin":"((?<!<)<<(?!<))[\\\\t ]*+([^\\\\t \\"']+)(?=[\\"\\\\&';<\\\\s])(.*)","beginCaptures":{"1":{"name":"keyword.operator.heredoc.shell"},"2":{"name":"punctuation.definition.string.heredoc.delimiter.shell"},"3":{"patterns":[{"include":"#redirect_fix"},{"include":"#typical_statements"}]}},"contentName":"string.unquoted.heredoc.no-indent.$2","end":"^\\\\2(?=[\\\\&;\\\\s]|$)","endCaptures":{"0":{"name":"punctuation.definition.string.heredoc.delimiter.shell"}},"patterns":[{"include":"#double_quote_escape_char"},{"include":"#variable"},{"include":"#interpolation"}]}]},"herestring":{"patterns":[{"begin":"(<<<)\\\\s*(('))","beginCaptures":{"1":{"name":"keyword.operator.herestring.shell"},"2":{"name":"string.quoted.single.shell"},"3":{"name":"punctuation.definition.string.begin.shell"}},"contentName":"string.quoted.single.shell","end":"(')","endCaptures":{"0":{"name":"string.quoted.single.shell"},"1":{"name":"punctuation.definition.string.end.shell"}},"name":"meta.herestring.shell"},{"begin":"(<<<)\\\\s*((\\"))","beginCaptures":{"1":{"name":"keyword.operator.herestring.shell"},"2":{"name":"string.quoted.double.shell"},"3":{"name":"punctuation.definition.string.begin.shell"}},"contentName":"string.quoted.double.shell","end":"(\\")","endCaptures":{"0":{"name":"string.quoted.double.shell"},"1":{"name":"punctuation.definition.string.end.shell"}},"name":"meta.herestring.shell","patterns":[{"include":"#double_quote_context"}]},{"captures":{"1":{"name":"keyword.operator.herestring.shell"},"2":{"name":"string.unquoted.herestring.shell","patterns":[{"include":"#initial_context"}]}},"match":"(<<<)\\\\s*(([^)\\\\\\\\\\\\s]|\\\\\\\\.)+)","name":"meta.herestring.shell"}]},"initial_context":{"patterns":[{"include":"#comment"},{"include":"#pipeline"},{"include":"#normal_statement_seperator"},{"include":"#logical_expression_double"},{"include":"#logical_expression_single"},{"include":"#assignment_statement"},{"include":"#case_statement"},{"include":"#for_statement"},{"include":"#loop"},{"include":"#function_definition"},{"include":"#line_continuation"},{"include":"#arithmetic_double"},{"include":"#misc_ranges"},{"include":"#variable"},{"include":"#interpolation"},{"include":"#heredoc"},{"include":"#herestring"},{"include":"#redirection"},{"include":"#pathname"},{"include":"#floating_keyword"},{"include":"#alias_statement"},{"include":"#normal_statement"},{"include":"#string"},{"include":"#support"}]},"inline_comment":{"captures":{"1":{"name":"comment.block.shell punctuation.definition.comment.begin.shell"},"2":{"name":"comment.block.shell"},"3":{"patterns":[{"match":"\\\\*/","name":"comment.block.shell punctuation.definition.comment.end.shell"},{"match":"\\\\*","name":"comment.block.shell"}]}},"match":"(/\\\\*)((?:[^*]|\\\\*++[^/])*+(\\\\*++/))"},"interpolation":{"patterns":[{"include":"#arithmetic_dollar"},{"include":"#subshell_dollar"},{"begin":"\`","beginCaptures":{"0":{"name":"punctuation.definition.evaluation.backticks.shell"}},"end":"\`","endCaptures":{"0":{"name":"punctuation.definition.evaluation.backticks.shell"}},"name":"string.interpolated.backtick.shell","patterns":[{"match":"\\\\\\\\[$\\\\\\\\\`]","name":"constant.character.escape.shell"},{"begin":"(?<=\\\\W)(?=#)(?!#\\\\{)","beginCaptures":{"1":{"name":"punctuation.whitespace.comment.leading.shell"}},"end":"(?!\\\\G)","patterns":[{"begin":"#","beginCaptures":{"0":{"name":"punctuation.definition.comment.shell"}},"end":"(?=\`)","name":"comment.line.number-sign.shell"}]},{"include":"#initial_context"}]}]},"keyword":{"patterns":[{"match":"(?<=^|[\\\\&;\\\\s])(then|else|elif|fi|for|in|do|done|select|continue|esac|while|until|return)(?=[\\\\&;\\\\s]|$)","name":"keyword.control.shell"},{"match":"(?<=^|[\\\\&;\\\\s])(?:export|declare|typeset|local|readonly)(?=[\\\\&;\\\\s]|$)","name":"storage.modifier.shell"}]},"line_comment":{"begin":"\\\\s*+(//)","beginCaptures":{"1":{"name":"punctuation.definition.comment.shell"}},"end":"(?<=\\\\n)(?<!\\\\\\\\\\\\n)","endCaptures":{},"name":"comment.line.double-slash.shell","patterns":[{"include":"#line_continuation_character"}]},"line_continuation":{"match":"\\\\\\\\(?=\\\\n)","name":"constant.character.escape.line-continuation.shell"},"logical-expression":{"patterns":[{"include":"#arithmetic_no_dollar"},{"match":"=[=~]?|!=?|[<>]|&&|\\\\|\\\\|","name":"keyword.operator.logical.shell"},{"match":"(?<!\\\\S)-(nt|ot|ef|eq|ne|l[et]|g[et]|[GLNOSa-hknopr-uwxz])\\\\b","name":"keyword.operator.logical.shell"}]},"logical_expression_context":{"patterns":[{"include":"#regex_comparison"},{"include":"#arithmetic_no_dollar"},{"include":"#logical-expression"},{"include":"#logical_expression_single"},{"include":"#logical_expression_double"},{"include":"#comment"},{"include":"#boolean"},{"include":"#redirect_number"},{"include":"#numeric_literal"},{"include":"#pipeline"},{"include":"#normal_statement_seperator"},{"include":"#string"},{"include":"#variable"},{"include":"#interpolation"},{"include":"#heredoc"},{"include":"#herestring"},{"include":"#pathname"},{"include":"#floating_keyword"},{"include":"#support"}]},"logical_expression_double":{"begin":"\\\\[\\\\[","beginCaptures":{"0":{"name":"punctuation.definition.logical-expression.shell"}},"end":"]]","endCaptures":{"0":{"name":"punctuation.definition.logical-expression.shell"}},"name":"meta.scope.logical-expression.shell","patterns":[{"include":"#logical_expression_context"}]},"logical_expression_single":{"begin":"\\\\[","beginCaptures":{"0":{"name":"punctuation.definition.logical-expression.shell"}},"end":"]","endCaptures":{"0":{"name":"punctuation.definition.logical-expression.shell"}},"name":"meta.scope.logical-expression.shell","patterns":[{"include":"#logical_expression_context"}]},"loop":{"patterns":[{"begin":"(?<=^|[\\\\&;\\\\s])(for)\\\\s+(.+?)\\\\s+(in)(?=[\\\\&;\\\\s]|$)","beginCaptures":{"1":{"name":"keyword.control.shell"},"2":{"name":"variable.other.loop.shell","patterns":[{"include":"#string"}]},"3":{"name":"keyword.control.shell"}},"end":"(?<=^|[\\\\&;\\\\s])done(?=[\\\\&;\\\\s]|$|\\\\))","endCaptures":{"0":{"name":"keyword.control.shell"}},"name":"meta.scope.for-in-loop.shell","patterns":[{"include":"#initial_context"}]},{"begin":"(?<=^|[\\\\&;\\\\s])(while|until)(?=[\\\\&;\\\\s]|$)","beginCaptures":{"1":{"name":"keyword.control.shell"}},"end":"(?<=^|[\\\\&;\\\\s])done(?=[\\\\&;\\\\s]|$|\\\\))","endCaptures":{"0":{"name":"keyword.control.shell"}},"name":"meta.scope.while-loop.shell","patterns":[{"include":"#initial_context"}]},{"begin":"(?<=^|[\\\\&;\\\\s])(select)\\\\s+((?:[^\\\\\\\\\\\\s]|\\\\\\\\.)+)(?=[\\\\&;\\\\s]|$)","beginCaptures":{"1":{"name":"keyword.control.shell"},"2":{"name":"variable.other.loop.shell"}},"end":"(?<=^|[\\\\&;\\\\s])(done)(?=[\\\\&;\\\\s]|$|\\\\))","endCaptures":{"1":{"name":"keyword.control.shell"}},"name":"meta.scope.select-block.shell","patterns":[{"include":"#initial_context"}]},{"begin":"(?<=^|[\\\\&;\\\\s])if(?=[\\\\&;\\\\s]|$)","beginCaptures":{"0":{"name":"keyword.control.if.shell"}},"end":"(?<=^|[\\\\&;\\\\s])fi(?=[\\\\&;\\\\s]|$)","endCaptures":{"0":{"name":"keyword.control.fi.shell"}},"name":"meta.scope.if-block.shell","patterns":[{"include":"#initial_context"}]}]},"math":{"patterns":[{"include":"#variable"},{"match":"\\\\+{1,2}|-{1,2}|[!~]|\\\\*{1,2}|[%/]|<[<=]?|>[=>]?|==|!=|^|\\\\|{1,2}|&{1,2}|[,:=?]|[-%\\\\&*+/^|]=|<<=|>>=","name":"keyword.operator.arithmetic.shell"},{"match":"0[Xx]\\\\h+","name":"constant.numeric.hex.shell"},{"match":";","name":"punctuation.separator.semicolon.range"},{"match":"0\\\\d+","name":"constant.numeric.octal.shell"},{"match":"\\\\d{1,2}#[0-9@-Z_a-z]+","name":"constant.numeric.other.shell"},{"match":"\\\\d+","name":"constant.numeric.integer.shell"},{"match":"(?<!\\\\w)[0-9A-Z_a-z]+(?!\\\\w)","name":"variable.other.normal.shell"}]},"math_operators":{"patterns":[{"match":"\\\\+{1,2}|-{1,2}|[!~]|\\\\*{1,2}|[%/]|<[<=]?|>[=>]?|==|!=|^|\\\\|{1,2}|&{1,2}|[,:=?]|[-%\\\\&*+/^|]=|<<=|>>=","name":"keyword.operator.arithmetic.shell"},{"match":"0[Xx]\\\\h+","name":"constant.numeric.hex.shell"},{"match":"0\\\\d+","name":"constant.numeric.octal.shell"},{"match":"\\\\d{1,2}#[0-9@-Z_a-z]+","name":"constant.numeric.other.shell"},{"match":"\\\\d+","name":"constant.numeric.integer.shell"}]},"misc_ranges":{"patterns":[{"include":"#logical_expression_single"},{"include":"#logical_expression_double"},{"include":"#subshell_dollar"},{"begin":"(?<![^\\\\t ])(\\\\{)(?![$\\\\w])","beginCaptures":{"1":{"name":"punctuation.definition.group.shell"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.group.shell"}},"name":"meta.scope.group.shell","patterns":[{"include":"#initial_context"}]}]},"modified_assignment_statement":{"begin":"(?<=^|[\\\\t \\\\&;])(?:readonly|declare|typeset|export|local)(?=[\\\\t \\\\&;]|$)","beginCaptures":{"0":{"name":"storage.modifier.$0.shell"}},"end":"(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\)","endCaptures":{},"name":"meta.statement.shell meta.expression.assignment.modified.shell","patterns":[{"match":"(?<!\\\\w)-\\\\w+\\\\b","name":"string.unquoted.argument.shell constant.other.option.shell"},{"include":"#array_value"},{"captures":{"1":{"name":"variable.other.assignment.shell"},"2":{"name":"punctuation.definition.array.access.shell"},"3":{"name":"variable.other.assignment.shell"},"4":{"name":"constant.numeric.shell constant.numeric.integer.shell"},"5":{"name":"punctuation.definition.array.access.shell"},"6":{"name":"keyword.operator.assignment.shell"},"7":{"name":"keyword.operator.assignment.compound.shell"},"8":{"name":"keyword.operator.assignment.compound.shell"},"9":{"name":"constant.numeric.shell constant.numeric.hex.shell"},"10":{"name":"constant.numeric.shell constant.numeric.octal.shell"},"11":{"name":"constant.numeric.shell constant.numeric.other.shell"},"12":{"name":"constant.numeric.shell constant.numeric.decimal.shell"},"13":{"name":"constant.numeric.shell constant.numeric.version.shell"},"14":{"name":"constant.numeric.shell constant.numeric.integer.shell"}},"match":"((?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w))(?:(\\\\[)((?:(?:\\\\$?(?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w)|@)|\\\\*)|(-?\\\\d+))(]))?(?:(?:(=)|(\\\\+=))|(-=))?(?:(?<=[\\\\t =]|^|[(\\\\[{])(?:(?:(?:(?:(?:(0[Xx]\\\\h+)|(0\\\\d+))|(\\\\d{1,2}#[0-9@-Z_a-z]+))|(-?\\\\d+\\\\.\\\\d+))|(-?\\\\d+(?:\\\\.\\\\d+)+))|(-?\\\\d+))(?=[\\\\t ]|$|[);}]))?"},{"include":"#normal_context"}]},"modifiers":{"match":"(?<=^|[\\\\t \\\\&;])(?:readonly|declare|typeset|export|local)(?=[\\\\t \\\\&;]|$)","name":"storage.modifier.$0.shell"},"normal_assignment_statement":{"begin":"[\\\\t ]*+((?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w))(?:(\\\\[)((?:(?:\\\\$?(?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w)|@)|\\\\*)|(-?\\\\d+))(]))?(?:(?:(=)|(\\\\+=))|(-=))","beginCaptures":{"1":{"name":"variable.other.assignment.shell"},"2":{"name":"punctuation.definition.array.access.shell"},"3":{"name":"variable.other.assignment.shell"},"4":{"name":"constant.numeric.shell constant.numeric.integer.shell"},"5":{"name":"punctuation.definition.array.access.shell"},"6":{"name":"keyword.operator.assignment.shell"},"7":{"name":"keyword.operator.assignment.compound.shell"},"8":{"name":"keyword.operator.assignment.compound.shell"}},"end":"(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\)","endCaptures":{},"name":"meta.expression.assignment.shell","patterns":[{"include":"#comment"},{"include":"#string"},{"include":"#normal_assignment_statement"},{"begin":"(?<=[\\\\t ])(?![\\\\t ]|\\\\w+=)","beginCaptures":{},"end":"(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\)","endCaptures":{},"name":"meta.statement.command.env.shell","patterns":[{"include":"#command_name_range"},{"include":"#line_continuation"},{"include":"#option"},{"include":"#argument"},{"include":"#string"}]},{"include":"#simple_unquoted"},{"include":"#normal_context"}]},"normal_context":{"patterns":[{"include":"#comment"},{"include":"#pipeline"},{"include":"#normal_statement_seperator"},{"include":"#misc_ranges"},{"include":"#boolean"},{"include":"#redirect_number"},{"include":"#numeric_literal"},{"include":"#string"},{"include":"#variable"},{"include":"#interpolation"},{"include":"#heredoc"},{"include":"#herestring"},{"include":"#redirection"},{"include":"#pathname"},{"include":"#floating_keyword"},{"include":"#support"},{"include":"#parenthese"}]},"normal_statement":{"begin":"(?!^[\\\\t ]*+$)(?:(?<=(?:^until| until|\\\\tuntil|^while| while|\\\\twhile|^elif| elif|\\\\telif|^else| else|\\\\telse|^then| then|\\\\tthen|^do| do|\\\\tdo|^if| if|\\\\tif) )|(?<=^|[!\\\\&(;\`{|]))[\\\\t ]*+(?!nocorrect\\\\W|nocorrect\\\\$|function\\\\W|function\\\\$|foreach\\\\W|foreach\\\\$|repeat\\\\W|repeat\\\\$|logout\\\\W|logout\\\\$|coproc\\\\W|coproc\\\\$|select\\\\W|select\\\\$|while\\\\W|while\\\\$|pushd\\\\W|pushd\\\\$|until\\\\W|until\\\\$|case\\\\W|case\\\\$|done\\\\W|done\\\\$|elif\\\\W|elif\\\\$|else\\\\W|else\\\\$|esac\\\\W|esac\\\\$|popd\\\\W|popd\\\\$|then\\\\W|then\\\\$|time\\\\W|time\\\\$|for\\\\W|for\\\\$|end\\\\W|end\\\\$|fi\\\\W|fi\\\\$|do\\\\W|do\\\\$|in\\\\W|in\\\\$|if\\\\W|if\\\\$)","beginCaptures":{},"end":"(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\)","endCaptures":{},"name":"meta.statement.shell","patterns":[{"include":"#typical_statements"}]},"normal_statement_seperator":{"captures":{"1":{"name":"punctuation.terminator.statement.semicolon.shell"},"2":{"name":"punctuation.separator.statement.and.shell"},"3":{"name":"punctuation.separator.statement.or.shell"},"4":{"name":"punctuation.separator.statement.background.shell"}},"match":"(?:(?:(;)|(&&))|(\\\\|\\\\|))|(&)"},"numeric_literal":{"captures":{"1":{"name":"constant.numeric.shell constant.numeric.hex.shell"},"2":{"name":"constant.numeric.shell constant.numeric.octal.shell"},"3":{"name":"constant.numeric.shell constant.numeric.other.shell"},"4":{"name":"constant.numeric.shell constant.numeric.decimal.shell"},"5":{"name":"constant.numeric.shell constant.numeric.version.shell"},"6":{"name":"constant.numeric.shell constant.numeric.integer.shell"}},"match":"(?<=[\\\\t =]|^|[(\\\\[{])(?:(?:(?:(?:(?:(0[Xx]\\\\h+)|(0\\\\d+))|(\\\\d{1,2}#[0-9@-Z_a-z]+))|(-?\\\\d+\\\\.\\\\d+))|(-?\\\\d+(?:\\\\.\\\\d+)+))|(-?\\\\d+))(?=[\\\\t ]|$|[);}])"},"option":{"begin":"[\\\\t ]++(-)((?![\\\\n!#\\\\&()<>\\\\[{|]|$|[\\\\t ;]))","beginCaptures":{"1":{"name":"string.unquoted.argument.shell constant.other.option.dash.shell"},"2":{"name":"string.unquoted.argument.shell constant.other.option.shell"}},"contentName":"string.unquoted.argument constant.other.option","end":"(?=[\\\\t ])|(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\)","endCaptures":{},"patterns":[{"include":"#option_context"}]},"option_context":{"patterns":[{"include":"#misc_ranges"},{"include":"#string"},{"include":"#variable"},{"include":"#interpolation"},{"include":"#heredoc"},{"include":"#herestring"},{"include":"#redirection"},{"include":"#pathname"},{"include":"#floating_keyword"},{"include":"#support"}]},"parenthese":{"patterns":[{"begin":"\\\\(","beginCaptures":{"0":{"name":"punctuation.section.parenthese.shell"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.section.parenthese.shell"}},"name":"meta.parenthese.group.shell","patterns":[{"include":"#initial_context"}]}]},"pathname":{"patterns":[{"match":"(?<=[:=\\\\s]|^)~","name":"keyword.operator.tilde.shell"},{"match":"[*?]","name":"keyword.operator.glob.shell"},{"begin":"([!*+?@])(\\\\()","beginCaptures":{"1":{"name":"keyword.operator.extglob.shell"},"2":{"name":"punctuation.definition.extglob.shell"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.definition.extglob.shell"}},"name":"meta.structure.extglob.shell","patterns":[{"include":"#initial_context"}]}]},"pipeline":{"patterns":[{"match":"(?<=^|[\\\\&;\\\\s])(time)(?=[\\\\&;\\\\s]|$)","name":"keyword.other.shell"},{"match":"[!|]","name":"keyword.operator.pipe.shell"}]},"redirect_fix":{"captures":{"1":{"name":"keyword.operator.redirect.shell"},"2":{"name":"string.unquoted.argument.shell"}},"match":"(>>?)[\\\\t ]*+([^\\\\t\\\\n \\"$\\\\&-);<>\\\\\\\\\`|]+)"},"redirect_number":{"captures":{"1":{"name":"keyword.operator.redirect.stdout.shell"},"2":{"name":"keyword.operator.redirect.stderr.shell"},"3":{"name":"keyword.operator.redirect.$3.shell"}},"match":"(?<=[\\\\t ])(?:(1)|(2)|(\\\\d+))(?=>)"},"redirection":{"patterns":[{"begin":"[<>]\\\\(","beginCaptures":{"0":{"name":"punctuation.definition.string.begin.shell"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.definition.string.end.shell"}},"name":"string.interpolated.process-substitution.shell","patterns":[{"include":"#initial_context"}]},{"match":"(?<![<>])(&>|\\\\d*>&\\\\d*|\\\\d*(>>|[<>])|\\\\d*<&|\\\\d*<>)(?![<>])","name":"keyword.operator.redirect.shell"}]},"regex_comparison":{"match":"=~","name":"keyword.operator.logical.regex.shell"},"regexp":{"patterns":[{"match":".+"}]},"simple_options":{"captures":{"0":{"patterns":[{"captures":{"1":{"name":"string.unquoted.argument.shell constant.other.option.dash.shell"},"2":{"name":"string.unquoted.argument.shell constant.other.option.shell"}},"match":"[\\\\t ]++(-)(\\\\w+)"}]}},"match":"(?:[\\\\t ]++-\\\\w+)*"},"simple_unquoted":{"match":"[^\\\\t\\\\n \\"$\\\\&-);<>\\\\\\\\\`|]","name":"string.unquoted.shell"},"special_expansion":{"match":"!|:[-=?]?|[*@]|##?|%%|[%/]","name":"keyword.operator.expansion.shell"},"start_of_command":{"match":"[\\\\t ]*+(?![\\\\n!#\\\\&()<>\\\\[{|]|$|[\\\\t ;])(?!nocorrect |nocorrect\\\\t|nocorrect$|readonly |readonly\\\\t|readonly$|function |function\\\\t|function$|foreach |foreach\\\\t|foreach$|coproc |coproc\\\\t|coproc$|logout |logout\\\\t|logout$|export |export\\\\t|export$|select |select\\\\t|select$|repeat |repeat\\\\t|repeat$|pushd |pushd\\\\t|pushd$|until |until\\\\t|until$|while |while\\\\t|while$|local |local\\\\t|local$|case |case\\\\t|case$|done |done\\\\t|done$|elif |elif\\\\t|elif$|else |else\\\\t|else$|esac |esac\\\\t|esac$|popd |popd\\\\t|popd$|then |then\\\\t|then$|time |time\\\\t|time$|for |for\\\\t|for$|end |end\\\\t|end$|fi |fi\\\\t|fi$|do |do\\\\t|do$|in |in\\\\t|in$|if |if\\\\t|if$)(?!\\\\\\\\\\\\n?$)"},"string":{"patterns":[{"match":"\\\\\\\\.","name":"constant.character.escape.shell"},{"begin":"'","beginCaptures":{"0":{"name":"punctuation.definition.string.begin.shell"}},"end":"'","endCaptures":{"0":{"name":"punctuation.definition.string.end.shell"}},"name":"string.quoted.single.shell"},{"begin":"\\\\$?\\"","beginCaptures":{"0":{"name":"punctuation.definition.string.begin.shell"}},"end":"\\"","endCaptures":{"0":{"name":"punctuation.definition.string.end.shell"}},"name":"string.quoted.double.shell","patterns":[{"match":"\\\\\\\\[\\\\n\\"$\\\\\\\\\`]","name":"constant.character.escape.shell"},{"include":"#variable"},{"include":"#interpolation"}]},{"begin":"\\\\$'","beginCaptures":{"0":{"name":"punctuation.definition.string.begin.shell"}},"end":"'","endCaptures":{"0":{"name":"punctuation.definition.string.end.shell"}},"name":"string.quoted.single.dollar.shell","patterns":[{"match":"\\\\\\\\['\\\\\\\\abefnrtv]","name":"constant.character.escape.ansi-c.shell"},{"match":"\\\\\\\\[0-9]{3}\\"","name":"constant.character.escape.octal.shell"},{"match":"\\\\\\\\x\\\\h{2}\\"","name":"constant.character.escape.hex.shell"},{"match":"\\\\\\\\c.\\"","name":"constant.character.escape.control-char.shell"}]}]},"subshell_dollar":{"patterns":[{"begin":"\\\\$\\\\(","beginCaptures":{"0":{"name":"punctuation.definition.subshell.single.shell"}},"end":"\\\\)","endCaptures":{"0":{"name":"punctuation.definition.subshell.single.shell"}},"name":"meta.scope.subshell","patterns":[{"include":"#parenthese"},{"include":"#initial_context"}]}]},"support":{"patterns":[{"match":"(?<=^|[\\\\&;\\\\s])[.:](?=[\\\\&;\\\\s]|$)","name":"support.function.builtin.shell"}]},"typical_statements":{"patterns":[{"include":"#assignment_statement"},{"include":"#case_statement"},{"include":"#for_statement"},{"include":"#while_statement"},{"include":"#function_definition"},{"include":"#command_statement"},{"include":"#line_continuation"},{"include":"#arithmetic_double"},{"include":"#normal_context"}]},"variable":{"patterns":[{"captures":{"1":{"name":"punctuation.definition.variable.shell variable.parameter.positional.all.shell"},"2":{"name":"variable.parameter.positional.all.shell"}},"match":"(\\\\$)(@(?!\\\\w))"},{"captures":{"1":{"name":"punctuation.definition.variable.shell variable.parameter.positional.shell"},"2":{"name":"variable.parameter.positional.shell"}},"match":"(\\\\$)([0-9](?!\\\\w))"},{"captures":{"1":{"name":"punctuation.definition.variable.shell variable.language.special.shell"},"2":{"name":"variable.language.special.shell"}},"match":"(\\\\$)([-!#$*0?_](?!\\\\w))"},{"begin":"(\\\\$)(\\\\{)[\\\\t ]*+(?=\\\\d)","beginCaptures":{"1":{"name":"punctuation.definition.variable.shell variable.parameter.positional.shell"},"2":{"name":"punctuation.section.bracket.curly.variable.begin.shell punctuation.definition.variable.shell variable.parameter.positional.shell"}},"contentName":"meta.parameter-expansion","end":"}","endCaptures":{"0":{"name":"punctuation.section.bracket.curly.variable.end.shell punctuation.definition.variable.shell variable.parameter.positional.shell"}},"patterns":[{"include":"#special_expansion"},{"include":"#array_access_inline"},{"match":"[0-9]+","name":"variable.parameter.positional.shell"},{"match":"(?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w)","name":"variable.other.normal.shell"},{"include":"#variable"},{"include":"#string"}]},{"begin":"(\\\\$)(\\\\{)","beginCaptures":{"1":{"name":"punctuation.definition.variable.shell"},"2":{"name":"punctuation.section.bracket.curly.variable.begin.shell punctuation.definition.variable.shell"}},"contentName":"meta.parameter-expansion","end":"}","endCaptures":{"0":{"name":"punctuation.section.bracket.curly.variable.end.shell punctuation.definition.variable.shell"}},"patterns":[{"include":"#special_expansion"},{"include":"#array_access_inline"},{"match":"(?<!\\\\w)[-0-9A-Z_a-z]+(?!\\\\w)","name":"variable.other.normal.shell"},{"include":"#variable"},{"include":"#string"}]},{"captures":{"1":{"name":"punctuation.definition.variable.shell variable.other.normal.shell"},"2":{"name":"variable.other.normal.shell"}},"match":"(\\\\$)(\\\\w+(?!\\\\w))"}]},"while_statement":{"patterns":[{"begin":"\\\\b(while)\\\\b","beginCaptures":{"1":{"name":"keyword.control.while.shell"}},"end":"(?=[\\\\n\\\\&);\`{|}]|[\\\\t ]*#|])(?<!\\\\\\\\)","endCaptures":{},"name":"meta.while.shell","patterns":[{"include":"#line_continuation"},{"include":"#math_operators"},{"include":"#option"},{"include":"#simple_unquoted"},{"include":"#normal_context"},{"include":"#string"}]}]}},"scopeName":"source.shell","aliases":["bash","sh","shell","zsh"]}`)),
  f5 = [kd],
  _d = Object.freeze(JSON.parse('{"displayName":"JSON","name":"json","patterns":[{"include":"#value"}],"repository":{"array":{"begin":"\\\\[","beginCaptures":{"0":{"name":"punctuation.definition.array.begin.json"}},"end":"]","endCaptures":{"0":{"name":"punctuation.definition.array.end.json"}},"name":"meta.structure.array.json","patterns":[{"include":"#value"},{"match":",","name":"punctuation.separator.array.json"},{"match":"[^]\\\\s]","name":"invalid.illegal.expected-array-separator.json"}]},"comments":{"patterns":[{"begin":"/\\\\*\\\\*(?!/)","captures":{"0":{"name":"punctuation.definition.comment.json"}},"end":"\\\\*/","name":"comment.block.documentation.json"},{"begin":"/\\\\*","captures":{"0":{"name":"punctuation.definition.comment.json"}},"end":"\\\\*/","name":"comment.block.json"},{"captures":{"1":{"name":"punctuation.definition.comment.json"}},"match":"(//).*$\\\\n?","name":"comment.line.double-slash.js"}]},"constant":{"match":"\\\\b(?:true|false|null)\\\\b","name":"constant.language.json"},"number":{"match":"-?(?:0|[1-9]\\\\d*)(?:(?:\\\\.\\\\d+)?(?:[Ee][-+]?\\\\d+)?)?","name":"constant.numeric.json"},"object":{"begin":"\\\\{","beginCaptures":{"0":{"name":"punctuation.definition.dictionary.begin.json"}},"end":"}","endCaptures":{"0":{"name":"punctuation.definition.dictionary.end.json"}},"name":"meta.structure.dictionary.json","patterns":[{"include":"#objectkey"},{"include":"#comments"},{"begin":":","beginCaptures":{"0":{"name":"punctuation.separator.dictionary.key-value.json"}},"end":"(,)|(?=})","endCaptures":{"1":{"name":"punctuation.separator.dictionary.pair.json"}},"name":"meta.structure.dictionary.value.json","patterns":[{"include":"#value"},{"match":"[^,\\\\s]","name":"invalid.illegal.expected-dictionary-separator.json"}]},{"match":"[^}\\\\s]","name":"invalid.illegal.expected-dictionary-separator.json"}]},"objectkey":{"begin":"\\"","beginCaptures":{"0":{"name":"punctuation.support.type.property-name.begin.json"}},"end":"\\"","endCaptures":{"0":{"name":"punctuation.support.type.property-name.end.json"}},"name":"string.json support.type.property-name.json","patterns":[{"include":"#stringcontent"}]},"string":{"begin":"\\"","beginCaptures":{"0":{"name":"punctuation.definition.string.begin.json"}},"end":"\\"","endCaptures":{"0":{"name":"punctuation.definition.string.end.json"}},"name":"string.quoted.double.json","patterns":[{"include":"#stringcontent"}]},"stringcontent":{"patterns":[{"match":"\\\\\\\\(?:[\\"/\\\\\\\\bfnrt]|u\\\\h{4})","name":"constant.character.escape.json"},{"match":"\\\\\\\\.","name":"invalid.illegal.unrecognized-string-escape.json"}]},"value":{"patterns":[{"include":"#constant"},{"include":"#number"},{"include":"#string"},{"include":"#array"},{"include":"#object"},{"include":"#comments"}]}},"scopeName":"source.json"}')),
  g5 = [_d],
  $d = {};
function Cd(e, t) {
  const n = $d,
    r = typeof n.includeImageAlt == "boolean" ? n.includeImageAlt : !0,
    a = typeof n.includeHtml == "boolean" ? n.includeHtml : !0;
  return k0(e, r, a);
}
function k0(e, t, n) {
  if (Sd(e)) {
    if ("value" in e) return e.type === "html" && !n ? "" : e.value;
    if (t && "alt" in e && e.alt) return e.alt;
    if ("children" in e) return co(e.children, t, n);
  }
  return Array.isArray(e) ? co(e, t, n) : "";
}
function co(e, t, n) {
  const r = [];
  let a = -1;
  for (; ++a < e.length;) r[a] = k0(e[a], t, n);
  return r.join("");
}
function Sd(e) {
  return !!(e && typeof e == "object");
}
const mo = document.createElement("i");
function ns(e) {
  const t = "&" + e + ";";
  mo.innerHTML = t;
  const n = mo.textContent;
  return n.charCodeAt(n.length - 1) === 59 && e !== "semi" || n === t ? !1 : n;
}
function Je(e, t, n, r) {
  const a = e.length;
  let i = 0,
    s;
  if (t < 0 ? t = -t > a ? 0 : a + t : t = t > a ? a : t, n = n > 0 ? n : 0, r.length < 1e4) s = Array.from(r), s.unshift(t, n), e.splice(...s);else for (n && e.splice(t, n); i < r.length;) s = r.slice(i, i + 1e4), s.unshift(t, 0), e.splice(...s), i += 1e4, t += 1e4;
}
function st(e, t) {
  return e.length > 0 ? (Je(e, e.length, 0, t), e) : t;
}
const ho = {}.hasOwnProperty;
function _0(e) {
  const t = {};
  let n = -1;
  for (; ++n < e.length;) Ad(t, e[n]);
  return t;
}
function Ad(e, t) {
  let n;
  for (n in t) {
    const a = (ho.call(e, n) ? e[n] : void 0) || (e[n] = {}),
      i = t[n];
    let s;
    if (i) for (s in i) {
      ho.call(a, s) || (a[s] = []);
      const o = i[s];
      Td(a[s], Array.isArray(o) ? o : o ? [o] : []);
    }
  }
}
function Td(e, t) {
  let n = -1;
  const r = [];
  for (; ++n < t.length;) (t[n].add === "after" ? e : r).push(t[n]);
  Je(e, 0, 0, r);
}
function $0(e, t) {
  const n = Number.parseInt(e, t);
  return n < 9 || n === 11 || n > 13 && n < 32 || n > 126 && n < 160 || n > 55295 && n < 57344 || n > 64975 && n < 65008 || (n & 65535) === 65535 || (n & 65535) === 65534 || n > 1114111 ? "�" : String.fromCodePoint(n);
}
function ft(e) {
  return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
const Ge = Yt(/[A-Za-z]/),
  Fe = Yt(/[\dA-Za-z]/),
  Ed = Yt(/[#-'*+\--9=?A-Z^-~]/);
function Zr(e) {
  return e !== null && (e < 32 || e === 127);
}
const ki = Yt(/\d/),
  Md = Yt(/[\dA-Fa-f]/),
  zd = Yt(/[!-/:-@[-`{-~]/);
function X(e) {
  return e !== null && e < -2;
}
function fe(e) {
  return e !== null && (e < 0 || e === 32);
}
function oe(e) {
  return e === -2 || e === -1 || e === 32;
}
const or = Yt(/\p{P}|\p{S}/u),
  pn = Yt(/\s/);
function Yt(e) {
  return t;
  function t(n) {
    return n !== null && n > -1 && e.test(String.fromCharCode(n));
  }
}
function b5(e) {
  const t = [];
  let n = -1,
    r = 0,
    a = 0;
  for (; ++n < e.length;) {
    const i = e.charCodeAt(n);
    let s = "";
    if (i === 37 && Fe(e.charCodeAt(n + 1)) && Fe(e.charCodeAt(n + 2))) a = 2;else if (i < 128) /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(i)) || (s = String.fromCharCode(i));else if (i > 55295 && i < 57344) {
      const o = e.charCodeAt(n + 1);
      i < 56320 && o > 56319 && o < 57344 ? (s = String.fromCharCode(i, o), a = 1) : s = "�";
    } else s = String.fromCharCode(i);
    s && (t.push(e.slice(r, n), encodeURIComponent(s)), r = n + a + 1, s = ""), a && (n += a, a = 0);
  }
  return t.join("") + e.slice(r);
}
function ae(e, t, n, r) {
  const a = r ? r - 1 : Number.POSITIVE_INFINITY;
  let i = 0;
  return s;
  function s(l) {
    return oe(l) ? (e.enter(n), o(l)) : t(l);
  }
  function o(l) {
    return oe(l) && i++ < a ? (e.consume(l), o) : (e.exit(n), t(l));
  }
}
const Id = {
  tokenize: Nd
};
function Nd(e) {
  const t = e.attempt(this.parser.constructs.contentInitial, r, a);
  let n;
  return t;
  function r(o) {
    if (o === null) {
      e.consume(o);
      return;
    }
    return e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), ae(e, t, "linePrefix");
  }
  function a(o) {
    return e.enter("paragraph"), i(o);
  }
  function i(o) {
    const l = e.enter("chunkText", {
      contentType: "text",
      previous: n
    });
    return n && (n.next = l), n = l, s(o);
  }
  function s(o) {
    if (o === null) {
      e.exit("chunkText"), e.exit("paragraph"), e.consume(o);
      return;
    }
    return X(o) ? (e.consume(o), e.exit("chunkText"), i) : (e.consume(o), s);
  }
}
const Rd = {
    tokenize: Bd
  },
  po = {
    tokenize: Dd
  };
function Bd(e) {
  const t = this,
    n = [];
  let r = 0,
    a,
    i,
    s;
  return o;
  function o(T) {
    if (r < n.length) {
      const I = n[r];
      return t.containerState = I[1], e.attempt(I[0].continuation, l, u)(T);
    }
    return u(T);
  }
  function l(T) {
    if (r++, t.containerState._closeFlow) {
      t.containerState._closeFlow = void 0, a && _();
      const I = t.events.length;
      let R = I,
        E;
      for (; R--;) if (t.events[R][0] === "exit" && t.events[R][1].type === "chunkFlow") {
        E = t.events[R][1].end;
        break;
      }
      w(r);
      let O = I;
      for (; O < t.events.length;) t.events[O][1].end = {
        ...E
      }, O++;
      return Je(t.events, R + 1, 0, t.events.slice(I)), t.events.length = O, u(T);
    }
    return o(T);
  }
  function u(T) {
    if (r === n.length) {
      if (!a) return f(T);
      if (a.currentConstruct && a.currentConstruct.concrete) return b(T);
      t.interrupt = !!(a.currentConstruct && !a._gfmTableDynamicInterruptHack);
    }
    return t.containerState = {}, e.check(po, c, h)(T);
  }
  function c(T) {
    return a && _(), w(r), f(T);
  }
  function h(T) {
    return t.parser.lazy[t.now().line] = r !== n.length, s = t.now().offset, b(T);
  }
  function f(T) {
    return t.containerState = {}, e.attempt(po, d, b)(T);
  }
  function d(T) {
    return r++, n.push([t.currentConstruct, t.containerState]), f(T);
  }
  function b(T) {
    if (T === null) {
      a && _(), w(0), e.consume(T);
      return;
    }
    return a = a || t.parser.flow(t.now()), e.enter("chunkFlow", {
      _tokenizer: a,
      contentType: "flow",
      previous: i
    }), k(T);
  }
  function k(T) {
    if (T === null) {
      A(e.exit("chunkFlow"), !0), w(0), e.consume(T);
      return;
    }
    return X(T) ? (e.consume(T), A(e.exit("chunkFlow")), r = 0, t.interrupt = void 0, o) : (e.consume(T), k);
  }
  function A(T, I) {
    const R = t.sliceStream(T);
    if (I && R.push(null), T.previous = i, i && (i.next = T), i = T, a.defineSkip(T.start), a.write(R), t.parser.lazy[T.start.line]) {
      let E = a.events.length;
      for (; E--;) if (a.events[E][1].start.offset < s && (!a.events[E][1].end || a.events[E][1].end.offset > s)) return;
      const O = t.events.length;
      let W = O,
        G,
        M;
      for (; W--;) if (t.events[W][0] === "exit" && t.events[W][1].type === "chunkFlow") {
        if (G) {
          M = t.events[W][1].end;
          break;
        }
        G = !0;
      }
      for (w(r), E = O; E < t.events.length;) t.events[E][1].end = {
        ...M
      }, E++;
      Je(t.events, W + 1, 0, t.events.slice(O)), t.events.length = E;
    }
  }
  function w(T) {
    let I = n.length;
    for (; I-- > T;) {
      const R = n[I];
      t.containerState = R[1], R[0].exit.call(t, e);
    }
    n.length = T;
  }
  function _() {
    a.write([null]), i = void 0, a = void 0, t.containerState._closeFlow = void 0;
  }
}
function Dd(e, t, n) {
  return ae(e, e.attempt(this.parser.constructs.document, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
}
function Kr(e) {
  if (e === null || fe(e) || pn(e)) return 1;
  if (or(e)) return 2;
}
function ua(e, t, n) {
  const r = [];
  let a = -1;
  for (; ++a < e.length;) {
    const i = e[a].resolveAll;
    i && !r.includes(i) && (t = i(t, n), r.push(i));
  }
  return t;
}
const _i = {
  name: "attention",
  resolveAll: Ld,
  tokenize: Fd
};
function Ld(e, t) {
  let n = -1,
    r,
    a,
    i,
    s,
    o,
    l,
    u,
    c;
  for (; ++n < e.length;) if (e[n][0] === "enter" && e[n][1].type === "attentionSequence" && e[n][1]._close) {
    for (r = n; r--;) if (e[r][0] === "exit" && e[r][1].type === "attentionSequence" && e[r][1]._open && t.sliceSerialize(e[r][1]).charCodeAt(0) === t.sliceSerialize(e[n][1]).charCodeAt(0)) {
      if ((e[r][1]._close || e[n][1]._open) && (e[n][1].end.offset - e[n][1].start.offset) % 3 && !((e[r][1].end.offset - e[r][1].start.offset + e[n][1].end.offset - e[n][1].start.offset) % 3)) continue;
      l = e[r][1].end.offset - e[r][1].start.offset > 1 && e[n][1].end.offset - e[n][1].start.offset > 1 ? 2 : 1;
      const h = {
          ...e[r][1].end
        },
        f = {
          ...e[n][1].start
        };
      fo(h, -l), fo(f, l), s = {
        type: l > 1 ? "strongSequence" : "emphasisSequence",
        start: h,
        end: {
          ...e[r][1].end
        }
      }, o = {
        type: l > 1 ? "strongSequence" : "emphasisSequence",
        start: {
          ...e[n][1].start
        },
        end: f
      }, i = {
        type: l > 1 ? "strongText" : "emphasisText",
        start: {
          ...e[r][1].end
        },
        end: {
          ...e[n][1].start
        }
      }, a = {
        type: l > 1 ? "strong" : "emphasis",
        start: {
          ...s.start
        },
        end: {
          ...o.end
        }
      }, e[r][1].end = {
        ...s.start
      }, e[n][1].start = {
        ...o.end
      }, u = [], e[r][1].end.offset - e[r][1].start.offset && (u = st(u, [["enter", e[r][1], t], ["exit", e[r][1], t]])), u = st(u, [["enter", a, t], ["enter", s, t], ["exit", s, t], ["enter", i, t]]), u = st(u, ua(t.parser.constructs.insideSpan.null, e.slice(r + 1, n), t)), u = st(u, [["exit", i, t], ["enter", o, t], ["exit", o, t], ["exit", a, t]]), e[n][1].end.offset - e[n][1].start.offset ? (c = 2, u = st(u, [["enter", e[n][1], t], ["exit", e[n][1], t]])) : c = 0, Je(e, r - 1, n - r + 3, u), n = r + u.length - c - 2;
      break;
    }
  }
  for (n = -1; ++n < e.length;) e[n][1].type === "attentionSequence" && (e[n][1].type = "data");
  return e;
}
function Fd(e, t) {
  const n = this.parser.constructs.attentionMarkers.null,
    r = this.previous,
    a = Kr(r);
  let i;
  return s;
  function s(l) {
    return i = l, e.enter("attentionSequence"), o(l);
  }
  function o(l) {
    if (l === i) return e.consume(l), o;
    const u = e.exit("attentionSequence"),
      c = Kr(l),
      h = !c || c === 2 && a || n.includes(l),
      f = !a || a === 2 && c || n.includes(r);
    return u._open = !!(i === 42 ? h : h && (a || !f)), u._close = !!(i === 42 ? f : f && (c || !h)), t(l);
  }
}
function fo(e, t) {
  e.column += t, e.offset += t, e._bufferIndex += t;
}
const Pd = {
  name: "autolink",
  tokenize: Od
};
function Od(e, t, n) {
  let r = 0;
  return a;
  function a(d) {
    return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(d), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), i;
  }
  function i(d) {
    return Ge(d) ? (e.consume(d), s) : d === 64 ? n(d) : u(d);
  }
  function s(d) {
    return d === 43 || d === 45 || d === 46 || Fe(d) ? (r = 1, o(d)) : u(d);
  }
  function o(d) {
    return d === 58 ? (e.consume(d), r = 0, l) : (d === 43 || d === 45 || d === 46 || Fe(d)) && r++ < 32 ? (e.consume(d), o) : (r = 0, u(d));
  }
  function l(d) {
    return d === 62 ? (e.exit("autolinkProtocol"), e.enter("autolinkMarker"), e.consume(d), e.exit("autolinkMarker"), e.exit("autolink"), t) : d === null || d === 32 || d === 60 || Zr(d) ? n(d) : (e.consume(d), l);
  }
  function u(d) {
    return d === 64 ? (e.consume(d), c) : Ed(d) ? (e.consume(d), u) : n(d);
  }
  function c(d) {
    return Fe(d) ? h(d) : n(d);
  }
  function h(d) {
    return d === 46 ? (e.consume(d), r = 0, c) : d === 62 ? (e.exit("autolinkProtocol").type = "autolinkEmail", e.enter("autolinkMarker"), e.consume(d), e.exit("autolinkMarker"), e.exit("autolink"), t) : f(d);
  }
  function f(d) {
    if ((d === 45 || Fe(d)) && r++ < 63) {
      const b = d === 45 ? f : h;
      return e.consume(d), b;
    }
    return n(d);
  }
}
const lr = {
  partial: !0,
  tokenize: qd
};
function qd(e, t, n) {
  return r;
  function r(i) {
    return oe(i) ? ae(e, a, "linePrefix")(i) : a(i);
  }
  function a(i) {
    return i === null || X(i) ? t(i) : n(i);
  }
}
const C0 = {
  continuation: {
    tokenize: Gd
  },
  exit: Hd,
  name: "blockQuote",
  tokenize: jd
};
function jd(e, t, n) {
  const r = this;
  return a;
  function a(s) {
    if (s === 62) {
      const o = r.containerState;
      return o.open || (e.enter("blockQuote", {
        _container: !0
      }), o.open = !0), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(s), e.exit("blockQuoteMarker"), i;
    }
    return n(s);
  }
  function i(s) {
    return oe(s) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(s), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), t) : (e.exit("blockQuotePrefix"), t(s));
  }
}
function Gd(e, t, n) {
  const r = this;
  return a;
  function a(s) {
    return oe(s) ? ae(e, i, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(s) : i(s);
  }
  function i(s) {
    return e.attempt(C0, t, n)(s);
  }
}
function Hd(e) {
  e.exit("blockQuote");
}
const S0 = {
  name: "characterEscape",
  tokenize: Ud
};
function Ud(e, t, n) {
  return r;
  function r(i) {
    return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(i), e.exit("escapeMarker"), a;
  }
  function a(i) {
    return zd(i) ? (e.enter("characterEscapeValue"), e.consume(i), e.exit("characterEscapeValue"), e.exit("characterEscape"), t) : n(i);
  }
}
const A0 = {
  name: "characterReference",
  tokenize: Wd
};
function Wd(e, t, n) {
  const r = this;
  let a = 0,
    i,
    s;
  return o;
  function o(h) {
    return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(h), e.exit("characterReferenceMarker"), l;
  }
  function l(h) {
    return h === 35 ? (e.enter("characterReferenceMarkerNumeric"), e.consume(h), e.exit("characterReferenceMarkerNumeric"), u) : (e.enter("characterReferenceValue"), i = 31, s = Fe, c(h));
  }
  function u(h) {
    return h === 88 || h === 120 ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(h), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), i = 6, s = Md, c) : (e.enter("characterReferenceValue"), i = 7, s = ki, c(h));
  }
  function c(h) {
    if (h === 59 && a) {
      const f = e.exit("characterReferenceValue");
      return s === Fe && !ns(r.sliceSerialize(f)) ? n(h) : (e.enter("characterReferenceMarker"), e.consume(h), e.exit("characterReferenceMarker"), e.exit("characterReference"), t);
    }
    return s(h) && a++ < i ? (e.consume(h), c) : n(h);
  }
}
const go = {
    partial: !0,
    tokenize: Xd
  },
  bo = {
    concrete: !0,
    name: "codeFenced",
    tokenize: Vd
  };
function Vd(e, t, n) {
  const r = this,
    a = {
      partial: !0,
      tokenize: R
    };
  let i = 0,
    s = 0,
    o;
  return l;
  function l(E) {
    return u(E);
  }
  function u(E) {
    const O = r.events[r.events.length - 1];
    return i = O && O[1].type === "linePrefix" ? O[2].sliceSerialize(O[1], !0).length : 0, o = E, e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), c(E);
  }
  function c(E) {
    return E === o ? (s++, e.consume(E), c) : s < 3 ? n(E) : (e.exit("codeFencedFenceSequence"), oe(E) ? ae(e, h, "whitespace")(E) : h(E));
  }
  function h(E) {
    return E === null || X(E) ? (e.exit("codeFencedFence"), r.interrupt ? t(E) : e.check(go, k, I)(E)) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", {
      contentType: "string"
    }), f(E));
  }
  function f(E) {
    return E === null || X(E) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), h(E)) : oe(E) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), ae(e, d, "whitespace")(E)) : E === 96 && E === o ? n(E) : (e.consume(E), f);
  }
  function d(E) {
    return E === null || X(E) ? h(E) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", {
      contentType: "string"
    }), b(E));
  }
  function b(E) {
    return E === null || X(E) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), h(E)) : E === 96 && E === o ? n(E) : (e.consume(E), b);
  }
  function k(E) {
    return e.attempt(a, I, A)(E);
  }
  function A(E) {
    return e.enter("lineEnding"), e.consume(E), e.exit("lineEnding"), w;
  }
  function w(E) {
    return i > 0 && oe(E) ? ae(e, _, "linePrefix", i + 1)(E) : _(E);
  }
  function _(E) {
    return E === null || X(E) ? e.check(go, k, I)(E) : (e.enter("codeFlowValue"), T(E));
  }
  function T(E) {
    return E === null || X(E) ? (e.exit("codeFlowValue"), _(E)) : (e.consume(E), T);
  }
  function I(E) {
    return e.exit("codeFenced"), t(E);
  }
  function R(E, O, W) {
    let G = 0;
    return M;
    function M(Y) {
      return E.enter("lineEnding"), E.consume(Y), E.exit("lineEnding"), H;
    }
    function H(Y) {
      return E.enter("codeFencedFence"), oe(Y) ? ae(E, q, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(Y) : q(Y);
    }
    function q(Y) {
      return Y === o ? (E.enter("codeFencedFenceSequence"), ne(Y)) : W(Y);
    }
    function ne(Y) {
      return Y === o ? (G++, E.consume(Y), ne) : G >= s ? (E.exit("codeFencedFenceSequence"), oe(Y) ? ae(E, se, "whitespace")(Y) : se(Y)) : W(Y);
    }
    function se(Y) {
      return Y === null || X(Y) ? (E.exit("codeFencedFence"), O(Y)) : W(Y);
    }
  }
}
function Xd(e, t, n) {
  const r = this;
  return a;
  function a(s) {
    return s === null ? n(s) : (e.enter("lineEnding"), e.consume(s), e.exit("lineEnding"), i);
  }
  function i(s) {
    return r.parser.lazy[r.now().line] ? n(s) : t(s);
  }
}
const Fa = {
    name: "codeIndented",
    tokenize: Zd
  },
  Yd = {
    partial: !0,
    tokenize: Kd
  };
function Zd(e, t, n) {
  const r = this;
  return a;
  function a(u) {
    return e.enter("codeIndented"), ae(e, i, "linePrefix", 5)(u);
  }
  function i(u) {
    const c = r.events[r.events.length - 1];
    return c && c[1].type === "linePrefix" && c[2].sliceSerialize(c[1], !0).length >= 4 ? s(u) : n(u);
  }
  function s(u) {
    return u === null ? l(u) : X(u) ? e.attempt(Yd, s, l)(u) : (e.enter("codeFlowValue"), o(u));
  }
  function o(u) {
    return u === null || X(u) ? (e.exit("codeFlowValue"), s(u)) : (e.consume(u), o);
  }
  function l(u) {
    return e.exit("codeIndented"), t(u);
  }
}
function Kd(e, t, n) {
  const r = this;
  return a;
  function a(s) {
    return r.parser.lazy[r.now().line] ? n(s) : X(s) ? (e.enter("lineEnding"), e.consume(s), e.exit("lineEnding"), a) : ae(e, i, "linePrefix", 5)(s);
  }
  function i(s) {
    const o = r.events[r.events.length - 1];
    return o && o[1].type === "linePrefix" && o[2].sliceSerialize(o[1], !0).length >= 4 ? t(s) : X(s) ? a(s) : n(s);
  }
}
const Qd = {
  name: "codeText",
  previous: e1,
  resolve: Jd,
  tokenize: t1
};
function Jd(e) {
  let t = e.length - 4,
    n = 3,
    r,
    a;
  if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
    for (r = n; ++r < t;) if (e[r][1].type === "codeTextData") {
      e[n][1].type = "codeTextPadding", e[t][1].type = "codeTextPadding", n += 2, t -= 2;
      break;
    }
  }
  for (r = n - 1, t++; ++r <= t;) a === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (a = r) : (r === t || e[r][1].type === "lineEnding") && (e[a][1].type = "codeTextData", r !== a + 2 && (e[a][1].end = e[r - 1][1].end, e.splice(a + 2, r - a - 2), t -= r - a - 2, r = a + 2), a = void 0);
  return e;
}
function e1(e) {
  return e !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function t1(e, t, n) {
  let r = 0,
    a,
    i;
  return s;
  function s(h) {
    return e.enter("codeText"), e.enter("codeTextSequence"), o(h);
  }
  function o(h) {
    return h === 96 ? (e.consume(h), r++, o) : (e.exit("codeTextSequence"), l(h));
  }
  function l(h) {
    return h === null ? n(h) : h === 32 ? (e.enter("space"), e.consume(h), e.exit("space"), l) : h === 96 ? (i = e.enter("codeTextSequence"), a = 0, c(h)) : X(h) ? (e.enter("lineEnding"), e.consume(h), e.exit("lineEnding"), l) : (e.enter("codeTextData"), u(h));
  }
  function u(h) {
    return h === null || h === 32 || h === 96 || X(h) ? (e.exit("codeTextData"), l(h)) : (e.consume(h), u);
  }
  function c(h) {
    return h === 96 ? (e.consume(h), a++, c) : a === r ? (e.exit("codeTextSequence"), e.exit("codeText"), t(h)) : (i.type = "codeTextData", u(h));
  }
}
class n1 {
  constructor(t) {
    this.left = t ? [...t] : [], this.right = [];
  }
  get(t) {
    if (t < 0 || t >= this.left.length + this.right.length) throw new RangeError("Cannot access index `" + t + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
    return t < this.left.length ? this.left[t] : this.right[this.right.length - t + this.left.length - 1];
  }
  get length() {
    return this.left.length + this.right.length;
  }
  shift() {
    return this.setCursor(0), this.right.pop();
  }
  slice(t, n) {
    const r = n ?? Number.POSITIVE_INFINITY;
    return r < this.left.length ? this.left.slice(t, r) : t > this.left.length ? this.right.slice(this.right.length - r + this.left.length, this.right.length - t + this.left.length).reverse() : this.left.slice(t).concat(this.right.slice(this.right.length - r + this.left.length).reverse());
  }
  splice(t, n, r) {
    const a = n || 0;
    this.setCursor(Math.trunc(t));
    const i = this.right.splice(this.right.length - a, Number.POSITIVE_INFINITY);
    return r && qn(this.left, r), i.reverse();
  }
  pop() {
    return this.setCursor(Number.POSITIVE_INFINITY), this.left.pop();
  }
  push(t) {
    this.setCursor(Number.POSITIVE_INFINITY), this.left.push(t);
  }
  pushMany(t) {
    this.setCursor(Number.POSITIVE_INFINITY), qn(this.left, t);
  }
  unshift(t) {
    this.setCursor(0), this.right.push(t);
  }
  unshiftMany(t) {
    this.setCursor(0), qn(this.right, t.reverse());
  }
  setCursor(t) {
    if (!(t === this.left.length || t > this.left.length && this.right.length === 0 || t < 0 && this.left.length === 0)) if (t < this.left.length) {
      const n = this.left.splice(t, Number.POSITIVE_INFINITY);
      qn(this.right, n.reverse());
    } else {
      const n = this.right.splice(this.left.length + this.right.length - t, Number.POSITIVE_INFINITY);
      qn(this.left, n.reverse());
    }
  }
}
function qn(e, t) {
  let n = 0;
  if (t.length < 1e4) e.push(...t);else for (; n < t.length;) e.push(...t.slice(n, n + 1e4)), n += 1e4;
}
function T0(e) {
  const t = {};
  let n = -1,
    r,
    a,
    i,
    s,
    o,
    l,
    u;
  const c = new n1(e);
  for (; ++n < c.length;) {
    for (; n in t;) n = t[n];
    if (r = c.get(n), n && r[1].type === "chunkFlow" && c.get(n - 1)[1].type === "listItemPrefix" && (l = r[1]._tokenizer.events, i = 0, i < l.length && l[i][1].type === "lineEndingBlank" && (i += 2), i < l.length && l[i][1].type === "content")) for (; ++i < l.length && l[i][1].type !== "content";) l[i][1].type === "chunkText" && (l[i][1]._isInFirstContentOfListItem = !0, i++);
    if (r[0] === "enter") r[1].contentType && (Object.assign(t, r1(c, n)), n = t[n], u = !0);else if (r[1]._container) {
      for (i = n, a = void 0; i--;) if (s = c.get(i), s[1].type === "lineEnding" || s[1].type === "lineEndingBlank") s[0] === "enter" && (a && (c.get(a)[1].type = "lineEndingBlank"), s[1].type = "lineEnding", a = i);else if (!(s[1].type === "linePrefix" || s[1].type === "listItemIndent")) break;
      a && (r[1].end = {
        ...c.get(a)[1].start
      }, o = c.slice(a, n), o.unshift(r), c.splice(a, n - a + 1, o));
    }
  }
  return Je(e, 0, Number.POSITIVE_INFINITY, c.slice(0)), !u;
}
function r1(e, t) {
  const n = e.get(t)[1],
    r = e.get(t)[2];
  let a = t - 1;
  const i = [];
  let s = n._tokenizer;
  s || (s = r.parser[n.contentType](n.start), n._contentTypeTextTrailing && (s._contentTypeTextTrailing = !0));
  const o = s.events,
    l = [],
    u = {};
  let c,
    h,
    f = -1,
    d = n,
    b = 0,
    k = 0;
  const A = [k];
  for (; d;) {
    for (; e.get(++a)[1] !== d;);
    i.push(a), d._tokenizer || (c = r.sliceStream(d), d.next || c.push(null), h && s.defineSkip(d.start), d._isInFirstContentOfListItem && (s._gfmTasklistFirstContentOfListItem = !0), s.write(c), d._isInFirstContentOfListItem && (s._gfmTasklistFirstContentOfListItem = void 0)), h = d, d = d.next;
  }
  for (d = n; ++f < o.length;) o[f][0] === "exit" && o[f - 1][0] === "enter" && o[f][1].type === o[f - 1][1].type && o[f][1].start.line !== o[f][1].end.line && (k = f + 1, A.push(k), d._tokenizer = void 0, d.previous = void 0, d = d.next);
  for (s.events = [], d ? (d._tokenizer = void 0, d.previous = void 0) : A.pop(), f = A.length; f--;) {
    const w = o.slice(A[f], A[f + 1]),
      _ = i.pop();
    l.push([_, _ + w.length - 1]), e.splice(_, 2, w);
  }
  for (l.reverse(), f = -1; ++f < l.length;) u[b + l[f][0]] = b + l[f][1], b += l[f][1] - l[f][0] - 1;
  return u;
}
const a1 = {
    resolve: s1,
    tokenize: o1
  },
  i1 = {
    partial: !0,
    tokenize: l1
  };
function s1(e) {
  return T0(e), e;
}
function o1(e, t) {
  let n;
  return r;
  function r(o) {
    return e.enter("content"), n = e.enter("chunkContent", {
      contentType: "content"
    }), a(o);
  }
  function a(o) {
    return o === null ? i(o) : X(o) ? e.check(i1, s, i)(o) : (e.consume(o), a);
  }
  function i(o) {
    return e.exit("chunkContent"), e.exit("content"), t(o);
  }
  function s(o) {
    return e.consume(o), e.exit("chunkContent"), n.next = e.enter("chunkContent", {
      contentType: "content",
      previous: n
    }), n = n.next, a;
  }
}
function l1(e, t, n) {
  const r = this;
  return a;
  function a(s) {
    return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(s), e.exit("lineEnding"), ae(e, i, "linePrefix");
  }
  function i(s) {
    if (s === null || X(s)) return n(s);
    const o = r.events[r.events.length - 1];
    return !r.parser.constructs.disable.null.includes("codeIndented") && o && o[1].type === "linePrefix" && o[2].sliceSerialize(o[1], !0).length >= 4 ? t(s) : e.interrupt(r.parser.constructs.flow, n, t)(s);
  }
}
function E0(e, t, n, r, a, i, s, o, l) {
  const u = l || Number.POSITIVE_INFINITY;
  let c = 0;
  return h;
  function h(w) {
    return w === 60 ? (e.enter(r), e.enter(a), e.enter(i), e.consume(w), e.exit(i), f) : w === null || w === 32 || w === 41 || Zr(w) ? n(w) : (e.enter(r), e.enter(s), e.enter(o), e.enter("chunkString", {
      contentType: "string"
    }), k(w));
  }
  function f(w) {
    return w === 62 ? (e.enter(i), e.consume(w), e.exit(i), e.exit(a), e.exit(r), t) : (e.enter(o), e.enter("chunkString", {
      contentType: "string"
    }), d(w));
  }
  function d(w) {
    return w === 62 ? (e.exit("chunkString"), e.exit(o), f(w)) : w === null || w === 60 || X(w) ? n(w) : (e.consume(w), w === 92 ? b : d);
  }
  function b(w) {
    return w === 60 || w === 62 || w === 92 ? (e.consume(w), d) : d(w);
  }
  function k(w) {
    return !c && (w === null || w === 41 || fe(w)) ? (e.exit("chunkString"), e.exit(o), e.exit(s), e.exit(r), t(w)) : c < u && w === 40 ? (e.consume(w), c++, k) : w === 41 ? (e.consume(w), c--, k) : w === null || w === 32 || w === 40 || Zr(w) ? n(w) : (e.consume(w), w === 92 ? A : k);
  }
  function A(w) {
    return w === 40 || w === 41 || w === 92 ? (e.consume(w), k) : k(w);
  }
}
function M0(e, t, n, r, a, i) {
  const s = this;
  let o = 0,
    l;
  return u;
  function u(d) {
    return e.enter(r), e.enter(a), e.consume(d), e.exit(a), e.enter(i), c;
  }
  function c(d) {
    return o > 999 || d === null || d === 91 || d === 93 && !l || d === 94 && !o && "_hiddenFootnoteSupport" in s.parser.constructs ? n(d) : d === 93 ? (e.exit(i), e.enter(a), e.consume(d), e.exit(a), e.exit(r), t) : X(d) ? (e.enter("lineEnding"), e.consume(d), e.exit("lineEnding"), c) : (e.enter("chunkString", {
      contentType: "string"
    }), h(d));
  }
  function h(d) {
    return d === null || d === 91 || d === 93 || X(d) || o++ > 999 ? (e.exit("chunkString"), c(d)) : (e.consume(d), l || (l = !oe(d)), d === 92 ? f : h);
  }
  function f(d) {
    return d === 91 || d === 92 || d === 93 ? (e.consume(d), o++, h) : h(d);
  }
}
function z0(e, t, n, r, a, i) {
  let s;
  return o;
  function o(f) {
    return f === 34 || f === 39 || f === 40 ? (e.enter(r), e.enter(a), e.consume(f), e.exit(a), s = f === 40 ? 41 : f, l) : n(f);
  }
  function l(f) {
    return f === s ? (e.enter(a), e.consume(f), e.exit(a), e.exit(r), t) : (e.enter(i), u(f));
  }
  function u(f) {
    return f === s ? (e.exit(i), l(s)) : f === null ? n(f) : X(f) ? (e.enter("lineEnding"), e.consume(f), e.exit("lineEnding"), ae(e, u, "linePrefix")) : (e.enter("chunkString", {
      contentType: "string"
    }), c(f));
  }
  function c(f) {
    return f === s || f === null || X(f) ? (e.exit("chunkString"), u(f)) : (e.consume(f), f === 92 ? h : c);
  }
  function h(f) {
    return f === s || f === 92 ? (e.consume(f), c) : c(f);
  }
}
function Wn(e, t) {
  let n;
  return r;
  function r(a) {
    return X(a) ? (e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), n = !0, r) : oe(a) ? ae(e, r, n ? "linePrefix" : "lineSuffix")(a) : t(a);
  }
}
const u1 = {
    name: "definition",
    tokenize: m1
  },
  c1 = {
    partial: !0,
    tokenize: h1
  };
function m1(e, t, n) {
  const r = this;
  let a;
  return i;
  function i(d) {
    return e.enter("definition"), s(d);
  }
  function s(d) {
    return M0.call(r, e, o, n, "definitionLabel", "definitionLabelMarker", "definitionLabelString")(d);
  }
  function o(d) {
    return a = ft(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), d === 58 ? (e.enter("definitionMarker"), e.consume(d), e.exit("definitionMarker"), l) : n(d);
  }
  function l(d) {
    return fe(d) ? Wn(e, u)(d) : u(d);
  }
  function u(d) {
    return E0(e, c, n, "definitionDestination", "definitionDestinationLiteral", "definitionDestinationLiteralMarker", "definitionDestinationRaw", "definitionDestinationString")(d);
  }
  function c(d) {
    return e.attempt(c1, h, h)(d);
  }
  function h(d) {
    return oe(d) ? ae(e, f, "whitespace")(d) : f(d);
  }
  function f(d) {
    return d === null || X(d) ? (e.exit("definition"), r.parser.defined.push(a), t(d)) : n(d);
  }
}
function h1(e, t, n) {
  return r;
  function r(o) {
    return fe(o) ? Wn(e, a)(o) : n(o);
  }
  function a(o) {
    return z0(e, i, n, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(o);
  }
  function i(o) {
    return oe(o) ? ae(e, s, "whitespace")(o) : s(o);
  }
  function s(o) {
    return o === null || X(o) ? t(o) : n(o);
  }
}
const p1 = {
  name: "hardBreakEscape",
  tokenize: d1
};
function d1(e, t, n) {
  return r;
  function r(i) {
    return e.enter("hardBreakEscape"), e.consume(i), a;
  }
  function a(i) {
    return X(i) ? (e.exit("hardBreakEscape"), t(i)) : n(i);
  }
}
const f1 = {
  name: "headingAtx",
  resolve: g1,
  tokenize: b1
};
function g1(e, t) {
  let n = e.length - 2,
    r = 3,
    a,
    i;
  return e[r][1].type === "whitespace" && (r += 2), n - 2 > r && e[n][1].type === "whitespace" && (n -= 2), e[n][1].type === "atxHeadingSequence" && (r === n - 1 || n - 4 > r && e[n - 2][1].type === "whitespace") && (n -= r + 1 === n ? 2 : 4), n > r && (a = {
    type: "atxHeadingText",
    start: e[r][1].start,
    end: e[n][1].end
  }, i = {
    type: "chunkText",
    start: e[r][1].start,
    end: e[n][1].end,
    contentType: "text"
  }, Je(e, r, n - r + 1, [["enter", a, t], ["enter", i, t], ["exit", i, t], ["exit", a, t]])), e;
}
function b1(e, t, n) {
  let r = 0;
  return a;
  function a(c) {
    return e.enter("atxHeading"), i(c);
  }
  function i(c) {
    return e.enter("atxHeadingSequence"), s(c);
  }
  function s(c) {
    return c === 35 && r++ < 6 ? (e.consume(c), s) : c === null || fe(c) ? (e.exit("atxHeadingSequence"), o(c)) : n(c);
  }
  function o(c) {
    return c === 35 ? (e.enter("atxHeadingSequence"), l(c)) : c === null || X(c) ? (e.exit("atxHeading"), t(c)) : oe(c) ? ae(e, o, "whitespace")(c) : (e.enter("atxHeadingText"), u(c));
  }
  function l(c) {
    return c === 35 ? (e.consume(c), l) : (e.exit("atxHeadingSequence"), o(c));
  }
  function u(c) {
    return c === null || c === 35 || fe(c) ? (e.exit("atxHeadingText"), o(c)) : (e.consume(c), u);
  }
}
const y1 = ["address", "article", "aside", "base", "basefont", "blockquote", "body", "caption", "center", "col", "colgroup", "dd", "details", "dialog", "dir", "div", "dl", "dt", "fieldset", "figcaption", "figure", "footer", "form", "frame", "frameset", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hr", "html", "iframe", "legend", "li", "link", "main", "menu", "menuitem", "nav", "noframes", "ol", "optgroup", "option", "p", "param", "search", "section", "summary", "table", "tbody", "td", "tfoot", "th", "thead", "title", "tr", "track", "ul"],
  yo = ["pre", "script", "style", "textarea"],
  v1 = {
    concrete: !0,
    name: "htmlFlow",
    resolveTo: k1,
    tokenize: _1
  },
  w1 = {
    partial: !0,
    tokenize: C1
  },
  x1 = {
    partial: !0,
    tokenize: $1
  };
function k1(e) {
  let t = e.length;
  for (; t-- && !(e[t][0] === "enter" && e[t][1].type === "htmlFlow"););
  return t > 1 && e[t - 2][1].type === "linePrefix" && (e[t][1].start = e[t - 2][1].start, e[t + 1][1].start = e[t - 2][1].start, e.splice(t - 2, 2)), e;
}
function _1(e, t, n) {
  const r = this;
  let a, i, s, o, l;
  return u;
  function u(C) {
    return c(C);
  }
  function c(C) {
    return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(C), h;
  }
  function h(C) {
    return C === 33 ? (e.consume(C), f) : C === 47 ? (e.consume(C), i = !0, k) : C === 63 ? (e.consume(C), a = 3, r.interrupt ? t : $) : Ge(C) ? (e.consume(C), s = String.fromCharCode(C), A) : n(C);
  }
  function f(C) {
    return C === 45 ? (e.consume(C), a = 2, d) : C === 91 ? (e.consume(C), a = 5, o = 0, b) : Ge(C) ? (e.consume(C), a = 4, r.interrupt ? t : $) : n(C);
  }
  function d(C) {
    return C === 45 ? (e.consume(C), r.interrupt ? t : $) : n(C);
  }
  function b(C) {
    const Be = "CDATA[";
    return C === Be.charCodeAt(o++) ? (e.consume(C), o === Be.length ? r.interrupt ? t : q : b) : n(C);
  }
  function k(C) {
    return Ge(C) ? (e.consume(C), s = String.fromCharCode(C), A) : n(C);
  }
  function A(C) {
    if (C === null || C === 47 || C === 62 || fe(C)) {
      const Be = C === 47,
        gt = s.toLowerCase();
      return !Be && !i && yo.includes(gt) ? (a = 1, r.interrupt ? t(C) : q(C)) : y1.includes(s.toLowerCase()) ? (a = 6, Be ? (e.consume(C), w) : r.interrupt ? t(C) : q(C)) : (a = 7, r.interrupt && !r.parser.lazy[r.now().line] ? n(C) : i ? _(C) : T(C));
    }
    return C === 45 || Fe(C) ? (e.consume(C), s += String.fromCharCode(C), A) : n(C);
  }
  function w(C) {
    return C === 62 ? (e.consume(C), r.interrupt ? t : q) : n(C);
  }
  function _(C) {
    return oe(C) ? (e.consume(C), _) : M(C);
  }
  function T(C) {
    return C === 47 ? (e.consume(C), M) : C === 58 || C === 95 || Ge(C) ? (e.consume(C), I) : oe(C) ? (e.consume(C), T) : M(C);
  }
  function I(C) {
    return C === 45 || C === 46 || C === 58 || C === 95 || Fe(C) ? (e.consume(C), I) : R(C);
  }
  function R(C) {
    return C === 61 ? (e.consume(C), E) : oe(C) ? (e.consume(C), R) : T(C);
  }
  function E(C) {
    return C === null || C === 60 || C === 61 || C === 62 || C === 96 ? n(C) : C === 34 || C === 39 ? (e.consume(C), l = C, O) : oe(C) ? (e.consume(C), E) : W(C);
  }
  function O(C) {
    return C === l ? (e.consume(C), l = null, G) : C === null || X(C) ? n(C) : (e.consume(C), O);
  }
  function W(C) {
    return C === null || C === 34 || C === 39 || C === 47 || C === 60 || C === 61 || C === 62 || C === 96 || fe(C) ? R(C) : (e.consume(C), W);
  }
  function G(C) {
    return C === 47 || C === 62 || oe(C) ? T(C) : n(C);
  }
  function M(C) {
    return C === 62 ? (e.consume(C), H) : n(C);
  }
  function H(C) {
    return C === null || X(C) ? q(C) : oe(C) ? (e.consume(C), H) : n(C);
  }
  function q(C) {
    return C === 45 && a === 2 ? (e.consume(C), le) : C === 60 && a === 1 ? (e.consume(C), me) : C === 62 && a === 4 ? (e.consume(C), _e) : C === 63 && a === 3 ? (e.consume(C), $) : C === 93 && a === 5 ? (e.consume(C), Ye) : X(C) && (a === 6 || a === 7) ? (e.exit("htmlFlowData"), e.check(w1, Oe, ne)(C)) : C === null || X(C) ? (e.exit("htmlFlowData"), ne(C)) : (e.consume(C), q);
  }
  function ne(C) {
    return e.check(x1, se, Oe)(C);
  }
  function se(C) {
    return e.enter("lineEnding"), e.consume(C), e.exit("lineEnding"), Y;
  }
  function Y(C) {
    return C === null || X(C) ? ne(C) : (e.enter("htmlFlowData"), q(C));
  }
  function le(C) {
    return C === 45 ? (e.consume(C), $) : q(C);
  }
  function me(C) {
    return C === 47 ? (e.consume(C), s = "", Ne) : q(C);
  }
  function Ne(C) {
    if (C === 62) {
      const Be = s.toLowerCase();
      return yo.includes(Be) ? (e.consume(C), _e) : q(C);
    }
    return Ge(C) && s.length < 8 ? (e.consume(C), s += String.fromCharCode(C), Ne) : q(C);
  }
  function Ye(C) {
    return C === 93 ? (e.consume(C), $) : q(C);
  }
  function $(C) {
    return C === 62 ? (e.consume(C), _e) : C === 45 && a === 2 ? (e.consume(C), $) : q(C);
  }
  function _e(C) {
    return C === null || X(C) ? (e.exit("htmlFlowData"), Oe(C)) : (e.consume(C), _e);
  }
  function Oe(C) {
    return e.exit("htmlFlow"), t(C);
  }
}
function $1(e, t, n) {
  const r = this;
  return a;
  function a(s) {
    return X(s) ? (e.enter("lineEnding"), e.consume(s), e.exit("lineEnding"), i) : n(s);
  }
  function i(s) {
    return r.parser.lazy[r.now().line] ? n(s) : t(s);
  }
}
function C1(e, t, n) {
  return r;
  function r(a) {
    return e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), e.attempt(lr, t, n);
  }
}
const S1 = {
  name: "htmlText",
  tokenize: A1
};
function A1(e, t, n) {
  const r = this;
  let a, i, s;
  return o;
  function o($) {
    return e.enter("htmlText"), e.enter("htmlTextData"), e.consume($), l;
  }
  function l($) {
    return $ === 33 ? (e.consume($), u) : $ === 47 ? (e.consume($), R) : $ === 63 ? (e.consume($), T) : Ge($) ? (e.consume($), W) : n($);
  }
  function u($) {
    return $ === 45 ? (e.consume($), c) : $ === 91 ? (e.consume($), i = 0, b) : Ge($) ? (e.consume($), _) : n($);
  }
  function c($) {
    return $ === 45 ? (e.consume($), d) : n($);
  }
  function h($) {
    return $ === null ? n($) : $ === 45 ? (e.consume($), f) : X($) ? (s = h, me($)) : (e.consume($), h);
  }
  function f($) {
    return $ === 45 ? (e.consume($), d) : h($);
  }
  function d($) {
    return $ === 62 ? le($) : $ === 45 ? f($) : h($);
  }
  function b($) {
    const _e = "CDATA[";
    return $ === _e.charCodeAt(i++) ? (e.consume($), i === _e.length ? k : b) : n($);
  }
  function k($) {
    return $ === null ? n($) : $ === 93 ? (e.consume($), A) : X($) ? (s = k, me($)) : (e.consume($), k);
  }
  function A($) {
    return $ === 93 ? (e.consume($), w) : k($);
  }
  function w($) {
    return $ === 62 ? le($) : $ === 93 ? (e.consume($), w) : k($);
  }
  function _($) {
    return $ === null || $ === 62 ? le($) : X($) ? (s = _, me($)) : (e.consume($), _);
  }
  function T($) {
    return $ === null ? n($) : $ === 63 ? (e.consume($), I) : X($) ? (s = T, me($)) : (e.consume($), T);
  }
  function I($) {
    return $ === 62 ? le($) : T($);
  }
  function R($) {
    return Ge($) ? (e.consume($), E) : n($);
  }
  function E($) {
    return $ === 45 || Fe($) ? (e.consume($), E) : O($);
  }
  function O($) {
    return X($) ? (s = O, me($)) : oe($) ? (e.consume($), O) : le($);
  }
  function W($) {
    return $ === 45 || Fe($) ? (e.consume($), W) : $ === 47 || $ === 62 || fe($) ? G($) : n($);
  }
  function G($) {
    return $ === 47 ? (e.consume($), le) : $ === 58 || $ === 95 || Ge($) ? (e.consume($), M) : X($) ? (s = G, me($)) : oe($) ? (e.consume($), G) : le($);
  }
  function M($) {
    return $ === 45 || $ === 46 || $ === 58 || $ === 95 || Fe($) ? (e.consume($), M) : H($);
  }
  function H($) {
    return $ === 61 ? (e.consume($), q) : X($) ? (s = H, me($)) : oe($) ? (e.consume($), H) : G($);
  }
  function q($) {
    return $ === null || $ === 60 || $ === 61 || $ === 62 || $ === 96 ? n($) : $ === 34 || $ === 39 ? (e.consume($), a = $, ne) : X($) ? (s = q, me($)) : oe($) ? (e.consume($), q) : (e.consume($), se);
  }
  function ne($) {
    return $ === a ? (e.consume($), a = void 0, Y) : $ === null ? n($) : X($) ? (s = ne, me($)) : (e.consume($), ne);
  }
  function se($) {
    return $ === null || $ === 34 || $ === 39 || $ === 60 || $ === 61 || $ === 96 ? n($) : $ === 47 || $ === 62 || fe($) ? G($) : (e.consume($), se);
  }
  function Y($) {
    return $ === 47 || $ === 62 || fe($) ? G($) : n($);
  }
  function le($) {
    return $ === 62 ? (e.consume($), e.exit("htmlTextData"), e.exit("htmlText"), t) : n($);
  }
  function me($) {
    return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume($), e.exit("lineEnding"), Ne;
  }
  function Ne($) {
    return oe($) ? ae(e, Ye, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)($) : Ye($);
  }
  function Ye($) {
    return e.enter("htmlTextData"), s($);
  }
}
const rs = {
    name: "labelEnd",
    resolveAll: z1,
    resolveTo: I1,
    tokenize: N1
  },
  T1 = {
    tokenize: R1
  },
  E1 = {
    tokenize: B1
  },
  M1 = {
    tokenize: D1
  };
function z1(e) {
  let t = -1;
  const n = [];
  for (; ++t < e.length;) {
    const r = e[t][1];
    if (n.push(e[t]), r.type === "labelImage" || r.type === "labelLink" || r.type === "labelEnd") {
      const a = r.type === "labelImage" ? 4 : 2;
      r.type = "data", t += a;
    }
  }
  return e.length !== n.length && Je(e, 0, e.length, n), e;
}
function I1(e, t) {
  let n = e.length,
    r = 0,
    a,
    i,
    s,
    o;
  for (; n--;) if (a = e[n][1], i) {
    if (a.type === "link" || a.type === "labelLink" && a._inactive) break;
    e[n][0] === "enter" && a.type === "labelLink" && (a._inactive = !0);
  } else if (s) {
    if (e[n][0] === "enter" && (a.type === "labelImage" || a.type === "labelLink") && !a._balanced && (i = n, a.type !== "labelLink")) {
      r = 2;
      break;
    }
  } else a.type === "labelEnd" && (s = n);
  const l = {
      type: e[i][1].type === "labelLink" ? "link" : "image",
      start: {
        ...e[i][1].start
      },
      end: {
        ...e[e.length - 1][1].end
      }
    },
    u = {
      type: "label",
      start: {
        ...e[i][1].start
      },
      end: {
        ...e[s][1].end
      }
    },
    c = {
      type: "labelText",
      start: {
        ...e[i + r + 2][1].end
      },
      end: {
        ...e[s - 2][1].start
      }
    };
  return o = [["enter", l, t], ["enter", u, t]], o = st(o, e.slice(i + 1, i + r + 3)), o = st(o, [["enter", c, t]]), o = st(o, ua(t.parser.constructs.insideSpan.null, e.slice(i + r + 4, s - 3), t)), o = st(o, [["exit", c, t], e[s - 2], e[s - 1], ["exit", u, t]]), o = st(o, e.slice(s + 1)), o = st(o, [["exit", l, t]]), Je(e, i, e.length, o), e;
}
function N1(e, t, n) {
  const r = this;
  let a = r.events.length,
    i,
    s;
  for (; a--;) if ((r.events[a][1].type === "labelImage" || r.events[a][1].type === "labelLink") && !r.events[a][1]._balanced) {
    i = r.events[a][1];
    break;
  }
  return o;
  function o(f) {
    return i ? i._inactive ? h(f) : (s = r.parser.defined.includes(ft(r.sliceSerialize({
      start: i.end,
      end: r.now()
    }))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(f), e.exit("labelMarker"), e.exit("labelEnd"), l) : n(f);
  }
  function l(f) {
    return f === 40 ? e.attempt(T1, c, s ? c : h)(f) : f === 91 ? e.attempt(E1, c, s ? u : h)(f) : s ? c(f) : h(f);
  }
  function u(f) {
    return e.attempt(M1, c, h)(f);
  }
  function c(f) {
    return t(f);
  }
  function h(f) {
    return i._balanced = !0, n(f);
  }
}
function R1(e, t, n) {
  return r;
  function r(h) {
    return e.enter("resource"), e.enter("resourceMarker"), e.consume(h), e.exit("resourceMarker"), a;
  }
  function a(h) {
    return fe(h) ? Wn(e, i)(h) : i(h);
  }
  function i(h) {
    return h === 41 ? c(h) : E0(e, s, o, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(h);
  }
  function s(h) {
    return fe(h) ? Wn(e, l)(h) : c(h);
  }
  function o(h) {
    return n(h);
  }
  function l(h) {
    return h === 34 || h === 39 || h === 40 ? z0(e, u, n, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(h) : c(h);
  }
  function u(h) {
    return fe(h) ? Wn(e, c)(h) : c(h);
  }
  function c(h) {
    return h === 41 ? (e.enter("resourceMarker"), e.consume(h), e.exit("resourceMarker"), e.exit("resource"), t) : n(h);
  }
}
function B1(e, t, n) {
  const r = this;
  return a;
  function a(o) {
    return M0.call(r, e, i, s, "reference", "referenceMarker", "referenceString")(o);
  }
  function i(o) {
    return r.parser.defined.includes(ft(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? t(o) : n(o);
  }
  function s(o) {
    return n(o);
  }
}
function D1(e, t, n) {
  return r;
  function r(i) {
    return e.enter("reference"), e.enter("referenceMarker"), e.consume(i), e.exit("referenceMarker"), a;
  }
  function a(i) {
    return i === 93 ? (e.enter("referenceMarker"), e.consume(i), e.exit("referenceMarker"), e.exit("reference"), t) : n(i);
  }
}
const L1 = {
  name: "labelStartImage",
  resolveAll: rs.resolveAll,
  tokenize: F1
};
function F1(e, t, n) {
  const r = this;
  return a;
  function a(o) {
    return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(o), e.exit("labelImageMarker"), i;
  }
  function i(o) {
    return o === 91 ? (e.enter("labelMarker"), e.consume(o), e.exit("labelMarker"), e.exit("labelImage"), s) : n(o);
  }
  function s(o) {
    return o === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(o) : t(o);
  }
}
const P1 = {
  name: "labelStartLink",
  resolveAll: rs.resolveAll,
  tokenize: O1
};
function O1(e, t, n) {
  const r = this;
  return a;
  function a(s) {
    return e.enter("labelLink"), e.enter("labelMarker"), e.consume(s), e.exit("labelMarker"), e.exit("labelLink"), i;
  }
  function i(s) {
    return s === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(s) : t(s);
  }
}
const Pa = {
  name: "lineEnding",
  tokenize: q1
};
function q1(e, t) {
  return n;
  function n(r) {
    return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), ae(e, t, "linePrefix");
  }
}
const Rr = {
  name: "thematicBreak",
  tokenize: j1
};
function j1(e, t, n) {
  let r = 0,
    a;
  return i;
  function i(u) {
    return e.enter("thematicBreak"), s(u);
  }
  function s(u) {
    return a = u, o(u);
  }
  function o(u) {
    return u === a ? (e.enter("thematicBreakSequence"), l(u)) : r >= 3 && (u === null || X(u)) ? (e.exit("thematicBreak"), t(u)) : n(u);
  }
  function l(u) {
    return u === a ? (e.consume(u), r++, l) : (e.exit("thematicBreakSequence"), oe(u) ? ae(e, o, "whitespace")(u) : o(u));
  }
}
const We = {
    continuation: {
      tokenize: W1
    },
    exit: X1,
    name: "list",
    tokenize: U1
  },
  G1 = {
    partial: !0,
    tokenize: Y1
  },
  H1 = {
    partial: !0,
    tokenize: V1
  };
function U1(e, t, n) {
  const r = this,
    a = r.events[r.events.length - 1];
  let i = a && a[1].type === "linePrefix" ? a[2].sliceSerialize(a[1], !0).length : 0,
    s = 0;
  return o;
  function o(d) {
    const b = r.containerState.type || (d === 42 || d === 43 || d === 45 ? "listUnordered" : "listOrdered");
    if (b === "listUnordered" ? !r.containerState.marker || d === r.containerState.marker : ki(d)) {
      if (r.containerState.type || (r.containerState.type = b, e.enter(b, {
        _container: !0
      })), b === "listUnordered") return e.enter("listItemPrefix"), d === 42 || d === 45 ? e.check(Rr, n, u)(d) : u(d);
      if (!r.interrupt || d === 49) return e.enter("listItemPrefix"), e.enter("listItemValue"), l(d);
    }
    return n(d);
  }
  function l(d) {
    return ki(d) && ++s < 10 ? (e.consume(d), l) : (!r.interrupt || s < 2) && (r.containerState.marker ? d === r.containerState.marker : d === 41 || d === 46) ? (e.exit("listItemValue"), u(d)) : n(d);
  }
  function u(d) {
    return e.enter("listItemMarker"), e.consume(d), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || d, e.check(lr, r.interrupt ? n : c, e.attempt(G1, f, h));
  }
  function c(d) {
    return r.containerState.initialBlankLine = !0, i++, f(d);
  }
  function h(d) {
    return oe(d) ? (e.enter("listItemPrefixWhitespace"), e.consume(d), e.exit("listItemPrefixWhitespace"), f) : n(d);
  }
  function f(d) {
    return r.containerState.size = i + r.sliceSerialize(e.exit("listItemPrefix"), !0).length, t(d);
  }
}
function W1(e, t, n) {
  const r = this;
  return r.containerState._closeFlow = void 0, e.check(lr, a, i);
  function a(o) {
    return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, ae(e, t, "listItemIndent", r.containerState.size + 1)(o);
  }
  function i(o) {
    return r.containerState.furtherBlankLines || !oe(o) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, s(o)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(H1, t, s)(o));
  }
  function s(o) {
    return r.containerState._closeFlow = !0, r.interrupt = void 0, ae(e, e.attempt(We, t, n), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(o);
  }
}
function V1(e, t, n) {
  const r = this;
  return ae(e, a, "listItemIndent", r.containerState.size + 1);
  function a(i) {
    const s = r.events[r.events.length - 1];
    return s && s[1].type === "listItemIndent" && s[2].sliceSerialize(s[1], !0).length === r.containerState.size ? t(i) : n(i);
  }
}
function X1(e) {
  e.exit(this.containerState.type);
}
function Y1(e, t, n) {
  const r = this;
  return ae(e, a, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);
  function a(i) {
    const s = r.events[r.events.length - 1];
    return !oe(i) && s && s[1].type === "listItemPrefixWhitespace" ? t(i) : n(i);
  }
}
const vo = {
  name: "setextUnderline",
  resolveTo: Z1,
  tokenize: K1
};
function Z1(e, t) {
  let n = e.length,
    r,
    a,
    i;
  for (; n--;) if (e[n][0] === "enter") {
    if (e[n][1].type === "content") {
      r = n;
      break;
    }
    e[n][1].type === "paragraph" && (a = n);
  } else e[n][1].type === "content" && e.splice(n, 1), !i && e[n][1].type === "definition" && (i = n);
  const s = {
    type: "setextHeading",
    start: {
      ...e[r][1].start
    },
    end: {
      ...e[e.length - 1][1].end
    }
  };
  return e[a][1].type = "setextHeadingText", i ? (e.splice(a, 0, ["enter", s, t]), e.splice(i + 1, 0, ["exit", e[r][1], t]), e[r][1].end = {
    ...e[i][1].end
  }) : e[r][1] = s, e.push(["exit", s, t]), e;
}
function K1(e, t, n) {
  const r = this;
  let a;
  return i;
  function i(u) {
    let c = r.events.length,
      h;
    for (; c--;) if (r.events[c][1].type !== "lineEnding" && r.events[c][1].type !== "linePrefix" && r.events[c][1].type !== "content") {
      h = r.events[c][1].type === "paragraph";
      break;
    }
    return !r.parser.lazy[r.now().line] && (r.interrupt || h) ? (e.enter("setextHeadingLine"), a = u, s(u)) : n(u);
  }
  function s(u) {
    return e.enter("setextHeadingLineSequence"), o(u);
  }
  function o(u) {
    return u === a ? (e.consume(u), o) : (e.exit("setextHeadingLineSequence"), oe(u) ? ae(e, l, "lineSuffix")(u) : l(u));
  }
  function l(u) {
    return u === null || X(u) ? (e.exit("setextHeadingLine"), t(u)) : n(u);
  }
}
const Q1 = {
  tokenize: J1
};
function J1(e) {
  const t = this,
    n = e.attempt(lr, r, e.attempt(this.parser.constructs.flowInitial, a, ae(e, e.attempt(this.parser.constructs.flow, a, e.attempt(a1, a)), "linePrefix")));
  return n;
  function r(i) {
    if (i === null) {
      e.consume(i);
      return;
    }
    return e.enter("lineEndingBlank"), e.consume(i), e.exit("lineEndingBlank"), t.currentConstruct = void 0, n;
  }
  function a(i) {
    if (i === null) {
      e.consume(i);
      return;
    }
    return e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), t.currentConstruct = void 0, n;
  }
}
const ef = {
    resolveAll: N0()
  },
  tf = I0("string"),
  nf = I0("text");
function I0(e) {
  return {
    resolveAll: N0(e === "text" ? rf : void 0),
    tokenize: t
  };
  function t(n) {
    const r = this,
      a = this.parser.constructs[e],
      i = n.attempt(a, s, o);
    return s;
    function s(c) {
      return u(c) ? i(c) : o(c);
    }
    function o(c) {
      if (c === null) {
        n.consume(c);
        return;
      }
      return n.enter("data"), n.consume(c), l;
    }
    function l(c) {
      return u(c) ? (n.exit("data"), i(c)) : (n.consume(c), l);
    }
    function u(c) {
      if (c === null) return !0;
      const h = a[c];
      let f = -1;
      if (h) for (; ++f < h.length;) {
        const d = h[f];
        if (!d.previous || d.previous.call(r, r.previous)) return !0;
      }
      return !1;
    }
  }
}
function N0(e) {
  return t;
  function t(n, r) {
    let a = -1,
      i;
    for (; ++a <= n.length;) i === void 0 ? n[a] && n[a][1].type === "data" && (i = a, a++) : (!n[a] || n[a][1].type !== "data") && (a !== i + 2 && (n[i][1].end = n[a - 1][1].end, n.splice(i + 2, a - i - 2), a = i + 2), i = void 0);
    return e ? e(n, r) : n;
  }
}
function rf(e, t) {
  let n = 0;
  for (; ++n <= e.length;) if ((n === e.length || e[n][1].type === "lineEnding") && e[n - 1][1].type === "data") {
    const r = e[n - 1][1],
      a = t.sliceStream(r);
    let i = a.length,
      s = -1,
      o = 0,
      l;
    for (; i--;) {
      const u = a[i];
      if (typeof u == "string") {
        for (s = u.length; u.charCodeAt(s - 1) === 32;) o++, s--;
        if (s) break;
        s = -1;
      } else if (u === -2) l = !0, o++;else if (u !== -1) {
        i++;
        break;
      }
    }
    if (t._contentTypeTextTrailing && n === e.length && (o = 0), o) {
      const u = {
        type: n === e.length || l || o < 2 ? "lineSuffix" : "hardBreakTrailing",
        start: {
          _bufferIndex: i ? s : r.start._bufferIndex + s,
          _index: r.start._index + i,
          line: r.end.line,
          column: r.end.column - o,
          offset: r.end.offset - o
        },
        end: {
          ...r.end
        }
      };
      r.end = {
        ...u.start
      }, r.start.offset === r.end.offset ? Object.assign(r, u) : (e.splice(n, 0, ["enter", u, t], ["exit", u, t]), n += 2);
    }
    n++;
  }
  return e;
}
const af = {
    42: We,
    43: We,
    45: We,
    48: We,
    49: We,
    50: We,
    51: We,
    52: We,
    53: We,
    54: We,
    55: We,
    56: We,
    57: We,
    62: C0
  },
  sf = {
    91: u1
  },
  of = {
    [-2]: Fa,
    [-1]: Fa,
    32: Fa
  },
  lf = {
    35: f1,
    42: Rr,
    45: [vo, Rr],
    60: v1,
    61: vo,
    95: Rr,
    96: bo,
    126: bo
  },
  uf = {
    38: A0,
    92: S0
  },
  cf = {
    [-5]: Pa,
    [-4]: Pa,
    [-3]: Pa,
    33: L1,
    38: A0,
    42: _i,
    60: [Pd, S1],
    91: P1,
    92: [p1, S0],
    93: rs,
    95: _i,
    96: Qd
  },
  mf = {
    null: [_i, ef]
  },
  hf = {
    null: [42, 95]
  },
  pf = {
    null: []
  },
  df = Object.freeze(Object.defineProperty({
    __proto__: null,
    attentionMarkers: hf,
    contentInitial: sf,
    disable: pf,
    document: af,
    flow: lf,
    flowInitial: of,
    insideSpan: mf,
    string: uf,
    text: cf
  }, Symbol.toStringTag, {
    value: "Module"
  }));
function ff(e, t, n) {
  let r = {
    _bufferIndex: -1,
    _index: 0,
    line: n && n.line || 1,
    column: n && n.column || 1,
    offset: n && n.offset || 0
  };
  const a = {},
    i = [];
  let s = [],
    o = [];
  const l = {
      attempt: O(R),
      check: O(E),
      consume: _,
      enter: T,
      exit: I,
      interrupt: O(E, {
        interrupt: !0
      })
    },
    u = {
      code: null,
      containerState: {},
      defineSkip: k,
      events: [],
      now: b,
      parser: e,
      previous: null,
      sliceSerialize: f,
      sliceStream: d,
      write: h
    };
  let c = t.tokenize.call(u, l);
  return t.resolveAll && i.push(t), u;
  function h(H) {
    return s = st(s, H), A(), s[s.length - 1] !== null ? [] : (W(t, 0), u.events = ua(i, u.events, u), u.events);
  }
  function f(H, q) {
    return bf(d(H), q);
  }
  function d(H) {
    return gf(s, H);
  }
  function b() {
    const {
      _bufferIndex: H,
      _index: q,
      line: ne,
      column: se,
      offset: Y
    } = r;
    return {
      _bufferIndex: H,
      _index: q,
      line: ne,
      column: se,
      offset: Y
    };
  }
  function k(H) {
    a[H.line] = H.column, M();
  }
  function A() {
    let H;
    for (; r._index < s.length;) {
      const q = s[r._index];
      if (typeof q == "string") for (H = r._index, r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === H && r._bufferIndex < q.length;) w(q.charCodeAt(r._bufferIndex));else w(q);
    }
  }
  function w(H) {
    c = c(H);
  }
  function _(H) {
    X(H) ? (r.line++, r.column = 1, r.offset += H === -3 ? 2 : 1, M()) : H !== -1 && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === s[r._index].length && (r._bufferIndex = -1, r._index++)), u.previous = H;
  }
  function T(H, q) {
    const ne = q || {};
    return ne.type = H, ne.start = b(), u.events.push(["enter", ne, u]), o.push(ne), ne;
  }
  function I(H) {
    const q = o.pop();
    return q.end = b(), u.events.push(["exit", q, u]), q;
  }
  function R(H, q) {
    W(H, q.from);
  }
  function E(H, q) {
    q.restore();
  }
  function O(H, q) {
    return ne;
    function ne(se, Y, le) {
      let me, Ne, Ye, $;
      return Array.isArray(se) ? Oe(se) : "tokenize" in se ? Oe([se]) : _e(se);
      function _e(Te) {
        return at;
        function at(mt) {
          const Ze = mt !== null && Te[mt],
            $t = mt !== null && Te.null,
            Kt = [...(Array.isArray(Ze) ? Ze : Ze ? [Ze] : []), ...(Array.isArray($t) ? $t : $t ? [$t] : [])];
          return Oe(Kt)(mt);
        }
      }
      function Oe(Te) {
        return me = Te, Ne = 0, Te.length === 0 ? le : C(Te[Ne]);
      }
      function C(Te) {
        return at;
        function at(mt) {
          return $ = G(), Ye = Te, Te.partial || (u.currentConstruct = Te), Te.name && u.parser.constructs.disable.null.includes(Te.name) ? gt() : Te.tokenize.call(q ? Object.assign(Object.create(u), q) : u, l, Be, gt)(mt);
        }
      }
      function Be(Te) {
        return H(Ye, $), Y;
      }
      function gt(Te) {
        return $.restore(), ++Ne < me.length ? C(me[Ne]) : le;
      }
    }
  }
  function W(H, q) {
    H.resolveAll && !i.includes(H) && i.push(H), H.resolve && Je(u.events, q, u.events.length - q, H.resolve(u.events.slice(q), u)), H.resolveTo && (u.events = H.resolveTo(u.events, u));
  }
  function G() {
    const H = b(),
      q = u.previous,
      ne = u.currentConstruct,
      se = u.events.length,
      Y = Array.from(o);
    return {
      from: se,
      restore: le
    };
    function le() {
      r = H, u.previous = q, u.currentConstruct = ne, u.events.length = se, o = Y, M();
    }
  }
  function M() {
    r.line in a && r.column < 2 && (r.column = a[r.line], r.offset += a[r.line] - 1);
  }
}
function gf(e, t) {
  const n = t.start._index,
    r = t.start._bufferIndex,
    a = t.end._index,
    i = t.end._bufferIndex;
  let s;
  if (n === a) s = [e[n].slice(r, i)];else {
    if (s = e.slice(n, a), r > -1) {
      const o = s[0];
      typeof o == "string" ? s[0] = o.slice(r) : s.shift();
    }
    i > 0 && s.push(e[a].slice(0, i));
  }
  return s;
}
function bf(e, t) {
  let n = -1;
  const r = [];
  let a;
  for (; ++n < e.length;) {
    const i = e[n];
    let s;
    if (typeof i == "string") s = i;else switch (i) {
      case -5:
        {
          s = "\r";
          break;
        }
      case -4:
        {
          s = `
`;
          break;
        }
      case -3:
        {
          s = `\r
`;
          break;
        }
      case -2:
        {
          s = t ? " " : "	";
          break;
        }
      case -1:
        {
          if (!t && a) continue;
          s = " ";
          break;
        }
      default:
        s = String.fromCharCode(i);
    }
    a = i === -2, r.push(s);
  }
  return r.join("");
}
function yf(e) {
  const r = {
    constructs: _0([df, ...((e || {}).extensions || [])]),
    content: a(Id),
    defined: [],
    document: a(Rd),
    flow: a(Q1),
    lazy: {},
    string: a(tf),
    text: a(nf)
  };
  return r;
  function a(i) {
    return s;
    function s(o) {
      return ff(r, i, o);
    }
  }
}
function vf(e) {
  for (; !T0(e););
  return e;
}
const wo = /[\0\t\n\r]/g;
function wf() {
  let e = 1,
    t = "",
    n = !0,
    r;
  return a;
  function a(i, s, o) {
    const l = [];
    let u, c, h, f, d;
    for (i = t + (typeof i == "string" ? i.toString() : new TextDecoder(s || void 0).decode(i)), h = 0, t = "", n && (i.charCodeAt(0) === 65279 && h++, n = void 0); h < i.length;) {
      if (wo.lastIndex = h, u = wo.exec(i), f = u && u.index !== void 0 ? u.index : i.length, d = i.charCodeAt(f), !u) {
        t = i.slice(h);
        break;
      }
      if (d === 10 && h === f && r) l.push(-3), r = void 0;else switch (r && (l.push(-5), r = void 0), h < f && (l.push(i.slice(h, f)), e += f - h), d) {
        case 0:
          {
            l.push(65533), e++;
            break;
          }
        case 9:
          {
            for (c = Math.ceil(e / 4) * 4, l.push(-2); e++ < c;) l.push(-1);
            break;
          }
        case 10:
          {
            l.push(-4), e = 1;
            break;
          }
        default:
          r = !0, e = 1;
      }
      h = f + 1;
    }
    return o && (r && l.push(-5), t && l.push(t), l.push(null)), l;
  }
}
const xf = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function kf(e) {
  return e.replace(xf, _f);
}
function _f(e, t, n) {
  if (t) return t;
  if (n.charCodeAt(0) === 35) {
    const a = n.charCodeAt(1),
      i = a === 120 || a === 88;
    return $0(n.slice(i ? 2 : 1), i ? 16 : 10);
  }
  return ns(n) || e;
}
function Br(e) {
  return !e || typeof e != "object" ? "" : "position" in e || "type" in e ? xo(e.position) : "start" in e || "end" in e ? xo(e) : "line" in e || "column" in e ? $i(e) : "";
}
function $i(e) {
  return ko(e && e.line) + ":" + ko(e && e.column);
}
function xo(e) {
  return $i(e && e.start) + "-" + $i(e && e.end);
}
function ko(e) {
  return e && typeof e == "number" ? e : 1;
}
const R0 = {}.hasOwnProperty;
function y5(e, t, n) {
  return t && typeof t == "object" && (n = t, t = void 0), $f(n)(vf(yf(n).document().write(wf()(e, t, !0))));
}
function $f(e) {
  const t = {
    transforms: [],
    canContainEols: ["emphasis", "fragment", "heading", "paragraph", "strong"],
    enter: {
      autolink: i(Dn),
      autolinkProtocol: G,
      autolinkEmail: G,
      atxHeading: i(mr),
      blockQuote: i($t),
      characterEscape: G,
      characterReference: G,
      codeFenced: i(Kt),
      codeFencedFenceInfo: s,
      codeFencedFenceMeta: s,
      codeIndented: i(Kt, s),
      codeText: i(cr, s),
      codeTextData: G,
      data: G,
      codeFlowValue: G,
      definition: i(gn),
      definitionDestinationString: s,
      definitionLabelString: s,
      definitionTitleString: s,
      emphasis: i(bn),
      hardBreakEscape: i(hr),
      hardBreakTrailing: i(hr),
      htmlFlow: i(pr, s),
      htmlFlowData: G,
      htmlText: i(pr, s),
      htmlTextData: G,
      image: i(dr),
      label: s,
      link: i(Dn),
      listItem: i(ka),
      listItemValue: f,
      listOrdered: i(Qt, h),
      listUnordered: i(Qt),
      paragraph: i(_a),
      reference: C,
      referenceString: s,
      resourceDestinationString: s,
      resourceTitleString: s,
      setextHeading: i(mr),
      strong: i(Ln),
      thematicBreak: i(gr)
    },
    exit: {
      atxHeading: l(),
      atxHeadingSequence: R,
      autolink: l(),
      autolinkEmail: Ze,
      autolinkProtocol: mt,
      blockQuote: l(),
      characterEscapeValue: M,
      characterReferenceMarkerHexadecimal: gt,
      characterReferenceMarkerNumeric: gt,
      characterReferenceValue: Te,
      characterReference: at,
      codeFenced: l(A),
      codeFencedFence: k,
      codeFencedFenceInfo: d,
      codeFencedFenceMeta: b,
      codeFlowValue: M,
      codeIndented: l(w),
      codeText: l(Y),
      codeTextData: M,
      data: M,
      definition: l(),
      definitionDestinationString: I,
      definitionLabelString: _,
      definitionTitleString: T,
      emphasis: l(),
      hardBreakEscape: l(q),
      hardBreakTrailing: l(q),
      htmlFlow: l(ne),
      htmlFlowData: M,
      htmlText: l(se),
      htmlTextData: M,
      image: l(me),
      label: Ye,
      labelText: Ne,
      lineEnding: H,
      link: l(le),
      listItem: l(),
      listOrdered: l(),
      listUnordered: l(),
      paragraph: l(),
      referenceString: Be,
      resourceDestinationString: $,
      resourceTitleString: _e,
      resource: Oe,
      setextHeading: l(W),
      setextHeadingLineSequence: O,
      setextHeadingText: E,
      strong: l(),
      thematicBreak: l()
    }
  };
  B0(t, (e || {}).mdastExtensions || []);
  const n = {};
  return r;
  function r(z) {
    let j = {
      type: "root",
      children: []
    };
    const K = {
        stack: [j],
        tokenStack: [],
        config: t,
        enter: o,
        exit: u,
        buffer: s,
        resume: c,
        data: n
      },
      re = [];
    let pe = -1;
    for (; ++pe < z.length;) if (z[pe][1].type === "listOrdered" || z[pe][1].type === "listUnordered") if (z[pe][0] === "enter") re.push(pe);else {
      const ht = re.pop();
      pe = a(z, ht, pe);
    }
    for (pe = -1; ++pe < z.length;) {
      const ht = t[z[pe][0]];
      R0.call(ht, z[pe][1].type) && ht[z[pe][1].type].call(Object.assign({
        sliceSerialize: z[pe][2].sliceSerialize
      }, K), z[pe][1]);
    }
    if (K.tokenStack.length > 0) {
      const ht = K.tokenStack[K.tokenStack.length - 1];
      (ht[1] || _o).call(K, void 0, ht[0]);
    }
    for (j.position = {
      start: Ft(z.length > 0 ? z[0][1].start : {
        line: 1,
        column: 1,
        offset: 0
      }),
      end: Ft(z.length > 0 ? z[z.length - 2][1].end : {
        line: 1,
        column: 1,
        offset: 0
      })
    }, pe = -1; ++pe < t.transforms.length;) j = t.transforms[pe](j) || j;
    return j;
  }
  function a(z, j, K) {
    let re = j - 1,
      pe = -1,
      ht = !1,
      Jt,
      Ct,
      Fn,
      Pn;
    for (; ++re <= K;) {
      const Ke = z[re];
      switch (Ke[1].type) {
        case "listUnordered":
        case "listOrdered":
        case "blockQuote":
          {
            Ke[0] === "enter" ? pe++ : pe--, Pn = void 0;
            break;
          }
        case "lineEndingBlank":
          {
            Ke[0] === "enter" && (Jt && !Pn && !pe && !Fn && (Fn = re), Pn = void 0);
            break;
          }
        case "linePrefix":
        case "listItemValue":
        case "listItemMarker":
        case "listItemPrefix":
        case "listItemPrefixWhitespace":
          break;
        default:
          Pn = void 0;
      }
      if (!pe && Ke[0] === "enter" && Ke[1].type === "listItemPrefix" || pe === -1 && Ke[0] === "exit" && (Ke[1].type === "listUnordered" || Ke[1].type === "listOrdered")) {
        if (Jt) {
          let yn = re;
          for (Ct = void 0; yn--;) {
            const St = z[yn];
            if (St[1].type === "lineEnding" || St[1].type === "lineEndingBlank") {
              if (St[0] === "exit") continue;
              Ct && (z[Ct][1].type = "lineEndingBlank", ht = !0), St[1].type = "lineEnding", Ct = yn;
            } else if (!(St[1].type === "linePrefix" || St[1].type === "blockQuotePrefix" || St[1].type === "blockQuotePrefixWhitespace" || St[1].type === "blockQuoteMarker" || St[1].type === "listItemIndent")) break;
          }
          Fn && (!Ct || Fn < Ct) && (Jt._spread = !0), Jt.end = Object.assign({}, Ct ? z[Ct][1].start : Ke[1].end), z.splice(Ct || re, 0, ["exit", Jt, Ke[2]]), re++, K++;
        }
        if (Ke[1].type === "listItemPrefix") {
          const yn = {
            type: "listItem",
            _spread: !1,
            start: Object.assign({}, Ke[1].start),
            end: void 0
          };
          Jt = yn, z.splice(re, 0, ["enter", yn, Ke[2]]), re++, K++, Fn = void 0, Pn = !0;
        }
      }
    }
    return z[j][1]._spread = ht, K;
  }
  function i(z, j) {
    return K;
    function K(re) {
      o.call(this, z(re), re), j && j.call(this, re);
    }
  }
  function s() {
    this.stack.push({
      type: "fragment",
      children: []
    });
  }
  function o(z, j, K) {
    this.stack[this.stack.length - 1].children.push(z), this.stack.push(z), this.tokenStack.push([j, K || void 0]), z.position = {
      start: Ft(j.start),
      end: void 0
    };
  }
  function l(z) {
    return j;
    function j(K) {
      z && z.call(this, K), u.call(this, K);
    }
  }
  function u(z, j) {
    const K = this.stack.pop(),
      re = this.tokenStack.pop();
    if (re) re[0].type !== z.type && (j ? j.call(this, z, re[0]) : (re[1] || _o).call(this, z, re[0]));else throw new Error("Cannot close `" + z.type + "` (" + Br({
      start: z.start,
      end: z.end
    }) + "): it’s not open");
    K.position.end = Ft(z.end);
  }
  function c() {
    return Cd(this.stack.pop());
  }
  function h() {
    this.data.expectingFirstListItemValue = !0;
  }
  function f(z) {
    if (this.data.expectingFirstListItemValue) {
      const j = this.stack[this.stack.length - 2];
      j.start = Number.parseInt(this.sliceSerialize(z), 10), this.data.expectingFirstListItemValue = void 0;
    }
  }
  function d() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.lang = z;
  }
  function b() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.meta = z;
  }
  function k() {
    this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0);
  }
  function A() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.value = z.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
  }
  function w() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.value = z.replace(/(\r?\n|\r)$/g, "");
  }
  function _(z) {
    const j = this.resume(),
      K = this.stack[this.stack.length - 1];
    K.label = j, K.identifier = ft(this.sliceSerialize(z)).toLowerCase();
  }
  function T() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.title = z;
  }
  function I() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.url = z;
  }
  function R(z) {
    const j = this.stack[this.stack.length - 1];
    if (!j.depth) {
      const K = this.sliceSerialize(z).length;
      j.depth = K;
    }
  }
  function E() {
    this.data.setextHeadingSlurpLineEnding = !0;
  }
  function O(z) {
    const j = this.stack[this.stack.length - 1];
    j.depth = this.sliceSerialize(z).codePointAt(0) === 61 ? 1 : 2;
  }
  function W() {
    this.data.setextHeadingSlurpLineEnding = void 0;
  }
  function G(z) {
    const K = this.stack[this.stack.length - 1].children;
    let re = K[K.length - 1];
    (!re || re.type !== "text") && (re = fr(), re.position = {
      start: Ft(z.start),
      end: void 0
    }, K.push(re)), this.stack.push(re);
  }
  function M(z) {
    const j = this.stack.pop();
    j.value += this.sliceSerialize(z), j.position.end = Ft(z.end);
  }
  function H(z) {
    const j = this.stack[this.stack.length - 1];
    if (this.data.atHardBreak) {
      const K = j.children[j.children.length - 1];
      K.position.end = Ft(z.end), this.data.atHardBreak = void 0;
      return;
    }
    !this.data.setextHeadingSlurpLineEnding && t.canContainEols.includes(j.type) && (G.call(this, z), M.call(this, z));
  }
  function q() {
    this.data.atHardBreak = !0;
  }
  function ne() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.value = z;
  }
  function se() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.value = z;
  }
  function Y() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.value = z;
  }
  function le() {
    const z = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const j = this.data.referenceType || "shortcut";
      z.type += "Reference", z.referenceType = j, delete z.url, delete z.title;
    } else delete z.identifier, delete z.label;
    this.data.referenceType = void 0;
  }
  function me() {
    const z = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const j = this.data.referenceType || "shortcut";
      z.type += "Reference", z.referenceType = j, delete z.url, delete z.title;
    } else delete z.identifier, delete z.label;
    this.data.referenceType = void 0;
  }
  function Ne(z) {
    const j = this.sliceSerialize(z),
      K = this.stack[this.stack.length - 2];
    K.label = kf(j), K.identifier = ft(j).toLowerCase();
  }
  function Ye() {
    const z = this.stack[this.stack.length - 1],
      j = this.resume(),
      K = this.stack[this.stack.length - 1];
    if (this.data.inReference = !0, K.type === "link") {
      const re = z.children;
      K.children = re;
    } else K.alt = j;
  }
  function $() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.url = z;
  }
  function _e() {
    const z = this.resume(),
      j = this.stack[this.stack.length - 1];
    j.title = z;
  }
  function Oe() {
    this.data.inReference = void 0;
  }
  function C() {
    this.data.referenceType = "collapsed";
  }
  function Be(z) {
    const j = this.resume(),
      K = this.stack[this.stack.length - 1];
    K.label = j, K.identifier = ft(this.sliceSerialize(z)).toLowerCase(), this.data.referenceType = "full";
  }
  function gt(z) {
    this.data.characterReferenceType = z.type;
  }
  function Te(z) {
    const j = this.sliceSerialize(z),
      K = this.data.characterReferenceType;
    let re;
    K ? (re = $0(j, K === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : re = ns(j);
    const pe = this.stack[this.stack.length - 1];
    pe.value += re;
  }
  function at(z) {
    const j = this.stack.pop();
    j.position.end = Ft(z.end);
  }
  function mt(z) {
    M.call(this, z);
    const j = this.stack[this.stack.length - 1];
    j.url = this.sliceSerialize(z);
  }
  function Ze(z) {
    M.call(this, z);
    const j = this.stack[this.stack.length - 1];
    j.url = "mailto:" + this.sliceSerialize(z);
  }
  function $t() {
    return {
      type: "blockquote",
      children: []
    };
  }
  function Kt() {
    return {
      type: "code",
      lang: null,
      meta: null,
      value: ""
    };
  }
  function cr() {
    return {
      type: "inlineCode",
      value: ""
    };
  }
  function gn() {
    return {
      type: "definition",
      identifier: "",
      label: null,
      title: null,
      url: ""
    };
  }
  function bn() {
    return {
      type: "emphasis",
      children: []
    };
  }
  function mr() {
    return {
      type: "heading",
      depth: 0,
      children: []
    };
  }
  function hr() {
    return {
      type: "break"
    };
  }
  function pr() {
    return {
      type: "html",
      value: ""
    };
  }
  function dr() {
    return {
      type: "image",
      title: null,
      url: "",
      alt: null
    };
  }
  function Dn() {
    return {
      type: "link",
      title: null,
      url: "",
      children: []
    };
  }
  function Qt(z) {
    return {
      type: "list",
      ordered: z.type === "listOrdered",
      start: null,
      spread: z._spread,
      children: []
    };
  }
  function ka(z) {
    return {
      type: "listItem",
      spread: z._spread,
      checked: null,
      children: []
    };
  }
  function _a() {
    return {
      type: "paragraph",
      children: []
    };
  }
  function Ln() {
    return {
      type: "strong",
      children: []
    };
  }
  function fr() {
    return {
      type: "text",
      value: ""
    };
  }
  function gr() {
    return {
      type: "thematicBreak"
    };
  }
}
function Ft(e) {
  return {
    line: e.line,
    column: e.column,
    offset: e.offset
  };
}
function B0(e, t) {
  let n = -1;
  for (; ++n < t.length;) {
    const r = t[n];
    Array.isArray(r) ? B0(e, r) : Cf(e, r);
  }
}
function Cf(e, t) {
  let n;
  for (n in t) if (R0.call(t, n)) switch (n) {
    case "canContainEols":
      {
        const r = t[n];
        r && e[n].push(...r);
        break;
      }
    case "transforms":
      {
        const r = t[n];
        r && e[n].push(...r);
        break;
      }
    case "enter":
    case "exit":
      {
        const r = t[n];
        r && Object.assign(e[n], r);
        break;
      }
  }
}
function _o(e, t) {
  throw e ? new Error("Cannot close `" + e.type + "` (" + Br({
    start: e.start,
    end: e.end
  }) + "): a different token (`" + t.type + "`, " + Br({
    start: t.start,
    end: t.end
  }) + ") is open") : new Error("Cannot close document, a token (`" + t.type + "`, " + Br({
    start: t.start,
    end: t.end
  }) + ") is still open");
}
function Sf(e) {
  if (typeof e != "string") throw new TypeError("Expected a string");
  return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
const as = function (e) {
  if (e == null) return Mf;
  if (typeof e == "function") return ca(e);
  if (typeof e == "object") return Array.isArray(e) ? Af(e) : Tf(e);
  if (typeof e == "string") return Ef(e);
  throw new Error("Expected function, string, or object as test");
};
function Af(e) {
  const t = [];
  let n = -1;
  for (; ++n < e.length;) t[n] = as(e[n]);
  return ca(r);
  function r(...a) {
    let i = -1;
    for (; ++i < t.length;) if (t[i].apply(this, a)) return !0;
    return !1;
  }
}
function Tf(e) {
  const t = e;
  return ca(n);
  function n(r) {
    const a = r;
    let i;
    for (i in e) if (a[i] !== t[i]) return !1;
    return !0;
  }
}
function Ef(e) {
  return ca(t);
  function t(n) {
    return n && n.type === e;
  }
}
function ca(e) {
  return t;
  function t(n, r, a) {
    return !!(zf(n) && e.call(this, n, typeof r == "number" ? r : void 0, a || void 0));
  }
}
function Mf() {
  return !0;
}
function zf(e) {
  return e !== null && typeof e == "object" && "type" in e;
}
const D0 = [],
  If = !0,
  $o = !1,
  Nf = "skip";
function Rf(e, t, n, r) {
  let a;
  a = t;
  const i = as(a),
    s = 1;
  o(e, void 0, [])();
  function o(l, u, c) {
    const h = l && typeof l == "object" ? l : {};
    if (typeof h.type == "string") {
      const d = typeof h.tagName == "string" ? h.tagName : typeof h.name == "string" ? h.name : void 0;
      Object.defineProperty(f, "name", {
        value: "node (" + (l.type + (d ? "<" + d + ">" : "")) + ")"
      });
    }
    return f;
    function f() {
      let d = D0,
        b,
        k,
        A;
      if (i(l, u, c[c.length - 1] || void 0) && (d = Bf(n(l, c)), d[0] === $o)) return d;
      if ("children" in l && l.children) {
        const w = l;
        if (w.children && d[0] !== Nf) for (k = -1 + s, A = c.concat(w); k > -1 && k < w.children.length;) {
          const _ = w.children[k];
          if (b = o(_, k, A)(), b[0] === $o) return b;
          k = typeof b[1] == "number" ? b[1] : k + s;
        }
      }
      return d;
    }
  }
}
function Bf(e) {
  return Array.isArray(e) ? e : typeof e == "number" ? [If, e] : e == null ? D0 : [e];
}
function Df(e, t, n) {
  const a = as((n || {}).ignore || []),
    i = Lf(t);
  let s = -1;
  for (; ++s < i.length;) Rf(e, "text", o);
  function o(u, c) {
    let h = -1,
      f;
    for (; ++h < c.length;) {
      const d = c[h],
        b = f ? f.children : void 0;
      if (a(d, b ? b.indexOf(d) : void 0, f)) return;
      f = d;
    }
    if (f) return l(u, c);
  }
  function l(u, c) {
    const h = c[c.length - 1],
      f = i[s][0],
      d = i[s][1];
    let b = 0;
    const A = h.children.indexOf(u);
    let w = !1,
      _ = [];
    f.lastIndex = 0;
    let T = f.exec(u.value);
    for (; T;) {
      const I = T.index,
        R = {
          index: T.index,
          input: T.input,
          stack: [...c, u]
        };
      let E = d(...T, R);
      if (typeof E == "string" && (E = E.length > 0 ? {
        type: "text",
        value: E
      } : void 0), E === !1 ? f.lastIndex = I + 1 : (b !== I && _.push({
        type: "text",
        value: u.value.slice(b, I)
      }), Array.isArray(E) ? _.push(...E) : E && _.push(E), b = I + T[0].length, w = !0), !f.global) break;
      T = f.exec(u.value);
    }
    return w ? (b < u.value.length && _.push({
      type: "text",
      value: u.value.slice(b)
    }), h.children.splice(A, 1, ..._)) : _ = [u], A + _.length;
  }
}
function Lf(e) {
  const t = [];
  if (!Array.isArray(e)) throw new TypeError("Expected find and replace tuple or list of tuples");
  const n = !e[0] || Array.isArray(e[0]) ? e : [e];
  let r = -1;
  for (; ++r < n.length;) {
    const a = n[r];
    t.push([Ff(a[0]), Pf(a[1])]);
  }
  return t;
}
function Ff(e) {
  return typeof e == "string" ? new RegExp(Sf(e), "g") : e;
}
function Pf(e) {
  return typeof e == "function" ? e : function () {
    return e;
  };
}
function Of() {
  return {
    transforms: [Wf],
    enter: {
      literalAutolink: qf,
      literalAutolinkEmail: Oa,
      literalAutolinkHttp: Oa,
      literalAutolinkWww: Oa
    },
    exit: {
      literalAutolink: Uf,
      literalAutolinkEmail: Hf,
      literalAutolinkHttp: jf,
      literalAutolinkWww: Gf
    }
  };
}
function qf(e) {
  this.enter({
    type: "link",
    title: null,
    url: "",
    children: []
  }, e);
}
function Oa(e) {
  this.config.enter.autolinkProtocol.call(this, e);
}
function jf(e) {
  this.config.exit.autolinkProtocol.call(this, e);
}
function Gf(e) {
  this.config.exit.data.call(this, e);
  const t = this.stack[this.stack.length - 1];
  t.type, t.url = "http://" + this.sliceSerialize(e);
}
function Hf(e) {
  this.config.exit.autolinkEmail.call(this, e);
}
function Uf(e) {
  this.exit(e);
}
function Wf(e) {
  Df(e, [[/(https?:\/\/|www(?=\.))([-.\w]+)((?:[!-~]|(?![\p{P}\p{S}\s])[^ \t\r\n])*)/giu, Vf], [/(?<=^|\s|\p{P}|\p{S})([-.\w+]+)@([-\w]+(?:\.[-\w]+)+)/gu, Xf]], {
    ignore: ["link", "linkReference"]
  });
}
function Vf(e, t, n, r, a) {
  let i = "";
  if (!L0(a) || (/^w/i.test(t) && (n = t + n, t = "", i = "http://"), !Yf(n))) return !1;
  const s = Zf(n + r);
  if (!s[0]) return !1;
  const o = {
    type: "link",
    title: null,
    url: i + t + s[0],
    children: [{
      type: "text",
      value: t + s[0]
    }]
  };
  return s[1] ? [o, {
    type: "text",
    value: s[1]
  }] : o;
}
function Xf(e, t, n, r) {
  return !L0(r, !0) || /[-\d_]$/.test(n) ? !1 : {
    type: "link",
    title: null,
    url: "mailto:" + t + "@" + n,
    children: [{
      type: "text",
      value: t + "@" + n
    }]
  };
}
function Yf(e) {
  const t = e.split(".");
  return !(t.length < 2 || t[t.length - 1] && (/_/.test(t[t.length - 1]) || !/[a-zA-Z\d]/.test(t[t.length - 1])) || t[t.length - 2] && (/_/.test(t[t.length - 2]) || !/[a-zA-Z\d]/.test(t[t.length - 2])));
}
function Zf(e) {
  const t = /[!"&'),.:;<>?\]}]+$/.exec(e);
  if (!t) return [e, void 0];
  e = e.slice(0, t.index);
  let n = t[0],
    r = n.indexOf(")");
  const a = Hr(e, "(");
  let i = Hr(e, ")");
  for (; r !== -1 && a > i;) e += n.slice(0, r + 1), n = n.slice(r + 1), r = n.indexOf(")"), i++;
  return [e, n];
}
function L0(e, t) {
  const n = e.input.charCodeAt(e.index - 1);
  return (e.index === 0 || pn(n) || or(n)) && (!t || n !== 47);
}
function Kf() {
  this.buffer();
}
function Qf(e) {
  this.enter({
    type: "footnoteReference",
    identifier: "",
    label: ""
  }, e);
}
function Jf() {
  this.buffer();
}
function eg(e) {
  this.enter({
    type: "footnoteDefinition",
    identifier: "",
    label: "",
    children: []
  }, e);
}
function tg(e) {
  const t = this.resume(),
    n = this.stack[this.stack.length - 1];
  n.type, n.identifier = ft(this.sliceSerialize(e)).toLowerCase(), n.label = t;
}
function ng(e) {
  this.exit(e);
}
function rg(e) {
  const t = this.resume(),
    n = this.stack[this.stack.length - 1];
  n.type, n.identifier = ft(this.sliceSerialize(e)).toLowerCase(), n.label = t;
}
function ag(e) {
  this.exit(e);
}
function ig() {
  return {
    enter: {
      gfmFootnoteCallString: Kf,
      gfmFootnoteCall: Qf,
      gfmFootnoteDefinitionLabelString: Jf,
      gfmFootnoteDefinition: eg
    },
    exit: {
      gfmFootnoteCallString: tg,
      gfmFootnoteCall: ng,
      gfmFootnoteDefinitionLabelString: rg,
      gfmFootnoteDefinition: ag
    }
  };
}
function sg() {
  return {
    canContainEols: ["delete"],
    enter: {
      strikethrough: og
    },
    exit: {
      strikethrough: lg
    }
  };
}
function og(e) {
  this.enter({
    type: "delete",
    children: []
  }, e);
}
function lg(e) {
  this.exit(e);
}
function ug() {
  return {
    enter: {
      table: cg,
      tableData: Co,
      tableHeader: Co,
      tableRow: hg
    },
    exit: {
      codeText: pg,
      table: mg,
      tableData: qa,
      tableHeader: qa,
      tableRow: qa
    }
  };
}
function cg(e) {
  const t = e._align;
  this.enter({
    type: "table",
    align: t.map(function (n) {
      return n === "none" ? null : n;
    }),
    children: []
  }, e), this.data.inTable = !0;
}
function mg(e) {
  this.exit(e), this.data.inTable = void 0;
}
function hg(e) {
  this.enter({
    type: "tableRow",
    children: []
  }, e);
}
function qa(e) {
  this.exit(e);
}
function Co(e) {
  this.enter({
    type: "tableCell",
    children: []
  }, e);
}
function pg(e) {
  let t = this.resume();
  this.data.inTable && (t = t.replace(/\\([\\|])/g, dg));
  const n = this.stack[this.stack.length - 1];
  n.type, n.value = t, this.exit(e);
}
function dg(e, t) {
  return t === "|" ? t : e;
}
function fg() {
  return {
    exit: {
      taskListCheckValueChecked: So,
      taskListCheckValueUnchecked: So,
      paragraph: gg
    }
  };
}
function So(e) {
  const t = this.stack[this.stack.length - 2];
  t.type, t.checked = e.type === "taskListCheckValueChecked";
}
function gg(e) {
  const t = this.stack[this.stack.length - 2];
  if (t && t.type === "listItem" && typeof t.checked == "boolean") {
    const n = this.stack[this.stack.length - 1];
    n.type;
    const r = n.children[0];
    if (r && r.type === "text") {
      const a = t.children;
      let i = -1,
        s;
      for (; ++i < a.length;) {
        const o = a[i];
        if (o.type === "paragraph") {
          s = o;
          break;
        }
      }
      s === n && (r.value = r.value.slice(1), r.value.length === 0 ? n.children.shift() : n.position && r.position && typeof r.position.start.offset == "number" && (r.position.start.column++, r.position.start.offset++, n.position.start = Object.assign({}, r.position.start)));
    }
  }
  this.exit(e);
}
function v5() {
  return [Of(), ig(), sg(), ug(), fg()];
}
function w5() {
  return {
    enter: {
      mathFlow: e,
      mathFlowFenceMeta: t,
      mathText: i
    },
    exit: {
      mathFlow: a,
      mathFlowFence: r,
      mathFlowFenceMeta: n,
      mathFlowValue: o,
      mathText: s,
      mathTextData: o
    }
  };
  function e(l) {
    const u = {
      type: "element",
      tagName: "code",
      properties: {
        className: ["language-math", "math-display"]
      },
      children: []
    };
    this.enter({
      type: "math",
      meta: null,
      value: "",
      data: {
        hName: "pre",
        hChildren: [u]
      }
    }, l);
  }
  function t() {
    this.buffer();
  }
  function n() {
    const l = this.resume(),
      u = this.stack[this.stack.length - 1];
    u.type, u.meta = l;
  }
  function r() {
    this.data.mathFlowInside || (this.buffer(), this.data.mathFlowInside = !0);
  }
  function a(l) {
    const u = this.resume().replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""),
      c = this.stack[this.stack.length - 1];
    c.type, this.exit(l), c.value = u;
    const h = c.data.hChildren[0];
    h.type, h.tagName, h.children.push({
      type: "text",
      value: u
    }), this.data.mathFlowInside = void 0;
  }
  function i(l) {
    this.enter({
      type: "inlineMath",
      value: "",
      data: {
        hName: "code",
        hProperties: {
          className: ["language-math", "math-inline"]
        },
        hChildren: []
      }
    }, l), this.buffer();
  }
  function s(l) {
    const u = this.resume(),
      c = this.stack[this.stack.length - 1];
    c.type, this.exit(l), c.value = u, c.data.hChildren.push({
      type: "text",
      value: u
    });
  }
  function o(l) {
    this.config.enter.data.call(this, l), this.config.exit.data.call(this, l);
  }
}
const bg = {
    tokenize: _g,
    partial: !0
  },
  F0 = {
    tokenize: $g,
    partial: !0
  },
  P0 = {
    tokenize: Cg,
    partial: !0
  },
  O0 = {
    tokenize: Sg,
    partial: !0
  },
  q0 = {
    tokenize: Tg,
    partial: !0
  },
  yg = {
    tokenize: Ag,
    partial: !0
  },
  j0 = {
    name: "wwwAutolink",
    tokenize: xg,
    previous: H0
  },
  G0 = {
    name: "protocolAutolink",
    tokenize: kg,
    previous: U0
  },
  Rt = {
    name: "emailAutolink",
    tokenize: wg,
    previous: W0
  },
  wt = {};
function vg() {
  return {
    text: wt
  };
}
let tn = 48;
for (; tn < 123;) wt[tn] = Rt, tn++, tn === 58 ? tn = 65 : tn === 91 && (tn = 97);
wt[43] = Rt;
wt[45] = Rt;
wt[46] = Rt;
wt[95] = Rt;
wt[72] = [Rt, G0];
wt[104] = [Rt, G0];
wt[87] = [Rt, j0];
wt[119] = [Rt, j0];
function wg(e, t, n) {
  const r = this;
  let a, i;
  return s;
  function s(h) {
    return !Ci(h) || !W0.call(r, r.previous) || is(r.events) ? n(h) : (e.enter("literalAutolink"), e.enter("literalAutolinkEmail"), o(h));
  }
  function o(h) {
    return Ci(h) ? (e.consume(h), o) : h === 64 ? (e.consume(h), l) : n(h);
  }
  function l(h) {
    return h === 46 ? e.check(yg, c, u)(h) : h === 45 || h === 95 || Fe(h) ? (i = !0, e.consume(h), l) : c(h);
  }
  function u(h) {
    return e.consume(h), a = !0, l;
  }
  function c(h) {
    return i && a && Ge(r.previous) ? (e.exit("literalAutolinkEmail"), e.exit("literalAutolink"), t(h)) : n(h);
  }
}
function xg(e, t, n) {
  const r = this;
  return a;
  function a(s) {
    return s !== 87 && s !== 119 || !H0.call(r, r.previous) || is(r.events) ? n(s) : (e.enter("literalAutolink"), e.enter("literalAutolinkWww"), e.check(bg, e.attempt(F0, e.attempt(P0, i), n), n)(s));
  }
  function i(s) {
    return e.exit("literalAutolinkWww"), e.exit("literalAutolink"), t(s);
  }
}
function kg(e, t, n) {
  const r = this;
  let a = "",
    i = !1;
  return s;
  function s(h) {
    return (h === 72 || h === 104) && U0.call(r, r.previous) && !is(r.events) ? (e.enter("literalAutolink"), e.enter("literalAutolinkHttp"), a += String.fromCodePoint(h), e.consume(h), o) : n(h);
  }
  function o(h) {
    if (Ge(h) && a.length < 5) return a += String.fromCodePoint(h), e.consume(h), o;
    if (h === 58) {
      const f = a.toLowerCase();
      if (f === "http" || f === "https") return e.consume(h), l;
    }
    return n(h);
  }
  function l(h) {
    return h === 47 ? (e.consume(h), i ? u : (i = !0, l)) : n(h);
  }
  function u(h) {
    return h === null || Zr(h) || fe(h) || pn(h) || or(h) ? n(h) : e.attempt(F0, e.attempt(P0, c), n)(h);
  }
  function c(h) {
    return e.exit("literalAutolinkHttp"), e.exit("literalAutolink"), t(h);
  }
}
function _g(e, t, n) {
  let r = 0;
  return a;
  function a(s) {
    return (s === 87 || s === 119) && r < 3 ? (r++, e.consume(s), a) : s === 46 && r === 3 ? (e.consume(s), i) : n(s);
  }
  function i(s) {
    return s === null ? n(s) : t(s);
  }
}
function $g(e, t, n) {
  let r, a, i;
  return s;
  function s(u) {
    return u === 46 || u === 95 ? e.check(O0, l, o)(u) : u === null || fe(u) || pn(u) || u !== 45 && or(u) ? l(u) : (i = !0, e.consume(u), s);
  }
  function o(u) {
    return u === 95 ? r = !0 : (a = r, r = void 0), e.consume(u), s;
  }
  function l(u) {
    return a || r || !i ? n(u) : t(u);
  }
}
function Cg(e, t) {
  let n = 0,
    r = 0;
  return a;
  function a(s) {
    return s === 40 ? (n++, e.consume(s), a) : s === 41 && r < n ? i(s) : s === 33 || s === 34 || s === 38 || s === 39 || s === 41 || s === 42 || s === 44 || s === 46 || s === 58 || s === 59 || s === 60 || s === 63 || s === 93 || s === 95 || s === 126 ? e.check(O0, t, i)(s) : X0(s) ? e.check(q0, t, i)(s) : s === null || fe(s) || pn(s) || V0(s) ? t(s) : (e.consume(s), a);
  }
  function i(s) {
    return s === 41 && r++, e.consume(s), a;
  }
}
function Sg(e, t, n) {
  return r;
  function r(o) {
    return o === 33 || o === 34 || o === 39 || o === 41 || o === 42 || o === 44 || o === 46 || o === 58 || o === 59 || o === 63 || o === 95 || o === 126 ? (e.consume(o), r) : o === 38 ? (e.consume(o), i) : o === 93 ? (e.consume(o), a) : o === 60 || o === null || fe(o) || pn(o) || V0(o) ? t(o) : X0(o) ? e.check(q0, t, n)(o) : n(o);
  }
  function a(o) {
    return o === null || o === 40 || o === 91 || fe(o) || pn(o) ? t(o) : r(o);
  }
  function i(o) {
    return Ge(o) ? s(o) : n(o);
  }
  function s(o) {
    return o === 59 ? (e.consume(o), r) : Ge(o) ? (e.consume(o), s) : n(o);
  }
}
function Ag(e, t, n) {
  return r;
  function r(i) {
    return e.consume(i), a;
  }
  function a(i) {
    return Fe(i) ? n(i) : t(i);
  }
}
function H0(e) {
  return e === null || e === 40 || e === 42 || e === 95 || e === 91 || e === 93 || e === 126 || fe(e);
}
function U0(e) {
  return !Ge(e);
}
function W0(e) {
  return !(e === 47 || Ci(e));
}
function V0(e) {
  return e !== null && e > 127 && or(e);
}
function X0(e) {
  return e !== null && e >= 55296 && e <= 56319;
}
function Tg(e, t, n) {
  let r;
  return a;
  function a(s) {
    return r = s, e.consume(s), i;
  }
  function i(s) {
    return s !== null && s >= 56320 && s <= 57343 && /[\p{P}\p{S}]/u.test(String.fromCharCode(r, s)) ? t(s) : n(s);
  }
}
function Ci(e) {
  return e === 43 || e === 45 || e === 46 || e === 95 || Fe(e);
}
function is(e) {
  let t = e.length,
    n = !1;
  for (; t--;) {
    const r = e[t][1];
    if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
      n = !0;
      break;
    }
    if (r._gfmAutolinkLiteralWalkedInto) {
      n = !1;
      break;
    }
  }
  return e.length > 0 && !n && (e[e.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), n;
}
const Eg = {
  tokenize: Lg,
  partial: !0
};
function Mg() {
  return {
    document: {
      91: {
        name: "gfmFootnoteDefinition",
        tokenize: Rg,
        continuation: {
          tokenize: Bg
        },
        exit: Dg
      }
    },
    text: {
      91: {
        name: "gfmFootnoteCall",
        tokenize: Ng
      },
      93: {
        name: "gfmPotentialFootnoteCall",
        add: "after",
        tokenize: zg,
        resolveTo: Ig
      }
    }
  };
}
function zg(e, t, n) {
  const r = this;
  let a = r.events.length;
  const i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let s;
  for (; a--;) {
    const l = r.events[a][1];
    if (l.type === "labelImage") {
      s = l;
      break;
    }
    if (l.type === "gfmFootnoteCall" || l.type === "labelLink" || l.type === "label" || l.type === "image" || l.type === "link") break;
  }
  return o;
  function o(l) {
    if (!s || !s._balanced) return n(l);
    const u = ft(r.sliceSerialize({
      start: s.end,
      end: r.now()
    }));
    return u.codePointAt(0) !== 94 || !i.includes(u.slice(1)) ? n(l) : (e.enter("gfmFootnoteCallLabelMarker"), e.consume(l), e.exit("gfmFootnoteCallLabelMarker"), t(l));
  }
}
function Ig(e, t) {
  let n = e.length;
  for (; n--;) if (e[n][1].type === "labelImage" && e[n][0] === "enter") {
    e[n][1];
    break;
  }
  e[n + 1][1].type = "data", e[n + 3][1].type = "gfmFootnoteCallLabelMarker";
  const r = {
      type: "gfmFootnoteCall",
      start: Object.assign({}, e[n + 3][1].start),
      end: Object.assign({}, e[e.length - 1][1].end)
    },
    a = {
      type: "gfmFootnoteCallMarker",
      start: Object.assign({}, e[n + 3][1].end),
      end: Object.assign({}, e[n + 3][1].end)
    };
  a.end.column++, a.end.offset++, a.end._bufferIndex++;
  const i = {
      type: "gfmFootnoteCallString",
      start: Object.assign({}, a.end),
      end: Object.assign({}, e[e.length - 1][1].start)
    },
    s = {
      type: "chunkString",
      contentType: "string",
      start: Object.assign({}, i.start),
      end: Object.assign({}, i.end)
    },
    o = [e[n + 1], e[n + 2], ["enter", r, t], e[n + 3], e[n + 4], ["enter", a, t], ["exit", a, t], ["enter", i, t], ["enter", s, t], ["exit", s, t], ["exit", i, t], e[e.length - 2], e[e.length - 1], ["exit", r, t]];
  return e.splice(n, e.length - n + 1, ...o), e;
}
function Ng(e, t, n) {
  const r = this,
    a = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let i = 0,
    s;
  return o;
  function o(h) {
    return e.enter("gfmFootnoteCall"), e.enter("gfmFootnoteCallLabelMarker"), e.consume(h), e.exit("gfmFootnoteCallLabelMarker"), l;
  }
  function l(h) {
    return h !== 94 ? n(h) : (e.enter("gfmFootnoteCallMarker"), e.consume(h), e.exit("gfmFootnoteCallMarker"), e.enter("gfmFootnoteCallString"), e.enter("chunkString").contentType = "string", u);
  }
  function u(h) {
    if (i > 999 || h === 93 && !s || h === null || h === 91 || fe(h)) return n(h);
    if (h === 93) {
      e.exit("chunkString");
      const f = e.exit("gfmFootnoteCallString");
      return a.includes(ft(r.sliceSerialize(f))) ? (e.enter("gfmFootnoteCallLabelMarker"), e.consume(h), e.exit("gfmFootnoteCallLabelMarker"), e.exit("gfmFootnoteCall"), t) : n(h);
    }
    return fe(h) || (s = !0), i++, e.consume(h), h === 92 ? c : u;
  }
  function c(h) {
    return h === 91 || h === 92 || h === 93 ? (e.consume(h), i++, u) : u(h);
  }
}
function Rg(e, t, n) {
  const r = this,
    a = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let i,
    s = 0,
    o;
  return l;
  function l(b) {
    return e.enter("gfmFootnoteDefinition")._container = !0, e.enter("gfmFootnoteDefinitionLabel"), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(b), e.exit("gfmFootnoteDefinitionLabelMarker"), u;
  }
  function u(b) {
    return b === 94 ? (e.enter("gfmFootnoteDefinitionMarker"), e.consume(b), e.exit("gfmFootnoteDefinitionMarker"), e.enter("gfmFootnoteDefinitionLabelString"), e.enter("chunkString").contentType = "string", c) : n(b);
  }
  function c(b) {
    if (s > 999 || b === 93 && !o || b === null || b === 91 || fe(b)) return n(b);
    if (b === 93) {
      e.exit("chunkString");
      const k = e.exit("gfmFootnoteDefinitionLabelString");
      return i = ft(r.sliceSerialize(k)), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(b), e.exit("gfmFootnoteDefinitionLabelMarker"), e.exit("gfmFootnoteDefinitionLabel"), f;
    }
    return fe(b) || (o = !0), s++, e.consume(b), b === 92 ? h : c;
  }
  function h(b) {
    return b === 91 || b === 92 || b === 93 ? (e.consume(b), s++, c) : c(b);
  }
  function f(b) {
    return b === 58 ? (e.enter("definitionMarker"), e.consume(b), e.exit("definitionMarker"), a.includes(i) || a.push(i), ae(e, d, "gfmFootnoteDefinitionWhitespace")) : n(b);
  }
  function d(b) {
    return t(b);
  }
}
function Bg(e, t, n) {
  return e.check(lr, t, e.attempt(Eg, t, n));
}
function Dg(e) {
  e.exit("gfmFootnoteDefinition");
}
function Lg(e, t, n) {
  const r = this;
  return ae(e, a, "gfmFootnoteDefinitionIndent", 5);
  function a(i) {
    const s = r.events[r.events.length - 1];
    return s && s[1].type === "gfmFootnoteDefinitionIndent" && s[2].sliceSerialize(s[1], !0).length === 4 ? t(i) : n(i);
  }
}
function Fg(e) {
  let n = (e || {}).singleTilde;
  const r = {
    name: "strikethrough",
    tokenize: i,
    resolveAll: a
  };
  return n == null && (n = !0), {
    text: {
      126: r
    },
    insideSpan: {
      null: [r]
    },
    attentionMarkers: {
      null: [126]
    }
  };
  function a(s, o) {
    let l = -1;
    for (; ++l < s.length;) if (s[l][0] === "enter" && s[l][1].type === "strikethroughSequenceTemporary" && s[l][1]._close) {
      let u = l;
      for (; u--;) if (s[u][0] === "exit" && s[u][1].type === "strikethroughSequenceTemporary" && s[u][1]._open && s[l][1].end.offset - s[l][1].start.offset === s[u][1].end.offset - s[u][1].start.offset) {
        s[l][1].type = "strikethroughSequence", s[u][1].type = "strikethroughSequence";
        const c = {
            type: "strikethrough",
            start: Object.assign({}, s[u][1].start),
            end: Object.assign({}, s[l][1].end)
          },
          h = {
            type: "strikethroughText",
            start: Object.assign({}, s[u][1].end),
            end: Object.assign({}, s[l][1].start)
          },
          f = [["enter", c, o], ["enter", s[u][1], o], ["exit", s[u][1], o], ["enter", h, o]],
          d = o.parser.constructs.insideSpan.null;
        d && Je(f, f.length, 0, ua(d, s.slice(u + 1, l), o)), Je(f, f.length, 0, [["exit", h, o], ["enter", s[l][1], o], ["exit", s[l][1], o], ["exit", c, o]]), Je(s, u - 1, l - u + 3, f), l = u + f.length - 2;
        break;
      }
    }
    for (l = -1; ++l < s.length;) s[l][1].type === "strikethroughSequenceTemporary" && (s[l][1].type = "data");
    return s;
  }
  function i(s, o, l) {
    const u = this.previous,
      c = this.events;
    let h = 0;
    return f;
    function f(b) {
      return u === 126 && c[c.length - 1][1].type !== "characterEscape" ? l(b) : (s.enter("strikethroughSequenceTemporary"), d(b));
    }
    function d(b) {
      const k = Kr(u);
      if (b === 126) return h > 1 ? l(b) : (s.consume(b), h++, d);
      if (h < 2 && !n) return l(b);
      const A = s.exit("strikethroughSequenceTemporary"),
        w = Kr(b);
      return A._open = !w || w === 2 && !!k, A._close = !k || k === 2 && !!w, o(b);
    }
  }
}
class Pg {
  constructor() {
    this.map = [];
  }
  add(t, n, r) {
    Og(this, t, n, r);
  }
  consume(t) {
    if (this.map.sort(function (i, s) {
      return i[0] - s[0];
    }), this.map.length === 0) return;
    let n = this.map.length;
    const r = [];
    for (; n > 0;) n -= 1, r.push(t.slice(this.map[n][0] + this.map[n][1]), this.map[n][2]), t.length = this.map[n][0];
    r.push(t.slice()), t.length = 0;
    let a = r.pop();
    for (; a;) {
      for (const i of a) t.push(i);
      a = r.pop();
    }
    this.map.length = 0;
  }
}
function Og(e, t, n, r) {
  let a = 0;
  if (!(n === 0 && r.length === 0)) {
    for (; a < e.map.length;) {
      if (e.map[a][0] === t) {
        e.map[a][1] += n, e.map[a][2].push(...r);
        return;
      }
      a += 1;
    }
    e.map.push([t, n, r]);
  }
}
function qg(e, t) {
  let n = !1;
  const r = [];
  for (; t < e.length;) {
    const a = e[t];
    if (n) {
      if (a[0] === "enter") a[1].type === "tableContent" && r.push(e[t + 1][1].type === "tableDelimiterMarker" ? "left" : "none");else if (a[1].type === "tableContent") {
        if (e[t - 1][1].type === "tableDelimiterMarker") {
          const i = r.length - 1;
          r[i] = r[i] === "left" ? "center" : "right";
        }
      } else if (a[1].type === "tableDelimiterRow") break;
    } else a[0] === "enter" && a[1].type === "tableDelimiterRow" && (n = !0);
    t += 1;
  }
  return r;
}
function jg() {
  return {
    flow: {
      null: {
        name: "table",
        tokenize: Gg,
        resolveAll: Hg
      }
    }
  };
}
function Gg(e, t, n) {
  const r = this;
  let a = 0,
    i = 0,
    s;
  return o;
  function o(M) {
    let H = r.events.length - 1;
    for (; H > -1;) {
      const se = r.events[H][1].type;
      if (se === "lineEnding" || se === "linePrefix") H--;else break;
    }
    const q = H > -1 ? r.events[H][1].type : null,
      ne = q === "tableHead" || q === "tableRow" ? E : l;
    return ne === E && r.parser.lazy[r.now().line] ? n(M) : ne(M);
  }
  function l(M) {
    return e.enter("tableHead"), e.enter("tableRow"), u(M);
  }
  function u(M) {
    return M === 124 || (s = !0, i += 1), c(M);
  }
  function c(M) {
    return M === null ? n(M) : X(M) ? i > 1 ? (i = 0, r.interrupt = !0, e.exit("tableRow"), e.enter("lineEnding"), e.consume(M), e.exit("lineEnding"), d) : n(M) : oe(M) ? ae(e, c, "whitespace")(M) : (i += 1, s && (s = !1, a += 1), M === 124 ? (e.enter("tableCellDivider"), e.consume(M), e.exit("tableCellDivider"), s = !0, c) : (e.enter("data"), h(M)));
  }
  function h(M) {
    return M === null || M === 124 || fe(M) ? (e.exit("data"), c(M)) : (e.consume(M), M === 92 ? f : h);
  }
  function f(M) {
    return M === 92 || M === 124 ? (e.consume(M), h) : h(M);
  }
  function d(M) {
    return r.interrupt = !1, r.parser.lazy[r.now().line] ? n(M) : (e.enter("tableDelimiterRow"), s = !1, oe(M) ? ae(e, b, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(M) : b(M));
  }
  function b(M) {
    return M === 45 || M === 58 ? A(M) : M === 124 ? (s = !0, e.enter("tableCellDivider"), e.consume(M), e.exit("tableCellDivider"), k) : R(M);
  }
  function k(M) {
    return oe(M) ? ae(e, A, "whitespace")(M) : A(M);
  }
  function A(M) {
    return M === 58 ? (i += 1, s = !0, e.enter("tableDelimiterMarker"), e.consume(M), e.exit("tableDelimiterMarker"), w) : M === 45 ? (i += 1, w(M)) : M === null || X(M) ? I(M) : R(M);
  }
  function w(M) {
    return M === 45 ? (e.enter("tableDelimiterFiller"), _(M)) : R(M);
  }
  function _(M) {
    return M === 45 ? (e.consume(M), _) : M === 58 ? (s = !0, e.exit("tableDelimiterFiller"), e.enter("tableDelimiterMarker"), e.consume(M), e.exit("tableDelimiterMarker"), T) : (e.exit("tableDelimiterFiller"), T(M));
  }
  function T(M) {
    return oe(M) ? ae(e, I, "whitespace")(M) : I(M);
  }
  function I(M) {
    return M === 124 ? b(M) : M === null || X(M) ? !s || a !== i ? R(M) : (e.exit("tableDelimiterRow"), e.exit("tableHead"), t(M)) : R(M);
  }
  function R(M) {
    return n(M);
  }
  function E(M) {
    return e.enter("tableRow"), O(M);
  }
  function O(M) {
    return M === 124 ? (e.enter("tableCellDivider"), e.consume(M), e.exit("tableCellDivider"), O) : M === null || X(M) ? (e.exit("tableRow"), t(M)) : oe(M) ? ae(e, O, "whitespace")(M) : (e.enter("data"), W(M));
  }
  function W(M) {
    return M === null || M === 124 || fe(M) ? (e.exit("data"), O(M)) : (e.consume(M), M === 92 ? G : W);
  }
  function G(M) {
    return M === 92 || M === 124 ? (e.consume(M), W) : W(M);
  }
}
function Hg(e, t) {
  let n = -1,
    r = !0,
    a = 0,
    i = [0, 0, 0, 0],
    s = [0, 0, 0, 0],
    o = !1,
    l = 0,
    u,
    c,
    h;
  const f = new Pg();
  for (; ++n < e.length;) {
    const d = e[n],
      b = d[1];
    d[0] === "enter" ? b.type === "tableHead" ? (o = !1, l !== 0 && (Ao(f, t, l, u, c), c = void 0, l = 0), u = {
      type: "table",
      start: Object.assign({}, b.start),
      end: Object.assign({}, b.end)
    }, f.add(n, 0, [["enter", u, t]])) : b.type === "tableRow" || b.type === "tableDelimiterRow" ? (r = !0, h = void 0, i = [0, 0, 0, 0], s = [0, n + 1, 0, 0], o && (o = !1, c = {
      type: "tableBody",
      start: Object.assign({}, b.start),
      end: Object.assign({}, b.end)
    }, f.add(n, 0, [["enter", c, t]])), a = b.type === "tableDelimiterRow" ? 2 : c ? 3 : 1) : a && (b.type === "data" || b.type === "tableDelimiterMarker" || b.type === "tableDelimiterFiller") ? (r = !1, s[2] === 0 && (i[1] !== 0 && (s[0] = s[1], h = _r(f, t, i, a, void 0, h), i = [0, 0, 0, 0]), s[2] = n)) : b.type === "tableCellDivider" && (r ? r = !1 : (i[1] !== 0 && (s[0] = s[1], h = _r(f, t, i, a, void 0, h)), i = s, s = [i[1], n, 0, 0])) : b.type === "tableHead" ? (o = !0, l = n) : b.type === "tableRow" || b.type === "tableDelimiterRow" ? (l = n, i[1] !== 0 ? (s[0] = s[1], h = _r(f, t, i, a, n, h)) : s[1] !== 0 && (h = _r(f, t, s, a, n, h)), a = 0) : a && (b.type === "data" || b.type === "tableDelimiterMarker" || b.type === "tableDelimiterFiller") && (s[3] = n);
  }
  for (l !== 0 && Ao(f, t, l, u, c), f.consume(t.events), n = -1; ++n < t.events.length;) {
    const d = t.events[n];
    d[0] === "enter" && d[1].type === "table" && (d[1]._align = qg(t.events, n));
  }
  return e;
}
function _r(e, t, n, r, a, i) {
  const s = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData",
    o = "tableContent";
  n[0] !== 0 && (i.end = Object.assign({}, $n(t.events, n[0])), e.add(n[0], 0, [["exit", i, t]]));
  const l = $n(t.events, n[1]);
  if (i = {
    type: s,
    start: Object.assign({}, l),
    end: Object.assign({}, l)
  }, e.add(n[1], 0, [["enter", i, t]]), n[2] !== 0) {
    const u = $n(t.events, n[2]),
      c = $n(t.events, n[3]),
      h = {
        type: o,
        start: Object.assign({}, u),
        end: Object.assign({}, c)
      };
    if (e.add(n[2], 0, [["enter", h, t]]), r !== 2) {
      const f = t.events[n[2]],
        d = t.events[n[3]];
      if (f[1].end = Object.assign({}, d[1].end), f[1].type = "chunkText", f[1].contentType = "text", n[3] > n[2] + 1) {
        const b = n[2] + 1,
          k = n[3] - n[2] - 1;
        e.add(b, k, []);
      }
    }
    e.add(n[3] + 1, 0, [["exit", h, t]]);
  }
  return a !== void 0 && (i.end = Object.assign({}, $n(t.events, a)), e.add(a, 0, [["exit", i, t]]), i = void 0), i;
}
function Ao(e, t, n, r, a) {
  const i = [],
    s = $n(t.events, n);
  a && (a.end = Object.assign({}, s), i.push(["exit", a, t])), r.end = Object.assign({}, s), i.push(["exit", r, t]), e.add(n + 1, 0, i);
}
function $n(e, t) {
  const n = e[t],
    r = n[0] === "enter" ? "start" : "end";
  return n[1][r];
}
const Ug = {
  name: "tasklistCheck",
  tokenize: Vg
};
function Wg() {
  return {
    text: {
      91: Ug
    }
  };
}
function Vg(e, t, n) {
  const r = this;
  return a;
  function a(l) {
    return r.previous !== null || !r._gfmTasklistFirstContentOfListItem ? n(l) : (e.enter("taskListCheck"), e.enter("taskListCheckMarker"), e.consume(l), e.exit("taskListCheckMarker"), i);
  }
  function i(l) {
    return fe(l) ? (e.enter("taskListCheckValueUnchecked"), e.consume(l), e.exit("taskListCheckValueUnchecked"), s) : l === 88 || l === 120 ? (e.enter("taskListCheckValueChecked"), e.consume(l), e.exit("taskListCheckValueChecked"), s) : n(l);
  }
  function s(l) {
    return l === 93 ? (e.enter("taskListCheckMarker"), e.consume(l), e.exit("taskListCheckMarker"), e.exit("taskListCheck"), o) : n(l);
  }
  function o(l) {
    return X(l) ? t(l) : oe(l) ? e.check({
      tokenize: Xg
    }, t, n)(l) : n(l);
  }
}
function Xg(e, t, n) {
  return ae(e, r, "whitespace");
  function r(a) {
    return a === null ? n(a) : t(a);
  }
}
function x5(e) {
  return _0([vg(), Mg(), Fg(e), jg(), Wg()]);
}
const Yg = {
    tokenize: Zg,
    concrete: !0,
    name: "mathFlow"
  },
  To = {
    tokenize: Kg,
    partial: !0
  };
function Zg(e, t, n) {
  const r = this,
    a = r.events[r.events.length - 1],
    i = a && a[1].type === "linePrefix" ? a[2].sliceSerialize(a[1], !0).length : 0;
  let s = 0;
  return o;
  function o(_) {
    return e.enter("mathFlow"), e.enter("mathFlowFence"), e.enter("mathFlowFenceSequence"), l(_);
  }
  function l(_) {
    return _ === 36 ? (e.consume(_), s++, l) : s < 2 ? n(_) : (e.exit("mathFlowFenceSequence"), ae(e, u, "whitespace")(_));
  }
  function u(_) {
    return _ === null || X(_) ? h(_) : (e.enter("mathFlowFenceMeta"), e.enter("chunkString", {
      contentType: "string"
    }), c(_));
  }
  function c(_) {
    return _ === null || X(_) ? (e.exit("chunkString"), e.exit("mathFlowFenceMeta"), h(_)) : _ === 36 ? n(_) : (e.consume(_), c);
  }
  function h(_) {
    return e.exit("mathFlowFence"), r.interrupt ? t(_) : e.attempt(To, f, A)(_);
  }
  function f(_) {
    return e.attempt({
      tokenize: w,
      partial: !0
    }, A, d)(_);
  }
  function d(_) {
    return (i ? ae(e, b, "linePrefix", i + 1) : b)(_);
  }
  function b(_) {
    return _ === null ? A(_) : X(_) ? e.attempt(To, f, A)(_) : (e.enter("mathFlowValue"), k(_));
  }
  function k(_) {
    return _ === null || X(_) ? (e.exit("mathFlowValue"), b(_)) : (e.consume(_), k);
  }
  function A(_) {
    return e.exit("mathFlow"), t(_);
  }
  function w(_, T, I) {
    let R = 0;
    return ae(_, E, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
    function E(G) {
      return _.enter("mathFlowFence"), _.enter("mathFlowFenceSequence"), O(G);
    }
    function O(G) {
      return G === 36 ? (R++, _.consume(G), O) : R < s ? I(G) : (_.exit("mathFlowFenceSequence"), ae(_, W, "whitespace")(G));
    }
    function W(G) {
      return G === null || X(G) ? (_.exit("mathFlowFence"), T(G)) : I(G);
    }
  }
}
function Kg(e, t, n) {
  const r = this;
  return a;
  function a(s) {
    return s === null ? t(s) : (e.enter("lineEnding"), e.consume(s), e.exit("lineEnding"), i);
  }
  function i(s) {
    return r.parser.lazy[r.now().line] ? n(s) : t(s);
  }
}
function Qg(e) {
  let n = {}.singleDollarTextMath;
  return n == null && (n = !0), {
    tokenize: r,
    resolve: Jg,
    previous: e4,
    name: "mathText"
  };
  function r(a, i, s) {
    let o = 0,
      l,
      u;
    return c;
    function c(k) {
      return a.enter("mathText"), a.enter("mathTextSequence"), h(k);
    }
    function h(k) {
      return k === 36 ? (a.consume(k), o++, h) : o < 2 && !n ? s(k) : (a.exit("mathTextSequence"), f(k));
    }
    function f(k) {
      return k === null ? s(k) : k === 36 ? (u = a.enter("mathTextSequence"), l = 0, b(k)) : k === 32 ? (a.enter("space"), a.consume(k), a.exit("space"), f) : X(k) ? (a.enter("lineEnding"), a.consume(k), a.exit("lineEnding"), f) : (a.enter("mathTextData"), d(k));
    }
    function d(k) {
      return k === null || k === 32 || k === 36 || X(k) ? (a.exit("mathTextData"), f(k)) : (a.consume(k), d);
    }
    function b(k) {
      return k === 36 ? (a.consume(k), l++, b) : l === o ? (a.exit("mathTextSequence"), a.exit("mathText"), i(k)) : (u.type = "mathTextData", d(k));
    }
  }
}
function Jg(e) {
  let t = e.length - 4,
    n = 3,
    r,
    a;
  if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
    for (r = n; ++r < t;) if (e[r][1].type === "mathTextData") {
      e[t][1].type = "mathTextPadding", e[n][1].type = "mathTextPadding", n += 2, t -= 2;
      break;
    }
  }
  for (r = n - 1, t++; ++r <= t;) a === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (a = r) : (r === t || e[r][1].type === "lineEnding") && (e[a][1].type = "mathTextData", r !== a + 2 && (e[a][1].end = e[r - 1][1].end, e.splice(a + 2, r - a - 2), t -= r - a - 2, r = a + 2), a = void 0);
  return e;
}
function e4(e) {
  return e !== 36 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function k5(e) {
  return {
    flow: {
      36: Yg
    },
    text: {
      36: Qg()
    }
  };
}
const _5 = {
    eof: null,
    dollarSign: 36,
    leftParenthesis: 40,
    rightParenthesis: 41,
    asterisk: 42,
    leftSquareBracket: 91,
    backslash: 92,
    rightSquareBracket: 93
  },
  $5 = {
    characterGroupPunctuation: 2,
    tabSize: 4
  },
  C5 = {
    whitespace: "whitespace",
    lineEnding: "lineEnding",
    linePrefix: "linePrefix",
    characterEscape: "characterEscape",
    chunkString: "chunkString"
  };
class D extends Error {
  constructor(t, n) {
    var r = "KaTeX parse error: " + t,
      a,
      i,
      s = n && n.loc;
    if (s && s.start <= s.end) {
      var o = s.lexer.input;
      a = s.start, i = s.end, a === o.length ? r += " at end of input: " : r += " at position " + (a + 1) + ": ";
      var l = o.slice(a, i).replace(/[^]/g, "$&̲"),
        u;
      a > 15 ? u = "…" + o.slice(a - 15, a) : u = o.slice(0, a);
      var c;
      i + 15 < o.length ? c = o.slice(i, i + 15) + "…" : c = o.slice(i), r += u + l + c;
    }
    super(r), this.name = "ParseError", this.position = void 0, this.length = void 0, this.rawMessage = void 0, Object.setPrototypeOf(this, D.prototype), this.position = a, a != null && i != null && (this.length = i - a), this.rawMessage = t;
  }
}
var t4 = /([A-Z])/g,
  n4 = e => e.replace(t4, "-$1").toLowerCase(),
  r4 = {
    "&": "&amp;",
    ">": "&gt;",
    "<": "&lt;",
    '"': "&quot;",
    "'": "&#x27;"
  },
  a4 = /[&><"']/g,
  Pe = e => String(e).replace(a4, t => r4[t]),
  Dr = e => e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? Dr(e.body[0]) : e : e.type === "font" ? Dr(e.body) : e,
  i4 = new Set(["mathord", "textord", "atom"]),
  Bt = e => i4.has(Dr(e).type),
  s4 = e => {
    var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
    return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
  },
  Si = {
    displayMode: {
      type: "boolean",
      description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
      cli: "-d, --display-mode"
    },
    output: {
      type: {
        enum: ["htmlAndMathml", "html", "mathml"]
      },
      description: "Determines the markup language of the output.",
      cli: "-F, --format <type>"
    },
    leqno: {
      type: "boolean",
      description: "Render display math in leqno style (left-justified tags)."
    },
    fleqn: {
      type: "boolean",
      description: "Render display math flush left."
    },
    throwOnError: {
      type: "boolean",
      default: !0,
      cli: "-t, --no-throw-on-error",
      cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
    },
    errorColor: {
      type: "string",
      default: "#cc0000",
      cli: "-c, --error-color <color>",
      cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
      cliProcessor: e => "#" + e
    },
    macros: {
      type: "object",
      cli: "-m, --macro <def>",
      cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
      cliDefault: [],
      cliProcessor: (e, t) => (t.push(e), t)
    },
    minRuleThickness: {
      type: "number",
      description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
      processor: e => Math.max(0, e),
      cli: "--min-rule-thickness <size>",
      cliProcessor: parseFloat
    },
    colorIsTextColor: {
      type: "boolean",
      description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
      cli: "-b, --color-is-text-color"
    },
    strict: {
      type: [{
        enum: ["warn", "ignore", "error"]
      }, "boolean", "function"],
      description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
      cli: "-S, --strict",
      cliDefault: !1
    },
    trust: {
      type: ["boolean", "function"],
      description: "Trust the input, enabling all HTML features such as \\url.",
      cli: "-T, --trust"
    },
    maxSize: {
      type: "number",
      default: 1 / 0,
      description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
      processor: e => Math.max(0, e),
      cli: "-s, --max-size <n>",
      cliProcessor: parseInt
    },
    maxExpand: {
      type: "number",
      default: 1e3,
      description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
      processor: e => Math.max(0, e),
      cli: "-e, --max-expand <n>",
      cliProcessor: e => e === "Infinity" ? 1 / 0 : parseInt(e)
    },
    globalGroup: {
      type: "boolean",
      cli: !1
    }
  };
function o4(e) {
  if (typeof e != "string") return e.enum[0];
  switch (e) {
    case "boolean":
      return !1;
    case "string":
      return "";
    case "number":
      return 0;
    case "object":
      return {};
    default:
      throw new Error("Unexpected schema type; settings must declare an explicit default.");
  }
}
function l4(e) {
  if (Object.prototype.hasOwnProperty.call(e, "default") && e.default !== void 0) return e.default;
  var t = Array.isArray(e.type) ? e.type[0] : e.type;
  return o4(t);
}
function u4(e, t, n, r) {
  var a = Object.prototype.hasOwnProperty.call(n, t) ? n[t] : void 0,
    i = Object.prototype.hasOwnProperty.call(r, "processor") ? r.processor : void 0;
  e[t] = a !== void 0 ? i ? i(a) : a : l4(r);
}
class ss {
  constructor(t) {
    t === void 0 && (t = {}), this.displayMode = void 0, this.output = void 0, this.leqno = void 0, this.fleqn = void 0, this.throwOnError = void 0, this.errorColor = void 0, this.macros = void 0, this.minRuleThickness = void 0, this.colorIsTextColor = void 0, this.strict = void 0, this.trust = void 0, this.maxSize = void 0, this.maxExpand = void 0, this.globalGroup = void 0, t = t || {};
    for (var n of Object.keys(Si)) {
      var r = Si[n];
      r && u4(this, n, t, r);
    }
  }
  reportNonstrict(t, n, r) {
    var a = this.strict;
    if (typeof a == "function" && (a = a(t, n, r)), !(!a || a === "ignore")) {
      if (a === !0 || a === "error") throw new D("LaTeX-incompatible input and strict mode is set to 'error': " + (n + " [" + t + "]"), r);
      a === "warn" ? typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (n + " [" + t + "]")) : typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + a + "': " + n + " [" + t + "]"));
    }
  }
  useStrictBehavior(t, n, r) {
    var a = this.strict;
    if (typeof a == "function") try {
      a = a(t, n, r);
    } catch {
      a = "error";
    }
    return !a || a === "ignore" ? !1 : a === !0 || a === "error" ? !0 : a === "warn" ? (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (n + " [" + t + "]")), !1) : (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + a + "': " + n + " [" + t + "]")), !1);
  }
  isTrusted(t) {
    if ("url" in t && t.url && !t.protocol) {
      var n = s4(t.url);
      if (n == null) return !1;
      t.protocol = n;
    }
    var r = typeof this.trust == "function" ? this.trust(t) : this.trust;
    return !!r;
  }
}
class Pt {
  constructor(t, n, r) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = t, this.size = n, this.cramped = r;
  }
  sup() {
    return yt[c4[this.id]];
  }
  sub() {
    return yt[m4[this.id]];
  }
  fracNum() {
    return yt[h4[this.id]];
  }
  fracDen() {
    return yt[p4[this.id]];
  }
  cramp() {
    return yt[d4[this.id]];
  }
  text() {
    return yt[f4[this.id]];
  }
  isTight() {
    return this.size >= 2;
  }
}
var os = 0,
  Qr = 1,
  Sn = 2,
  It = 3,
  Jn = 4,
  ut = 5,
  An = 6,
  He = 7,
  yt = [new Pt(os, 0, !1), new Pt(Qr, 0, !0), new Pt(Sn, 1, !1), new Pt(It, 1, !0), new Pt(Jn, 2, !1), new Pt(ut, 2, !0), new Pt(An, 3, !1), new Pt(He, 3, !0)],
  c4 = [Jn, ut, Jn, ut, An, He, An, He],
  m4 = [ut, ut, ut, ut, He, He, He, He],
  h4 = [Sn, It, Jn, ut, An, He, An, He],
  p4 = [It, It, ut, ut, He, He, He, He],
  d4 = [Qr, Qr, It, It, ut, ut, He, He],
  f4 = [os, Qr, Sn, It, Sn, It, Sn, It],
  ee = {
    DISPLAY: yt[os],
    TEXT: yt[Sn],
    SCRIPT: yt[Jn],
    SCRIPTSCRIPT: yt[An]
  },
  Ai = [{
    name: "latin",
    blocks: [[256, 591], [768, 879]]
  }, {
    name: "cyrillic",
    blocks: [[1024, 1279]]
  }, {
    name: "armenian",
    blocks: [[1328, 1423]]
  }, {
    name: "brahmic",
    blocks: [[2304, 4255]]
  }, {
    name: "georgian",
    blocks: [[4256, 4351]]
  }, {
    name: "cjk",
    blocks: [[12288, 12543], [19968, 40879], [65280, 65376]]
  }, {
    name: "hangul",
    blocks: [[44032, 55215]]
  }];
function g4(e) {
  for (var t = 0; t < Ai.length; t++) for (var n = Ai[t], r = 0; r < n.blocks.length; r++) {
    var a = n.blocks[r];
    if (e >= a[0] && e <= a[1]) return n.name;
  }
  return null;
}
var Lr = [];
Ai.forEach(e => e.blocks.forEach(t => Lr.push(...t)));
function Y0(e) {
  for (var t = 0; t < Lr.length; t += 2) if (e >= Lr[t] && e <= Lr[t + 1]) return !0;
  return !1;
}
var Ee = e => e + " " + e,
  xn = 80,
  b4 = function (t, n) {
    return "M95," + (622 + t + n) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + t / 2.075 + " -" + t + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + t) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + t) + " " + n + "h400000v" + (40 + t) + "h-400000z";
  },
  y4 = function (t, n) {
    return "M263," + (601 + t + n) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + t / 2.084 + " -" + t + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + t) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + t) + " " + n + "h400000v" + (40 + t) + "h-400000z";
  },
  v4 = function (t, n) {
    return "M983 " + (10 + t + n) + `
l` + t / 3.13 + " -" + t + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + t) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + t) + " " + n + "h400000v" + (40 + t) + "h-400000z";
  },
  w4 = function (t, n) {
    return "M424," + (2398 + t + n) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + t / 4.223 + " -" + t + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + t) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + t) + " " + n + `
h400000v` + (40 + t) + "h-400000z";
  },
  x4 = function (t, n) {
    return "M473," + (2713 + t + n) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + t / 5.298 + " -" + t + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + t) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + t) + " " + n + "h400000v" + (40 + t) + "H1017.7z";
  },
  k4 = function (t) {
    var n = t / 2;
    return "M400000 " + t + " H0 L" + n + " 0 l65 45 L145 " + (t - 80) + " H400000z";
  },
  _4 = function (t, n, r) {
    var a = r - 54 - n - t;
    return "M702 " + (t + n) + "H400000" + (40 + t) + `
H742v` + a + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + n + "H400000v" + (40 + t) + "H742z";
  },
  $4 = function (t, n, r) {
    n = 1e3 * n;
    var a = "";
    switch (t) {
      case "sqrtMain":
        a = b4(n, xn);
        break;
      case "sqrtSize1":
        a = y4(n, xn);
        break;
      case "sqrtSize2":
        a = v4(n, xn);
        break;
      case "sqrtSize3":
        a = w4(n, xn);
        break;
      case "sqrtSize4":
        a = x4(n, xn);
        break;
      case "sqrtTall":
        a = _4(n, xn, r);
    }
    return a;
  },
  C4 = function (t, n) {
    switch (t) {
      case "⎜":
        return Ee("M291 0 H417 V" + n + " H291z");
      case "∣":
        return Ee("M145 0 H188 V" + n + " H145z");
      case "∥":
        return Ee("M145 0 H188 V" + n + " H145z") + Ee("M367 0 H410 V" + n + " H367z");
      case "⎟":
        return Ee("M457 0 H583 V" + n + " H457z");
      case "⎢":
        return Ee("M319 0 H403 V" + n + " H319z");
      case "⎥":
        return Ee("M263 0 H347 V" + n + " H263z");
      case "⎪":
        return Ee("M384 0 H504 V" + n + " H384z");
      case "⏐":
        return Ee("M312 0 H355 V" + n + " H312z");
      case "‖":
        return Ee("M257 0 H300 V" + n + " H257z") + Ee("M478 0 H521 V" + n + " H478z");
      default:
        return "";
    }
  },
  Eo = {
    doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
    doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
    leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
    leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
    leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
    leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
    leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
    leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
    leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
    leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
    leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
    lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
    leftlinesegment: Ee("M40 281 V428 H0 V94 H40 V241 H400000 v40z"),
    leftbracketunder: Ee("M0 0 h120 V290 H399995 v120 H0z"),
    leftbracketover: Ee("M0 440 h120 V150 H399995 v-120 H0z"),
    leftmapsto: Ee("M40 281 V448H0V74H40V241H400000v40z"),
    leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
    longequal: Ee("M0 50 h400000 v40H0z m0 194h40000v40H0z"),
    midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
    midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
    oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
    oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
    oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
    oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
    rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
    rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
    rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
    rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
    rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
    rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
    rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
    rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
    rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
    righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
    rightlinesegment: Ee("M399960 241 V94 h40 V428 h-40 V281 H0 v-40z"),
    rightbracketunder: Ee("M399995 0 h-120 V290 H0 v120 H400000z"),
    rightbracketover: Ee("M399995 440 h-120 V150 H0 v-120 H399995z"),
    rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
    twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
    twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
    tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
    tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
    tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
    tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
    vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
    widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
    widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
    widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
    widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
    widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
    widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
    widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
    widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
    baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
    rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
    baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
    rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
    shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
    shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
  },
  S4 = function (t, n) {
    switch (t) {
      case "lbrack":
        return "M403 1759 V84 H666 V0 H319 V1759 v" + n + ` v1759 v84 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + n + " v1759 v84 h84z";
      case "rbrack":
        return "M347 1759 V0 H0 V84 H263 V1759 v" + n + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + n + " v1759 h84z";
      case "vert":
        return "M145 15 v585 v" + n + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -n + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + n + " v585 h43z";
      case "doublevert":
        return "M145 15 v585 v" + n + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -n + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + n + ` v585 h43z
M367 15 v585 v` + n + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -n + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + n + " v585 h43z";
      case "lfloor":
        return "M319 602 V0 H403 V602 v" + n + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + n + " v1715 H319z";
      case "rfloor":
        return "M319 602 V0 H403 V602 v" + n + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + n + " v1715 H319z";
      case "lceil":
        return "M403 1759 V84 H666 V0 H319 V1759 v" + n + ` v602 h84z
M403 1759 V0 H319 V1759 v` + n + " v602 h84z";
      case "rceil":
        return "M347 1759 V0 H0 V84 H263 V1759 v" + n + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + n + " v602 h84z";
      case "lparen":
        return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (n + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (n + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
      case "rparen":
        return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (n + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (n + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
      default:
        throw new Error("Unknown stretchy delimiter.");
    }
  };
function A4(e) {
  return "toText" in e;
}
class Nn {
  constructor(t) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = t, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(t) {
    return this.classes.includes(t);
  }
  toNode() {
    for (var t = document.createDocumentFragment(), n = 0; n < this.children.length; n++) t.appendChild(this.children[n].toNode());
    return t;
  }
  toMarkup() {
    for (var t = "", n = 0; n < this.children.length; n++) t += this.children[n].toMarkup();
    return t;
  }
  toText() {
    return this.children.map(t => {
      if (A4(t)) return t.toText();
      throw new Error("Expected MathDomNode with toText, got " + t.constructor.name);
    }).join("");
  }
}
var Ti = {
    pt: 1,
    mm: 7227 / 2540,
    cm: 7227 / 254,
    in: 72.27,
    bp: 803 / 800,
    pc: 12,
    dd: 1238 / 1157,
    cc: 14856 / 1157,
    nd: 685 / 642,
    nc: 1370 / 107,
    sp: 1 / 65536,
    px: 803 / 800
  },
  T4 = {
    ex: !0,
    em: !0,
    mu: !0
  },
  Z0 = function (t) {
    return typeof t != "string" && (t = t.unit), t in Ti || t in T4 || t === "ex";
  },
  we = function (t, n) {
    var r;
    if (t.unit in Ti) r = Ti[t.unit] / n.fontMetrics().ptPerEm / n.sizeMultiplier;else if (t.unit === "mu") r = n.fontMetrics().cssEmPerMu;else {
      var a;
      if (n.style.isTight() ? a = n.havingStyle(n.style.text()) : a = n, t.unit === "ex") r = a.fontMetrics().xHeight;else if (t.unit === "em") r = a.fontMetrics().quad;else throw new D("Invalid unit: '" + t.unit + "'");
      a !== n && (r *= a.sizeMultiplier / n.sizeMultiplier);
    }
    return Math.min(t.number * r, n.maxSize);
  },
  P = function (t) {
    return +t.toFixed(4) + "em";
  },
  Ut = function (t) {
    return t.filter(n => n).join(" ");
  },
  ls = function (t) {
    var n = "";
    for (var r of Object.keys(t)) {
      var a = t[r];
      a !== void 0 && (n += n4(r) + ":" + a + ";");
    }
    return n;
  },
  K0 = function (t, n, r) {
    if (this.classes = t || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = r || {}, n) {
      n.style.isTight() && this.classes.push("mtight");
      var a = n.getColor();
      a && (this.style.color = a);
    }
  },
  Q0 = function (t) {
    var n = document.createElement(t);
    n.className = Ut(this.classes), Object.assign(n.style, this.style);
    for (var r of Object.keys(this.attributes)) n.setAttribute(r, this.attributes[r]);
    for (var a = 0; a < this.children.length; a++) n.appendChild(this.children[a].toNode());
    return n;
  },
  E4 = /[\s"'>/=\x00-\x1f]/,
  J0 = function (t) {
    var n = "<" + t;
    this.classes.length && (n += ' class="' + Pe(Ut(this.classes)) + '"');
    var r = ls(this.style);
    r && (n += ' style="' + Pe(r) + '"');
    for (var a of Object.keys(this.attributes)) {
      if (E4.test(a)) throw new D("Invalid attribute name '" + a + "'");
      n += " " + a + '="' + Pe(this.attributes[a]) + '"';
    }
    n += ">";
    for (var i = 0; i < this.children.length; i++) n += this.children[i].toMarkup();
    return n += "</" + t + ">", n;
  };
class Rn {
  constructor(t, n, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, this.italic = void 0, K0.call(this, t, r, a), this.children = n || [];
  }
  setAttribute(t, n) {
    this.attributes[t] = n;
  }
  hasClass(t) {
    return this.classes.includes(t);
  }
  toNode() {
    return Q0.call(this, "span");
  }
  toMarkup() {
    return J0.call(this, "span");
  }
}
class ma {
  constructor(t, n, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, K0.call(this, n, a), this.children = r || [], this.setAttribute("href", t);
  }
  setAttribute(t, n) {
    this.attributes[t] = n;
  }
  hasClass(t) {
    return this.classes.includes(t);
  }
  toNode() {
    return Q0.call(this, "a");
  }
  toMarkup() {
    return J0.call(this, "a");
  }
}
class M4 {
  constructor(t, n, r) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = n, this.src = t, this.classes = ["mord"], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = r;
  }
  hasClass(t) {
    return this.classes.includes(t);
  }
  toNode() {
    var t = document.createElement("img");
    return t.src = this.src, t.alt = this.alt, t.className = "mord", Object.assign(t.style, this.style), t;
  }
  toMarkup() {
    var t = '<img src="' + Pe(this.src) + '"' + (' alt="' + Pe(this.alt) + '"'),
      n = ls(this.style);
    return n && (t += ' style="' + Pe(n) + '"'), t += "'/>", t;
  }
}
var z4 = {
  î: "ı̂",
  ï: "ı̈",
  í: "ı́",
  ì: "ı̀"
};
class tt {
  constructor(t, n, r, a, i, s, o, l) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = t, this.height = n || 0, this.depth = r || 0, this.italic = a || 0, this.skew = i || 0, this.width = s || 0, this.classes = o || [], this.style = l || {}, this.maxFontSize = 0;
    var u = g4(this.text.charCodeAt(0));
    u && this.classes.push(u + "_fallback"), /[îïíì]/.test(this.text) && (this.text = z4[this.text]);
  }
  hasClass(t) {
    return this.classes.includes(t);
  }
  toNode() {
    var t = document.createTextNode(this.text),
      n = null;
    return this.italic > 0 && (n = document.createElement("span"), n.style.marginRight = P(this.italic)), this.classes.length > 0 && (n = n || document.createElement("span"), n.className = Ut(this.classes)), Object.keys(this.style).length > 0 && (n = n || document.createElement("span"), Object.assign(n.style, this.style)), n ? (n.appendChild(t), n) : t;
  }
  toMarkup() {
    var t = !1,
      n = "<span";
    this.classes.length && (t = !0, n += ' class="', n += Pe(Ut(this.classes)), n += '"');
    var r = "";
    this.italic > 0 && (r += "margin-right:" + P(this.italic) + ";"), r += ls(this.style), r && (t = !0, n += ' style="' + Pe(r) + '"');
    var a = Pe(this.text);
    return t ? (n += ">", n += a, n += "</span>", n) : a;
  }
}
class Nt {
  constructor(t, n) {
    this.children = void 0, this.attributes = void 0, this.children = t || [], this.attributes = n || {};
  }
  toNode() {
    var t = "http://www.w3.org/2000/svg",
      n = document.createElementNS(t, "svg");
    for (var r of Object.keys(this.attributes)) n.setAttribute(r, this.attributes[r]);
    for (var a = 0; a < this.children.length; a++) n.appendChild(this.children[a].toNode());
    return n;
  }
  toMarkup() {
    var t = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var n of Object.keys(this.attributes)) t += " " + n + '="' + Pe(this.attributes[n]) + '"';
    t += ">";
    for (var r = 0; r < this.children.length; r++) t += this.children[r].toMarkup();
    return t += "</svg>", t;
  }
}
class Wt {
  constructor(t, n) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = t, this.alternate = n;
  }
  toNode() {
    var t = "http://www.w3.org/2000/svg",
      n = document.createElementNS(t, "path");
    return this.alternate ? n.setAttribute("d", this.alternate) : n.setAttribute("d", Eo[this.pathName]), n;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + Pe(this.alternate) + '"/>' : '<path d="' + Pe(Eo[this.pathName]) + '"/>';
  }
}
class Ei {
  constructor(t) {
    this.attributes = void 0, this.attributes = t || {};
  }
  toNode() {
    var t = "http://www.w3.org/2000/svg",
      n = document.createElementNS(t, "line");
    for (var r of Object.keys(this.attributes)) n.setAttribute(r, this.attributes[r]);
    return n;
  }
  toMarkup() {
    var t = "<line";
    for (var n of Object.keys(this.attributes)) t += " " + n + '="' + Pe(this.attributes[n]) + '"';
    return t += "/>", t;
  }
}
function I4(e) {
  if (e instanceof tt) return e;
  throw new Error("Expected symbolNode but got " + String(e) + ".");
}
function N4(e) {
  if (e instanceof Rn) return e;
  throw new Error("Expected span<HtmlDomNode> but got " + String(e) + ".");
}
var R4 = e => e instanceof Rn || e instanceof ma || e instanceof Nn,
  vt = {
    "AMS-Regular": {
      32: [0, 0, 0, 0, .25],
      65: [0, .68889, 0, 0, .72222],
      66: [0, .68889, 0, 0, .66667],
      67: [0, .68889, 0, 0, .72222],
      68: [0, .68889, 0, 0, .72222],
      69: [0, .68889, 0, 0, .66667],
      70: [0, .68889, 0, 0, .61111],
      71: [0, .68889, 0, 0, .77778],
      72: [0, .68889, 0, 0, .77778],
      73: [0, .68889, 0, 0, .38889],
      74: [.16667, .68889, 0, 0, .5],
      75: [0, .68889, 0, 0, .77778],
      76: [0, .68889, 0, 0, .66667],
      77: [0, .68889, 0, 0, .94445],
      78: [0, .68889, 0, 0, .72222],
      79: [.16667, .68889, 0, 0, .77778],
      80: [0, .68889, 0, 0, .61111],
      81: [.16667, .68889, 0, 0, .77778],
      82: [0, .68889, 0, 0, .72222],
      83: [0, .68889, 0, 0, .55556],
      84: [0, .68889, 0, 0, .66667],
      85: [0, .68889, 0, 0, .72222],
      86: [0, .68889, 0, 0, .72222],
      87: [0, .68889, 0, 0, 1],
      88: [0, .68889, 0, 0, .72222],
      89: [0, .68889, 0, 0, .72222],
      90: [0, .68889, 0, 0, .66667],
      107: [0, .68889, 0, 0, .55556],
      160: [0, 0, 0, 0, .25],
      165: [0, .675, .025, 0, .75],
      174: [.15559, .69224, 0, 0, .94666],
      240: [0, .68889, 0, 0, .55556],
      295: [0, .68889, 0, 0, .54028],
      710: [0, .825, 0, 0, 2.33334],
      732: [0, .9, 0, 0, 2.33334],
      770: [0, .825, 0, 0, 2.33334],
      771: [0, .9, 0, 0, 2.33334],
      989: [.08167, .58167, 0, 0, .77778],
      1008: [0, .43056, .04028, 0, .66667],
      8245: [0, .54986, 0, 0, .275],
      8463: [0, .68889, 0, 0, .54028],
      8487: [0, .68889, 0, 0, .72222],
      8498: [0, .68889, 0, 0, .55556],
      8502: [0, .68889, 0, 0, .66667],
      8503: [0, .68889, 0, 0, .44445],
      8504: [0, .68889, 0, 0, .66667],
      8513: [0, .68889, 0, 0, .63889],
      8592: [-.03598, .46402, 0, 0, .5],
      8594: [-.03598, .46402, 0, 0, .5],
      8602: [-.13313, .36687, 0, 0, 1],
      8603: [-.13313, .36687, 0, 0, 1],
      8606: [.01354, .52239, 0, 0, 1],
      8608: [.01354, .52239, 0, 0, 1],
      8610: [.01354, .52239, 0, 0, 1.11111],
      8611: [.01354, .52239, 0, 0, 1.11111],
      8619: [0, .54986, 0, 0, 1],
      8620: [0, .54986, 0, 0, 1],
      8621: [-.13313, .37788, 0, 0, 1.38889],
      8622: [-.13313, .36687, 0, 0, 1],
      8624: [0, .69224, 0, 0, .5],
      8625: [0, .69224, 0, 0, .5],
      8630: [0, .43056, 0, 0, 1],
      8631: [0, .43056, 0, 0, 1],
      8634: [.08198, .58198, 0, 0, .77778],
      8635: [.08198, .58198, 0, 0, .77778],
      8638: [.19444, .69224, 0, 0, .41667],
      8639: [.19444, .69224, 0, 0, .41667],
      8642: [.19444, .69224, 0, 0, .41667],
      8643: [.19444, .69224, 0, 0, .41667],
      8644: [.1808, .675, 0, 0, 1],
      8646: [.1808, .675, 0, 0, 1],
      8647: [.1808, .675, 0, 0, 1],
      8648: [.19444, .69224, 0, 0, .83334],
      8649: [.1808, .675, 0, 0, 1],
      8650: [.19444, .69224, 0, 0, .83334],
      8651: [.01354, .52239, 0, 0, 1],
      8652: [.01354, .52239, 0, 0, 1],
      8653: [-.13313, .36687, 0, 0, 1],
      8654: [-.13313, .36687, 0, 0, 1],
      8655: [-.13313, .36687, 0, 0, 1],
      8666: [.13667, .63667, 0, 0, 1],
      8667: [.13667, .63667, 0, 0, 1],
      8669: [-.13313, .37788, 0, 0, 1],
      8672: [-.064, .437, 0, 0, 1.334],
      8674: [-.064, .437, 0, 0, 1.334],
      8705: [0, .825, 0, 0, .5],
      8708: [0, .68889, 0, 0, .55556],
      8709: [.08167, .58167, 0, 0, .77778],
      8717: [0, .43056, 0, 0, .42917],
      8722: [-.03598, .46402, 0, 0, .5],
      8724: [.08198, .69224, 0, 0, .77778],
      8726: [.08167, .58167, 0, 0, .77778],
      8733: [0, .69224, 0, 0, .77778],
      8736: [0, .69224, 0, 0, .72222],
      8737: [0, .69224, 0, 0, .72222],
      8738: [.03517, .52239, 0, 0, .72222],
      8739: [.08167, .58167, 0, 0, .22222],
      8740: [.25142, .74111, 0, 0, .27778],
      8741: [.08167, .58167, 0, 0, .38889],
      8742: [.25142, .74111, 0, 0, .5],
      8756: [0, .69224, 0, 0, .66667],
      8757: [0, .69224, 0, 0, .66667],
      8764: [-.13313, .36687, 0, 0, .77778],
      8765: [-.13313, .37788, 0, 0, .77778],
      8769: [-.13313, .36687, 0, 0, .77778],
      8770: [-.03625, .46375, 0, 0, .77778],
      8774: [.30274, .79383, 0, 0, .77778],
      8776: [-.01688, .48312, 0, 0, .77778],
      8778: [.08167, .58167, 0, 0, .77778],
      8782: [.06062, .54986, 0, 0, .77778],
      8783: [.06062, .54986, 0, 0, .77778],
      8785: [.08198, .58198, 0, 0, .77778],
      8786: [.08198, .58198, 0, 0, .77778],
      8787: [.08198, .58198, 0, 0, .77778],
      8790: [0, .69224, 0, 0, .77778],
      8791: [.22958, .72958, 0, 0, .77778],
      8796: [.08198, .91667, 0, 0, .77778],
      8806: [.25583, .75583, 0, 0, .77778],
      8807: [.25583, .75583, 0, 0, .77778],
      8808: [.25142, .75726, 0, 0, .77778],
      8809: [.25142, .75726, 0, 0, .77778],
      8812: [.25583, .75583, 0, 0, .5],
      8814: [.20576, .70576, 0, 0, .77778],
      8815: [.20576, .70576, 0, 0, .77778],
      8816: [.30274, .79383, 0, 0, .77778],
      8817: [.30274, .79383, 0, 0, .77778],
      8818: [.22958, .72958, 0, 0, .77778],
      8819: [.22958, .72958, 0, 0, .77778],
      8822: [.1808, .675, 0, 0, .77778],
      8823: [.1808, .675, 0, 0, .77778],
      8828: [.13667, .63667, 0, 0, .77778],
      8829: [.13667, .63667, 0, 0, .77778],
      8830: [.22958, .72958, 0, 0, .77778],
      8831: [.22958, .72958, 0, 0, .77778],
      8832: [.20576, .70576, 0, 0, .77778],
      8833: [.20576, .70576, 0, 0, .77778],
      8840: [.30274, .79383, 0, 0, .77778],
      8841: [.30274, .79383, 0, 0, .77778],
      8842: [.13597, .63597, 0, 0, .77778],
      8843: [.13597, .63597, 0, 0, .77778],
      8847: [.03517, .54986, 0, 0, .77778],
      8848: [.03517, .54986, 0, 0, .77778],
      8858: [.08198, .58198, 0, 0, .77778],
      8859: [.08198, .58198, 0, 0, .77778],
      8861: [.08198, .58198, 0, 0, .77778],
      8862: [0, .675, 0, 0, .77778],
      8863: [0, .675, 0, 0, .77778],
      8864: [0, .675, 0, 0, .77778],
      8865: [0, .675, 0, 0, .77778],
      8872: [0, .69224, 0, 0, .61111],
      8873: [0, .69224, 0, 0, .72222],
      8874: [0, .69224, 0, 0, .88889],
      8876: [0, .68889, 0, 0, .61111],
      8877: [0, .68889, 0, 0, .61111],
      8878: [0, .68889, 0, 0, .72222],
      8879: [0, .68889, 0, 0, .72222],
      8882: [.03517, .54986, 0, 0, .77778],
      8883: [.03517, .54986, 0, 0, .77778],
      8884: [.13667, .63667, 0, 0, .77778],
      8885: [.13667, .63667, 0, 0, .77778],
      8888: [0, .54986, 0, 0, 1.11111],
      8890: [.19444, .43056, 0, 0, .55556],
      8891: [.19444, .69224, 0, 0, .61111],
      8892: [.19444, .69224, 0, 0, .61111],
      8901: [0, .54986, 0, 0, .27778],
      8903: [.08167, .58167, 0, 0, .77778],
      8905: [.08167, .58167, 0, 0, .77778],
      8906: [.08167, .58167, 0, 0, .77778],
      8907: [0, .69224, 0, 0, .77778],
      8908: [0, .69224, 0, 0, .77778],
      8909: [-.03598, .46402, 0, 0, .77778],
      8910: [0, .54986, 0, 0, .76042],
      8911: [0, .54986, 0, 0, .76042],
      8912: [.03517, .54986, 0, 0, .77778],
      8913: [.03517, .54986, 0, 0, .77778],
      8914: [0, .54986, 0, 0, .66667],
      8915: [0, .54986, 0, 0, .66667],
      8916: [0, .69224, 0, 0, .66667],
      8918: [.0391, .5391, 0, 0, .77778],
      8919: [.0391, .5391, 0, 0, .77778],
      8920: [.03517, .54986, 0, 0, 1.33334],
      8921: [.03517, .54986, 0, 0, 1.33334],
      8922: [.38569, .88569, 0, 0, .77778],
      8923: [.38569, .88569, 0, 0, .77778],
      8926: [.13667, .63667, 0, 0, .77778],
      8927: [.13667, .63667, 0, 0, .77778],
      8928: [.30274, .79383, 0, 0, .77778],
      8929: [.30274, .79383, 0, 0, .77778],
      8934: [.23222, .74111, 0, 0, .77778],
      8935: [.23222, .74111, 0, 0, .77778],
      8936: [.23222, .74111, 0, 0, .77778],
      8937: [.23222, .74111, 0, 0, .77778],
      8938: [.20576, .70576, 0, 0, .77778],
      8939: [.20576, .70576, 0, 0, .77778],
      8940: [.30274, .79383, 0, 0, .77778],
      8941: [.30274, .79383, 0, 0, .77778],
      8994: [.19444, .69224, 0, 0, .77778],
      8995: [.19444, .69224, 0, 0, .77778],
      9416: [.15559, .69224, 0, 0, .90222],
      9484: [0, .69224, 0, 0, .5],
      9488: [0, .69224, 0, 0, .5],
      9492: [0, .37788, 0, 0, .5],
      9496: [0, .37788, 0, 0, .5],
      9585: [.19444, .68889, 0, 0, .88889],
      9586: [.19444, .74111, 0, 0, .88889],
      9632: [0, .675, 0, 0, .77778],
      9633: [0, .675, 0, 0, .77778],
      9650: [0, .54986, 0, 0, .72222],
      9651: [0, .54986, 0, 0, .72222],
      9654: [.03517, .54986, 0, 0, .77778],
      9660: [0, .54986, 0, 0, .72222],
      9661: [0, .54986, 0, 0, .72222],
      9664: [.03517, .54986, 0, 0, .77778],
      9674: [.11111, .69224, 0, 0, .66667],
      9733: [.19444, .69224, 0, 0, .94445],
      10003: [0, .69224, 0, 0, .83334],
      10016: [0, .69224, 0, 0, .83334],
      10731: [.11111, .69224, 0, 0, .66667],
      10846: [.19444, .75583, 0, 0, .61111],
      10877: [.13667, .63667, 0, 0, .77778],
      10878: [.13667, .63667, 0, 0, .77778],
      10885: [.25583, .75583, 0, 0, .77778],
      10886: [.25583, .75583, 0, 0, .77778],
      10887: [.13597, .63597, 0, 0, .77778],
      10888: [.13597, .63597, 0, 0, .77778],
      10889: [.26167, .75726, 0, 0, .77778],
      10890: [.26167, .75726, 0, 0, .77778],
      10891: [.48256, .98256, 0, 0, .77778],
      10892: [.48256, .98256, 0, 0, .77778],
      10901: [.13667, .63667, 0, 0, .77778],
      10902: [.13667, .63667, 0, 0, .77778],
      10933: [.25142, .75726, 0, 0, .77778],
      10934: [.25142, .75726, 0, 0, .77778],
      10935: [.26167, .75726, 0, 0, .77778],
      10936: [.26167, .75726, 0, 0, .77778],
      10937: [.26167, .75726, 0, 0, .77778],
      10938: [.26167, .75726, 0, 0, .77778],
      10949: [.25583, .75583, 0, 0, .77778],
      10950: [.25583, .75583, 0, 0, .77778],
      10955: [.28481, .79383, 0, 0, .77778],
      10956: [.28481, .79383, 0, 0, .77778],
      57350: [.08167, .58167, 0, 0, .22222],
      57351: [.08167, .58167, 0, 0, .38889],
      57352: [.08167, .58167, 0, 0, .77778],
      57353: [0, .43056, .04028, 0, .66667],
      57356: [.25142, .75726, 0, 0, .77778],
      57357: [.25142, .75726, 0, 0, .77778],
      57358: [.41951, .91951, 0, 0, .77778],
      57359: [.30274, .79383, 0, 0, .77778],
      57360: [.30274, .79383, 0, 0, .77778],
      57361: [.41951, .91951, 0, 0, .77778],
      57366: [.25142, .75726, 0, 0, .77778],
      57367: [.25142, .75726, 0, 0, .77778],
      57368: [.25142, .75726, 0, 0, .77778],
      57369: [.25142, .75726, 0, 0, .77778],
      57370: [.13597, .63597, 0, 0, .77778],
      57371: [.13597, .63597, 0, 0, .77778]
    },
    "Caligraphic-Regular": {
      32: [0, 0, 0, 0, .25],
      65: [0, .68333, 0, .19445, .79847],
      66: [0, .68333, .03041, .13889, .65681],
      67: [0, .68333, .05834, .13889, .52653],
      68: [0, .68333, .02778, .08334, .77139],
      69: [0, .68333, .08944, .11111, .52778],
      70: [0, .68333, .09931, .11111, .71875],
      71: [.09722, .68333, .0593, .11111, .59487],
      72: [0, .68333, .00965, .11111, .84452],
      73: [0, .68333, .07382, 0, .54452],
      74: [.09722, .68333, .18472, .16667, .67778],
      75: [0, .68333, .01445, .05556, .76195],
      76: [0, .68333, 0, .13889, .68972],
      77: [0, .68333, 0, .13889, 1.2009],
      78: [0, .68333, .14736, .08334, .82049],
      79: [0, .68333, .02778, .11111, .79611],
      80: [0, .68333, .08222, .08334, .69556],
      81: [.09722, .68333, 0, .11111, .81667],
      82: [0, .68333, 0, .08334, .8475],
      83: [0, .68333, .075, .13889, .60556],
      84: [0, .68333, .25417, 0, .54464],
      85: [0, .68333, .09931, .08334, .62583],
      86: [0, .68333, .08222, 0, .61278],
      87: [0, .68333, .08222, .08334, .98778],
      88: [0, .68333, .14643, .13889, .7133],
      89: [.09722, .68333, .08222, .08334, .66834],
      90: [0, .68333, .07944, .13889, .72473],
      160: [0, 0, 0, 0, .25]
    },
    "Fraktur-Regular": {
      32: [0, 0, 0, 0, .25],
      33: [0, .69141, 0, 0, .29574],
      34: [0, .69141, 0, 0, .21471],
      38: [0, .69141, 0, 0, .73786],
      39: [0, .69141, 0, 0, .21201],
      40: [.24982, .74947, 0, 0, .38865],
      41: [.24982, .74947, 0, 0, .38865],
      42: [0, .62119, 0, 0, .27764],
      43: [.08319, .58283, 0, 0, .75623],
      44: [0, .10803, 0, 0, .27764],
      45: [.08319, .58283, 0, 0, .75623],
      46: [0, .10803, 0, 0, .27764],
      47: [.24982, .74947, 0, 0, .50181],
      48: [0, .47534, 0, 0, .50181],
      49: [0, .47534, 0, 0, .50181],
      50: [0, .47534, 0, 0, .50181],
      51: [.18906, .47534, 0, 0, .50181],
      52: [.18906, .47534, 0, 0, .50181],
      53: [.18906, .47534, 0, 0, .50181],
      54: [0, .69141, 0, 0, .50181],
      55: [.18906, .47534, 0, 0, .50181],
      56: [0, .69141, 0, 0, .50181],
      57: [.18906, .47534, 0, 0, .50181],
      58: [0, .47534, 0, 0, .21606],
      59: [.12604, .47534, 0, 0, .21606],
      61: [-.13099, .36866, 0, 0, .75623],
      63: [0, .69141, 0, 0, .36245],
      65: [0, .69141, 0, 0, .7176],
      66: [0, .69141, 0, 0, .88397],
      67: [0, .69141, 0, 0, .61254],
      68: [0, .69141, 0, 0, .83158],
      69: [0, .69141, 0, 0, .66278],
      70: [.12604, .69141, 0, 0, .61119],
      71: [0, .69141, 0, 0, .78539],
      72: [.06302, .69141, 0, 0, .7203],
      73: [0, .69141, 0, 0, .55448],
      74: [.12604, .69141, 0, 0, .55231],
      75: [0, .69141, 0, 0, .66845],
      76: [0, .69141, 0, 0, .66602],
      77: [0, .69141, 0, 0, 1.04953],
      78: [0, .69141, 0, 0, .83212],
      79: [0, .69141, 0, 0, .82699],
      80: [.18906, .69141, 0, 0, .82753],
      81: [.03781, .69141, 0, 0, .82699],
      82: [0, .69141, 0, 0, .82807],
      83: [0, .69141, 0, 0, .82861],
      84: [0, .69141, 0, 0, .66899],
      85: [0, .69141, 0, 0, .64576],
      86: [0, .69141, 0, 0, .83131],
      87: [0, .69141, 0, 0, 1.04602],
      88: [0, .69141, 0, 0, .71922],
      89: [.18906, .69141, 0, 0, .83293],
      90: [.12604, .69141, 0, 0, .60201],
      91: [.24982, .74947, 0, 0, .27764],
      93: [.24982, .74947, 0, 0, .27764],
      94: [0, .69141, 0, 0, .49965],
      97: [0, .47534, 0, 0, .50046],
      98: [0, .69141, 0, 0, .51315],
      99: [0, .47534, 0, 0, .38946],
      100: [0, .62119, 0, 0, .49857],
      101: [0, .47534, 0, 0, .40053],
      102: [.18906, .69141, 0, 0, .32626],
      103: [.18906, .47534, 0, 0, .5037],
      104: [.18906, .69141, 0, 0, .52126],
      105: [0, .69141, 0, 0, .27899],
      106: [0, .69141, 0, 0, .28088],
      107: [0, .69141, 0, 0, .38946],
      108: [0, .69141, 0, 0, .27953],
      109: [0, .47534, 0, 0, .76676],
      110: [0, .47534, 0, 0, .52666],
      111: [0, .47534, 0, 0, .48885],
      112: [.18906, .52396, 0, 0, .50046],
      113: [.18906, .47534, 0, 0, .48912],
      114: [0, .47534, 0, 0, .38919],
      115: [0, .47534, 0, 0, .44266],
      116: [0, .62119, 0, 0, .33301],
      117: [0, .47534, 0, 0, .5172],
      118: [0, .52396, 0, 0, .5118],
      119: [0, .52396, 0, 0, .77351],
      120: [.18906, .47534, 0, 0, .38865],
      121: [.18906, .47534, 0, 0, .49884],
      122: [.18906, .47534, 0, 0, .39054],
      160: [0, 0, 0, 0, .25],
      8216: [0, .69141, 0, 0, .21471],
      8217: [0, .69141, 0, 0, .21471],
      58112: [0, .62119, 0, 0, .49749],
      58113: [0, .62119, 0, 0, .4983],
      58114: [.18906, .69141, 0, 0, .33328],
      58115: [.18906, .69141, 0, 0, .32923],
      58116: [.18906, .47534, 0, 0, .50343],
      58117: [0, .69141, 0, 0, .33301],
      58118: [0, .62119, 0, 0, .33409],
      58119: [0, .47534, 0, 0, .50073]
    },
    "Main-Bold": {
      32: [0, 0, 0, 0, .25],
      33: [0, .69444, 0, 0, .35],
      34: [0, .69444, 0, 0, .60278],
      35: [.19444, .69444, 0, 0, .95833],
      36: [.05556, .75, 0, 0, .575],
      37: [.05556, .75, 0, 0, .95833],
      38: [0, .69444, 0, 0, .89444],
      39: [0, .69444, 0, 0, .31944],
      40: [.25, .75, 0, 0, .44722],
      41: [.25, .75, 0, 0, .44722],
      42: [0, .75, 0, 0, .575],
      43: [.13333, .63333, 0, 0, .89444],
      44: [.19444, .15556, 0, 0, .31944],
      45: [0, .44444, 0, 0, .38333],
      46: [0, .15556, 0, 0, .31944],
      47: [.25, .75, 0, 0, .575],
      48: [0, .64444, 0, 0, .575],
      49: [0, .64444, 0, 0, .575],
      50: [0, .64444, 0, 0, .575],
      51: [0, .64444, 0, 0, .575],
      52: [0, .64444, 0, 0, .575],
      53: [0, .64444, 0, 0, .575],
      54: [0, .64444, 0, 0, .575],
      55: [0, .64444, 0, 0, .575],
      56: [0, .64444, 0, 0, .575],
      57: [0, .64444, 0, 0, .575],
      58: [0, .44444, 0, 0, .31944],
      59: [.19444, .44444, 0, 0, .31944],
      60: [.08556, .58556, 0, 0, .89444],
      61: [-.10889, .39111, 0, 0, .89444],
      62: [.08556, .58556, 0, 0, .89444],
      63: [0, .69444, 0, 0, .54305],
      64: [0, .69444, 0, 0, .89444],
      65: [0, .68611, 0, 0, .86944],
      66: [0, .68611, 0, 0, .81805],
      67: [0, .68611, 0, 0, .83055],
      68: [0, .68611, 0, 0, .88194],
      69: [0, .68611, 0, 0, .75555],
      70: [0, .68611, 0, 0, .72361],
      71: [0, .68611, 0, 0, .90416],
      72: [0, .68611, 0, 0, .9],
      73: [0, .68611, 0, 0, .43611],
      74: [0, .68611, 0, 0, .59444],
      75: [0, .68611, 0, 0, .90138],
      76: [0, .68611, 0, 0, .69166],
      77: [0, .68611, 0, 0, 1.09166],
      78: [0, .68611, 0, 0, .9],
      79: [0, .68611, 0, 0, .86388],
      80: [0, .68611, 0, 0, .78611],
      81: [.19444, .68611, 0, 0, .86388],
      82: [0, .68611, 0, 0, .8625],
      83: [0, .68611, 0, 0, .63889],
      84: [0, .68611, 0, 0, .8],
      85: [0, .68611, 0, 0, .88472],
      86: [0, .68611, .01597, 0, .86944],
      87: [0, .68611, .01597, 0, 1.18888],
      88: [0, .68611, 0, 0, .86944],
      89: [0, .68611, .02875, 0, .86944],
      90: [0, .68611, 0, 0, .70277],
      91: [.25, .75, 0, 0, .31944],
      92: [.25, .75, 0, 0, .575],
      93: [.25, .75, 0, 0, .31944],
      94: [0, .69444, 0, 0, .575],
      95: [.31, .13444, .03194, 0, .575],
      97: [0, .44444, 0, 0, .55902],
      98: [0, .69444, 0, 0, .63889],
      99: [0, .44444, 0, 0, .51111],
      100: [0, .69444, 0, 0, .63889],
      101: [0, .44444, 0, 0, .52708],
      102: [0, .69444, .10903, 0, .35139],
      103: [.19444, .44444, .01597, 0, .575],
      104: [0, .69444, 0, 0, .63889],
      105: [0, .69444, 0, 0, .31944],
      106: [.19444, .69444, 0, 0, .35139],
      107: [0, .69444, 0, 0, .60694],
      108: [0, .69444, 0, 0, .31944],
      109: [0, .44444, 0, 0, .95833],
      110: [0, .44444, 0, 0, .63889],
      111: [0, .44444, 0, 0, .575],
      112: [.19444, .44444, 0, 0, .63889],
      113: [.19444, .44444, 0, 0, .60694],
      114: [0, .44444, 0, 0, .47361],
      115: [0, .44444, 0, 0, .45361],
      116: [0, .63492, 0, 0, .44722],
      117: [0, .44444, 0, 0, .63889],
      118: [0, .44444, .01597, 0, .60694],
      119: [0, .44444, .01597, 0, .83055],
      120: [0, .44444, 0, 0, .60694],
      121: [.19444, .44444, .01597, 0, .60694],
      122: [0, .44444, 0, 0, .51111],
      123: [.25, .75, 0, 0, .575],
      124: [.25, .75, 0, 0, .31944],
      125: [.25, .75, 0, 0, .575],
      126: [.35, .34444, 0, 0, .575],
      160: [0, 0, 0, 0, .25],
      163: [0, .69444, 0, 0, .86853],
      168: [0, .69444, 0, 0, .575],
      172: [0, .44444, 0, 0, .76666],
      176: [0, .69444, 0, 0, .86944],
      177: [.13333, .63333, 0, 0, .89444],
      184: [.17014, 0, 0, 0, .51111],
      198: [0, .68611, 0, 0, 1.04166],
      215: [.13333, .63333, 0, 0, .89444],
      216: [.04861, .73472, 0, 0, .89444],
      223: [0, .69444, 0, 0, .59722],
      230: [0, .44444, 0, 0, .83055],
      247: [.13333, .63333, 0, 0, .89444],
      248: [.09722, .54167, 0, 0, .575],
      305: [0, .44444, 0, 0, .31944],
      338: [0, .68611, 0, 0, 1.16944],
      339: [0, .44444, 0, 0, .89444],
      567: [.19444, .44444, 0, 0, .35139],
      710: [0, .69444, 0, 0, .575],
      711: [0, .63194, 0, 0, .575],
      713: [0, .59611, 0, 0, .575],
      714: [0, .69444, 0, 0, .575],
      715: [0, .69444, 0, 0, .575],
      728: [0, .69444, 0, 0, .575],
      729: [0, .69444, 0, 0, .31944],
      730: [0, .69444, 0, 0, .86944],
      732: [0, .69444, 0, 0, .575],
      733: [0, .69444, 0, 0, .575],
      915: [0, .68611, 0, 0, .69166],
      916: [0, .68611, 0, 0, .95833],
      920: [0, .68611, 0, 0, .89444],
      923: [0, .68611, 0, 0, .80555],
      926: [0, .68611, 0, 0, .76666],
      928: [0, .68611, 0, 0, .9],
      931: [0, .68611, 0, 0, .83055],
      933: [0, .68611, 0, 0, .89444],
      934: [0, .68611, 0, 0, .83055],
      936: [0, .68611, 0, 0, .89444],
      937: [0, .68611, 0, 0, .83055],
      8211: [0, .44444, .03194, 0, .575],
      8212: [0, .44444, .03194, 0, 1.14999],
      8216: [0, .69444, 0, 0, .31944],
      8217: [0, .69444, 0, 0, .31944],
      8220: [0, .69444, 0, 0, .60278],
      8221: [0, .69444, 0, 0, .60278],
      8224: [.19444, .69444, 0, 0, .51111],
      8225: [.19444, .69444, 0, 0, .51111],
      8242: [0, .55556, 0, 0, .34444],
      8407: [0, .72444, .15486, 0, .575],
      8463: [0, .69444, 0, 0, .66759],
      8465: [0, .69444, 0, 0, .83055],
      8467: [0, .69444, 0, 0, .47361],
      8472: [.19444, .44444, 0, 0, .74027],
      8476: [0, .69444, 0, 0, .83055],
      8501: [0, .69444, 0, 0, .70277],
      8592: [-.10889, .39111, 0, 0, 1.14999],
      8593: [.19444, .69444, 0, 0, .575],
      8594: [-.10889, .39111, 0, 0, 1.14999],
      8595: [.19444, .69444, 0, 0, .575],
      8596: [-.10889, .39111, 0, 0, 1.14999],
      8597: [.25, .75, 0, 0, .575],
      8598: [.19444, .69444, 0, 0, 1.14999],
      8599: [.19444, .69444, 0, 0, 1.14999],
      8600: [.19444, .69444, 0, 0, 1.14999],
      8601: [.19444, .69444, 0, 0, 1.14999],
      8636: [-.10889, .39111, 0, 0, 1.14999],
      8637: [-.10889, .39111, 0, 0, 1.14999],
      8640: [-.10889, .39111, 0, 0, 1.14999],
      8641: [-.10889, .39111, 0, 0, 1.14999],
      8656: [-.10889, .39111, 0, 0, 1.14999],
      8657: [.19444, .69444, 0, 0, .70277],
      8658: [-.10889, .39111, 0, 0, 1.14999],
      8659: [.19444, .69444, 0, 0, .70277],
      8660: [-.10889, .39111, 0, 0, 1.14999],
      8661: [.25, .75, 0, 0, .70277],
      8704: [0, .69444, 0, 0, .63889],
      8706: [0, .69444, .06389, 0, .62847],
      8707: [0, .69444, 0, 0, .63889],
      8709: [.05556, .75, 0, 0, .575],
      8711: [0, .68611, 0, 0, .95833],
      8712: [.08556, .58556, 0, 0, .76666],
      8715: [.08556, .58556, 0, 0, .76666],
      8722: [.13333, .63333, 0, 0, .89444],
      8723: [.13333, .63333, 0, 0, .89444],
      8725: [.25, .75, 0, 0, .575],
      8726: [.25, .75, 0, 0, .575],
      8727: [-.02778, .47222, 0, 0, .575],
      8728: [-.02639, .47361, 0, 0, .575],
      8729: [-.02639, .47361, 0, 0, .575],
      8730: [.18, .82, 0, 0, .95833],
      8733: [0, .44444, 0, 0, .89444],
      8734: [0, .44444, 0, 0, 1.14999],
      8736: [0, .69224, 0, 0, .72222],
      8739: [.25, .75, 0, 0, .31944],
      8741: [.25, .75, 0, 0, .575],
      8743: [0, .55556, 0, 0, .76666],
      8744: [0, .55556, 0, 0, .76666],
      8745: [0, .55556, 0, 0, .76666],
      8746: [0, .55556, 0, 0, .76666],
      8747: [.19444, .69444, .12778, 0, .56875],
      8764: [-.10889, .39111, 0, 0, .89444],
      8768: [.19444, .69444, 0, 0, .31944],
      8771: [.00222, .50222, 0, 0, .89444],
      8773: [.027, .638, 0, 0, .894],
      8776: [.02444, .52444, 0, 0, .89444],
      8781: [.00222, .50222, 0, 0, .89444],
      8801: [.00222, .50222, 0, 0, .89444],
      8804: [.19667, .69667, 0, 0, .89444],
      8805: [.19667, .69667, 0, 0, .89444],
      8810: [.08556, .58556, 0, 0, 1.14999],
      8811: [.08556, .58556, 0, 0, 1.14999],
      8826: [.08556, .58556, 0, 0, .89444],
      8827: [.08556, .58556, 0, 0, .89444],
      8834: [.08556, .58556, 0, 0, .89444],
      8835: [.08556, .58556, 0, 0, .89444],
      8838: [.19667, .69667, 0, 0, .89444],
      8839: [.19667, .69667, 0, 0, .89444],
      8846: [0, .55556, 0, 0, .76666],
      8849: [.19667, .69667, 0, 0, .89444],
      8850: [.19667, .69667, 0, 0, .89444],
      8851: [0, .55556, 0, 0, .76666],
      8852: [0, .55556, 0, 0, .76666],
      8853: [.13333, .63333, 0, 0, .89444],
      8854: [.13333, .63333, 0, 0, .89444],
      8855: [.13333, .63333, 0, 0, .89444],
      8856: [.13333, .63333, 0, 0, .89444],
      8857: [.13333, .63333, 0, 0, .89444],
      8866: [0, .69444, 0, 0, .70277],
      8867: [0, .69444, 0, 0, .70277],
      8868: [0, .69444, 0, 0, .89444],
      8869: [0, .69444, 0, 0, .89444],
      8900: [-.02639, .47361, 0, 0, .575],
      8901: [-.02639, .47361, 0, 0, .31944],
      8902: [-.02778, .47222, 0, 0, .575],
      8968: [.25, .75, 0, 0, .51111],
      8969: [.25, .75, 0, 0, .51111],
      8970: [.25, .75, 0, 0, .51111],
      8971: [.25, .75, 0, 0, .51111],
      8994: [-.13889, .36111, 0, 0, 1.14999],
      8995: [-.13889, .36111, 0, 0, 1.14999],
      9651: [.19444, .69444, 0, 0, 1.02222],
      9657: [-.02778, .47222, 0, 0, .575],
      9661: [.19444, .69444, 0, 0, 1.02222],
      9667: [-.02778, .47222, 0, 0, .575],
      9711: [.19444, .69444, 0, 0, 1.14999],
      9824: [.12963, .69444, 0, 0, .89444],
      9825: [.12963, .69444, 0, 0, .89444],
      9826: [.12963, .69444, 0, 0, .89444],
      9827: [.12963, .69444, 0, 0, .89444],
      9837: [0, .75, 0, 0, .44722],
      9838: [.19444, .69444, 0, 0, .44722],
      9839: [.19444, .69444, 0, 0, .44722],
      10216: [.25, .75, 0, 0, .44722],
      10217: [.25, .75, 0, 0, .44722],
      10815: [0, .68611, 0, 0, .9],
      10927: [.19667, .69667, 0, 0, .89444],
      10928: [.19667, .69667, 0, 0, .89444],
      57376: [.19444, .69444, 0, 0, 0]
    },
    "Main-BoldItalic": {
      32: [0, 0, 0, 0, .25],
      33: [0, .69444, .11417, 0, .38611],
      34: [0, .69444, .07939, 0, .62055],
      35: [.19444, .69444, .06833, 0, .94444],
      37: [.05556, .75, .12861, 0, .94444],
      38: [0, .69444, .08528, 0, .88555],
      39: [0, .69444, .12945, 0, .35555],
      40: [.25, .75, .15806, 0, .47333],
      41: [.25, .75, .03306, 0, .47333],
      42: [0, .75, .14333, 0, .59111],
      43: [.10333, .60333, .03306, 0, .88555],
      44: [.19444, .14722, 0, 0, .35555],
      45: [0, .44444, .02611, 0, .41444],
      46: [0, .14722, 0, 0, .35555],
      47: [.25, .75, .15806, 0, .59111],
      48: [0, .64444, .13167, 0, .59111],
      49: [0, .64444, .13167, 0, .59111],
      50: [0, .64444, .13167, 0, .59111],
      51: [0, .64444, .13167, 0, .59111],
      52: [.19444, .64444, .13167, 0, .59111],
      53: [0, .64444, .13167, 0, .59111],
      54: [0, .64444, .13167, 0, .59111],
      55: [.19444, .64444, .13167, 0, .59111],
      56: [0, .64444, .13167, 0, .59111],
      57: [0, .64444, .13167, 0, .59111],
      58: [0, .44444, .06695, 0, .35555],
      59: [.19444, .44444, .06695, 0, .35555],
      61: [-.10889, .39111, .06833, 0, .88555],
      63: [0, .69444, .11472, 0, .59111],
      64: [0, .69444, .09208, 0, .88555],
      65: [0, .68611, 0, 0, .86555],
      66: [0, .68611, .0992, 0, .81666],
      67: [0, .68611, .14208, 0, .82666],
      68: [0, .68611, .09062, 0, .87555],
      69: [0, .68611, .11431, 0, .75666],
      70: [0, .68611, .12903, 0, .72722],
      71: [0, .68611, .07347, 0, .89527],
      72: [0, .68611, .17208, 0, .8961],
      73: [0, .68611, .15681, 0, .47166],
      74: [0, .68611, .145, 0, .61055],
      75: [0, .68611, .14208, 0, .89499],
      76: [0, .68611, 0, 0, .69777],
      77: [0, .68611, .17208, 0, 1.07277],
      78: [0, .68611, .17208, 0, .8961],
      79: [0, .68611, .09062, 0, .85499],
      80: [0, .68611, .0992, 0, .78721],
      81: [.19444, .68611, .09062, 0, .85499],
      82: [0, .68611, .02559, 0, .85944],
      83: [0, .68611, .11264, 0, .64999],
      84: [0, .68611, .12903, 0, .7961],
      85: [0, .68611, .17208, 0, .88083],
      86: [0, .68611, .18625, 0, .86555],
      87: [0, .68611, .18625, 0, 1.15999],
      88: [0, .68611, .15681, 0, .86555],
      89: [0, .68611, .19803, 0, .86555],
      90: [0, .68611, .14208, 0, .70888],
      91: [.25, .75, .1875, 0, .35611],
      93: [.25, .75, .09972, 0, .35611],
      94: [0, .69444, .06709, 0, .59111],
      95: [.31, .13444, .09811, 0, .59111],
      97: [0, .44444, .09426, 0, .59111],
      98: [0, .69444, .07861, 0, .53222],
      99: [0, .44444, .05222, 0, .53222],
      100: [0, .69444, .10861, 0, .59111],
      101: [0, .44444, .085, 0, .53222],
      102: [.19444, .69444, .21778, 0, .4],
      103: [.19444, .44444, .105, 0, .53222],
      104: [0, .69444, .09426, 0, .59111],
      105: [0, .69326, .11387, 0, .35555],
      106: [.19444, .69326, .1672, 0, .35555],
      107: [0, .69444, .11111, 0, .53222],
      108: [0, .69444, .10861, 0, .29666],
      109: [0, .44444, .09426, 0, .94444],
      110: [0, .44444, .09426, 0, .64999],
      111: [0, .44444, .07861, 0, .59111],
      112: [.19444, .44444, .07861, 0, .59111],
      113: [.19444, .44444, .105, 0, .53222],
      114: [0, .44444, .11111, 0, .50167],
      115: [0, .44444, .08167, 0, .48694],
      116: [0, .63492, .09639, 0, .385],
      117: [0, .44444, .09426, 0, .62055],
      118: [0, .44444, .11111, 0, .53222],
      119: [0, .44444, .11111, 0, .76777],
      120: [0, .44444, .12583, 0, .56055],
      121: [.19444, .44444, .105, 0, .56166],
      122: [0, .44444, .13889, 0, .49055],
      126: [.35, .34444, .11472, 0, .59111],
      160: [0, 0, 0, 0, .25],
      168: [0, .69444, .11473, 0, .59111],
      176: [0, .69444, 0, 0, .94888],
      184: [.17014, 0, 0, 0, .53222],
      198: [0, .68611, .11431, 0, 1.02277],
      216: [.04861, .73472, .09062, 0, .88555],
      223: [.19444, .69444, .09736, 0, .665],
      230: [0, .44444, .085, 0, .82666],
      248: [.09722, .54167, .09458, 0, .59111],
      305: [0, .44444, .09426, 0, .35555],
      338: [0, .68611, .11431, 0, 1.14054],
      339: [0, .44444, .085, 0, .82666],
      567: [.19444, .44444, .04611, 0, .385],
      710: [0, .69444, .06709, 0, .59111],
      711: [0, .63194, .08271, 0, .59111],
      713: [0, .59444, .10444, 0, .59111],
      714: [0, .69444, .08528, 0, .59111],
      715: [0, .69444, 0, 0, .59111],
      728: [0, .69444, .10333, 0, .59111],
      729: [0, .69444, .12945, 0, .35555],
      730: [0, .69444, 0, 0, .94888],
      732: [0, .69444, .11472, 0, .59111],
      733: [0, .69444, .11472, 0, .59111],
      915: [0, .68611, .12903, 0, .69777],
      916: [0, .68611, 0, 0, .94444],
      920: [0, .68611, .09062, 0, .88555],
      923: [0, .68611, 0, 0, .80666],
      926: [0, .68611, .15092, 0, .76777],
      928: [0, .68611, .17208, 0, .8961],
      931: [0, .68611, .11431, 0, .82666],
      933: [0, .68611, .10778, 0, .88555],
      934: [0, .68611, .05632, 0, .82666],
      936: [0, .68611, .10778, 0, .88555],
      937: [0, .68611, .0992, 0, .82666],
      8211: [0, .44444, .09811, 0, .59111],
      8212: [0, .44444, .09811, 0, 1.18221],
      8216: [0, .69444, .12945, 0, .35555],
      8217: [0, .69444, .12945, 0, .35555],
      8220: [0, .69444, .16772, 0, .62055],
      8221: [0, .69444, .07939, 0, .62055]
    },
    "Main-Italic": {
      32: [0, 0, 0, 0, .25],
      33: [0, .69444, .12417, 0, .30667],
      34: [0, .69444, .06961, 0, .51444],
      35: [.19444, .69444, .06616, 0, .81777],
      37: [.05556, .75, .13639, 0, .81777],
      38: [0, .69444, .09694, 0, .76666],
      39: [0, .69444, .12417, 0, .30667],
      40: [.25, .75, .16194, 0, .40889],
      41: [.25, .75, .03694, 0, .40889],
      42: [0, .75, .14917, 0, .51111],
      43: [.05667, .56167, .03694, 0, .76666],
      44: [.19444, .10556, 0, 0, .30667],
      45: [0, .43056, .02826, 0, .35778],
      46: [0, .10556, 0, 0, .30667],
      47: [.25, .75, .16194, 0, .51111],
      48: [0, .64444, .13556, 0, .51111],
      49: [0, .64444, .13556, 0, .51111],
      50: [0, .64444, .13556, 0, .51111],
      51: [0, .64444, .13556, 0, .51111],
      52: [.19444, .64444, .13556, 0, .51111],
      53: [0, .64444, .13556, 0, .51111],
      54: [0, .64444, .13556, 0, .51111],
      55: [.19444, .64444, .13556, 0, .51111],
      56: [0, .64444, .13556, 0, .51111],
      57: [0, .64444, .13556, 0, .51111],
      58: [0, .43056, .0582, 0, .30667],
      59: [.19444, .43056, .0582, 0, .30667],
      61: [-.13313, .36687, .06616, 0, .76666],
      63: [0, .69444, .1225, 0, .51111],
      64: [0, .69444, .09597, 0, .76666],
      65: [0, .68333, 0, 0, .74333],
      66: [0, .68333, .10257, 0, .70389],
      67: [0, .68333, .14528, 0, .71555],
      68: [0, .68333, .09403, 0, .755],
      69: [0, .68333, .12028, 0, .67833],
      70: [0, .68333, .13305, 0, .65277],
      71: [0, .68333, .08722, 0, .77361],
      72: [0, .68333, .16389, 0, .74333],
      73: [0, .68333, .15806, 0, .38555],
      74: [0, .68333, .14028, 0, .525],
      75: [0, .68333, .14528, 0, .76888],
      76: [0, .68333, 0, 0, .62722],
      77: [0, .68333, .16389, 0, .89666],
      78: [0, .68333, .16389, 0, .74333],
      79: [0, .68333, .09403, 0, .76666],
      80: [0, .68333, .10257, 0, .67833],
      81: [.19444, .68333, .09403, 0, .76666],
      82: [0, .68333, .03868, 0, .72944],
      83: [0, .68333, .11972, 0, .56222],
      84: [0, .68333, .13305, 0, .71555],
      85: [0, .68333, .16389, 0, .74333],
      86: [0, .68333, .18361, 0, .74333],
      87: [0, .68333, .18361, 0, .99888],
      88: [0, .68333, .15806, 0, .74333],
      89: [0, .68333, .19383, 0, .74333],
      90: [0, .68333, .14528, 0, .61333],
      91: [.25, .75, .1875, 0, .30667],
      93: [.25, .75, .10528, 0, .30667],
      94: [0, .69444, .06646, 0, .51111],
      95: [.31, .12056, .09208, 0, .51111],
      97: [0, .43056, .07671, 0, .51111],
      98: [0, .69444, .06312, 0, .46],
      99: [0, .43056, .05653, 0, .46],
      100: [0, .69444, .10333, 0, .51111],
      101: [0, .43056, .07514, 0, .46],
      102: [.19444, .69444, .21194, 0, .30667],
      103: [.19444, .43056, .08847, 0, .46],
      104: [0, .69444, .07671, 0, .51111],
      105: [0, .65536, .1019, 0, .30667],
      106: [.19444, .65536, .14467, 0, .30667],
      107: [0, .69444, .10764, 0, .46],
      108: [0, .69444, .10333, 0, .25555],
      109: [0, .43056, .07671, 0, .81777],
      110: [0, .43056, .07671, 0, .56222],
      111: [0, .43056, .06312, 0, .51111],
      112: [.19444, .43056, .06312, 0, .51111],
      113: [.19444, .43056, .08847, 0, .46],
      114: [0, .43056, .10764, 0, .42166],
      115: [0, .43056, .08208, 0, .40889],
      116: [0, .61508, .09486, 0, .33222],
      117: [0, .43056, .07671, 0, .53666],
      118: [0, .43056, .10764, 0, .46],
      119: [0, .43056, .10764, 0, .66444],
      120: [0, .43056, .12042, 0, .46389],
      121: [.19444, .43056, .08847, 0, .48555],
      122: [0, .43056, .12292, 0, .40889],
      126: [.35, .31786, .11585, 0, .51111],
      160: [0, 0, 0, 0, .25],
      168: [0, .66786, .10474, 0, .51111],
      176: [0, .69444, 0, 0, .83129],
      184: [.17014, 0, 0, 0, .46],
      198: [0, .68333, .12028, 0, .88277],
      216: [.04861, .73194, .09403, 0, .76666],
      223: [.19444, .69444, .10514, 0, .53666],
      230: [0, .43056, .07514, 0, .71555],
      248: [.09722, .52778, .09194, 0, .51111],
      338: [0, .68333, .12028, 0, .98499],
      339: [0, .43056, .07514, 0, .71555],
      710: [0, .69444, .06646, 0, .51111],
      711: [0, .62847, .08295, 0, .51111],
      713: [0, .56167, .10333, 0, .51111],
      714: [0, .69444, .09694, 0, .51111],
      715: [0, .69444, 0, 0, .51111],
      728: [0, .69444, .10806, 0, .51111],
      729: [0, .66786, .11752, 0, .30667],
      730: [0, .69444, 0, 0, .83129],
      732: [0, .66786, .11585, 0, .51111],
      733: [0, .69444, .1225, 0, .51111],
      915: [0, .68333, .13305, 0, .62722],
      916: [0, .68333, 0, 0, .81777],
      920: [0, .68333, .09403, 0, .76666],
      923: [0, .68333, 0, 0, .69222],
      926: [0, .68333, .15294, 0, .66444],
      928: [0, .68333, .16389, 0, .74333],
      931: [0, .68333, .12028, 0, .71555],
      933: [0, .68333, .11111, 0, .76666],
      934: [0, .68333, .05986, 0, .71555],
      936: [0, .68333, .11111, 0, .76666],
      937: [0, .68333, .10257, 0, .71555],
      8211: [0, .43056, .09208, 0, .51111],
      8212: [0, .43056, .09208, 0, 1.02222],
      8216: [0, .69444, .12417, 0, .30667],
      8217: [0, .69444, .12417, 0, .30667],
      8220: [0, .69444, .1685, 0, .51444],
      8221: [0, .69444, .06961, 0, .51444],
      8463: [0, .68889, 0, 0, .54028]
    },
    "Main-Regular": {
      32: [0, 0, 0, 0, .25],
      33: [0, .69444, 0, 0, .27778],
      34: [0, .69444, 0, 0, .5],
      35: [.19444, .69444, 0, 0, .83334],
      36: [.05556, .75, 0, 0, .5],
      37: [.05556, .75, 0, 0, .83334],
      38: [0, .69444, 0, 0, .77778],
      39: [0, .69444, 0, 0, .27778],
      40: [.25, .75, 0, 0, .38889],
      41: [.25, .75, 0, 0, .38889],
      42: [0, .75, 0, 0, .5],
      43: [.08333, .58333, 0, 0, .77778],
      44: [.19444, .10556, 0, 0, .27778],
      45: [0, .43056, 0, 0, .33333],
      46: [0, .10556, 0, 0, .27778],
      47: [.25, .75, 0, 0, .5],
      48: [0, .64444, 0, 0, .5],
      49: [0, .64444, 0, 0, .5],
      50: [0, .64444, 0, 0, .5],
      51: [0, .64444, 0, 0, .5],
      52: [0, .64444, 0, 0, .5],
      53: [0, .64444, 0, 0, .5],
      54: [0, .64444, 0, 0, .5],
      55: [0, .64444, 0, 0, .5],
      56: [0, .64444, 0, 0, .5],
      57: [0, .64444, 0, 0, .5],
      58: [0, .43056, 0, 0, .27778],
      59: [.19444, .43056, 0, 0, .27778],
      60: [.0391, .5391, 0, 0, .77778],
      61: [-.13313, .36687, 0, 0, .77778],
      62: [.0391, .5391, 0, 0, .77778],
      63: [0, .69444, 0, 0, .47222],
      64: [0, .69444, 0, 0, .77778],
      65: [0, .68333, 0, 0, .75],
      66: [0, .68333, 0, 0, .70834],
      67: [0, .68333, 0, 0, .72222],
      68: [0, .68333, 0, 0, .76389],
      69: [0, .68333, 0, 0, .68056],
      70: [0, .68333, 0, 0, .65278],
      71: [0, .68333, 0, 0, .78472],
      72: [0, .68333, 0, 0, .75],
      73: [0, .68333, 0, 0, .36111],
      74: [0, .68333, 0, 0, .51389],
      75: [0, .68333, 0, 0, .77778],
      76: [0, .68333, 0, 0, .625],
      77: [0, .68333, 0, 0, .91667],
      78: [0, .68333, 0, 0, .75],
      79: [0, .68333, 0, 0, .77778],
      80: [0, .68333, 0, 0, .68056],
      81: [.19444, .68333, 0, 0, .77778],
      82: [0, .68333, 0, 0, .73611],
      83: [0, .68333, 0, 0, .55556],
      84: [0, .68333, 0, 0, .72222],
      85: [0, .68333, 0, 0, .75],
      86: [0, .68333, .01389, 0, .75],
      87: [0, .68333, .01389, 0, 1.02778],
      88: [0, .68333, 0, 0, .75],
      89: [0, .68333, .025, 0, .75],
      90: [0, .68333, 0, 0, .61111],
      91: [.25, .75, 0, 0, .27778],
      92: [.25, .75, 0, 0, .5],
      93: [.25, .75, 0, 0, .27778],
      94: [0, .69444, 0, 0, .5],
      95: [.31, .12056, .02778, 0, .5],
      97: [0, .43056, 0, 0, .5],
      98: [0, .69444, 0, 0, .55556],
      99: [0, .43056, 0, 0, .44445],
      100: [0, .69444, 0, 0, .55556],
      101: [0, .43056, 0, 0, .44445],
      102: [0, .69444, .07778, 0, .30556],
      103: [.19444, .43056, .01389, 0, .5],
      104: [0, .69444, 0, 0, .55556],
      105: [0, .66786, 0, 0, .27778],
      106: [.19444, .66786, 0, 0, .30556],
      107: [0, .69444, 0, 0, .52778],
      108: [0, .69444, 0, 0, .27778],
      109: [0, .43056, 0, 0, .83334],
      110: [0, .43056, 0, 0, .55556],
      111: [0, .43056, 0, 0, .5],
      112: [.19444, .43056, 0, 0, .55556],
      113: [.19444, .43056, 0, 0, .52778],
      114: [0, .43056, 0, 0, .39167],
      115: [0, .43056, 0, 0, .39445],
      116: [0, .61508, 0, 0, .38889],
      117: [0, .43056, 0, 0, .55556],
      118: [0, .43056, .01389, 0, .52778],
      119: [0, .43056, .01389, 0, .72222],
      120: [0, .43056, 0, 0, .52778],
      121: [.19444, .43056, .01389, 0, .52778],
      122: [0, .43056, 0, 0, .44445],
      123: [.25, .75, 0, 0, .5],
      124: [.25, .75, 0, 0, .27778],
      125: [.25, .75, 0, 0, .5],
      126: [.35, .31786, 0, 0, .5],
      160: [0, 0, 0, 0, .25],
      163: [0, .69444, 0, 0, .76909],
      167: [.19444, .69444, 0, 0, .44445],
      168: [0, .66786, 0, 0, .5],
      172: [0, .43056, 0, 0, .66667],
      176: [0, .69444, 0, 0, .75],
      177: [.08333, .58333, 0, 0, .77778],
      182: [.19444, .69444, 0, 0, .61111],
      184: [.17014, 0, 0, 0, .44445],
      198: [0, .68333, 0, 0, .90278],
      215: [.08333, .58333, 0, 0, .77778],
      216: [.04861, .73194, 0, 0, .77778],
      223: [0, .69444, 0, 0, .5],
      230: [0, .43056, 0, 0, .72222],
      247: [.08333, .58333, 0, 0, .77778],
      248: [.09722, .52778, 0, 0, .5],
      305: [0, .43056, 0, 0, .27778],
      338: [0, .68333, 0, 0, 1.01389],
      339: [0, .43056, 0, 0, .77778],
      567: [.19444, .43056, 0, 0, .30556],
      710: [0, .69444, 0, 0, .5],
      711: [0, .62847, 0, 0, .5],
      713: [0, .56778, 0, 0, .5],
      714: [0, .69444, 0, 0, .5],
      715: [0, .69444, 0, 0, .5],
      728: [0, .69444, 0, 0, .5],
      729: [0, .66786, 0, 0, .27778],
      730: [0, .69444, 0, 0, .75],
      732: [0, .66786, 0, 0, .5],
      733: [0, .69444, 0, 0, .5],
      915: [0, .68333, 0, 0, .625],
      916: [0, .68333, 0, 0, .83334],
      920: [0, .68333, 0, 0, .77778],
      923: [0, .68333, 0, 0, .69445],
      926: [0, .68333, 0, 0, .66667],
      928: [0, .68333, 0, 0, .75],
      931: [0, .68333, 0, 0, .72222],
      933: [0, .68333, 0, 0, .77778],
      934: [0, .68333, 0, 0, .72222],
      936: [0, .68333, 0, 0, .77778],
      937: [0, .68333, 0, 0, .72222],
      8211: [0, .43056, .02778, 0, .5],
      8212: [0, .43056, .02778, 0, 1],
      8216: [0, .69444, 0, 0, .27778],
      8217: [0, .69444, 0, 0, .27778],
      8220: [0, .69444, 0, 0, .5],
      8221: [0, .69444, 0, 0, .5],
      8224: [.19444, .69444, 0, 0, .44445],
      8225: [.19444, .69444, 0, 0, .44445],
      8230: [0, .123, 0, 0, 1.172],
      8242: [0, .55556, 0, 0, .275],
      8407: [0, .71444, .15382, 0, .5],
      8463: [0, .68889, 0, 0, .54028],
      8465: [0, .69444, 0, 0, .72222],
      8467: [0, .69444, 0, .11111, .41667],
      8472: [.19444, .43056, 0, .11111, .63646],
      8476: [0, .69444, 0, 0, .72222],
      8501: [0, .69444, 0, 0, .61111],
      8592: [-.13313, .36687, 0, 0, 1],
      8593: [.19444, .69444, 0, 0, .5],
      8594: [-.13313, .36687, 0, 0, 1],
      8595: [.19444, .69444, 0, 0, .5],
      8596: [-.13313, .36687, 0, 0, 1],
      8597: [.25, .75, 0, 0, .5],
      8598: [.19444, .69444, 0, 0, 1],
      8599: [.19444, .69444, 0, 0, 1],
      8600: [.19444, .69444, 0, 0, 1],
      8601: [.19444, .69444, 0, 0, 1],
      8614: [.011, .511, 0, 0, 1],
      8617: [.011, .511, 0, 0, 1.126],
      8618: [.011, .511, 0, 0, 1.126],
      8636: [-.13313, .36687, 0, 0, 1],
      8637: [-.13313, .36687, 0, 0, 1],
      8640: [-.13313, .36687, 0, 0, 1],
      8641: [-.13313, .36687, 0, 0, 1],
      8652: [.011, .671, 0, 0, 1],
      8656: [-.13313, .36687, 0, 0, 1],
      8657: [.19444, .69444, 0, 0, .61111],
      8658: [-.13313, .36687, 0, 0, 1],
      8659: [.19444, .69444, 0, 0, .61111],
      8660: [-.13313, .36687, 0, 0, 1],
      8661: [.25, .75, 0, 0, .61111],
      8704: [0, .69444, 0, 0, .55556],
      8706: [0, .69444, .05556, .08334, .5309],
      8707: [0, .69444, 0, 0, .55556],
      8709: [.05556, .75, 0, 0, .5],
      8711: [0, .68333, 0, 0, .83334],
      8712: [.0391, .5391, 0, 0, .66667],
      8715: [.0391, .5391, 0, 0, .66667],
      8722: [.08333, .58333, 0, 0, .77778],
      8723: [.08333, .58333, 0, 0, .77778],
      8725: [.25, .75, 0, 0, .5],
      8726: [.25, .75, 0, 0, .5],
      8727: [-.03472, .46528, 0, 0, .5],
      8728: [-.05555, .44445, 0, 0, .5],
      8729: [-.05555, .44445, 0, 0, .5],
      8730: [.2, .8, 0, 0, .83334],
      8733: [0, .43056, 0, 0, .77778],
      8734: [0, .43056, 0, 0, 1],
      8736: [0, .69224, 0, 0, .72222],
      8739: [.25, .75, 0, 0, .27778],
      8741: [.25, .75, 0, 0, .5],
      8743: [0, .55556, 0, 0, .66667],
      8744: [0, .55556, 0, 0, .66667],
      8745: [0, .55556, 0, 0, .66667],
      8746: [0, .55556, 0, 0, .66667],
      8747: [.19444, .69444, .11111, 0, .41667],
      8764: [-.13313, .36687, 0, 0, .77778],
      8768: [.19444, .69444, 0, 0, .27778],
      8771: [-.03625, .46375, 0, 0, .77778],
      8773: [-.022, .589, 0, 0, .778],
      8776: [-.01688, .48312, 0, 0, .77778],
      8781: [-.03625, .46375, 0, 0, .77778],
      8784: [-.133, .673, 0, 0, .778],
      8801: [-.03625, .46375, 0, 0, .77778],
      8804: [.13597, .63597, 0, 0, .77778],
      8805: [.13597, .63597, 0, 0, .77778],
      8810: [.0391, .5391, 0, 0, 1],
      8811: [.0391, .5391, 0, 0, 1],
      8826: [.0391, .5391, 0, 0, .77778],
      8827: [.0391, .5391, 0, 0, .77778],
      8834: [.0391, .5391, 0, 0, .77778],
      8835: [.0391, .5391, 0, 0, .77778],
      8838: [.13597, .63597, 0, 0, .77778],
      8839: [.13597, .63597, 0, 0, .77778],
      8846: [0, .55556, 0, 0, .66667],
      8849: [.13597, .63597, 0, 0, .77778],
      8850: [.13597, .63597, 0, 0, .77778],
      8851: [0, .55556, 0, 0, .66667],
      8852: [0, .55556, 0, 0, .66667],
      8853: [.08333, .58333, 0, 0, .77778],
      8854: [.08333, .58333, 0, 0, .77778],
      8855: [.08333, .58333, 0, 0, .77778],
      8856: [.08333, .58333, 0, 0, .77778],
      8857: [.08333, .58333, 0, 0, .77778],
      8866: [0, .69444, 0, 0, .61111],
      8867: [0, .69444, 0, 0, .61111],
      8868: [0, .69444, 0, 0, .77778],
      8869: [0, .69444, 0, 0, .77778],
      8872: [.249, .75, 0, 0, .867],
      8900: [-.05555, .44445, 0, 0, .5],
      8901: [-.05555, .44445, 0, 0, .27778],
      8902: [-.03472, .46528, 0, 0, .5],
      8904: [.005, .505, 0, 0, .9],
      8942: [.03, .903, 0, 0, .278],
      8943: [-.19, .313, 0, 0, 1.172],
      8945: [-.1, .823, 0, 0, 1.282],
      8968: [.25, .75, 0, 0, .44445],
      8969: [.25, .75, 0, 0, .44445],
      8970: [.25, .75, 0, 0, .44445],
      8971: [.25, .75, 0, 0, .44445],
      8994: [-.14236, .35764, 0, 0, 1],
      8995: [-.14236, .35764, 0, 0, 1],
      9136: [.244, .744, 0, 0, .412],
      9137: [.244, .745, 0, 0, .412],
      9651: [.19444, .69444, 0, 0, .88889],
      9657: [-.03472, .46528, 0, 0, .5],
      9661: [.19444, .69444, 0, 0, .88889],
      9667: [-.03472, .46528, 0, 0, .5],
      9711: [.19444, .69444, 0, 0, 1],
      9824: [.12963, .69444, 0, 0, .77778],
      9825: [.12963, .69444, 0, 0, .77778],
      9826: [.12963, .69444, 0, 0, .77778],
      9827: [.12963, .69444, 0, 0, .77778],
      9837: [0, .75, 0, 0, .38889],
      9838: [.19444, .69444, 0, 0, .38889],
      9839: [.19444, .69444, 0, 0, .38889],
      10216: [.25, .75, 0, 0, .38889],
      10217: [.25, .75, 0, 0, .38889],
      10222: [.244, .744, 0, 0, .412],
      10223: [.244, .745, 0, 0, .412],
      10229: [.011, .511, 0, 0, 1.609],
      10230: [.011, .511, 0, 0, 1.638],
      10231: [.011, .511, 0, 0, 1.859],
      10232: [.024, .525, 0, 0, 1.609],
      10233: [.024, .525, 0, 0, 1.638],
      10234: [.024, .525, 0, 0, 1.858],
      10236: [.011, .511, 0, 0, 1.638],
      10815: [0, .68333, 0, 0, .75],
      10927: [.13597, .63597, 0, 0, .77778],
      10928: [.13597, .63597, 0, 0, .77778],
      57376: [.19444, .69444, 0, 0, 0]
    },
    "Math-BoldItalic": {
      32: [0, 0, 0, 0, .25],
      48: [0, .44444, 0, 0, .575],
      49: [0, .44444, 0, 0, .575],
      50: [0, .44444, 0, 0, .575],
      51: [.19444, .44444, 0, 0, .575],
      52: [.19444, .44444, 0, 0, .575],
      53: [.19444, .44444, 0, 0, .575],
      54: [0, .64444, 0, 0, .575],
      55: [.19444, .44444, 0, 0, .575],
      56: [0, .64444, 0, 0, .575],
      57: [.19444, .44444, 0, 0, .575],
      65: [0, .68611, 0, 0, .86944],
      66: [0, .68611, .04835, 0, .8664],
      67: [0, .68611, .06979, 0, .81694],
      68: [0, .68611, .03194, 0, .93812],
      69: [0, .68611, .05451, 0, .81007],
      70: [0, .68611, .15972, 0, .68889],
      71: [0, .68611, 0, 0, .88673],
      72: [0, .68611, .08229, 0, .98229],
      73: [0, .68611, .07778, 0, .51111],
      74: [0, .68611, .10069, 0, .63125],
      75: [0, .68611, .06979, 0, .97118],
      76: [0, .68611, 0, 0, .75555],
      77: [0, .68611, .11424, 0, 1.14201],
      78: [0, .68611, .11424, 0, .95034],
      79: [0, .68611, .03194, 0, .83666],
      80: [0, .68611, .15972, 0, .72309],
      81: [.19444, .68611, 0, 0, .86861],
      82: [0, .68611, .00421, 0, .87235],
      83: [0, .68611, .05382, 0, .69271],
      84: [0, .68611, .15972, 0, .63663],
      85: [0, .68611, .11424, 0, .80027],
      86: [0, .68611, .25555, 0, .67778],
      87: [0, .68611, .15972, 0, 1.09305],
      88: [0, .68611, .07778, 0, .94722],
      89: [0, .68611, .25555, 0, .67458],
      90: [0, .68611, .06979, 0, .77257],
      97: [0, .44444, 0, 0, .63287],
      98: [0, .69444, 0, 0, .52083],
      99: [0, .44444, 0, 0, .51342],
      100: [0, .69444, 0, 0, .60972],
      101: [0, .44444, 0, 0, .55361],
      102: [.19444, .69444, .11042, 0, .56806],
      103: [.19444, .44444, .03704, 0, .5449],
      104: [0, .69444, 0, 0, .66759],
      105: [0, .69326, 0, 0, .4048],
      106: [.19444, .69326, .0622, 0, .47083],
      107: [0, .69444, .01852, 0, .6037],
      108: [0, .69444, .0088, 0, .34815],
      109: [0, .44444, 0, 0, 1.0324],
      110: [0, .44444, 0, 0, .71296],
      111: [0, .44444, 0, 0, .58472],
      112: [.19444, .44444, 0, 0, .60092],
      113: [.19444, .44444, .03704, 0, .54213],
      114: [0, .44444, .03194, 0, .5287],
      115: [0, .44444, 0, 0, .53125],
      116: [0, .63492, 0, 0, .41528],
      117: [0, .44444, 0, 0, .68102],
      118: [0, .44444, .03704, 0, .56666],
      119: [0, .44444, .02778, 0, .83148],
      120: [0, .44444, 0, 0, .65903],
      121: [.19444, .44444, .03704, 0, .59028],
      122: [0, .44444, .04213, 0, .55509],
      160: [0, 0, 0, 0, .25],
      915: [0, .68611, .15972, 0, .65694],
      916: [0, .68611, 0, 0, .95833],
      920: [0, .68611, .03194, 0, .86722],
      923: [0, .68611, 0, 0, .80555],
      926: [0, .68611, .07458, 0, .84125],
      928: [0, .68611, .08229, 0, .98229],
      931: [0, .68611, .05451, 0, .88507],
      933: [0, .68611, .15972, 0, .67083],
      934: [0, .68611, 0, 0, .76666],
      936: [0, .68611, .11653, 0, .71402],
      937: [0, .68611, .04835, 0, .8789],
      945: [0, .44444, 0, 0, .76064],
      946: [.19444, .69444, .03403, 0, .65972],
      947: [.19444, .44444, .06389, 0, .59003],
      948: [0, .69444, .03819, 0, .52222],
      949: [0, .44444, 0, 0, .52882],
      950: [.19444, .69444, .06215, 0, .50833],
      951: [.19444, .44444, .03704, 0, .6],
      952: [0, .69444, .03194, 0, .5618],
      953: [0, .44444, 0, 0, .41204],
      954: [0, .44444, 0, 0, .66759],
      955: [0, .69444, 0, 0, .67083],
      956: [.19444, .44444, 0, 0, .70787],
      957: [0, .44444, .06898, 0, .57685],
      958: [.19444, .69444, .03021, 0, .50833],
      959: [0, .44444, 0, 0, .58472],
      960: [0, .44444, .03704, 0, .68241],
      961: [.19444, .44444, 0, 0, .6118],
      962: [.09722, .44444, .07917, 0, .42361],
      963: [0, .44444, .03704, 0, .68588],
      964: [0, .44444, .13472, 0, .52083],
      965: [0, .44444, .03704, 0, .63055],
      966: [.19444, .44444, 0, 0, .74722],
      967: [.19444, .44444, 0, 0, .71805],
      968: [.19444, .69444, .03704, 0, .75833],
      969: [0, .44444, .03704, 0, .71782],
      977: [0, .69444, 0, 0, .69155],
      981: [.19444, .69444, 0, 0, .7125],
      982: [0, .44444, .03194, 0, .975],
      1009: [.19444, .44444, 0, 0, .6118],
      1013: [0, .44444, 0, 0, .48333],
      57649: [0, .44444, 0, 0, .39352],
      57911: [.19444, .44444, 0, 0, .43889]
    },
    "Math-Italic": {
      32: [0, 0, 0, 0, .25],
      48: [0, .43056, 0, 0, .5],
      49: [0, .43056, 0, 0, .5],
      50: [0, .43056, 0, 0, .5],
      51: [.19444, .43056, 0, 0, .5],
      52: [.19444, .43056, 0, 0, .5],
      53: [.19444, .43056, 0, 0, .5],
      54: [0, .64444, 0, 0, .5],
      55: [.19444, .43056, 0, 0, .5],
      56: [0, .64444, 0, 0, .5],
      57: [.19444, .43056, 0, 0, .5],
      65: [0, .68333, 0, .13889, .75],
      66: [0, .68333, .05017, .08334, .75851],
      67: [0, .68333, .07153, .08334, .71472],
      68: [0, .68333, .02778, .05556, .82792],
      69: [0, .68333, .05764, .08334, .7382],
      70: [0, .68333, .13889, .08334, .64306],
      71: [0, .68333, 0, .08334, .78625],
      72: [0, .68333, .08125, .05556, .83125],
      73: [0, .68333, .07847, .11111, .43958],
      74: [0, .68333, .09618, .16667, .55451],
      75: [0, .68333, .07153, .05556, .84931],
      76: [0, .68333, 0, .02778, .68056],
      77: [0, .68333, .10903, .08334, .97014],
      78: [0, .68333, .10903, .08334, .80347],
      79: [0, .68333, .02778, .08334, .76278],
      80: [0, .68333, .13889, .08334, .64201],
      81: [.19444, .68333, 0, .08334, .79056],
      82: [0, .68333, .00773, .08334, .75929],
      83: [0, .68333, .05764, .08334, .6132],
      84: [0, .68333, .13889, .08334, .58438],
      85: [0, .68333, .10903, .02778, .68278],
      86: [0, .68333, .22222, 0, .58333],
      87: [0, .68333, .13889, 0, .94445],
      88: [0, .68333, .07847, .08334, .82847],
      89: [0, .68333, .22222, 0, .58056],
      90: [0, .68333, .07153, .08334, .68264],
      97: [0, .43056, 0, 0, .52859],
      98: [0, .69444, 0, 0, .42917],
      99: [0, .43056, 0, .05556, .43276],
      100: [0, .69444, 0, .16667, .52049],
      101: [0, .43056, 0, .05556, .46563],
      102: [.19444, .69444, .10764, .16667, .48959],
      103: [.19444, .43056, .03588, .02778, .47697],
      104: [0, .69444, 0, 0, .57616],
      105: [0, .65952, 0, 0, .34451],
      106: [.19444, .65952, .05724, 0, .41181],
      107: [0, .69444, .03148, 0, .5206],
      108: [0, .69444, .01968, .08334, .29838],
      109: [0, .43056, 0, 0, .87801],
      110: [0, .43056, 0, 0, .60023],
      111: [0, .43056, 0, .05556, .48472],
      112: [.19444, .43056, 0, .08334, .50313],
      113: [.19444, .43056, .03588, .08334, .44641],
      114: [0, .43056, .02778, .05556, .45116],
      115: [0, .43056, 0, .05556, .46875],
      116: [0, .61508, 0, .08334, .36111],
      117: [0, .43056, 0, .02778, .57246],
      118: [0, .43056, .03588, .02778, .48472],
      119: [0, .43056, .02691, .08334, .71592],
      120: [0, .43056, 0, .02778, .57153],
      121: [.19444, .43056, .03588, .05556, .49028],
      122: [0, .43056, .04398, .05556, .46505],
      160: [0, 0, 0, 0, .25],
      915: [0, .68333, .13889, .08334, .61528],
      916: [0, .68333, 0, .16667, .83334],
      920: [0, .68333, .02778, .08334, .76278],
      923: [0, .68333, 0, .16667, .69445],
      926: [0, .68333, .07569, .08334, .74236],
      928: [0, .68333, .08125, .05556, .83125],
      931: [0, .68333, .05764, .08334, .77986],
      933: [0, .68333, .13889, .05556, .58333],
      934: [0, .68333, 0, .08334, .66667],
      936: [0, .68333, .11, .05556, .61222],
      937: [0, .68333, .05017, .08334, .7724],
      945: [0, .43056, .0037, .02778, .6397],
      946: [.19444, .69444, .05278, .08334, .56563],
      947: [.19444, .43056, .05556, 0, .51773],
      948: [0, .69444, .03785, .05556, .44444],
      949: [0, .43056, 0, .08334, .46632],
      950: [.19444, .69444, .07378, .08334, .4375],
      951: [.19444, .43056, .03588, .05556, .49653],
      952: [0, .69444, .02778, .08334, .46944],
      953: [0, .43056, 0, .05556, .35394],
      954: [0, .43056, 0, 0, .57616],
      955: [0, .69444, 0, 0, .58334],
      956: [.19444, .43056, 0, .02778, .60255],
      957: [0, .43056, .06366, .02778, .49398],
      958: [.19444, .69444, .04601, .11111, .4375],
      959: [0, .43056, 0, .05556, .48472],
      960: [0, .43056, .03588, 0, .57003],
      961: [.19444, .43056, 0, .08334, .51702],
      962: [.09722, .43056, .07986, .08334, .36285],
      963: [0, .43056, .03588, 0, .57141],
      964: [0, .43056, .1132, .02778, .43715],
      965: [0, .43056, .03588, .02778, .54028],
      966: [.19444, .43056, 0, .08334, .65417],
      967: [.19444, .43056, 0, .05556, .62569],
      968: [.19444, .69444, .03588, .11111, .65139],
      969: [0, .43056, .03588, 0, .62245],
      977: [0, .69444, 0, .08334, .59144],
      981: [.19444, .69444, 0, .08334, .59583],
      982: [0, .43056, .02778, 0, .82813],
      1009: [.19444, .43056, 0, .08334, .51702],
      1013: [0, .43056, 0, .05556, .4059],
      57649: [0, .43056, 0, .02778, .32246],
      57911: [.19444, .43056, 0, .08334, .38403]
    },
    "SansSerif-Bold": {
      32: [0, 0, 0, 0, .25],
      33: [0, .69444, 0, 0, .36667],
      34: [0, .69444, 0, 0, .55834],
      35: [.19444, .69444, 0, 0, .91667],
      36: [.05556, .75, 0, 0, .55],
      37: [.05556, .75, 0, 0, 1.02912],
      38: [0, .69444, 0, 0, .83056],
      39: [0, .69444, 0, 0, .30556],
      40: [.25, .75, 0, 0, .42778],
      41: [.25, .75, 0, 0, .42778],
      42: [0, .75, 0, 0, .55],
      43: [.11667, .61667, 0, 0, .85556],
      44: [.10556, .13056, 0, 0, .30556],
      45: [0, .45833, 0, 0, .36667],
      46: [0, .13056, 0, 0, .30556],
      47: [.25, .75, 0, 0, .55],
      48: [0, .69444, 0, 0, .55],
      49: [0, .69444, 0, 0, .55],
      50: [0, .69444, 0, 0, .55],
      51: [0, .69444, 0, 0, .55],
      52: [0, .69444, 0, 0, .55],
      53: [0, .69444, 0, 0, .55],
      54: [0, .69444, 0, 0, .55],
      55: [0, .69444, 0, 0, .55],
      56: [0, .69444, 0, 0, .55],
      57: [0, .69444, 0, 0, .55],
      58: [0, .45833, 0, 0, .30556],
      59: [.10556, .45833, 0, 0, .30556],
      61: [-.09375, .40625, 0, 0, .85556],
      63: [0, .69444, 0, 0, .51945],
      64: [0, .69444, 0, 0, .73334],
      65: [0, .69444, 0, 0, .73334],
      66: [0, .69444, 0, 0, .73334],
      67: [0, .69444, 0, 0, .70278],
      68: [0, .69444, 0, 0, .79445],
      69: [0, .69444, 0, 0, .64167],
      70: [0, .69444, 0, 0, .61111],
      71: [0, .69444, 0, 0, .73334],
      72: [0, .69444, 0, 0, .79445],
      73: [0, .69444, 0, 0, .33056],
      74: [0, .69444, 0, 0, .51945],
      75: [0, .69444, 0, 0, .76389],
      76: [0, .69444, 0, 0, .58056],
      77: [0, .69444, 0, 0, .97778],
      78: [0, .69444, 0, 0, .79445],
      79: [0, .69444, 0, 0, .79445],
      80: [0, .69444, 0, 0, .70278],
      81: [.10556, .69444, 0, 0, .79445],
      82: [0, .69444, 0, 0, .70278],
      83: [0, .69444, 0, 0, .61111],
      84: [0, .69444, 0, 0, .73334],
      85: [0, .69444, 0, 0, .76389],
      86: [0, .69444, .01528, 0, .73334],
      87: [0, .69444, .01528, 0, 1.03889],
      88: [0, .69444, 0, 0, .73334],
      89: [0, .69444, .0275, 0, .73334],
      90: [0, .69444, 0, 0, .67223],
      91: [.25, .75, 0, 0, .34306],
      93: [.25, .75, 0, 0, .34306],
      94: [0, .69444, 0, 0, .55],
      95: [.35, .10833, .03056, 0, .55],
      97: [0, .45833, 0, 0, .525],
      98: [0, .69444, 0, 0, .56111],
      99: [0, .45833, 0, 0, .48889],
      100: [0, .69444, 0, 0, .56111],
      101: [0, .45833, 0, 0, .51111],
      102: [0, .69444, .07639, 0, .33611],
      103: [.19444, .45833, .01528, 0, .55],
      104: [0, .69444, 0, 0, .56111],
      105: [0, .69444, 0, 0, .25556],
      106: [.19444, .69444, 0, 0, .28611],
      107: [0, .69444, 0, 0, .53056],
      108: [0, .69444, 0, 0, .25556],
      109: [0, .45833, 0, 0, .86667],
      110: [0, .45833, 0, 0, .56111],
      111: [0, .45833, 0, 0, .55],
      112: [.19444, .45833, 0, 0, .56111],
      113: [.19444, .45833, 0, 0, .56111],
      114: [0, .45833, .01528, 0, .37222],
      115: [0, .45833, 0, 0, .42167],
      116: [0, .58929, 0, 0, .40417],
      117: [0, .45833, 0, 0, .56111],
      118: [0, .45833, .01528, 0, .5],
      119: [0, .45833, .01528, 0, .74445],
      120: [0, .45833, 0, 0, .5],
      121: [.19444, .45833, .01528, 0, .5],
      122: [0, .45833, 0, 0, .47639],
      126: [.35, .34444, 0, 0, .55],
      160: [0, 0, 0, 0, .25],
      168: [0, .69444, 0, 0, .55],
      176: [0, .69444, 0, 0, .73334],
      180: [0, .69444, 0, 0, .55],
      184: [.17014, 0, 0, 0, .48889],
      305: [0, .45833, 0, 0, .25556],
      567: [.19444, .45833, 0, 0, .28611],
      710: [0, .69444, 0, 0, .55],
      711: [0, .63542, 0, 0, .55],
      713: [0, .63778, 0, 0, .55],
      728: [0, .69444, 0, 0, .55],
      729: [0, .69444, 0, 0, .30556],
      730: [0, .69444, 0, 0, .73334],
      732: [0, .69444, 0, 0, .55],
      733: [0, .69444, 0, 0, .55],
      915: [0, .69444, 0, 0, .58056],
      916: [0, .69444, 0, 0, .91667],
      920: [0, .69444, 0, 0, .85556],
      923: [0, .69444, 0, 0, .67223],
      926: [0, .69444, 0, 0, .73334],
      928: [0, .69444, 0, 0, .79445],
      931: [0, .69444, 0, 0, .79445],
      933: [0, .69444, 0, 0, .85556],
      934: [0, .69444, 0, 0, .79445],
      936: [0, .69444, 0, 0, .85556],
      937: [0, .69444, 0, 0, .79445],
      8211: [0, .45833, .03056, 0, .55],
      8212: [0, .45833, .03056, 0, 1.10001],
      8216: [0, .69444, 0, 0, .30556],
      8217: [0, .69444, 0, 0, .30556],
      8220: [0, .69444, 0, 0, .55834],
      8221: [0, .69444, 0, 0, .55834]
    },
    "SansSerif-Italic": {
      32: [0, 0, 0, 0, .25],
      33: [0, .69444, .05733, 0, .31945],
      34: [0, .69444, .00316, 0, .5],
      35: [.19444, .69444, .05087, 0, .83334],
      36: [.05556, .75, .11156, 0, .5],
      37: [.05556, .75, .03126, 0, .83334],
      38: [0, .69444, .03058, 0, .75834],
      39: [0, .69444, .07816, 0, .27778],
      40: [.25, .75, .13164, 0, .38889],
      41: [.25, .75, .02536, 0, .38889],
      42: [0, .75, .11775, 0, .5],
      43: [.08333, .58333, .02536, 0, .77778],
      44: [.125, .08333, 0, 0, .27778],
      45: [0, .44444, .01946, 0, .33333],
      46: [0, .08333, 0, 0, .27778],
      47: [.25, .75, .13164, 0, .5],
      48: [0, .65556, .11156, 0, .5],
      49: [0, .65556, .11156, 0, .5],
      50: [0, .65556, .11156, 0, .5],
      51: [0, .65556, .11156, 0, .5],
      52: [0, .65556, .11156, 0, .5],
      53: [0, .65556, .11156, 0, .5],
      54: [0, .65556, .11156, 0, .5],
      55: [0, .65556, .11156, 0, .5],
      56: [0, .65556, .11156, 0, .5],
      57: [0, .65556, .11156, 0, .5],
      58: [0, .44444, .02502, 0, .27778],
      59: [.125, .44444, .02502, 0, .27778],
      61: [-.13, .37, .05087, 0, .77778],
      63: [0, .69444, .11809, 0, .47222],
      64: [0, .69444, .07555, 0, .66667],
      65: [0, .69444, 0, 0, .66667],
      66: [0, .69444, .08293, 0, .66667],
      67: [0, .69444, .11983, 0, .63889],
      68: [0, .69444, .07555, 0, .72223],
      69: [0, .69444, .11983, 0, .59722],
      70: [0, .69444, .13372, 0, .56945],
      71: [0, .69444, .11983, 0, .66667],
      72: [0, .69444, .08094, 0, .70834],
      73: [0, .69444, .13372, 0, .27778],
      74: [0, .69444, .08094, 0, .47222],
      75: [0, .69444, .11983, 0, .69445],
      76: [0, .69444, 0, 0, .54167],
      77: [0, .69444, .08094, 0, .875],
      78: [0, .69444, .08094, 0, .70834],
      79: [0, .69444, .07555, 0, .73611],
      80: [0, .69444, .08293, 0, .63889],
      81: [.125, .69444, .07555, 0, .73611],
      82: [0, .69444, .08293, 0, .64584],
      83: [0, .69444, .09205, 0, .55556],
      84: [0, .69444, .13372, 0, .68056],
      85: [0, .69444, .08094, 0, .6875],
      86: [0, .69444, .1615, 0, .66667],
      87: [0, .69444, .1615, 0, .94445],
      88: [0, .69444, .13372, 0, .66667],
      89: [0, .69444, .17261, 0, .66667],
      90: [0, .69444, .11983, 0, .61111],
      91: [.25, .75, .15942, 0, .28889],
      93: [.25, .75, .08719, 0, .28889],
      94: [0, .69444, .0799, 0, .5],
      95: [.35, .09444, .08616, 0, .5],
      97: [0, .44444, .00981, 0, .48056],
      98: [0, .69444, .03057, 0, .51667],
      99: [0, .44444, .08336, 0, .44445],
      100: [0, .69444, .09483, 0, .51667],
      101: [0, .44444, .06778, 0, .44445],
      102: [0, .69444, .21705, 0, .30556],
      103: [.19444, .44444, .10836, 0, .5],
      104: [0, .69444, .01778, 0, .51667],
      105: [0, .67937, .09718, 0, .23889],
      106: [.19444, .67937, .09162, 0, .26667],
      107: [0, .69444, .08336, 0, .48889],
      108: [0, .69444, .09483, 0, .23889],
      109: [0, .44444, .01778, 0, .79445],
      110: [0, .44444, .01778, 0, .51667],
      111: [0, .44444, .06613, 0, .5],
      112: [.19444, .44444, .0389, 0, .51667],
      113: [.19444, .44444, .04169, 0, .51667],
      114: [0, .44444, .10836, 0, .34167],
      115: [0, .44444, .0778, 0, .38333],
      116: [0, .57143, .07225, 0, .36111],
      117: [0, .44444, .04169, 0, .51667],
      118: [0, .44444, .10836, 0, .46111],
      119: [0, .44444, .10836, 0, .68334],
      120: [0, .44444, .09169, 0, .46111],
      121: [.19444, .44444, .10836, 0, .46111],
      122: [0, .44444, .08752, 0, .43472],
      126: [.35, .32659, .08826, 0, .5],
      160: [0, 0, 0, 0, .25],
      168: [0, .67937, .06385, 0, .5],
      176: [0, .69444, 0, 0, .73752],
      184: [.17014, 0, 0, 0, .44445],
      305: [0, .44444, .04169, 0, .23889],
      567: [.19444, .44444, .04169, 0, .26667],
      710: [0, .69444, .0799, 0, .5],
      711: [0, .63194, .08432, 0, .5],
      713: [0, .60889, .08776, 0, .5],
      714: [0, .69444, .09205, 0, .5],
      715: [0, .69444, 0, 0, .5],
      728: [0, .69444, .09483, 0, .5],
      729: [0, .67937, .07774, 0, .27778],
      730: [0, .69444, 0, 0, .73752],
      732: [0, .67659, .08826, 0, .5],
      733: [0, .69444, .09205, 0, .5],
      915: [0, .69444, .13372, 0, .54167],
      916: [0, .69444, 0, 0, .83334],
      920: [0, .69444, .07555, 0, .77778],
      923: [0, .69444, 0, 0, .61111],
      926: [0, .69444, .12816, 0, .66667],
      928: [0, .69444, .08094, 0, .70834],
      931: [0, .69444, .11983, 0, .72222],
      933: [0, .69444, .09031, 0, .77778],
      934: [0, .69444, .04603, 0, .72222],
      936: [0, .69444, .09031, 0, .77778],
      937: [0, .69444, .08293, 0, .72222],
      8211: [0, .44444, .08616, 0, .5],
      8212: [0, .44444, .08616, 0, 1],
      8216: [0, .69444, .07816, 0, .27778],
      8217: [0, .69444, .07816, 0, .27778],
      8220: [0, .69444, .14205, 0, .5],
      8221: [0, .69444, .00316, 0, .5]
    },
    "SansSerif-Regular": {
      32: [0, 0, 0, 0, .25],
      33: [0, .69444, 0, 0, .31945],
      34: [0, .69444, 0, 0, .5],
      35: [.19444, .69444, 0, 0, .83334],
      36: [.05556, .75, 0, 0, .5],
      37: [.05556, .75, 0, 0, .83334],
      38: [0, .69444, 0, 0, .75834],
      39: [0, .69444, 0, 0, .27778],
      40: [.25, .75, 0, 0, .38889],
      41: [.25, .75, 0, 0, .38889],
      42: [0, .75, 0, 0, .5],
      43: [.08333, .58333, 0, 0, .77778],
      44: [.125, .08333, 0, 0, .27778],
      45: [0, .44444, 0, 0, .33333],
      46: [0, .08333, 0, 0, .27778],
      47: [.25, .75, 0, 0, .5],
      48: [0, .65556, 0, 0, .5],
      49: [0, .65556, 0, 0, .5],
      50: [0, .65556, 0, 0, .5],
      51: [0, .65556, 0, 0, .5],
      52: [0, .65556, 0, 0, .5],
      53: [0, .65556, 0, 0, .5],
      54: [0, .65556, 0, 0, .5],
      55: [0, .65556, 0, 0, .5],
      56: [0, .65556, 0, 0, .5],
      57: [0, .65556, 0, 0, .5],
      58: [0, .44444, 0, 0, .27778],
      59: [.125, .44444, 0, 0, .27778],
      61: [-.13, .37, 0, 0, .77778],
      63: [0, .69444, 0, 0, .47222],
      64: [0, .69444, 0, 0, .66667],
      65: [0, .69444, 0, 0, .66667],
      66: [0, .69444, 0, 0, .66667],
      67: [0, .69444, 0, 0, .63889],
      68: [0, .69444, 0, 0, .72223],
      69: [0, .69444, 0, 0, .59722],
      70: [0, .69444, 0, 0, .56945],
      71: [0, .69444, 0, 0, .66667],
      72: [0, .69444, 0, 0, .70834],
      73: [0, .69444, 0, 0, .27778],
      74: [0, .69444, 0, 0, .47222],
      75: [0, .69444, 0, 0, .69445],
      76: [0, .69444, 0, 0, .54167],
      77: [0, .69444, 0, 0, .875],
      78: [0, .69444, 0, 0, .70834],
      79: [0, .69444, 0, 0, .73611],
      80: [0, .69444, 0, 0, .63889],
      81: [.125, .69444, 0, 0, .73611],
      82: [0, .69444, 0, 0, .64584],
      83: [0, .69444, 0, 0, .55556],
      84: [0, .69444, 0, 0, .68056],
      85: [0, .69444, 0, 0, .6875],
      86: [0, .69444, .01389, 0, .66667],
      87: [0, .69444, .01389, 0, .94445],
      88: [0, .69444, 0, 0, .66667],
      89: [0, .69444, .025, 0, .66667],
      90: [0, .69444, 0, 0, .61111],
      91: [.25, .75, 0, 0, .28889],
      93: [.25, .75, 0, 0, .28889],
      94: [0, .69444, 0, 0, .5],
      95: [.35, .09444, .02778, 0, .5],
      97: [0, .44444, 0, 0, .48056],
      98: [0, .69444, 0, 0, .51667],
      99: [0, .44444, 0, 0, .44445],
      100: [0, .69444, 0, 0, .51667],
      101: [0, .44444, 0, 0, .44445],
      102: [0, .69444, .06944, 0, .30556],
      103: [.19444, .44444, .01389, 0, .5],
      104: [0, .69444, 0, 0, .51667],
      105: [0, .67937, 0, 0, .23889],
      106: [.19444, .67937, 0, 0, .26667],
      107: [0, .69444, 0, 0, .48889],
      108: [0, .69444, 0, 0, .23889],
      109: [0, .44444, 0, 0, .79445],
      110: [0, .44444, 0, 0, .51667],
      111: [0, .44444, 0, 0, .5],
      112: [.19444, .44444, 0, 0, .51667],
      113: [.19444, .44444, 0, 0, .51667],
      114: [0, .44444, .01389, 0, .34167],
      115: [0, .44444, 0, 0, .38333],
      116: [0, .57143, 0, 0, .36111],
      117: [0, .44444, 0, 0, .51667],
      118: [0, .44444, .01389, 0, .46111],
      119: [0, .44444, .01389, 0, .68334],
      120: [0, .44444, 0, 0, .46111],
      121: [.19444, .44444, .01389, 0, .46111],
      122: [0, .44444, 0, 0, .43472],
      126: [.35, .32659, 0, 0, .5],
      160: [0, 0, 0, 0, .25],
      168: [0, .67937, 0, 0, .5],
      176: [0, .69444, 0, 0, .66667],
      184: [.17014, 0, 0, 0, .44445],
      305: [0, .44444, 0, 0, .23889],
      567: [.19444, .44444, 0, 0, .26667],
      710: [0, .69444, 0, 0, .5],
      711: [0, .63194, 0, 0, .5],
      713: [0, .60889, 0, 0, .5],
      714: [0, .69444, 0, 0, .5],
      715: [0, .69444, 0, 0, .5],
      728: [0, .69444, 0, 0, .5],
      729: [0, .67937, 0, 0, .27778],
      730: [0, .69444, 0, 0, .66667],
      732: [0, .67659, 0, 0, .5],
      733: [0, .69444, 0, 0, .5],
      915: [0, .69444, 0, 0, .54167],
      916: [0, .69444, 0, 0, .83334],
      920: [0, .69444, 0, 0, .77778],
      923: [0, .69444, 0, 0, .61111],
      926: [0, .69444, 0, 0, .66667],
      928: [0, .69444, 0, 0, .70834],
      931: [0, .69444, 0, 0, .72222],
      933: [0, .69444, 0, 0, .77778],
      934: [0, .69444, 0, 0, .72222],
      936: [0, .69444, 0, 0, .77778],
      937: [0, .69444, 0, 0, .72222],
      8211: [0, .44444, .02778, 0, .5],
      8212: [0, .44444, .02778, 0, 1],
      8216: [0, .69444, 0, 0, .27778],
      8217: [0, .69444, 0, 0, .27778],
      8220: [0, .69444, 0, 0, .5],
      8221: [0, .69444, 0, 0, .5]
    },
    "Script-Regular": {
      32: [0, 0, 0, 0, .25],
      65: [0, .7, .22925, 0, .80253],
      66: [0, .7, .04087, 0, .90757],
      67: [0, .7, .1689, 0, .66619],
      68: [0, .7, .09371, 0, .77443],
      69: [0, .7, .18583, 0, .56162],
      70: [0, .7, .13634, 0, .89544],
      71: [0, .7, .17322, 0, .60961],
      72: [0, .7, .29694, 0, .96919],
      73: [0, .7, .19189, 0, .80907],
      74: [.27778, .7, .19189, 0, 1.05159],
      75: [0, .7, .31259, 0, .91364],
      76: [0, .7, .19189, 0, .87373],
      77: [0, .7, .15981, 0, 1.08031],
      78: [0, .7, .3525, 0, .9015],
      79: [0, .7, .08078, 0, .73787],
      80: [0, .7, .08078, 0, 1.01262],
      81: [0, .7, .03305, 0, .88282],
      82: [0, .7, .06259, 0, .85],
      83: [0, .7, .19189, 0, .86767],
      84: [0, .7, .29087, 0, .74697],
      85: [0, .7, .25815, 0, .79996],
      86: [0, .7, .27523, 0, .62204],
      87: [0, .7, .27523, 0, .80532],
      88: [0, .7, .26006, 0, .94445],
      89: [0, .7, .2939, 0, .70961],
      90: [0, .7, .24037, 0, .8212],
      160: [0, 0, 0, 0, .25]
    },
    "Size1-Regular": {
      32: [0, 0, 0, 0, .25],
      40: [.35001, .85, 0, 0, .45834],
      41: [.35001, .85, 0, 0, .45834],
      47: [.35001, .85, 0, 0, .57778],
      91: [.35001, .85, 0, 0, .41667],
      92: [.35001, .85, 0, 0, .57778],
      93: [.35001, .85, 0, 0, .41667],
      123: [.35001, .85, 0, 0, .58334],
      125: [.35001, .85, 0, 0, .58334],
      160: [0, 0, 0, 0, .25],
      710: [0, .72222, 0, 0, .55556],
      732: [0, .72222, 0, 0, .55556],
      770: [0, .72222, 0, 0, .55556],
      771: [0, .72222, 0, 0, .55556],
      8214: [-99e-5, .601, 0, 0, .77778],
      8593: [1e-5, .6, 0, 0, .66667],
      8595: [1e-5, .6, 0, 0, .66667],
      8657: [1e-5, .6, 0, 0, .77778],
      8659: [1e-5, .6, 0, 0, .77778],
      8719: [.25001, .75, 0, 0, .94445],
      8720: [.25001, .75, 0, 0, .94445],
      8721: [.25001, .75, 0, 0, 1.05556],
      8730: [.35001, .85, 0, 0, 1],
      8739: [-.00599, .606, 0, 0, .33333],
      8741: [-.00599, .606, 0, 0, .55556],
      8747: [.30612, .805, .19445, 0, .47222],
      8748: [.306, .805, .19445, 0, .47222],
      8749: [.306, .805, .19445, 0, .47222],
      8750: [.30612, .805, .19445, 0, .47222],
      8896: [.25001, .75, 0, 0, .83334],
      8897: [.25001, .75, 0, 0, .83334],
      8898: [.25001, .75, 0, 0, .83334],
      8899: [.25001, .75, 0, 0, .83334],
      8968: [.35001, .85, 0, 0, .47222],
      8969: [.35001, .85, 0, 0, .47222],
      8970: [.35001, .85, 0, 0, .47222],
      8971: [.35001, .85, 0, 0, .47222],
      9168: [-99e-5, .601, 0, 0, .66667],
      10216: [.35001, .85, 0, 0, .47222],
      10217: [.35001, .85, 0, 0, .47222],
      10752: [.25001, .75, 0, 0, 1.11111],
      10753: [.25001, .75, 0, 0, 1.11111],
      10754: [.25001, .75, 0, 0, 1.11111],
      10756: [.25001, .75, 0, 0, .83334],
      10758: [.25001, .75, 0, 0, .83334]
    },
    "Size2-Regular": {
      32: [0, 0, 0, 0, .25],
      40: [.65002, 1.15, 0, 0, .59722],
      41: [.65002, 1.15, 0, 0, .59722],
      47: [.65002, 1.15, 0, 0, .81111],
      91: [.65002, 1.15, 0, 0, .47222],
      92: [.65002, 1.15, 0, 0, .81111],
      93: [.65002, 1.15, 0, 0, .47222],
      123: [.65002, 1.15, 0, 0, .66667],
      125: [.65002, 1.15, 0, 0, .66667],
      160: [0, 0, 0, 0, .25],
      710: [0, .75, 0, 0, 1],
      732: [0, .75, 0, 0, 1],
      770: [0, .75, 0, 0, 1],
      771: [0, .75, 0, 0, 1],
      8719: [.55001, 1.05, 0, 0, 1.27778],
      8720: [.55001, 1.05, 0, 0, 1.27778],
      8721: [.55001, 1.05, 0, 0, 1.44445],
      8730: [.65002, 1.15, 0, 0, 1],
      8747: [.86225, 1.36, .44445, 0, .55556],
      8748: [.862, 1.36, .44445, 0, .55556],
      8749: [.862, 1.36, .44445, 0, .55556],
      8750: [.86225, 1.36, .44445, 0, .55556],
      8896: [.55001, 1.05, 0, 0, 1.11111],
      8897: [.55001, 1.05, 0, 0, 1.11111],
      8898: [.55001, 1.05, 0, 0, 1.11111],
      8899: [.55001, 1.05, 0, 0, 1.11111],
      8968: [.65002, 1.15, 0, 0, .52778],
      8969: [.65002, 1.15, 0, 0, .52778],
      8970: [.65002, 1.15, 0, 0, .52778],
      8971: [.65002, 1.15, 0, 0, .52778],
      10216: [.65002, 1.15, 0, 0, .61111],
      10217: [.65002, 1.15, 0, 0, .61111],
      10752: [.55001, 1.05, 0, 0, 1.51112],
      10753: [.55001, 1.05, 0, 0, 1.51112],
      10754: [.55001, 1.05, 0, 0, 1.51112],
      10756: [.55001, 1.05, 0, 0, 1.11111],
      10758: [.55001, 1.05, 0, 0, 1.11111]
    },
    "Size3-Regular": {
      32: [0, 0, 0, 0, .25],
      40: [.95003, 1.45, 0, 0, .73611],
      41: [.95003, 1.45, 0, 0, .73611],
      47: [.95003, 1.45, 0, 0, 1.04445],
      91: [.95003, 1.45, 0, 0, .52778],
      92: [.95003, 1.45, 0, 0, 1.04445],
      93: [.95003, 1.45, 0, 0, .52778],
      123: [.95003, 1.45, 0, 0, .75],
      125: [.95003, 1.45, 0, 0, .75],
      160: [0, 0, 0, 0, .25],
      710: [0, .75, 0, 0, 1.44445],
      732: [0, .75, 0, 0, 1.44445],
      770: [0, .75, 0, 0, 1.44445],
      771: [0, .75, 0, 0, 1.44445],
      8730: [.95003, 1.45, 0, 0, 1],
      8968: [.95003, 1.45, 0, 0, .58334],
      8969: [.95003, 1.45, 0, 0, .58334],
      8970: [.95003, 1.45, 0, 0, .58334],
      8971: [.95003, 1.45, 0, 0, .58334],
      10216: [.95003, 1.45, 0, 0, .75],
      10217: [.95003, 1.45, 0, 0, .75]
    },
    "Size4-Regular": {
      32: [0, 0, 0, 0, .25],
      40: [1.25003, 1.75, 0, 0, .79167],
      41: [1.25003, 1.75, 0, 0, .79167],
      47: [1.25003, 1.75, 0, 0, 1.27778],
      91: [1.25003, 1.75, 0, 0, .58334],
      92: [1.25003, 1.75, 0, 0, 1.27778],
      93: [1.25003, 1.75, 0, 0, .58334],
      123: [1.25003, 1.75, 0, 0, .80556],
      125: [1.25003, 1.75, 0, 0, .80556],
      160: [0, 0, 0, 0, .25],
      710: [0, .825, 0, 0, 1.8889],
      732: [0, .825, 0, 0, 1.8889],
      770: [0, .825, 0, 0, 1.8889],
      771: [0, .825, 0, 0, 1.8889],
      8730: [1.25003, 1.75, 0, 0, 1],
      8968: [1.25003, 1.75, 0, 0, .63889],
      8969: [1.25003, 1.75, 0, 0, .63889],
      8970: [1.25003, 1.75, 0, 0, .63889],
      8971: [1.25003, 1.75, 0, 0, .63889],
      9115: [.64502, 1.155, 0, 0, .875],
      9116: [1e-5, .6, 0, 0, .875],
      9117: [.64502, 1.155, 0, 0, .875],
      9118: [.64502, 1.155, 0, 0, .875],
      9119: [1e-5, .6, 0, 0, .875],
      9120: [.64502, 1.155, 0, 0, .875],
      9121: [.64502, 1.155, 0, 0, .66667],
      9122: [-99e-5, .601, 0, 0, .66667],
      9123: [.64502, 1.155, 0, 0, .66667],
      9124: [.64502, 1.155, 0, 0, .66667],
      9125: [-99e-5, .601, 0, 0, .66667],
      9126: [.64502, 1.155, 0, 0, .66667],
      9127: [1e-5, .9, 0, 0, .88889],
      9128: [.65002, 1.15, 0, 0, .88889],
      9129: [.90001, 0, 0, 0, .88889],
      9130: [0, .3, 0, 0, .88889],
      9131: [1e-5, .9, 0, 0, .88889],
      9132: [.65002, 1.15, 0, 0, .88889],
      9133: [.90001, 0, 0, 0, .88889],
      9143: [.88502, .915, 0, 0, 1.05556],
      10216: [1.25003, 1.75, 0, 0, .80556],
      10217: [1.25003, 1.75, 0, 0, .80556],
      57344: [-.00499, .605, 0, 0, 1.05556],
      57345: [-.00499, .605, 0, 0, 1.05556],
      57680: [0, .12, 0, 0, .45],
      57681: [0, .12, 0, 0, .45],
      57682: [0, .12, 0, 0, .45],
      57683: [0, .12, 0, 0, .45]
    },
    "Typewriter-Regular": {
      32: [0, 0, 0, 0, .525],
      33: [0, .61111, 0, 0, .525],
      34: [0, .61111, 0, 0, .525],
      35: [0, .61111, 0, 0, .525],
      36: [.08333, .69444, 0, 0, .525],
      37: [.08333, .69444, 0, 0, .525],
      38: [0, .61111, 0, 0, .525],
      39: [0, .61111, 0, 0, .525],
      40: [.08333, .69444, 0, 0, .525],
      41: [.08333, .69444, 0, 0, .525],
      42: [0, .52083, 0, 0, .525],
      43: [-.08056, .53055, 0, 0, .525],
      44: [.13889, .125, 0, 0, .525],
      45: [-.08056, .53055, 0, 0, .525],
      46: [0, .125, 0, 0, .525],
      47: [.08333, .69444, 0, 0, .525],
      48: [0, .61111, 0, 0, .525],
      49: [0, .61111, 0, 0, .525],
      50: [0, .61111, 0, 0, .525],
      51: [0, .61111, 0, 0, .525],
      52: [0, .61111, 0, 0, .525],
      53: [0, .61111, 0, 0, .525],
      54: [0, .61111, 0, 0, .525],
      55: [0, .61111, 0, 0, .525],
      56: [0, .61111, 0, 0, .525],
      57: [0, .61111, 0, 0, .525],
      58: [0, .43056, 0, 0, .525],
      59: [.13889, .43056, 0, 0, .525],
      60: [-.05556, .55556, 0, 0, .525],
      61: [-.19549, .41562, 0, 0, .525],
      62: [-.05556, .55556, 0, 0, .525],
      63: [0, .61111, 0, 0, .525],
      64: [0, .61111, 0, 0, .525],
      65: [0, .61111, 0, 0, .525],
      66: [0, .61111, 0, 0, .525],
      67: [0, .61111, 0, 0, .525],
      68: [0, .61111, 0, 0, .525],
      69: [0, .61111, 0, 0, .525],
      70: [0, .61111, 0, 0, .525],
      71: [0, .61111, 0, 0, .525],
      72: [0, .61111, 0, 0, .525],
      73: [0, .61111, 0, 0, .525],
      74: [0, .61111, 0, 0, .525],
      75: [0, .61111, 0, 0, .525],
      76: [0, .61111, 0, 0, .525],
      77: [0, .61111, 0, 0, .525],
      78: [0, .61111, 0, 0, .525],
      79: [0, .61111, 0, 0, .525],
      80: [0, .61111, 0, 0, .525],
      81: [.13889, .61111, 0, 0, .525],
      82: [0, .61111, 0, 0, .525],
      83: [0, .61111, 0, 0, .525],
      84: [0, .61111, 0, 0, .525],
      85: [0, .61111, 0, 0, .525],
      86: [0, .61111, 0, 0, .525],
      87: [0, .61111, 0, 0, .525],
      88: [0, .61111, 0, 0, .525],
      89: [0, .61111, 0, 0, .525],
      90: [0, .61111, 0, 0, .525],
      91: [.08333, .69444, 0, 0, .525],
      92: [.08333, .69444, 0, 0, .525],
      93: [.08333, .69444, 0, 0, .525],
      94: [0, .61111, 0, 0, .525],
      95: [.09514, 0, 0, 0, .525],
      96: [0, .61111, 0, 0, .525],
      97: [0, .43056, 0, 0, .525],
      98: [0, .61111, 0, 0, .525],
      99: [0, .43056, 0, 0, .525],
      100: [0, .61111, 0, 0, .525],
      101: [0, .43056, 0, 0, .525],
      102: [0, .61111, 0, 0, .525],
      103: [.22222, .43056, 0, 0, .525],
      104: [0, .61111, 0, 0, .525],
      105: [0, .61111, 0, 0, .525],
      106: [.22222, .61111, 0, 0, .525],
      107: [0, .61111, 0, 0, .525],
      108: [0, .61111, 0, 0, .525],
      109: [0, .43056, 0, 0, .525],
      110: [0, .43056, 0, 0, .525],
      111: [0, .43056, 0, 0, .525],
      112: [.22222, .43056, 0, 0, .525],
      113: [.22222, .43056, 0, 0, .525],
      114: [0, .43056, 0, 0, .525],
      115: [0, .43056, 0, 0, .525],
      116: [0, .55358, 0, 0, .525],
      117: [0, .43056, 0, 0, .525],
      118: [0, .43056, 0, 0, .525],
      119: [0, .43056, 0, 0, .525],
      120: [0, .43056, 0, 0, .525],
      121: [.22222, .43056, 0, 0, .525],
      122: [0, .43056, 0, 0, .525],
      123: [.08333, .69444, 0, 0, .525],
      124: [.08333, .69444, 0, 0, .525],
      125: [.08333, .69444, 0, 0, .525],
      126: [0, .61111, 0, 0, .525],
      127: [0, .61111, 0, 0, .525],
      160: [0, 0, 0, 0, .525],
      176: [0, .61111, 0, 0, .525],
      184: [.19445, 0, 0, 0, .525],
      305: [0, .43056, 0, 0, .525],
      567: [.22222, .43056, 0, 0, .525],
      711: [0, .56597, 0, 0, .525],
      713: [0, .56555, 0, 0, .525],
      714: [0, .61111, 0, 0, .525],
      715: [0, .61111, 0, 0, .525],
      728: [0, .61111, 0, 0, .525],
      730: [0, .61111, 0, 0, .525],
      770: [0, .61111, 0, 0, .525],
      771: [0, .61111, 0, 0, .525],
      776: [0, .61111, 0, 0, .525],
      915: [0, .61111, 0, 0, .525],
      916: [0, .61111, 0, 0, .525],
      920: [0, .61111, 0, 0, .525],
      923: [0, .61111, 0, 0, .525],
      926: [0, .61111, 0, 0, .525],
      928: [0, .61111, 0, 0, .525],
      931: [0, .61111, 0, 0, .525],
      933: [0, .61111, 0, 0, .525],
      934: [0, .61111, 0, 0, .525],
      936: [0, .61111, 0, 0, .525],
      937: [0, .61111, 0, 0, .525],
      8216: [0, .61111, 0, 0, .525],
      8217: [0, .61111, 0, 0, .525],
      8242: [0, .61111, 0, 0, .525],
      9251: [.11111, .21944, 0, 0, .525]
    }
  },
  ja = {
    slant: [.25, .25, .25],
    space: [0, 0, 0],
    stretch: [0, 0, 0],
    shrink: [0, 0, 0],
    xHeight: [.431, .431, .431],
    quad: [1, 1.171, 1.472],
    extraSpace: [0, 0, 0],
    num1: [.677, .732, .925],
    num2: [.394, .384, .387],
    num3: [.444, .471, .504],
    denom1: [.686, .752, 1.025],
    denom2: [.345, .344, .532],
    sup1: [.413, .503, .504],
    sup2: [.363, .431, .404],
    sup3: [.289, .286, .294],
    sub1: [.15, .143, .2],
    sub2: [.247, .286, .4],
    supDrop: [.386, .353, .494],
    subDrop: [.05, .071, .1],
    delim1: [2.39, 1.7, 1.98],
    delim2: [1.01, 1.157, 1.42],
    axisHeight: [.25, .25, .25],
    defaultRuleThickness: [.04, .049, .049],
    bigOpSpacing1: [.111, .111, .111],
    bigOpSpacing2: [.166, .166, .166],
    bigOpSpacing3: [.2, .2, .2],
    bigOpSpacing4: [.6, .611, .611],
    bigOpSpacing5: [.1, .143, .143],
    sqrtRuleThickness: [.04, .04, .04],
    ptPerEm: [10, 10, 10],
    doubleRuleSep: [.2, .2, .2],
    arrayRuleWidth: [.04, .04, .04],
    fboxsep: [.3, .3, .3],
    fboxrule: [.04, .04, .04]
  },
  Mo = {
    Å: "A",
    Ð: "D",
    Þ: "o",
    å: "a",
    ð: "d",
    þ: "o",
    А: "A",
    Б: "B",
    В: "B",
    Г: "F",
    Д: "A",
    Е: "E",
    Ж: "K",
    З: "3",
    И: "N",
    Й: "N",
    К: "K",
    Л: "N",
    М: "M",
    Н: "H",
    О: "O",
    П: "N",
    Р: "P",
    С: "C",
    Т: "T",
    У: "y",
    Ф: "O",
    Х: "X",
    Ц: "U",
    Ч: "h",
    Ш: "W",
    Щ: "W",
    Ъ: "B",
    Ы: "X",
    Ь: "B",
    Э: "3",
    Ю: "X",
    Я: "R",
    а: "a",
    б: "b",
    в: "a",
    г: "r",
    д: "y",
    е: "e",
    ж: "m",
    з: "e",
    и: "n",
    й: "n",
    к: "n",
    л: "n",
    м: "m",
    н: "n",
    о: "o",
    п: "n",
    р: "p",
    с: "c",
    т: "o",
    у: "y",
    ф: "b",
    х: "x",
    ц: "n",
    ч: "n",
    ш: "w",
    щ: "w",
    ъ: "a",
    ы: "m",
    ь: "a",
    э: "e",
    ю: "m",
    я: "r"
  };
function B4(e, t) {
  vt[e] = t;
}
function us(e, t, n) {
  if (!vt[t]) throw new Error("Font metrics not found for font: " + t + ".");
  var r = e.charCodeAt(0),
    a = vt[t][r];
  if (!a && e[0] in Mo && (r = Mo[e[0]].charCodeAt(0), a = vt[t][r]), !a && n === "text" && Y0(r) && (a = vt[t][77]), a) return {
    depth: a[0],
    height: a[1],
    italic: a[2],
    skew: a[3],
    width: a[4]
  };
}
var Ga = {};
function D4(e) {
  var t;
  if (e >= 5 ? t = 0 : e >= 3 ? t = 1 : t = 2, !Ga[t]) {
    var n = Ga[t] = {
      cssEmPerMu: ja.quad[t] / 18
    };
    for (var r of Object.keys(ja)) n[r] = ja[r][t];
  }
  return Ga[t];
}
var be = {
  math: {},
  text: {}
};
function m(e, t, n, r, a, i) {
  be[e][a] = {
    font: t,
    group: n,
    replace: r
  }, i && r && (be[e][r] = be[e][a]);
}
var p = "math",
  N = "text",
  g = "main",
  v = "ams",
  ye = "accent-token",
  V = "bin",
  Ue = "close",
  Bn = "inner",
  Z = "mathord",
  Ae = "op-token",
  nt = "open",
  ur = "punct",
  x = "rel",
  Dt = "spacing",
  S = "textord";
m(p, g, x, "≡", "\\equiv", !0);
m(p, g, x, "≺", "\\prec", !0);
m(p, g, x, "≻", "\\succ", !0);
m(p, g, x, "∼", "\\sim", !0);
m(p, g, x, "⊥", "\\perp");
m(p, g, x, "⪯", "\\preceq", !0);
m(p, g, x, "⪰", "\\succeq", !0);
m(p, g, x, "≃", "\\simeq", !0);
m(p, g, x, "∣", "\\mid", !0);
m(p, g, x, "≪", "\\ll", !0);
m(p, g, x, "≫", "\\gg", !0);
m(p, g, x, "≍", "\\asymp", !0);
m(p, g, x, "∥", "\\parallel");
m(p, g, x, "⋈", "\\bowtie", !0);
m(p, g, x, "⌣", "\\smile", !0);
m(p, g, x, "⊑", "\\sqsubseteq", !0);
m(p, g, x, "⊒", "\\sqsupseteq", !0);
m(p, g, x, "≐", "\\doteq", !0);
m(p, g, x, "⌢", "\\frown", !0);
m(p, g, x, "∋", "\\ni", !0);
m(p, g, x, "∝", "\\propto", !0);
m(p, g, x, "⊢", "\\vdash", !0);
m(p, g, x, "⊣", "\\dashv", !0);
m(p, g, x, "∋", "\\owns");
m(p, g, ur, ".", "\\ldotp");
m(p, g, ur, "⋅", "\\cdotp");
m(p, g, ur, "⋅", "·");
m(N, g, S, "⋅", "·");
m(p, g, S, "#", "\\#");
m(N, g, S, "#", "\\#");
m(p, g, S, "&", "\\&");
m(N, g, S, "&", "\\&");
m(p, g, S, "ℵ", "\\aleph", !0);
m(p, g, S, "∀", "\\forall", !0);
m(p, g, S, "ℏ", "\\hbar", !0);
m(p, g, S, "∃", "\\exists", !0);
m(p, g, S, "∇", "\\nabla", !0);
m(p, g, S, "♭", "\\flat", !0);
m(p, g, S, "ℓ", "\\ell", !0);
m(p, g, S, "♮", "\\natural", !0);
m(p, g, S, "♣", "\\clubsuit", !0);
m(p, g, S, "℘", "\\wp", !0);
m(p, g, S, "♯", "\\sharp", !0);
m(p, g, S, "♢", "\\diamondsuit", !0);
m(p, g, S, "ℜ", "\\Re", !0);
m(p, g, S, "♡", "\\heartsuit", !0);
m(p, g, S, "ℑ", "\\Im", !0);
m(p, g, S, "♠", "\\spadesuit", !0);
m(p, g, S, "§", "\\S", !0);
m(N, g, S, "§", "\\S");
m(p, g, S, "¶", "\\P", !0);
m(N, g, S, "¶", "\\P");
m(p, g, S, "†", "\\dag");
m(N, g, S, "†", "\\dag");
m(N, g, S, "†", "\\textdagger");
m(p, g, S, "‡", "\\ddag");
m(N, g, S, "‡", "\\ddag");
m(N, g, S, "‡", "\\textdaggerdbl");
m(p, g, Ue, "⎱", "\\rmoustache", !0);
m(p, g, nt, "⎰", "\\lmoustache", !0);
m(p, g, Ue, "⟯", "\\rgroup", !0);
m(p, g, nt, "⟮", "\\lgroup", !0);
m(p, g, V, "∓", "\\mp", !0);
m(p, g, V, "⊖", "\\ominus", !0);
m(p, g, V, "⊎", "\\uplus", !0);
m(p, g, V, "⊓", "\\sqcap", !0);
m(p, g, V, "∗", "\\ast");
m(p, g, V, "⊔", "\\sqcup", !0);
m(p, g, V, "◯", "\\bigcirc", !0);
m(p, g, V, "∙", "\\bullet", !0);
m(p, g, V, "‡", "\\ddagger");
m(p, g, V, "≀", "\\wr", !0);
m(p, g, V, "⨿", "\\amalg");
m(p, g, V, "&", "\\And");
m(p, g, x, "⟵", "\\longleftarrow", !0);
m(p, g, x, "⇐", "\\Leftarrow", !0);
m(p, g, x, "⟸", "\\Longleftarrow", !0);
m(p, g, x, "⟶", "\\longrightarrow", !0);
m(p, g, x, "⇒", "\\Rightarrow", !0);
m(p, g, x, "⟹", "\\Longrightarrow", !0);
m(p, g, x, "↔", "\\leftrightarrow", !0);
m(p, g, x, "⟷", "\\longleftrightarrow", !0);
m(p, g, x, "⇔", "\\Leftrightarrow", !0);
m(p, g, x, "⟺", "\\Longleftrightarrow", !0);
m(p, g, x, "↦", "\\mapsto", !0);
m(p, g, x, "⟼", "\\longmapsto", !0);
m(p, g, x, "↗", "\\nearrow", !0);
m(p, g, x, "↩", "\\hookleftarrow", !0);
m(p, g, x, "↪", "\\hookrightarrow", !0);
m(p, g, x, "↘", "\\searrow", !0);
m(p, g, x, "↼", "\\leftharpoonup", !0);
m(p, g, x, "⇀", "\\rightharpoonup", !0);
m(p, g, x, "↙", "\\swarrow", !0);
m(p, g, x, "↽", "\\leftharpoondown", !0);
m(p, g, x, "⇁", "\\rightharpoondown", !0);
m(p, g, x, "↖", "\\nwarrow", !0);
m(p, g, x, "⇌", "\\rightleftharpoons", !0);
m(p, v, x, "≮", "\\nless", !0);
m(p, v, x, "", "\\@nleqslant");
m(p, v, x, "", "\\@nleqq");
m(p, v, x, "⪇", "\\lneq", !0);
m(p, v, x, "≨", "\\lneqq", !0);
m(p, v, x, "", "\\@lvertneqq");
m(p, v, x, "⋦", "\\lnsim", !0);
m(p, v, x, "⪉", "\\lnapprox", !0);
m(p, v, x, "⊀", "\\nprec", !0);
m(p, v, x, "⋠", "\\npreceq", !0);
m(p, v, x, "⋨", "\\precnsim", !0);
m(p, v, x, "⪹", "\\precnapprox", !0);
m(p, v, x, "≁", "\\nsim", !0);
m(p, v, x, "", "\\@nshortmid");
m(p, v, x, "∤", "\\nmid", !0);
m(p, v, x, "⊬", "\\nvdash", !0);
m(p, v, x, "⊭", "\\nvDash", !0);
m(p, v, x, "⋪", "\\ntriangleleft");
m(p, v, x, "⋬", "\\ntrianglelefteq", !0);
m(p, v, x, "⊊", "\\subsetneq", !0);
m(p, v, x, "", "\\@varsubsetneq");
m(p, v, x, "⫋", "\\subsetneqq", !0);
m(p, v, x, "", "\\@varsubsetneqq");
m(p, v, x, "≯", "\\ngtr", !0);
m(p, v, x, "", "\\@ngeqslant");
m(p, v, x, "", "\\@ngeqq");
m(p, v, x, "⪈", "\\gneq", !0);
m(p, v, x, "≩", "\\gneqq", !0);
m(p, v, x, "", "\\@gvertneqq");
m(p, v, x, "⋧", "\\gnsim", !0);
m(p, v, x, "⪊", "\\gnapprox", !0);
m(p, v, x, "⊁", "\\nsucc", !0);
m(p, v, x, "⋡", "\\nsucceq", !0);
m(p, v, x, "⋩", "\\succnsim", !0);
m(p, v, x, "⪺", "\\succnapprox", !0);
m(p, v, x, "≆", "\\ncong", !0);
m(p, v, x, "", "\\@nshortparallel");
m(p, v, x, "∦", "\\nparallel", !0);
m(p, v, x, "⊯", "\\nVDash", !0);
m(p, v, x, "⋫", "\\ntriangleright");
m(p, v, x, "⋭", "\\ntrianglerighteq", !0);
m(p, v, x, "", "\\@nsupseteqq");
m(p, v, x, "⊋", "\\supsetneq", !0);
m(p, v, x, "", "\\@varsupsetneq");
m(p, v, x, "⫌", "\\supsetneqq", !0);
m(p, v, x, "", "\\@varsupsetneqq");
m(p, v, x, "⊮", "\\nVdash", !0);
m(p, v, x, "⪵", "\\precneqq", !0);
m(p, v, x, "⪶", "\\succneqq", !0);
m(p, v, x, "", "\\@nsubseteqq");
m(p, v, V, "⊴", "\\unlhd");
m(p, v, V, "⊵", "\\unrhd");
m(p, v, x, "↚", "\\nleftarrow", !0);
m(p, v, x, "↛", "\\nrightarrow", !0);
m(p, v, x, "⇍", "\\nLeftarrow", !0);
m(p, v, x, "⇏", "\\nRightarrow", !0);
m(p, v, x, "↮", "\\nleftrightarrow", !0);
m(p, v, x, "⇎", "\\nLeftrightarrow", !0);
m(p, v, x, "△", "\\vartriangle");
m(p, v, S, "ℏ", "\\hslash");
m(p, v, S, "▽", "\\triangledown");
m(p, v, S, "◊", "\\lozenge");
m(p, v, S, "Ⓢ", "\\circledS");
m(p, v, S, "®", "\\circledR");
m(N, v, S, "®", "\\circledR");
m(p, v, S, "∡", "\\measuredangle", !0);
m(p, v, S, "∄", "\\nexists");
m(p, v, S, "℧", "\\mho");
m(p, v, S, "Ⅎ", "\\Finv", !0);
m(p, v, S, "⅁", "\\Game", !0);
m(p, v, S, "‵", "\\backprime");
m(p, v, S, "▲", "\\blacktriangle");
m(p, v, S, "▼", "\\blacktriangledown");
m(p, v, S, "■", "\\blacksquare");
m(p, v, S, "⧫", "\\blacklozenge");
m(p, v, S, "★", "\\bigstar");
m(p, v, S, "∢", "\\sphericalangle", !0);
m(p, v, S, "∁", "\\complement", !0);
m(p, v, S, "ð", "\\eth", !0);
m(N, g, S, "ð", "ð");
m(p, v, S, "╱", "\\diagup");
m(p, v, S, "╲", "\\diagdown");
m(p, v, S, "□", "\\square");
m(p, v, S, "□", "\\Box");
m(p, v, S, "◊", "\\Diamond");
m(p, v, S, "¥", "\\yen", !0);
m(N, v, S, "¥", "\\yen", !0);
m(p, v, S, "✓", "\\checkmark", !0);
m(N, v, S, "✓", "\\checkmark");
m(p, v, S, "ℶ", "\\beth", !0);
m(p, v, S, "ℸ", "\\daleth", !0);
m(p, v, S, "ℷ", "\\gimel", !0);
m(p, v, S, "ϝ", "\\digamma", !0);
m(p, v, S, "ϰ", "\\varkappa");
m(p, v, nt, "┌", "\\@ulcorner", !0);
m(p, v, Ue, "┐", "\\@urcorner", !0);
m(p, v, nt, "└", "\\@llcorner", !0);
m(p, v, Ue, "┘", "\\@lrcorner", !0);
m(p, v, x, "≦", "\\leqq", !0);
m(p, v, x, "⩽", "\\leqslant", !0);
m(p, v, x, "⪕", "\\eqslantless", !0);
m(p, v, x, "≲", "\\lesssim", !0);
m(p, v, x, "⪅", "\\lessapprox", !0);
m(p, v, x, "≊", "\\approxeq", !0);
m(p, v, V, "⋖", "\\lessdot");
m(p, v, x, "⋘", "\\lll", !0);
m(p, v, x, "≶", "\\lessgtr", !0);
m(p, v, x, "⋚", "\\lesseqgtr", !0);
m(p, v, x, "⪋", "\\lesseqqgtr", !0);
m(p, v, x, "≑", "\\doteqdot");
m(p, v, x, "≓", "\\risingdotseq", !0);
m(p, v, x, "≒", "\\fallingdotseq", !0);
m(p, v, x, "∽", "\\backsim", !0);
m(p, v, x, "⋍", "\\backsimeq", !0);
m(p, v, x, "⫅", "\\subseteqq", !0);
m(p, v, x, "⋐", "\\Subset", !0);
m(p, v, x, "⊏", "\\sqsubset", !0);
m(p, v, x, "≼", "\\preccurlyeq", !0);
m(p, v, x, "⋞", "\\curlyeqprec", !0);
m(p, v, x, "≾", "\\precsim", !0);
m(p, v, x, "⪷", "\\precapprox", !0);
m(p, v, x, "⊲", "\\vartriangleleft");
m(p, v, x, "⊴", "\\trianglelefteq");
m(p, v, x, "⊨", "\\vDash", !0);
m(p, v, x, "⊪", "\\Vvdash", !0);
m(p, v, x, "⌣", "\\smallsmile");
m(p, v, x, "⌢", "\\smallfrown");
m(p, v, x, "≏", "\\bumpeq", !0);
m(p, v, x, "≎", "\\Bumpeq", !0);
m(p, v, x, "≧", "\\geqq", !0);
m(p, v, x, "⩾", "\\geqslant", !0);
m(p, v, x, "⪖", "\\eqslantgtr", !0);
m(p, v, x, "≳", "\\gtrsim", !0);
m(p, v, x, "⪆", "\\gtrapprox", !0);
m(p, v, V, "⋗", "\\gtrdot");
m(p, v, x, "⋙", "\\ggg", !0);
m(p, v, x, "≷", "\\gtrless", !0);
m(p, v, x, "⋛", "\\gtreqless", !0);
m(p, v, x, "⪌", "\\gtreqqless", !0);
m(p, v, x, "≖", "\\eqcirc", !0);
m(p, v, x, "≗", "\\circeq", !0);
m(p, v, x, "≜", "\\triangleq", !0);
m(p, v, x, "∼", "\\thicksim");
m(p, v, x, "≈", "\\thickapprox");
m(p, v, x, "⫆", "\\supseteqq", !0);
m(p, v, x, "⋑", "\\Supset", !0);
m(p, v, x, "⊐", "\\sqsupset", !0);
m(p, v, x, "≽", "\\succcurlyeq", !0);
m(p, v, x, "⋟", "\\curlyeqsucc", !0);
m(p, v, x, "≿", "\\succsim", !0);
m(p, v, x, "⪸", "\\succapprox", !0);
m(p, v, x, "⊳", "\\vartriangleright");
m(p, v, x, "⊵", "\\trianglerighteq");
m(p, v, x, "⊩", "\\Vdash", !0);
m(p, v, x, "∣", "\\shortmid");
m(p, v, x, "∥", "\\shortparallel");
m(p, v, x, "≬", "\\between", !0);
m(p, v, x, "⋔", "\\pitchfork", !0);
m(p, v, x, "∝", "\\varpropto");
m(p, v, x, "◀", "\\blacktriangleleft");
m(p, v, x, "∴", "\\therefore", !0);
m(p, v, x, "∍", "\\backepsilon");
m(p, v, x, "▶", "\\blacktriangleright");
m(p, v, x, "∵", "\\because", !0);
m(p, v, x, "⋘", "\\llless");
m(p, v, x, "⋙", "\\gggtr");
m(p, v, V, "⊲", "\\lhd");
m(p, v, V, "⊳", "\\rhd");
m(p, v, x, "≂", "\\eqsim", !0);
m(p, g, x, "⋈", "\\Join");
m(p, v, x, "≑", "\\Doteq", !0);
m(p, v, V, "∔", "\\dotplus", !0);
m(p, v, V, "∖", "\\smallsetminus");
m(p, v, V, "⋒", "\\Cap", !0);
m(p, v, V, "⋓", "\\Cup", !0);
m(p, v, V, "⩞", "\\doublebarwedge", !0);
m(p, v, V, "⊟", "\\boxminus", !0);
m(p, v, V, "⊞", "\\boxplus", !0);
m(p, v, V, "⋇", "\\divideontimes", !0);
m(p, v, V, "⋉", "\\ltimes", !0);
m(p, v, V, "⋊", "\\rtimes", !0);
m(p, v, V, "⋋", "\\leftthreetimes", !0);
m(p, v, V, "⋌", "\\rightthreetimes", !0);
m(p, v, V, "⋏", "\\curlywedge", !0);
m(p, v, V, "⋎", "\\curlyvee", !0);
m(p, v, V, "⊝", "\\circleddash", !0);
m(p, v, V, "⊛", "\\circledast", !0);
m(p, v, V, "⋅", "\\centerdot");
m(p, v, V, "⊺", "\\intercal", !0);
m(p, v, V, "⋒", "\\doublecap");
m(p, v, V, "⋓", "\\doublecup");
m(p, v, V, "⊠", "\\boxtimes", !0);
m(p, v, x, "⇢", "\\dashrightarrow", !0);
m(p, v, x, "⇠", "\\dashleftarrow", !0);
m(p, v, x, "⇇", "\\leftleftarrows", !0);
m(p, v, x, "⇆", "\\leftrightarrows", !0);
m(p, v, x, "⇚", "\\Lleftarrow", !0);
m(p, v, x, "↞", "\\twoheadleftarrow", !0);
m(p, v, x, "↢", "\\leftarrowtail", !0);
m(p, v, x, "↫", "\\looparrowleft", !0);
m(p, v, x, "⇋", "\\leftrightharpoons", !0);
m(p, v, x, "↶", "\\curvearrowleft", !0);
m(p, v, x, "↺", "\\circlearrowleft", !0);
m(p, v, x, "↰", "\\Lsh", !0);
m(p, v, x, "⇈", "\\upuparrows", !0);
m(p, v, x, "↿", "\\upharpoonleft", !0);
m(p, v, x, "⇃", "\\downharpoonleft", !0);
m(p, g, x, "⊶", "\\origof", !0);
m(p, g, x, "⊷", "\\imageof", !0);
m(p, v, x, "⊸", "\\multimap", !0);
m(p, v, x, "↭", "\\leftrightsquigarrow", !0);
m(p, v, x, "⇉", "\\rightrightarrows", !0);
m(p, v, x, "⇄", "\\rightleftarrows", !0);
m(p, v, x, "↠", "\\twoheadrightarrow", !0);
m(p, v, x, "↣", "\\rightarrowtail", !0);
m(p, v, x, "↬", "\\looparrowright", !0);
m(p, v, x, "↷", "\\curvearrowright", !0);
m(p, v, x, "↻", "\\circlearrowright", !0);
m(p, v, x, "↱", "\\Rsh", !0);
m(p, v, x, "⇊", "\\downdownarrows", !0);
m(p, v, x, "↾", "\\upharpoonright", !0);
m(p, v, x, "⇂", "\\downharpoonright", !0);
m(p, v, x, "⇝", "\\rightsquigarrow", !0);
m(p, v, x, "⇝", "\\leadsto");
m(p, v, x, "⇛", "\\Rrightarrow", !0);
m(p, v, x, "↾", "\\restriction");
m(p, g, S, "‘", "`");
m(p, g, S, "$", "\\$");
m(N, g, S, "$", "\\$");
m(N, g, S, "$", "\\textdollar");
m(p, g, S, "%", "\\%");
m(N, g, S, "%", "\\%");
m(p, g, S, "_", "\\_");
m(N, g, S, "_", "\\_");
m(N, g, S, "_", "\\textunderscore");
m(p, g, S, "∠", "\\angle", !0);
m(p, g, S, "∞", "\\infty", !0);
m(p, g, S, "′", "\\prime");
m(p, g, S, "△", "\\triangle");
m(p, g, S, "Γ", "\\Gamma", !0);
m(p, g, S, "Δ", "\\Delta", !0);
m(p, g, S, "Θ", "\\Theta", !0);
m(p, g, S, "Λ", "\\Lambda", !0);
m(p, g, S, "Ξ", "\\Xi", !0);
m(p, g, S, "Π", "\\Pi", !0);
m(p, g, S, "Σ", "\\Sigma", !0);
m(p, g, S, "Υ", "\\Upsilon", !0);
m(p, g, S, "Φ", "\\Phi", !0);
m(p, g, S, "Ψ", "\\Psi", !0);
m(p, g, S, "Ω", "\\Omega", !0);
m(p, g, S, "A", "Α");
m(p, g, S, "B", "Β");
m(p, g, S, "E", "Ε");
m(p, g, S, "Z", "Ζ");
m(p, g, S, "H", "Η");
m(p, g, S, "I", "Ι");
m(p, g, S, "K", "Κ");
m(p, g, S, "M", "Μ");
m(p, g, S, "N", "Ν");
m(p, g, S, "O", "Ο");
m(p, g, S, "P", "Ρ");
m(p, g, S, "T", "Τ");
m(p, g, S, "X", "Χ");
m(p, g, S, "¬", "\\neg", !0);
m(p, g, S, "¬", "\\lnot");
m(p, g, S, "⊤", "\\top");
m(p, g, S, "⊥", "\\bot");
m(p, g, S, "∅", "\\emptyset");
m(p, v, S, "∅", "\\varnothing");
m(p, g, Z, "α", "\\alpha", !0);
m(p, g, Z, "β", "\\beta", !0);
m(p, g, Z, "γ", "\\gamma", !0);
m(p, g, Z, "δ", "\\delta", !0);
m(p, g, Z, "ϵ", "\\epsilon", !0);
m(p, g, Z, "ζ", "\\zeta", !0);
m(p, g, Z, "η", "\\eta", !0);
m(p, g, Z, "θ", "\\theta", !0);
m(p, g, Z, "ι", "\\iota", !0);
m(p, g, Z, "κ", "\\kappa", !0);
m(p, g, Z, "λ", "\\lambda", !0);
m(p, g, Z, "μ", "\\mu", !0);
m(p, g, Z, "ν", "\\nu", !0);
m(p, g, Z, "ξ", "\\xi", !0);
m(p, g, Z, "ο", "\\omicron", !0);
m(p, g, Z, "π", "\\pi", !0);
m(p, g, Z, "ρ", "\\rho", !0);
m(p, g, Z, "σ", "\\sigma", !0);
m(p, g, Z, "τ", "\\tau", !0);
m(p, g, Z, "υ", "\\upsilon", !0);
m(p, g, Z, "ϕ", "\\phi", !0);
m(p, g, Z, "χ", "\\chi", !0);
m(p, g, Z, "ψ", "\\psi", !0);
m(p, g, Z, "ω", "\\omega", !0);
m(p, g, Z, "ε", "\\varepsilon", !0);
m(p, g, Z, "ϑ", "\\vartheta", !0);
m(p, g, Z, "ϖ", "\\varpi", !0);
m(p, g, Z, "ϱ", "\\varrho", !0);
m(p, g, Z, "ς", "\\varsigma", !0);
m(p, g, Z, "φ", "\\varphi", !0);
m(p, g, V, "∗", "*", !0);
m(p, g, V, "+", "+");
m(p, g, V, "−", "-", !0);
m(p, g, V, "⋅", "\\cdot", !0);
m(p, g, V, "∘", "\\circ", !0);
m(p, g, V, "÷", "\\div", !0);
m(p, g, V, "±", "\\pm", !0);
m(p, g, V, "×", "\\times", !0);
m(p, g, V, "∩", "\\cap", !0);
m(p, g, V, "∪", "\\cup", !0);
m(p, g, V, "∖", "\\setminus", !0);
m(p, g, V, "∧", "\\land");
m(p, g, V, "∨", "\\lor");
m(p, g, V, "∧", "\\wedge", !0);
m(p, g, V, "∨", "\\vee", !0);
m(p, g, S, "√", "\\surd");
m(p, g, nt, "⟨", "\\langle", !0);
m(p, g, nt, "∣", "\\lvert");
m(p, g, nt, "∥", "\\lVert");
m(p, g, Ue, "?", "?");
m(p, g, Ue, "!", "!");
m(p, g, Ue, "⟩", "\\rangle", !0);
m(p, g, Ue, "∣", "\\rvert");
m(p, g, Ue, "∥", "\\rVert");
m(p, g, x, "=", "=");
m(p, g, x, ":", ":");
m(p, g, x, "≈", "\\approx", !0);
m(p, g, x, "≅", "\\cong", !0);
m(p, g, x, "≥", "\\ge");
m(p, g, x, "≥", "\\geq", !0);
m(p, g, x, "←", "\\gets");
m(p, g, x, ">", "\\gt", !0);
m(p, g, x, "∈", "\\in", !0);
m(p, g, x, "", "\\@not");
m(p, g, x, "⊂", "\\subset", !0);
m(p, g, x, "⊃", "\\supset", !0);
m(p, g, x, "⊆", "\\subseteq", !0);
m(p, g, x, "⊇", "\\supseteq", !0);
m(p, v, x, "⊈", "\\nsubseteq", !0);
m(p, v, x, "⊉", "\\nsupseteq", !0);
m(p, g, x, "⊨", "\\models");
m(p, g, x, "←", "\\leftarrow", !0);
m(p, g, x, "≤", "\\le");
m(p, g, x, "≤", "\\leq", !0);
m(p, g, x, "<", "\\lt", !0);
m(p, g, x, "→", "\\rightarrow", !0);
m(p, g, x, "→", "\\to");
m(p, v, x, "≱", "\\ngeq", !0);
m(p, v, x, "≰", "\\nleq", !0);
m(p, g, Dt, " ", "\\ ");
m(p, g, Dt, " ", "\\space");
m(p, g, Dt, " ", "\\nobreakspace");
m(N, g, Dt, " ", "\\ ");
m(N, g, Dt, " ", " ");
m(N, g, Dt, " ", "\\space");
m(N, g, Dt, " ", "\\nobreakspace");
m(p, g, Dt, "", "\\nobreak");
m(p, g, Dt, "", "\\allowbreak");
m(p, g, ur, ",", ",");
m(p, g, ur, ";", ";");
m(p, v, V, "⊼", "\\barwedge", !0);
m(p, v, V, "⊻", "\\veebar", !0);
m(p, g, V, "⊙", "\\odot", !0);
m(p, g, V, "⊕", "\\oplus", !0);
m(p, g, V, "⊗", "\\otimes", !0);
m(p, g, S, "∂", "\\partial", !0);
m(p, g, V, "⊘", "\\oslash", !0);
m(p, v, V, "⊚", "\\circledcirc", !0);
m(p, v, V, "⊡", "\\boxdot", !0);
m(p, g, V, "△", "\\bigtriangleup");
m(p, g, V, "▽", "\\bigtriangledown");
m(p, g, V, "†", "\\dagger");
m(p, g, V, "⋄", "\\diamond");
m(p, g, V, "⋆", "\\star");
m(p, g, V, "◃", "\\triangleleft");
m(p, g, V, "▹", "\\triangleright");
m(p, g, nt, "{", "\\{");
m(N, g, S, "{", "\\{");
m(N, g, S, "{", "\\textbraceleft");
m(p, g, Ue, "}", "\\}");
m(N, g, S, "}", "\\}");
m(N, g, S, "}", "\\textbraceright");
m(p, g, nt, "{", "\\lbrace");
m(p, g, Ue, "}", "\\rbrace");
m(p, g, nt, "[", "\\lbrack", !0);
m(N, g, S, "[", "\\lbrack", !0);
m(p, g, Ue, "]", "\\rbrack", !0);
m(N, g, S, "]", "\\rbrack", !0);
m(p, g, nt, "(", "\\lparen", !0);
m(p, g, Ue, ")", "\\rparen", !0);
m(N, g, S, "<", "\\textless", !0);
m(N, g, S, ">", "\\textgreater", !0);
m(p, g, nt, "⌊", "\\lfloor", !0);
m(p, g, Ue, "⌋", "\\rfloor", !0);
m(p, g, nt, "⌈", "\\lceil", !0);
m(p, g, Ue, "⌉", "\\rceil", !0);
m(p, g, S, "\\", "\\backslash");
m(p, g, S, "∣", "|");
m(p, g, S, "∣", "\\vert");
m(N, g, S, "|", "\\textbar", !0);
m(p, g, S, "∥", "\\|");
m(p, g, S, "∥", "\\Vert");
m(N, g, S, "∥", "\\textbardbl");
m(N, g, S, "~", "\\textasciitilde");
m(N, g, S, "\\", "\\textbackslash");
m(N, g, S, "^", "\\textasciicircum");
m(p, g, x, "↑", "\\uparrow", !0);
m(p, g, x, "⇑", "\\Uparrow", !0);
m(p, g, x, "↓", "\\downarrow", !0);
m(p, g, x, "⇓", "\\Downarrow", !0);
m(p, g, x, "↕", "\\updownarrow", !0);
m(p, g, x, "⇕", "\\Updownarrow", !0);
m(p, g, Ae, "∐", "\\coprod");
m(p, g, Ae, "⋁", "\\bigvee");
m(p, g, Ae, "⋀", "\\bigwedge");
m(p, g, Ae, "⨄", "\\biguplus");
m(p, g, Ae, "⋂", "\\bigcap");
m(p, g, Ae, "⋃", "\\bigcup");
m(p, g, Ae, "∫", "\\int");
m(p, g, Ae, "∫", "\\intop");
m(p, g, Ae, "∬", "\\iint");
m(p, g, Ae, "∭", "\\iiint");
m(p, g, Ae, "∏", "\\prod");
m(p, g, Ae, "∑", "\\sum");
m(p, g, Ae, "⨂", "\\bigotimes");
m(p, g, Ae, "⨁", "\\bigoplus");
m(p, g, Ae, "⨀", "\\bigodot");
m(p, g, Ae, "∮", "\\oint");
m(p, g, Ae, "∯", "\\oiint");
m(p, g, Ae, "∰", "\\oiiint");
m(p, g, Ae, "⨆", "\\bigsqcup");
m(p, g, Ae, "∫", "\\smallint");
m(N, g, Bn, "…", "\\textellipsis");
m(p, g, Bn, "…", "\\mathellipsis");
m(N, g, Bn, "…", "\\ldots", !0);
m(p, g, Bn, "…", "\\ldots", !0);
m(p, g, Bn, "⋯", "\\@cdots", !0);
m(p, g, Bn, "⋱", "\\ddots", !0);
m(p, g, S, "⋮", "\\varvdots");
m(N, g, S, "⋮", "\\varvdots");
m(p, g, ye, "ˊ", "\\acute");
m(p, g, ye, "ˋ", "\\grave");
m(p, g, ye, "¨", "\\ddot");
m(p, g, ye, "~", "\\tilde");
m(p, g, ye, "ˉ", "\\bar");
m(p, g, ye, "˘", "\\breve");
m(p, g, ye, "ˇ", "\\check");
m(p, g, ye, "^", "\\hat");
m(p, g, ye, "⃗", "\\vec");
m(p, g, ye, "˙", "\\dot");
m(p, g, ye, "˚", "\\mathring");
m(p, g, Z, "", "\\@imath");
m(p, g, Z, "", "\\@jmath");
m(p, g, S, "ı", "ı");
m(p, g, S, "ȷ", "ȷ");
m(N, g, S, "ı", "\\i", !0);
m(N, g, S, "ȷ", "\\j", !0);
m(N, g, S, "ß", "\\ss", !0);
m(N, g, S, "æ", "\\ae", !0);
m(N, g, S, "œ", "\\oe", !0);
m(N, g, S, "ø", "\\o", !0);
m(N, g, S, "Æ", "\\AE", !0);
m(N, g, S, "Œ", "\\OE", !0);
m(N, g, S, "Ø", "\\O", !0);
m(N, g, ye, "ˊ", "\\'");
m(N, g, ye, "ˋ", "\\`");
m(N, g, ye, "ˆ", "\\^");
m(N, g, ye, "˜", "\\~");
m(N, g, ye, "ˉ", "\\=");
m(N, g, ye, "˘", "\\u");
m(N, g, ye, "˙", "\\.");
m(N, g, ye, "¸", "\\c");
m(N, g, ye, "˚", "\\r");
m(N, g, ye, "ˇ", "\\v");
m(N, g, ye, "¨", '\\"');
m(N, g, ye, "˝", "\\H");
m(N, g, ye, "◯", "\\textcircled");
var eu = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
m(N, g, S, "–", "--", !0);
m(N, g, S, "–", "\\textendash");
m(N, g, S, "—", "---", !0);
m(N, g, S, "—", "\\textemdash");
m(N, g, S, "‘", "`", !0);
m(N, g, S, "‘", "\\textquoteleft");
m(N, g, S, "’", "'", !0);
m(N, g, S, "’", "\\textquoteright");
m(N, g, S, "“", "``", !0);
m(N, g, S, "“", "\\textquotedblleft");
m(N, g, S, "”", "''", !0);
m(N, g, S, "”", "\\textquotedblright");
m(p, g, S, "°", "\\degree", !0);
m(N, g, S, "°", "\\degree");
m(N, g, S, "°", "\\textdegree", !0);
m(p, g, S, "£", "\\pounds");
m(p, g, S, "£", "\\mathsterling", !0);
m(N, g, S, "£", "\\pounds");
m(N, g, S, "£", "\\textsterling", !0);
m(p, v, S, "✠", "\\maltese");
m(N, v, S, "✠", "\\maltese");
var zo = '0123456789/@."';
for (var Ha = 0; Ha < zo.length; Ha++) {
  var Io = zo.charAt(Ha);
  m(p, g, S, Io, Io);
}
var No = '0123456789!@*()-=+";:?/.,';
for (var Ua = 0; Ua < No.length; Ua++) {
  var Ro = No.charAt(Ua);
  m(N, g, S, Ro, Ro);
}
var Jr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var Wa = 0; Wa < Jr.length; Wa++) {
  var $r = Jr.charAt(Wa);
  m(p, g, Z, $r, $r), m(N, g, S, $r, $r);
}
m(p, v, S, "C", "ℂ");
m(N, v, S, "C", "ℂ");
m(p, v, S, "H", "ℍ");
m(N, v, S, "H", "ℍ");
m(p, v, S, "N", "ℕ");
m(N, v, S, "N", "ℕ");
m(p, v, S, "P", "ℙ");
m(N, v, S, "P", "ℙ");
m(p, v, S, "Q", "ℚ");
m(N, v, S, "Q", "ℚ");
m(p, v, S, "R", "ℝ");
m(N, v, S, "R", "ℝ");
m(p, v, S, "Z", "ℤ");
m(N, v, S, "Z", "ℤ");
m(p, g, Z, "h", "ℎ");
m(N, g, Z, "h", "ℎ");
var Q;
for (var qe = 0; qe < Jr.length; qe++) {
  var xe = Jr.charAt(qe);
  Q = String.fromCharCode(55349, 56320 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), Q = String.fromCharCode(55349, 56372 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), Q = String.fromCharCode(55349, 56424 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), Q = String.fromCharCode(55349, 56580 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), Q = String.fromCharCode(55349, 56684 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), Q = String.fromCharCode(55349, 56736 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), Q = String.fromCharCode(55349, 56788 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), Q = String.fromCharCode(55349, 56840 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), Q = String.fromCharCode(55349, 56944 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), qe < 26 && (Q = String.fromCharCode(55349, 56632 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q), Q = String.fromCharCode(55349, 56476 + qe), m(p, g, Z, xe, Q), m(N, g, S, xe, Q));
}
Q = "𝕜";
m(p, g, Z, "k", Q);
m(N, g, S, "k", Q);
for (var nn = 0; nn < 10; nn++) {
  var Ot = nn.toString();
  Q = String.fromCharCode(55349, 57294 + nn), m(p, g, Z, Ot, Q), m(N, g, S, Ot, Q), Q = String.fromCharCode(55349, 57314 + nn), m(p, g, Z, Ot, Q), m(N, g, S, Ot, Q), Q = String.fromCharCode(55349, 57324 + nn), m(p, g, Z, Ot, Q), m(N, g, S, Ot, Q), Q = String.fromCharCode(55349, 57334 + nn), m(p, g, Z, Ot, Q), m(N, g, S, Ot, Q);
}
var Mi = "ÐÞþ";
for (var Va = 0; Va < Mi.length; Va++) {
  var Cr = Mi.charAt(Va);
  m(p, g, Z, Cr, Cr), m(N, g, S, Cr, Cr);
}
var zi = {
    mathClass: "mathbf",
    textClass: "textbf",
    font: "Main-Bold"
  },
  Bo = {
    mathClass: "mathnormal",
    textClass: "textit",
    font: "Math-Italic"
  },
  Do = {
    mathClass: "boldsymbol",
    textClass: "boldsymbol",
    font: "Main-BoldItalic"
  },
  L4 = {
    mathClass: "mathscr",
    textClass: "textscr",
    font: "Script-Regular"
  },
  on = {
    mathClass: "",
    textClass: "",
    font: ""
  },
  Lo = {
    mathClass: "mathfrak",
    textClass: "textfrak",
    font: "Fraktur-Regular"
  },
  Fo = {
    mathClass: "mathbb",
    textClass: "textbb",
    font: "AMS-Regular"
  },
  Po = {
    mathClass: "mathboldfrak",
    textClass: "textboldfrak",
    font: "Fraktur-Regular"
  },
  Ii = {
    mathClass: "mathsf",
    textClass: "textsf",
    font: "SansSerif-Regular"
  },
  Ni = {
    mathClass: "mathboldsf",
    textClass: "textboldsf",
    font: "SansSerif-Bold"
  },
  Oo = {
    mathClass: "mathitsf",
    textClass: "textitsf",
    font: "SansSerif-Italic"
  },
  Ri = {
    mathClass: "mathtt",
    textClass: "texttt",
    font: "Typewriter-Regular"
  },
  qo = [zi, zi, Bo, Bo, Do, Do, L4, on, on, on, Lo, Lo, Fo, Fo, Po, Po, Ii, Ii, Ni, Ni, Oo, Oo, on, on, Ri, Ri],
  F4 = [zi, on, Ii, Ni, Ri],
  P4 = e => {
    var t = e.charCodeAt(0),
      n = e.charCodeAt(1),
      r = (t - 55296) * 1024 + (n - 56320) + 65536;
    if (119808 <= r && r < 120484) {
      var a = Math.floor((r - 119808) / 26);
      return qo[a];
    } else if (120782 <= r && r <= 120831) {
      var i = Math.floor((r - 120782) / 10);
      return F4[i];
    } else {
      if (r === 120485 || r === 120486) return qo[0];
      if (120486 < r && r < 120782) return on;
      throw new D("Unsupported character: " + e);
    }
  },
  ha = function (t, n, r) {
    if (be[r][t]) {
      var a = be[r][t].replace;
      a && (t = a);
    }
    return {
      value: t,
      metrics: us(t, n, r)
    };
  },
  je = function (t, n, r, a, i) {
    var s = ha(t, n, r),
      o = s.metrics;
    t = s.value;
    var l;
    if (o) {
      var u = o.italic;
      (r === "text" || a && a.font === "mathit") && (u = 0), l = new tt(t, o.height, o.depth, u, o.skew, o.width, i);
    } else typeof console < "u" && console.warn("No character metrics " + ("for '" + t + "' in style '" + n + "' and mode '" + r + "'")), l = new tt(t, 0, 0, 0, 0, 0, i);
    if (a) {
      l.maxFontSize = a.sizeMultiplier, a.style.isTight() && l.classes.push("mtight");
      var c = a.getColor();
      c && (l.style.color = c);
    }
    return l;
  },
  cs = function (t, n, r, a) {
    return a === void 0 && (a = []), r.font === "boldsymbol" && ha(t, "Main-Bold", n).metrics ? je(t, "Main-Bold", n, r, a.concat(["mathbf"])) : t === "\\" || be[n][t].font === "main" ? je(t, "Main-Regular", n, r, a) : je(t, "AMS-Regular", n, r, a.concat(["amsrm"]));
  },
  O4 = function (t, n, r) {
    return r !== "textord" && ha(t, "Math-BoldItalic", n).metrics ? {
      fontName: "Math-BoldItalic",
      fontClass: "boldsymbol"
    } : {
      fontName: "Main-Bold",
      fontClass: "mathbf"
    };
  },
  pa = function (t, n) {
    var r = t.type === "mathord" ? "mathord" : "textord",
      a = t.mode,
      i = t.text,
      s = ["mord"],
      o = n.font,
      l = n.fontFamily,
      u = n.fontWeight,
      c = n.fontShape,
      h = a === "math" || a === "text" && !!o,
      f = h ? o : l,
      d = "",
      b = "";
    if (i.charCodeAt(0) === 55349) {
      var k = P4(i);
      d = k.font, b = k[a + "Class"];
    }
    if (d) return je(i, d, a, n, s.concat(b));
    if (f) {
      var A, w;
      if (f === "boldsymbol") {
        var _ = O4(i, a, r);
        A = _.fontName, w = [_.fontClass];
      } else h ? (A = Bi[o].fontName, w = [o]) : (A = Sr(l, u, c), w = [l, u, c]);
      if (ha(i, A, a).metrics) return je(i, A, a, n, s.concat(w));
      if (Object.prototype.hasOwnProperty.call(eu, i) && A.slice(0, 10) === "Typewriter") {
        for (var T = [], I = 0; I < i.length; I++) T.push(je(i[I], A, a, n, s.concat(w)));
        return Lt(T);
      }
    }
    if (r === "mathord") return je(i, "Math-Italic", a, n, s.concat(["mathnormal"]));
    if (r === "textord") {
      var R = be[a][i] && be[a][i].font;
      if (R === "ams") {
        var E = Sr("amsrm", u, c);
        return je(i, E, a, n, s.concat("amsrm", u, c));
      } else if (R === "main" || !R) {
        var O = Sr("textrm", u, c);
        return je(i, O, a, n, s.concat(u, c));
      } else {
        var W = Sr(R, u, c);
        return je(i, W, a, n, s.concat(W, u, c));
      }
    } else throw new Error("unexpected type: " + r + " in makeOrd");
  },
  q4 = (e, t) => {
    if (Ut(e.classes) !== Ut(t.classes) || e.skew !== t.skew || e.maxFontSize !== t.maxFontSize || e.italic !== 0 && e.hasClass("mathnormal")) return !1;
    if (e.classes.length === 1) {
      var n = e.classes[0];
      if (n === "mbin" || n === "mord") return !1;
    }
    for (var r of Object.keys(e.style)) if (e.style[r] !== t.style[r]) return !1;
    for (var a of Object.keys(t.style)) if (e.style[a] !== t.style[a]) return !1;
    return !0;
  },
  tu = e => {
    for (var t = 0; t < e.length - 1; t++) {
      var n = e[t],
        r = e[t + 1];
      n instanceof tt && r instanceof tt && q4(n, r) && (n.text += r.text, n.height = Math.max(n.height, r.height), n.depth = Math.max(n.depth, r.depth), n.italic = r.italic, e.splice(t + 1, 1), t--);
    }
    return e;
  },
  ms = function (t) {
    for (var n = 0, r = 0, a = 0, i = 0; i < t.children.length; i++) {
      var s = t.children[i];
      s.height > n && (n = s.height), s.depth > r && (r = s.depth), s.maxFontSize > a && (a = s.maxFontSize);
    }
    t.height = n, t.depth = r, t.maxFontSize = a;
  },
  B = function (t, n, r, a) {
    var i = new Rn(t, n, r, a);
    return ms(i), i;
  },
  Vt = (e, t, n, r) => new Rn(e, t, n, r),
  Tn = function (t, n, r) {
    var a = B([t], [], n);
    return a.height = Math.max(r || n.fontMetrics().defaultRuleThickness, n.minRuleThickness), a.style.borderBottomWidth = P(a.height), a.maxFontSize = 1, a;
  },
  j4 = function (t, n, r, a) {
    var i = new ma(t, n, r, a);
    return ms(i), i;
  },
  Lt = function (t) {
    var n = new Nn(t);
    return ms(n), n;
  },
  En = function (t, n) {
    return t instanceof Nn ? B([], [t], n) : t;
  },
  G4 = function (t) {
    if (t.positionType === "individualShift") {
      for (var n = t.children, r = [n[0]], a = -n[0].shift - n[0].elem.depth, i = a, s = 1; s < n.length; s++) {
        var o = -n[s].shift - i - n[s].elem.depth,
          l = o - (n[s - 1].elem.height + n[s - 1].elem.depth);
        i = i + o, r.push({
          type: "kern",
          size: l
        }), r.push(n[s]);
      }
      return {
        children: r,
        depth: a
      };
    }
    var u;
    if (t.positionType === "top") {
      for (var c = t.positionData, h = 0; h < t.children.length; h++) {
        var f = t.children[h];
        c -= f.type === "kern" ? f.size : f.elem.height + f.elem.depth;
      }
      u = c;
    } else if (t.positionType === "bottom") u = -t.positionData;else {
      var d = t.children[0];
      if (d.type !== "elem") throw new Error('First child must have type "elem".');
      if (t.positionType === "shift") u = -d.elem.depth - t.positionData;else if (t.positionType === "firstBaseline") u = -d.elem.depth;else throw new Error("Invalid positionType " + t.positionType + ".");
    }
    return {
      children: t.children,
      depth: u
    };
  },
  ce = function (t, n) {
    for (var r = G4(t), a = r.children, i = r.depth, s = 0, o = 0; o < a.length; o++) {
      var l = a[o];
      if (l.type === "elem") {
        var u = l.elem;
        s = Math.max(s, u.maxFontSize, u.height);
      }
    }
    s += 2;
    var c = B(["pstrut"], []);
    c.style.height = P(s);
    for (var h = [], f = i, d = i, b = i, k = 0; k < a.length; k++) {
      var A = a[k];
      if (A.type === "kern") b += A.size;else {
        var w = A.elem,
          _ = A.wrapperClasses || [],
          T = A.wrapperStyle || {},
          I = B(_, [c, w], void 0, T);
        I.style.top = P(-s - b - w.depth), A.marginLeft && (I.style.marginLeft = A.marginLeft), A.marginRight && (I.style.marginRight = A.marginRight), h.push(I), b += w.height + w.depth;
      }
      f = Math.min(f, b), d = Math.max(d, b);
    }
    var R = B(["vlist"], h);
    R.style.height = P(d);
    var E;
    if (f < 0) {
      var O = B([], []),
        W = B(["vlist"], [O]);
      W.style.height = P(-f);
      var G = B(["vlist-s"], [new tt("​")]);
      E = [B(["vlist-r"], [R, G]), B(["vlist-r"], [W])];
    } else E = [B(["vlist-r"], [R])];
    var M = B(["vlist-t"], E);
    return E.length === 2 && M.classes.push("vlist-t2"), M.height = d, M.depth = -f, M;
  },
  nu = (e, t) => {
    var n = B(["mspace"], [], t),
      r = we(e, t);
    return n.style.marginRight = P(r), n;
  },
  Sr = (e, t, n) => {
    var r, a;
    switch (e) {
      case "amsrm":
        r = "AMS";
        break;
      case "textrm":
        r = "Main";
        break;
      case "textsf":
        r = "SansSerif";
        break;
      case "texttt":
        r = "Typewriter";
        break;
      default:
        r = e;
    }
    return t === "textbf" && n === "textit" ? a = "BoldItalic" : t === "textbf" ? a = "Bold" : n === "textit" ? a = "Italic" : a = "Regular", r + "-" + a;
  },
  Bi = {
    mathbf: {
      variant: "bold",
      fontName: "Main-Bold"
    },
    mathrm: {
      variant: "normal",
      fontName: "Main-Regular"
    },
    textit: {
      variant: "italic",
      fontName: "Main-Italic"
    },
    mathit: {
      variant: "italic",
      fontName: "Main-Italic"
    },
    mathnormal: {
      variant: "italic",
      fontName: "Math-Italic"
    },
    mathsfit: {
      variant: "sans-serif-italic",
      fontName: "SansSerif-Italic"
    },
    mathbb: {
      variant: "double-struck",
      fontName: "AMS-Regular"
    },
    mathcal: {
      variant: "script",
      fontName: "Caligraphic-Regular"
    },
    mathfrak: {
      variant: "fraktur",
      fontName: "Fraktur-Regular"
    },
    mathscr: {
      variant: "script",
      fontName: "Script-Regular"
    },
    mathsf: {
      variant: "sans-serif",
      fontName: "SansSerif-Regular"
    },
    mathtt: {
      variant: "monospace",
      fontName: "Typewriter-Regular"
    }
  },
  ru = {
    vec: ["vec", .471, .714],
    oiintSize1: ["oiintSize1", .957, .499],
    oiintSize2: ["oiintSize2", 1.472, .659],
    oiiintSize1: ["oiiintSize1", 1.304, .499],
    oiiintSize2: ["oiiintSize2", 1.98, .659]
  },
  au = function (t, n) {
    var r = ru[t],
      a = r[0],
      i = r[1],
      s = r[2],
      o = new Wt(a),
      l = new Nt([o], {
        width: P(i),
        height: P(s),
        style: "width:" + P(i),
        viewBox: "0 0 " + 1e3 * i + " " + 1e3 * s,
        preserveAspectRatio: "xMinYMin"
      }),
      u = Vt(["katex-overlay"], [l], n);
    return u.height = s, u.style.height = P(s), u.style.width = P(i), u;
  },
  ve = {
    number: 3,
    unit: "mu"
  },
  rn = {
    number: 4,
    unit: "mu"
  },
  Et = {
    number: 5,
    unit: "mu"
  },
  H4 = {
    mord: {
      mop: ve,
      mbin: rn,
      mrel: Et,
      minner: ve
    },
    mop: {
      mord: ve,
      mop: ve,
      mrel: Et,
      minner: ve
    },
    mbin: {
      mord: rn,
      mop: rn,
      mopen: rn,
      minner: rn
    },
    mrel: {
      mord: Et,
      mop: Et,
      mopen: Et,
      minner: Et
    },
    mopen: {},
    mclose: {
      mop: ve,
      mbin: rn,
      mrel: Et,
      minner: ve
    },
    mpunct: {
      mord: ve,
      mop: ve,
      mrel: Et,
      mopen: ve,
      mclose: ve,
      mpunct: ve,
      minner: ve
    },
    minner: {
      mord: ve,
      mop: ve,
      mbin: rn,
      mrel: Et,
      mopen: ve,
      mpunct: ve,
      minner: ve
    }
  },
  U4 = {
    mord: {
      mop: ve
    },
    mop: {
      mord: ve,
      mop: ve
    },
    mbin: {},
    mrel: {},
    mopen: {},
    mclose: {
      mop: ve
    },
    mpunct: {},
    minner: {
      mop: ve
    }
  },
  iu = {},
  er = {},
  tr = {};
function U(e) {
  for (var t = e.type, n = e.names, r = e.htmlBuilder, a = e.mathmlBuilder, i = 0; i < n.length; ++i) iu[n[i]] = e;
  t && (r && (er[t] = r), a && (tr[t] = a));
}
function fn(e) {
  var t = e.type,
    n = e.htmlBuilder,
    r = e.mathmlBuilder;
  n && (er[t] = n), r && (tr[t] = r);
}
var nr = function (t) {
    return t.type === "ordgroup" && t.body.length === 1 ? t.body[0] : t;
  },
  Ce = function (t) {
    return t.type === "ordgroup" ? t.body : [t];
  },
  W4 = new Set(["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"]),
  V4 = new Set(["rightmost", "mrel", "mclose", "mpunct"]),
  X4 = {
    display: ee.DISPLAY,
    text: ee.TEXT,
    script: ee.SCRIPT,
    scriptscript: ee.SCRIPTSCRIPT
  },
  Y4 = {
    mord: "mord",
    mop: "mop",
    mbin: "mbin",
    mrel: "mrel",
    mopen: "mopen",
    mclose: "mclose",
    mpunct: "mpunct",
    minner: "minner"
  },
  ze = function (t, n, r, a) {
    a === void 0 && (a = [null, null]);
    for (var i = [], s = 0; s < t.length; s++) {
      var o = ue(t[s], n);
      if (o instanceof Nn) {
        var l = o.children;
        i.push(...l);
      } else i.push(o);
    }
    if (tu(i), !r) return i;
    var u = n;
    if (t.length === 1) {
      var c = t[0];
      c.type === "sizing" ? u = n.havingSize(c.size) : c.type === "styling" && (u = n.havingStyle(X4[c.style]));
    }
    var h = B([a[0] || "leftmost"], [], n),
      f = B([a[1] || "rightmost"], [], n),
      d = r === "root";
    return Di(i, (b, k) => {
      var A = k.classes[0],
        w = b.classes[0];
      A === "mbin" && V4.has(w) ? k.classes[0] = "mord" : w === "mbin" && W4.has(A) && (b.classes[0] = "mord");
    }, {
      node: h
    }, f, d), Di(i, (b, k) => {
      var A,
        w,
        _ = Fi(k),
        T = Fi(b),
        I = _ && T ? b.hasClass("mtight") ? (A = U4[_]) == null ? void 0 : A[T] : (w = H4[_]) == null ? void 0 : w[T] : null;
      if (I) return nu(I, u);
    }, {
      node: h
    }, f, d), i;
  },
  Di = function (t, n, r, a, i) {
    a && t.push(a);
    for (var s = 0; s < t.length; s++) {
      var o = t[s],
        l = su(o);
      if (l) {
        Di(l.children, n, r, null, i);
        continue;
      }
      var u = !o.hasClass("mspace");
      if (u) {
        var c = n(o, r.node);
        c && (r.insertAfter ? r.insertAfter(c) : (t.unshift(c), s++));
      }
      u ? r.node = o : i && o.hasClass("katex-newline") && (r.node = B(["leftmost"])), r.insertAfter = (h => f => {
        t.splice(h + 1, 0, f), s++;
      })(s);
    }
    a && t.pop();
  },
  su = function (t) {
    return t instanceof Nn || t instanceof ma || t instanceof Rn && t.hasClass("enclosing") ? t : null;
  },
  Li = function (t, n) {
    var r = su(t);
    if (r) {
      var a = r.children;
      if (a.length) {
        if (n === "right") return Li(a[a.length - 1], "right");
        if (n === "left") return Li(a[0], "left");
      }
    }
    return t;
  },
  Fi = function (t, n) {
    if (!t) return null;
    n && (t = Li(t, n));
    var r = t.classes[0];
    return Y4[r] || null;
  },
  rr = function (t, n) {
    var r = ["nulldelimiter"].concat(t.baseSizingClasses());
    return B(n.concat(r));
  },
  ue = function (t, n, r) {
    if (!t) return B();
    if (er[t.type]) {
      var a = er[t.type](t, n);
      if (r && n.size !== r.size) {
        a = B(n.sizingClasses(r), [a], n);
        var i = n.sizeMultiplier / r.sizeMultiplier;
        a.height *= i, a.depth *= i;
      }
      return a;
    } else throw new D("Got group of unknown type: '" + t.type + "'");
  };
function Ar(e, t) {
  var n = B(["katex-base"], e, t),
    r = B(["katex-strut"]);
  return r.style.height = P(n.height + n.depth), n.depth && (r.style.verticalAlign = P(-n.depth)), n.children.unshift(r), n;
}
function Pi(e, t) {
  var n = null;
  e.length === 1 && e[0].type === "tag" && (n = e[0].tag, e = e[0].body);
  var r = ze(e, t, "root"),
    a;
  r.length === 2 && r[1].hasClass("katex-tag") && (a = r.pop());
  for (var i = [], s = [], o = 0; o < r.length; o++) if (s.push(r[o]), r[o].hasClass("mbin") || r[o].hasClass("mrel") || r[o].hasClass("allowbreak")) {
    for (var l = !1; o < r.length - 1 && r[o + 1].hasClass("mspace") && !r[o + 1].hasClass("katex-newline");) o++, s.push(r[o]), r[o].hasClass("nobreak") && (l = !0);
    l || (i.push(Ar(s, t)), s = []);
  } else r[o].hasClass("katex-newline") && (s.pop(), s.length > 0 && (i.push(Ar(s, t)), s = []), i.push(r[o]));
  s.length > 0 && i.push(Ar(s, t));
  var u;
  n ? (u = Ar(ze(n, t, !0), t), u.classes = ["katex-tag"], i.push(u)) : a && i.push(a);
  var c = B(["katex-html"], i);
  if (c.setAttribute("aria-hidden", "true"), u) {
    var h = u.children[0];
    h.style.height = P(c.height + c.depth), c.depth && (h.style.verticalAlign = P(-c.depth));
  }
  return c;
}
function ou(e) {
  return new Nn(e);
}
class F {
  constructor(t, n, r) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = t, this.attributes = {}, this.children = n || [], this.classes = r || [];
  }
  setAttribute(t, n) {
    this.attributes[t] = n;
  }
  getAttribute(t) {
    return this.attributes[t];
  }
  toNode() {
    var t = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var n of Object.entries(this.attributes)) {
      var r = n[0],
        a = n[1];
      t.setAttribute(r, a);
    }
    this.classes.length > 0 && (t.className = Ut(this.classes));
    for (var i = 0; i < this.children.length; i++) if (this.children[i] instanceof Se && this.children[i + 1] instanceof Se) {
      for (var s = this.children[i].toText() + this.children[++i].toText(); this.children[i + 1] instanceof Se;) s += this.children[++i].toText();
      t.appendChild(new Se(s).toNode());
    } else t.appendChild(this.children[i].toNode());
    return t;
  }
  toMarkup() {
    var t = "<" + this.type;
    for (var n of Object.entries(this.attributes)) {
      var r = n[0],
        a = n[1];
      t += " " + r + '="', t += Pe(a), t += '"';
    }
    this.classes.length > 0 && (t += ' class ="' + Pe(Ut(this.classes)) + '"'), t += ">";
    for (var i = 0; i < this.children.length; i++) t += this.children[i].toMarkup();
    return t += "</" + this.type + ">", t;
  }
  toText() {
    return this.children.map(t => t.toText()).join("");
  }
}
class Se {
  constructor(t) {
    this.text = void 0, this.text = t;
  }
  toNode() {
    return document.createTextNode(this.text);
  }
  toMarkup() {
    return Pe(this.toText());
  }
  toText() {
    return this.text;
  }
}
class lu {
  constructor(t) {
    this.width = void 0, this.character = void 0, this.width = t, t >= .05555 && t <= .05556 ? this.character = " " : t >= .1666 && t <= .1667 ? this.character = " " : t >= .2222 && t <= .2223 ? this.character = " " : t >= .2777 && t <= .2778 ? this.character = "  " : t >= -.05556 && t <= -.05555 ? this.character = " ⁣" : t >= -.1667 && t <= -.1666 ? this.character = " ⁣" : t >= -.2223 && t <= -.2222 ? this.character = " ⁣" : t >= -.2778 && t <= -.2777 ? this.character = " ⁣" : this.character = null;
  }
  toNode() {
    if (this.character) return document.createTextNode(this.character);
    var t = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return t.setAttribute("width", P(this.width)), t;
  }
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + P(this.width) + '"/>';
  }
  toText() {
    return this.character ? this.character : " ";
  }
}
var Z4 = new Set(["\\imath", "\\jmath"]),
  K4 = new Set(["mrow", "mtable"]),
  ct = function (t, n, r) {
    var a, i;
    return be[n][t] && be[n][t].replace && t.charCodeAt(0) !== 55349 && !(Object.prototype.hasOwnProperty.call(eu, t) && ((r == null || (a = r.fontFamily) == null ? void 0 : a.slice(4, 6)) === "tt" || (r == null || (i = r.font) == null ? void 0 : i.slice(4, 6)) === "tt")) && (t = be[n][t].replace), new Se(t);
  },
  hs = function (t) {
    return t.length === 1 ? t[0] : new F("mrow", t);
  },
  Q4 = {
    mathit: "italic",
    boldsymbol: e => e.type === "textord" ? "bold" : "bold-italic",
    mathbf: "bold",
    mathbb: "double-struck",
    mathsfit: "sans-serif-italic",
    mathfrak: "fraktur",
    mathscr: "script",
    mathcal: "script",
    mathsf: "sans-serif",
    mathtt: "monospace"
  },
  ps = (e, t) => {
    if (e.mode === "text") {
      if (t.fontFamily === "texttt") return "monospace";
      if (t.fontFamily === "textsf") return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
      if (t.fontShape === "textit" && t.fontWeight === "textbf") return "bold-italic";
      if (t.fontShape === "textit") return "italic";
      if (t.fontWeight === "textbf") return "bold";
    }
    var n = t.font;
    if (!n || n === "mathnormal") return null;
    var r = e.mode,
      a = Q4[n];
    if (a) return typeof a == "function" ? a(e) : a;
    var i = e.text;
    if (Z4.has(i)) return null;
    if (be[r][i]) {
      var s = be[r][i].replace;
      s && (i = s);
    }
    var o = Bi[n].fontName;
    return us(i, o, r) ? Bi[n].variant : null;
  };
function Xa(e) {
  if (!e) return !1;
  if (e.type === "mi" && e.children.length === 1) {
    var t = e.children[0];
    return t instanceof Se && t.text === ".";
  } else if (e.type === "mo" && e.children.length === 1 && e.getAttribute("separator") === "true" && e.getAttribute("lspace") === "0em" && e.getAttribute("rspace") === "0em") {
    var n = e.children[0];
    return n instanceof Se && n.text === ",";
  } else return !1;
}
var rt = function (t, n, r) {
    if (t.length === 1) {
      var a = he(t[0], n);
      return r && a instanceof F && a.type === "mo" && (a.setAttribute("lspace", "0em"), a.setAttribute("rspace", "0em")), [a];
    }
    for (var i = [], s, o = 0; o < t.length; o++) {
      var l = he(t[o], n);
      if (l instanceof F && s instanceof F) {
        if (l.type === "mtext" && s.type === "mtext" && l.getAttribute("mathvariant") === s.getAttribute("mathvariant")) {
          s.children.push(...l.children);
          continue;
        } else if (l.type === "mn" && s.type === "mn") {
          s.children.push(...l.children);
          continue;
        } else if (Xa(l) && s.type === "mn") {
          s.children.push(...l.children);
          continue;
        } else if (l.type === "mn" && Xa(s)) l.children = [...s.children, ...l.children], i.pop();else if ((l.type === "msup" || l.type === "msub") && l.children.length >= 1 && (s.type === "mn" || Xa(s))) {
          var u = l.children[0];
          u instanceof F && u.type === "mn" && (u.children = [...s.children, ...u.children], i.pop());
        } else if (s.type === "mi" && s.children.length === 1) {
          var c = s.children[0];
          if (c instanceof Se && c.text === "̸" && (l.type === "mo" || l.type === "mi" || l.type === "mn")) {
            var h = l.children[0];
            h instanceof Se && h.text.length > 0 && (h.text = h.text.slice(0, 1) + "̸" + h.text.slice(1), i.pop());
          }
        }
      }
      i.push(l), s = l;
    }
    return i;
  },
  Xt = function (t, n, r) {
    return hs(rt(t, n, r));
  },
  he = function (t, n) {
    if (!t) return new F("mrow");
    if (tr[t.type]) return tr[t.type](t, n);
    throw new D("Got group of unknown type: '" + t.type + "'");
  };
function jo(e, t, n, r, a) {
  var i = rt(e, n),
    s;
  i.length === 1 && i[0] instanceof F && K4.has(i[0].type) ? s = i[0] : s = new F("mrow", i);
  var o = new F("annotation", [new Se(t)]);
  o.setAttribute("encoding", "application/x-tex");
  var l = new F("semantics", [s, o]),
    u = new F("math", [l]);
  u.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), r && u.setAttribute("display", "block");
  var c = a ? "katex" : "katex-mathml";
  return B([c], [u]);
}
var J4 = [[1, 1, 1], [2, 1, 1], [3, 1, 1], [4, 2, 1], [5, 2, 1], [6, 3, 1], [7, 4, 2], [8, 6, 3], [9, 7, 6], [10, 8, 7], [11, 10, 9]],
  Go = [.5, .6, .7, .8, .9, 1, 1.2, 1.44, 1.728, 2.074, 2.488],
  Ho = function (t, n) {
    return n.size < 2 ? t : J4[t - 1][n.size - 1];
  };
class Mt {
  constructor(t) {
    this.style = void 0, this.color = void 0, this.size = void 0, this.textSize = void 0, this.phantom = void 0, this.font = void 0, this.fontFamily = void 0, this.fontWeight = void 0, this.fontShape = void 0, this.sizeMultiplier = void 0, this.maxSize = void 0, this.minRuleThickness = void 0, this._fontMetrics = void 0, this.style = t.style, this.color = t.color, this.size = t.size || Mt.BASESIZE, this.textSize = t.textSize || this.size, this.phantom = !!t.phantom, this.font = t.font || "", this.fontFamily = t.fontFamily || "", this.fontWeight = t.fontWeight || "", this.fontShape = t.fontShape || "", this.sizeMultiplier = Go[this.size - 1], this.maxSize = t.maxSize, this.minRuleThickness = t.minRuleThickness, this._fontMetrics = void 0;
  }
  extend(t) {
    var n = {
      style: this.style,
      size: this.size,
      textSize: this.textSize,
      color: this.color,
      phantom: this.phantom,
      font: this.font,
      fontFamily: this.fontFamily,
      fontWeight: this.fontWeight,
      fontShape: this.fontShape,
      maxSize: this.maxSize,
      minRuleThickness: this.minRuleThickness
    };
    return Object.assign(n, t), new Mt(n);
  }
  havingStyle(t) {
    return this.style === t ? this : this.extend({
      style: t,
      size: Ho(this.textSize, t)
    });
  }
  havingCrampedStyle() {
    return this.havingStyle(this.style.cramp());
  }
  havingSize(t) {
    return this.size === t && this.textSize === t ? this : this.extend({
      style: this.style.text(),
      size: t,
      textSize: t,
      sizeMultiplier: Go[t - 1]
    });
  }
  havingBaseStyle(t) {
    t = t || this.style.text();
    var n = Ho(Mt.BASESIZE, t);
    return this.size === n && this.textSize === Mt.BASESIZE && this.style === t ? this : this.extend({
      style: t,
      size: n
    });
  }
  havingBaseSizing() {
    var t;
    switch (this.style.id) {
      case 4:
      case 5:
        t = 3;
        break;
      case 6:
      case 7:
        t = 1;
        break;
      default:
        t = 6;
    }
    return this.extend({
      style: this.style.text(),
      size: t
    });
  }
  withColor(t) {
    return this.extend({
      color: t
    });
  }
  withPhantom() {
    return this.extend({
      phantom: !0
    });
  }
  withFont(t) {
    return this.extend({
      font: t
    });
  }
  withTextFontFamily(t) {
    return this.extend({
      fontFamily: t,
      font: ""
    });
  }
  withTextFontWeight(t) {
    return this.extend({
      fontWeight: t,
      font: ""
    });
  }
  withTextFontShape(t) {
    return this.extend({
      fontShape: t,
      font: ""
    });
  }
  sizingClasses(t) {
    return t.size !== this.size ? ["katex-sizing", "reset-size" + t.size, "size" + this.size] : [];
  }
  baseSizingClasses() {
    return this.size !== Mt.BASESIZE ? ["katex-sizing", "reset-size" + this.size, "size" + Mt.BASESIZE] : [];
  }
  fontMetrics() {
    return this._fontMetrics || (this._fontMetrics = D4(this.size)), this._fontMetrics;
  }
  getColor() {
    return this.phantom ? "transparent" : this.color;
  }
}
Mt.BASESIZE = 6;
var uu = function (t) {
    return new Mt({
      style: t.displayMode ? ee.DISPLAY : ee.TEXT,
      maxSize: t.maxSize,
      minRuleThickness: t.minRuleThickness
    });
  },
  cu = function (t, n) {
    if (n.displayMode) {
      var r = ["katex-display"];
      n.leqno && r.push("leqno"), n.fleqn && r.push("fleqn"), t = B(r, [t]);
    }
    return t;
  },
  e2 = function (t, n, r) {
    var a = uu(r),
      i;
    if (r.output === "mathml") return jo(t, n, a, r.displayMode, !0);
    if (r.output === "html") {
      var s = Pi(t, a);
      i = B(["katex"], [s]);
    } else {
      var o = jo(t, n, a, r.displayMode, !1),
        l = Pi(t, a);
      i = B(["katex"], [o, l]);
    }
    return cu(i, r);
  },
  t2 = function (t, n, r) {
    var a = uu(r),
      i = Pi(t, a),
      s = B(["katex"], [i]);
    return cu(s, r);
  },
  n2 = {
    widehat: "^",
    widecheck: "ˇ",
    widetilde: "~",
    utilde: "~",
    overleftarrow: "←",
    underleftarrow: "←",
    xleftarrow: "←",
    overrightarrow: "→",
    underrightarrow: "→",
    xrightarrow: "→",
    underbrace: "⏟",
    overbrace: "⏞",
    underbracket: "⎵",
    overbracket: "⎴",
    overgroup: "⏠",
    undergroup: "⏡",
    overleftrightarrow: "↔",
    underleftrightarrow: "↔",
    xleftrightarrow: "↔",
    Overrightarrow: "⇒",
    xRightarrow: "⇒",
    overleftharpoon: "↼",
    xleftharpoonup: "↼",
    overrightharpoon: "⇀",
    xrightharpoonup: "⇀",
    xLeftarrow: "⇐",
    xLeftrightarrow: "⇔",
    xhookleftarrow: "↩",
    xhookrightarrow: "↪",
    xmapsto: "↦",
    xrightharpoondown: "⇁",
    xleftharpoondown: "↽",
    xrightleftharpoons: "⇌",
    xleftrightharpoons: "⇋",
    xtwoheadleftarrow: "↞",
    xtwoheadrightarrow: "↠",
    xlongequal: "=",
    xtofrom: "⇄",
    xrightleftarrows: "⇄",
    xrightequilibrium: "⇌",
    xleftequilibrium: "⇋",
    "\\cdrightarrow": "→",
    "\\cdleftarrow": "←",
    "\\cdlongequal": "="
  },
  da = function (t) {
    var n = new F("mo", [new Se(n2[t.replace(/^\\/, "")])]);
    return n.setAttribute("stretchy", "true"), n;
  },
  r2 = {
    overrightarrow: [["rightarrow"], .888, 522, "xMaxYMin"],
    overleftarrow: [["leftarrow"], .888, 522, "xMinYMin"],
    underrightarrow: [["rightarrow"], .888, 522, "xMaxYMin"],
    underleftarrow: [["leftarrow"], .888, 522, "xMinYMin"],
    xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
    "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
    xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
    "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
    Overrightarrow: [["doublerightarrow"], .888, 560, "xMaxYMin"],
    xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
    xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
    overleftharpoon: [["leftharpoon"], .888, 522, "xMinYMin"],
    xleftharpoonup: [["leftharpoon"], .888, 522, "xMinYMin"],
    xleftharpoondown: [["leftharpoondown"], .888, 522, "xMinYMin"],
    overrightharpoon: [["rightharpoon"], .888, 522, "xMaxYMin"],
    xrightharpoonup: [["rightharpoon"], .888, 522, "xMaxYMin"],
    xrightharpoondown: [["rightharpoondown"], .888, 522, "xMaxYMin"],
    xlongequal: [["longequal"], .888, 334, "xMinYMin"],
    "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
    xtwoheadleftarrow: [["twoheadleftarrow"], .888, 334, "xMinYMin"],
    xtwoheadrightarrow: [["twoheadrightarrow"], .888, 334, "xMaxYMin"],
    overleftrightarrow: [["leftarrow", "rightarrow"], .888, 522],
    overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
    underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
    underleftrightarrow: [["leftarrow", "rightarrow"], .888, 522],
    xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
    xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
    xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
    xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
    xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
    xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
    overlinesegment: [["leftlinesegment", "rightlinesegment"], .888, 522],
    underlinesegment: [["leftlinesegment", "rightlinesegment"], .888, 522],
    overbracket: [["leftbracketover", "rightbracketover"], 1.6, 440],
    underbracket: [["leftbracketunder", "rightbracketunder"], 1.6, 410],
    overgroup: [["leftgroup", "rightgroup"], .888, 342],
    undergroup: [["leftgroupunder", "rightgroupunder"], .888, 342],
    xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
    xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
    xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
    xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
    xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
  },
  a2 = new Set(["widehat", "widecheck", "widetilde", "utilde"]),
  fa = function (t, n) {
    function r() {
      var l = 4e5,
        u = t.label.slice(1);
      if (a2.has(u) && "base" in t) {
        var c = t.base.type === "ordgroup" ? t.base.body.length : 1,
          h,
          f,
          d;
        if (c > 5) u === "widehat" || u === "widecheck" ? (h = 420, l = 2364, d = .42, f = u + "4") : (h = 312, l = 2340, d = .34, f = "tilde4");else {
          var b = [1, 1, 2, 2, 3, 3][c];
          u === "widehat" || u === "widecheck" ? (l = [0, 1062, 2364, 2364, 2364][b], h = [0, 239, 300, 360, 420][b], d = [0, .24, .3, .3, .36, .42][b], f = u + b) : (l = [0, 600, 1033, 2339, 2340][b], h = [0, 260, 286, 306, 312][b], d = [0, .26, .286, .3, .306, .34][b], f = "tilde" + b);
        }
        var k = new Wt(f),
          A = new Nt([k], {
            width: "100%",
            height: P(d),
            viewBox: "0 0 " + l + " " + h,
            preserveAspectRatio: "none"
          });
        return {
          span: Vt([], [A], n),
          minWidth: 0,
          height: d
        };
      } else {
        var w = [],
          _ = r2[u];
        if (!_) throw new Error('No SVG data for "' + u + '".');
        var T = _[0],
          I = _[1],
          R = _[2],
          E = R / 1e3,
          O = T.length,
          W,
          G;
        if (O === 1) {
          if (_.length !== 4) throw new Error('Expected 4-tuple for single-path SVG data "' + u + '".');
          W = ["hide-tail"], G = [_[3]];
        } else if (O === 2) W = ["halfarrow-left", "halfarrow-right"], G = ["xMinYMin", "xMaxYMin"];else if (O === 3) W = ["brace-left", "brace-center", "brace-right"], G = ["xMinYMin", "xMidYMin", "xMaxYMin"];else throw new Error(`Correct katexImagesData or update code here to support
                    ` + O + " children.");
        for (var M = 0; M < O; M++) {
          var H = new Wt(T[M]),
            q = new Nt([H], {
              width: "400em",
              height: P(E),
              viewBox: "0 0 " + l + " " + R,
              preserveAspectRatio: G[M] + " slice"
            }),
            ne = Vt([W[M]], [q], n);
          if (O === 1) return {
            span: ne,
            minWidth: I,
            height: E
          };
          ne.style.height = P(E), w.push(ne);
        }
        return {
          span: B(["katex-stretchy"], w, n),
          minWidth: I,
          height: E
        };
      }
    }
    var a = r(),
      i = a.span,
      s = a.minWidth,
      o = a.height;
    return i.height = o, i.style.height = P(o), s > 0 && (i.style.minWidth = P(s)), i;
  },
  i2 = function (t, n, r, a, i) {
    var s,
      o = t.height + t.depth + r + a;
    if (/fbox|color|angl/.test(n)) {
      if (s = B(["katex-stretchy", n], [], i), n === "fbox") {
        var l = i.color && i.getColor();
        l && (s.style.borderColor = l);
      }
    } else {
      var u = [];
      /^[bx]cancel$/.test(n) && u.push(new Ei({
        x1: "0",
        y1: "0",
        x2: "100%",
        y2: "100%",
        "stroke-width": "0.046em"
      })), /^x?cancel$/.test(n) && u.push(new Ei({
        x1: "0",
        y1: "100%",
        x2: "100%",
        y2: "0",
        "stroke-width": "0.046em"
      }));
      var c = new Nt(u, {
        width: "100%",
        height: P(o)
      });
      s = Vt([], [c], i);
    }
    return s.height = o, s.style.height = P(o), s;
  },
  s2 = ["bin", "close", "inner", "open", "punct", "rel"],
  o2 = ["accent-token", "mathord", "op-token", "spacing", "textord"],
  l2 = new Set(s2),
  u2 = new Set(o2);
function c2(e) {
  return l2.has(e);
}
function ie(e, t) {
  if (!e || e.type !== t) throw new Error("Expected node of type " + t + ", but got " + (e ? "node of type " + e.type : String(e)));
  return e;
}
function ga(e) {
  var t = ba(e);
  if (!t) throw new Error("Expected node of symbol group type, but got " + (e ? "node of type " + e.type : String(e)));
  return t;
}
function ba(e) {
  return e.type === "atom" || u2.has(e.type) ? e : null;
}
function ds(e, t, n) {
  var r = "";
  for (var a of e.body) if (a.type === "textord") r += a.text;else if (n && a.type === "spacing" && a.text === " ") r += " ";else throw new D(t, e);
  return r;
}
var mu = e => {
    if (e instanceof tt) return e;
    if (R4(e) && e.children.length === 1) return mu(e.children[0]);
  },
  hu = (e, t) => {
    var n, r, a;
    e && e.type === "supsub" ? (r = ie(e.base, "accent"), n = r.base, e.base = n, a = N4(ue(e, t)), e.base = r) : (r = ie(e, "accent"), n = r.base);
    var i = ue(n, t.havingCrampedStyle()),
      s = r.isShifty && Bt(n),
      o = 0;
    if (s) {
      var l, u;
      o = (l = (u = mu(i)) == null ? void 0 : u.skew) != null ? l : 0;
    }
    var c = r.label === "\\c",
      h = c ? i.height + i.depth : Math.min(i.height, t.fontMetrics().xHeight),
      f;
    if (r.isStretchy) f = fa(r, t), f = ce({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "elem",
        elem: f,
        wrapperClasses: ["svg-align"],
        wrapperStyle: o > 0 ? {
          width: "calc(100% - " + P(2 * o) + ")",
          marginLeft: P(2 * o)
        } : void 0
      }]
    });else {
      var d, b;
      r.label === "\\vec" ? (d = au("vec", t), b = ru.vec[1]) : (d = pa({
        type: "textord",
        mode: r.mode,
        text: r.label
      }, t), d = I4(d), d.italic = 0, b = d.width, c && (h += d.depth)), f = B(["accent-body"], [d]);
      var k = r.label === "\\textcircled";
      k && (f.classes.push("accent-full"), h = i.height);
      var A = o;
      k || (A -= b / 2), f.style.left = P(A), r.label === "\\textcircled" && (f.style.top = ".2em"), f = ce({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: i
        }, {
          type: "kern",
          size: -h
        }, {
          type: "elem",
          elem: f
        }]
      });
    }
    var w = B(["mord", "katex-accent"], [f], t);
    return a ? (a.children[0] = w, a.height = Math.max(w.height, a.height), a.classes[0] = "mord", a) : w;
  },
  m2 = (e, t) => {
    var n = e.isStretchy ? da(e.label) : new F("mo", [ct(e.label, e.mode)]),
      r = new F("mover", [he(e.base, t), n]);
    return r.setAttribute("accent", "true"), r;
  },
  h2 = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map(e => "\\" + e).join("|"));
U({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  numArgs: 1,
  handler: (e, t) => {
    var n = nr(t[0]),
      r = !h2.test(e.funcName),
      a = !r || e.funcName === "\\widehat" || e.funcName === "\\widetilde" || e.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: e.parser.mode,
      label: e.funcName,
      isStretchy: r,
      isShifty: a,
      base: n
    };
  },
  htmlBuilder: hu,
  mathmlBuilder: m2
});
U({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  numArgs: 1,
  allowedInText: !0,
  allowedInMath: !0,
  argTypes: ["primitive"],
  handler: (e, t) => {
    var n = t[0],
      r = e.parser.mode;
    return r === "math" && (e.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + e.funcName + " works only in text mode"), r = "text"), {
      type: "accent",
      mode: r,
      label: e.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: n
    };
  }
});
U({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  numArgs: 1,
  handler: (e, t) => {
    var n = e.parser,
      r = e.funcName,
      a = t[0];
    return {
      type: "accentUnder",
      mode: n.mode,
      label: r,
      base: a
    };
  },
  htmlBuilder: (e, t) => {
    var n = ue(e.base, t),
      r = fa(e, t),
      a = e.label === "\\utilde" ? .12 : 0,
      i = ce({
        positionType: "top",
        positionData: n.height,
        children: [{
          type: "elem",
          elem: r,
          wrapperClasses: ["svg-align"]
        }, {
          type: "kern",
          size: a
        }, {
          type: "elem",
          elem: n
        }]
      });
    return B(["mord", "accentunder"], [i], t);
  },
  mathmlBuilder: (e, t) => {
    var n = da(e.label),
      r = new F("munder", [he(e.base, t), n]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
var Tr = e => {
  var t = new F("mpadded", e ? [e] : []);
  return t.setAttribute("width", "+0.6em"), t.setAttribute("lspace", "0.3em"), t;
};
U({
  type: "xArrow",
  names: ["\\xleftarrow", "\\xrightarrow", "\\xLeftarrow", "\\xRightarrow", "\\xleftrightarrow", "\\xLeftrightarrow", "\\xhookleftarrow", "\\xhookrightarrow", "\\xmapsto", "\\xrightharpoondown", "\\xrightharpoonup", "\\xleftharpoondown", "\\xleftharpoonup", "\\xrightleftharpoons", "\\xleftrightharpoons", "\\xlongequal", "\\xtwoheadrightarrow", "\\xtwoheadleftarrow", "\\xtofrom", "\\xrightleftarrows", "\\xrightequilibrium", "\\xleftequilibrium", "\\\\cdrightarrow", "\\\\cdleftarrow", "\\\\cdlongequal"],
  numArgs: 1,
  numOptionalArgs: 1,
  handler(e, t, n) {
    var r = e.parser,
      a = e.funcName;
    return {
      type: "xArrow",
      mode: r.mode,
      label: a,
      body: t[0],
      below: n[0]
    };
  },
  htmlBuilder(e, t) {
    var n = t.style,
      r = t.havingStyle(n.sup()),
      a = En(ue(e.body, r, t), t),
      i = e.label.slice(0, 2) === "\\x" ? "x" : "cd";
    a.classes.push(i + "-arrow-pad");
    var s;
    e.below && (r = t.havingStyle(n.sub()), s = En(ue(e.below, r, t), t), s.classes.push(i + "-arrow-pad"));
    var o = fa(e, t),
      l = -t.fontMetrics().axisHeight + .5 * o.height,
      u = -t.fontMetrics().axisHeight - .5 * o.height - .111;
    (a.depth > .25 || e.label === "\\xleftequilibrium") && (u -= a.depth);
    var c;
    if (s) {
      var h = -t.fontMetrics().axisHeight + s.height + .5 * o.height + .111;
      c = ce({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: u
        }, {
          type: "elem",
          elem: o,
          shift: l,
          wrapperClasses: ["svg-align"]
        }, {
          type: "elem",
          elem: s,
          shift: h
        }]
      });
    } else c = ce({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: a,
        shift: u
      }, {
        type: "elem",
        elem: o,
        shift: l,
        wrapperClasses: ["svg-align"]
      }]
    });
    return B(["mrel", "x-arrow"], [c], t);
  },
  mathmlBuilder(e, t) {
    var n = da(e.label);
    n.setAttribute("minsize", e.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var r;
    if (e.body) {
      var a = Tr(he(e.body, t));
      if (e.below) {
        var i = Tr(he(e.below, t));
        r = new F("munderover", [n, i, a]);
      } else r = new F("mover", [n, a]);
    } else if (e.below) {
      var s = Tr(he(e.below, t));
      r = new F("munder", [n, s]);
    } else r = Tr(), r = new F("mover", [n, r]);
    return r;
  }
});
function p2(e, t) {
  var n = ze(e.body, t, !0);
  return B([e.mclass], n, t);
}
function d2(e, t) {
  var n,
    r = rt(e.body, t);
  return e.mclass === "minner" ? n = new F("mpadded", r) : e.mclass === "mord" ? e.isCharacterBox ? (n = r[0], n.type = "mi") : n = new F("mi", r) : (e.isCharacterBox ? (n = r[0], n.type = "mo") : n = new F("mo", r), e.mclass === "mbin" ? (n.attributes.lspace = "0.22em", n.attributes.rspace = "0.22em") : e.mclass === "mpunct" ? (n.attributes.lspace = "0em", n.attributes.rspace = "0.17em") : (e.mclass === "mopen" || e.mclass === "mclose") && (n.attributes.lspace = "0em", n.attributes.rspace = "0em")), n;
}
U({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  numArgs: 1,
  primitive: !0,
  handler(e, t) {
    var n = e.parser,
      r = e.funcName,
      a = t[0];
    return {
      type: "mclass",
      mode: n.mode,
      mclass: "m" + r.slice(5),
      body: Ce(a),
      isCharacterBox: Bt(a)
    };
  },
  htmlBuilder: p2,
  mathmlBuilder: d2
});
var ya = e => {
  var t = e.type === "ordgroup" && e.body.length ? e.body[0] : e;
  return t.type === "atom" && (t.family === "bin" || t.family === "rel") ? "m" + t.family : "mord";
};
U({
  type: "mclass",
  names: ["\\@binrel"],
  numArgs: 2,
  handler(e, t) {
    var n = e.parser;
    return {
      type: "mclass",
      mode: n.mode,
      mclass: ya(t[0]),
      body: Ce(t[1]),
      isCharacterBox: Bt(t[1])
    };
  }
});
U({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  numArgs: 2,
  handler(e, t) {
    var n = e.parser,
      r = e.funcName,
      a = t[1],
      i = t[0],
      s;
    r !== "\\stackrel" ? s = ya(a) : s = "mrel";
    var o = {
        type: "op",
        mode: a.mode,
        limits: !0,
        alwaysHandleSupSub: !0,
        parentIsSupSub: !1,
        symbol: !1,
        suppressBaseShift: r !== "\\stackrel",
        body: Ce(a)
      },
      l = r === "\\underset" ? {
        type: "supsub",
        mode: i.mode,
        base: o,
        sub: i
      } : {
        type: "supsub",
        mode: i.mode,
        base: o,
        sup: i
      };
    return {
      type: "mclass",
      mode: n.mode,
      mclass: s,
      body: [l],
      isCharacterBox: Bt(l)
    };
  }
});
U({
  type: "pmb",
  names: ["\\pmb"],
  numArgs: 1,
  allowedInText: !0,
  handler(e, t) {
    var n = e.parser;
    return {
      type: "pmb",
      mode: n.mode,
      mclass: ya(t[0]),
      body: Ce(t[0])
    };
  },
  htmlBuilder(e, t) {
    var n = ze(e.body, t, !0),
      r = B([e.mclass], n, t);
    return r.style.textShadow = "0.02em 0.01em 0.04px", r;
  },
  mathmlBuilder(e, t) {
    var n = rt(e.body, t),
      r = new F("mstyle", n);
    return r.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), r;
  }
});
var f2 = {
    ">": "\\\\cdrightarrow",
    "<": "\\\\cdleftarrow",
    "=": "\\\\cdlongequal",
    A: "\\uparrow",
    V: "\\downarrow",
    "|": "\\Vert",
    ".": "no arrow"
  },
  Uo = () => ({
    type: "styling",
    body: [],
    mode: "math",
    style: "display",
    resetFont: !0
  }),
  Wo = e => e.type === "textord" && e.text === "@",
  g2 = (e, t) => (e.type === "mathord" || e.type === "atom") && e.text === t;
function b2(e, t, n) {
  var r = f2[e];
  switch (r) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return n.callFunction(r, [t[0]], [t[1]]);
    case "\\uparrow":
    case "\\downarrow":
      {
        var a = n.callFunction("\\\\cdleft", [t[0]], []),
          i = {
            type: "atom",
            text: r,
            mode: "math",
            family: "rel"
          },
          s = n.callFunction("\\Big", [i], []),
          o = n.callFunction("\\\\cdright", [t[1]], []),
          l = {
            type: "ordgroup",
            mode: "math",
            body: [a, s, o]
          };
        return n.callFunction("\\\\cdparent", [l], []);
      }
    case "\\\\cdlongequal":
      return n.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert":
      {
        var u = {
          type: "textord",
          text: "\\Vert",
          mode: "math"
        };
        return n.callFunction("\\Big", [u], []);
      }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function y2(e) {
  var t = [];
  for (e.gullet.beginGroup(), e.gullet.macros.set("\\cr", "\\\\\\relax"), e.gullet.beginGroup();;) {
    t.push(e.parseExpression(!1, "\\\\")), e.gullet.endGroup(), e.gullet.beginGroup();
    var n = e.fetch().text;
    if (n === "&" || n === "\\\\") e.consume();else if (n === "\\end") {
      t[t.length - 1].length === 0 && t.pop();
      break;
    } else throw new D("Expected \\\\ or \\cr or \\end", e.nextToken);
  }
  for (var r = [], a = [r], i = 0; i < t.length; i++) {
    for (var s = t[i], o = Uo(), l = 0; l < s.length; l++) if (!Wo(s[l])) o.body.push(s[l]);else {
      r.push(o), l += 1;
      var u = ga(s[l]).text,
        c = new Array(2);
      if (c[0] = {
        type: "ordgroup",
        mode: "math",
        body: []
      }, c[1] = {
        type: "ordgroup",
        mode: "math",
        body: []
      }, !"=|.".includes(u)) if ("<>AV".includes(u)) for (var h = 0; h < 2; h++) {
        for (var f = !0, d = l + 1; d < s.length; d++) {
          if (g2(s[d], u)) {
            f = !1, l = d;
            break;
          }
          if (Wo(s[d])) throw new D("Missing a " + u + " character to complete a CD arrow.", s[d]);
          c[h].body.push(s[d]);
        }
        if (f) throw new D("Missing a " + u + " character to complete a CD arrow.", s[l]);
      } else throw new D('Expected one of "<>AV=|." after @', s[l]);
      var b = b2(u, c, e),
        k = {
          type: "styling",
          body: [b],
          mode: "math",
          style: "display",
          resetFont: !0
        };
      r.push(k), o = Uo();
    }
    i % 2 === 0 ? r.push(o) : r.shift(), r = [], a.push(r);
  }
  e.gullet.endGroup(), e.gullet.endGroup();
  var A = new Array(a[0].length).fill({
    type: "align",
    align: "c",
    pregap: .25,
    postgap: .25
  });
  return {
    type: "array",
    mode: "math",
    body: a,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: A,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(a.length + 1).fill([])
  };
}
U({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  numArgs: 1,
  handler(e, t) {
    var n = e.parser,
      r = e.funcName;
    return {
      type: "cdlabel",
      mode: n.mode,
      side: r.slice(4),
      label: t[0]
    };
  },
  htmlBuilder(e, t) {
    var n = t.havingStyle(t.style.sup()),
      r = En(ue(e.label, n, t), t);
    return r.classes.push("cd-label-" + e.side), r.style.bottom = P(.8 - r.depth), r.height = 0, r.depth = 0, r;
  },
  mathmlBuilder(e, t) {
    var n = new F("mrow", [he(e.label, t)]);
    return n = new F("mpadded", [n]), n.setAttribute("width", "0"), e.side === "left" && n.setAttribute("lspace", "-1width"), n.setAttribute("voffset", "0.7em"), n = new F("mstyle", [n]), n.setAttribute("displaystyle", "false"), n.setAttribute("scriptlevel", "1"), n;
  }
});
U({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  numArgs: 1,
  handler(e, t) {
    var n = e.parser;
    return {
      type: "cdlabelparent",
      mode: n.mode,
      fragment: t[0]
    };
  },
  htmlBuilder(e, t) {
    var n = En(ue(e.fragment, t), t);
    return n.classes.push("cd-vert-arrow"), n;
  },
  mathmlBuilder(e, t) {
    return new F("mrow", [he(e.fragment, t)]);
  }
});
U({
  type: "textord",
  names: ["\\@char"],
  numArgs: 1,
  allowedInText: !0,
  handler(e, t) {
    var n = e.parser,
      r = ie(t[0], "ordgroup"),
      a = ds(r, "\\@char has non-numeric argument"),
      i = parseInt(a),
      s;
    if (isNaN(i)) throw new D("\\@char has non-numeric argument " + a);
    if (i < 0 || i > 1114111) throw new D("\\@char with invalid code point " + a);
    return i <= 65535 ? s = String.fromCharCode(i) : (i -= 65536, s = String.fromCharCode((i >> 10) + 55296, (i & 1023) + 56320)), {
      type: "textord",
      mode: n.mode,
      text: s
    };
  }
});
var v2 = (e, t) => {
    var n = ze(e.body, t.withColor(e.color), !1);
    return Lt(n);
  },
  w2 = (e, t) => {
    var n = rt(e.body, t.withColor(e.color)),
      r = new F("mstyle", n);
    return r.setAttribute("mathcolor", e.color), r;
  };
U({
  type: "color",
  names: ["\\textcolor"],
  numArgs: 2,
  allowedInText: !0,
  argTypes: ["color", "original"],
  handler(e, t) {
    var n = e.parser,
      r = ie(t[0], "color-token").color,
      a = t[1];
    return {
      type: "color",
      mode: n.mode,
      color: r,
      body: Ce(a)
    };
  },
  htmlBuilder: v2,
  mathmlBuilder: w2
});
U({
  type: "color",
  names: ["\\color"],
  numArgs: 1,
  allowedInText: !0,
  argTypes: ["color"],
  handler(e, t) {
    var n = e.parser,
      r = e.breakOnTokenText,
      a = ie(t[0], "color-token").color;
    n.gullet.macros.set("\\current@color", a);
    var i = n.parseExpression(!0, r);
    return {
      type: "color",
      mode: n.mode,
      color: a,
      body: i
    };
  }
});
U({
  type: "cr",
  names: ["\\\\"],
  numArgs: 0,
  numOptionalArgs: 0,
  allowedInText: !0,
  handler(e, t, n) {
    var r = e.parser,
      a = r.gullet.future().text === "[" ? r.parseSizeGroup(!0) : null,
      i = !r.settings.displayMode || !r.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: r.mode,
      newLine: i,
      size: a && ie(a, "size").value
    };
  },
  htmlBuilder(e, t) {
    var n = B(["mspace"], [], t);
    return e.newLine && (n.classes.push("katex-newline"), e.size && (n.style.marginTop = P(we(e.size, t)))), n;
  },
  mathmlBuilder(e, t) {
    var n = new F("mspace");
    return e.newLine && (n.setAttribute("linebreak", "newline"), e.size && n.setAttribute("height", P(we(e.size, t)))), n;
  }
});
var Oi = {
    "\\global": "\\global",
    "\\long": "\\\\globallong",
    "\\\\globallong": "\\\\globallong",
    "\\def": "\\gdef",
    "\\gdef": "\\gdef",
    "\\edef": "\\xdef",
    "\\xdef": "\\xdef",
    "\\let": "\\\\globallet",
    "\\futurelet": "\\\\globalfuture"
  },
  pu = e => {
    var t = e.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(t)) throw new D("Expected a control sequence", e);
    return t;
  },
  x2 = e => {
    var t = e.gullet.popToken();
    return t.text === "=" && (t = e.gullet.popToken(), t.text === " " && (t = e.gullet.popToken())), t;
  },
  du = (e, t, n, r) => {
    var a = e.gullet.macros.get(n.text);
    a == null && (n.noexpand = !0, a = {
      tokens: [n],
      numArgs: 0,
      unexpandable: !e.gullet.isExpandable(n.text)
    }), e.gullet.macros.set(t, a, r);
  };
U({
  type: "internal",
  names: ["\\global", "\\long", "\\\\globallong"],
  numArgs: 0,
  allowedInText: !0,
  handler(e) {
    var t = e.parser,
      n = e.funcName;
    t.consumeSpaces();
    var r = t.fetch();
    if (Oi[r.text]) return (n === "\\global" || n === "\\\\globallong") && (r.text = Oi[r.text]), ie(t.parseFunction(), "internal");
    throw new D("Invalid token after macro prefix", r);
  }
});
U({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  numArgs: 0,
  allowedInText: !0,
  primitive: !0,
  handler(e) {
    var t = e.parser,
      n = e.funcName,
      r = t.gullet.popToken(),
      a = r.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(a)) throw new D("Expected a control sequence", r);
    for (var i = 0, s, o = [[]]; t.gullet.future().text !== "{";) if (r = t.gullet.popToken(), r.text === "#") {
      if (t.gullet.future().text === "{") {
        s = t.gullet.future(), o[i].push("{");
        break;
      }
      if (r = t.gullet.popToken(), !/^[1-9]$/.test(r.text)) throw new D('Invalid argument number "' + r.text + '"');
      if (parseInt(r.text) !== i + 1) throw new D('Argument number "' + r.text + '" out of order');
      i++, o.push([]);
    } else {
      if (r.text === "EOF") throw new D("Expected a macro definition");
      o[i].push(r.text);
    }
    var l = t.gullet.consumeArg(),
      u = l.tokens;
    return s && u.unshift(s), (n === "\\edef" || n === "\\xdef") && (u = t.gullet.expandTokens(u), u.reverse()), t.gullet.macros.set(a, {
      tokens: u,
      numArgs: i,
      delimiters: o
    }, n === Oi[n]), {
      type: "internal",
      mode: t.mode
    };
  }
});
U({
  type: "internal",
  names: ["\\let", "\\\\globallet"],
  numArgs: 0,
  allowedInText: !0,
  primitive: !0,
  handler(e) {
    var t = e.parser,
      n = e.funcName,
      r = pu(t.gullet.popToken());
    t.gullet.consumeSpaces();
    var a = x2(t);
    return du(t, r, a, n === "\\\\globallet"), {
      type: "internal",
      mode: t.mode
    };
  }
});
U({
  type: "internal",
  names: ["\\futurelet", "\\\\globalfuture"],
  numArgs: 0,
  allowedInText: !0,
  primitive: !0,
  handler(e) {
    var t = e.parser,
      n = e.funcName,
      r = pu(t.gullet.popToken()),
      a = t.gullet.popToken(),
      i = t.gullet.popToken();
    return du(t, r, i, n === "\\\\globalfuture"), t.gullet.pushToken(i), t.gullet.pushToken(a), {
      type: "internal",
      mode: t.mode
    };
  }
});
var Gn = function (t, n, r) {
    var a = be.math[t] && be.math[t].replace,
      i = us(a || t, n, r);
    if (!i) throw new Error("Unsupported symbol " + t + " and font size " + n + ".");
    return i;
  },
  fs = function (t, n, r, a) {
    var i = r.havingBaseStyle(n),
      s = B(a.concat(i.sizingClasses(r)), [t], r),
      o = i.sizeMultiplier / r.sizeMultiplier;
    return s.height *= o, s.depth *= o, s.maxFontSize = i.sizeMultiplier, s;
  },
  fu = function (t, n, r) {
    var a = n.havingBaseStyle(r),
      i = (1 - n.sizeMultiplier / a.sizeMultiplier) * n.fontMetrics().axisHeight;
    t.classes.push("delimcenter"), t.style.top = P(i), t.height -= i, t.depth += i;
  },
  k2 = function (t, n, r, a, i, s) {
    var o = je(t, "Main-Regular", i, a),
      l = fs(o, n, a, s);
    return fu(l, a, n), l;
  },
  _2 = function (t, n, r, a) {
    return je(t, "Size" + n + "-Regular", r, a);
  },
  gu = function (t, n, r, a, i, s) {
    var o = _2(t, n, i, a),
      l = fs(B(["delimsizing", "size" + n], [o], a), ee.TEXT, a, s);
    return r && fu(l, a, ee.TEXT), l;
  },
  Ya = function (t, n, r) {
    var a;
    n === "Size1-Regular" ? a = "delim-size1" : a = "delim-size4";
    var i = B(["delimsizinginner", a], [B([], [je(t, n, r)])]);
    return {
      type: "elem",
      elem: i
    };
  },
  Za = function (t, n, r) {
    var a = vt["Size4-Regular"][t.charCodeAt(0)] ? vt["Size4-Regular"][t.charCodeAt(0)][4] : vt["Size1-Regular"][t.charCodeAt(0)][4],
      i = new Wt("inner", C4(t, Math.round(1e3 * n))),
      s = new Nt([i], {
        width: P(a),
        height: P(n),
        style: "width:" + P(a),
        viewBox: "0 0 " + 1e3 * a + " " + Math.round(1e3 * n),
        preserveAspectRatio: "xMinYMin"
      }),
      o = Vt([], [s], r);
    return o.height = n, o.style.height = P(n), o.style.width = P(a), {
      type: "elem",
      elem: o
    };
  },
  qi = .008,
  Er = {
    type: "kern",
    size: -1 * qi
  },
  $2 = new Set(["|", "\\lvert", "\\rvert", "\\vert"]),
  C2 = new Set(["\\|", "\\lVert", "\\rVert", "\\Vert"]),
  bu = function (t, n, r, a, i, s) {
    var o,
      l,
      u,
      c,
      h = "",
      f = 0;
    o = u = c = t, l = null;
    var d = "Size1-Regular";
    t === "\\uparrow" ? u = c = "⏐" : t === "\\Uparrow" ? u = c = "‖" : t === "\\downarrow" ? o = u = "⏐" : t === "\\Downarrow" ? o = u = "‖" : t === "\\updownarrow" ? (o = "\\uparrow", u = "⏐", c = "\\downarrow") : t === "\\Updownarrow" ? (o = "\\Uparrow", u = "‖", c = "\\Downarrow") : $2.has(t) ? (u = "∣", h = "vert", f = 333) : C2.has(t) ? (u = "∥", h = "doublevert", f = 556) : t === "[" || t === "\\lbrack" ? (o = "⎡", u = "⎢", c = "⎣", d = "Size4-Regular", h = "lbrack", f = 667) : t === "]" || t === "\\rbrack" ? (o = "⎤", u = "⎥", c = "⎦", d = "Size4-Regular", h = "rbrack", f = 667) : t === "\\lfloor" || t === "⌊" ? (u = o = "⎢", c = "⎣", d = "Size4-Regular", h = "lfloor", f = 667) : t === "\\lceil" || t === "⌈" ? (o = "⎡", u = c = "⎢", d = "Size4-Regular", h = "lceil", f = 667) : t === "\\rfloor" || t === "⌋" ? (u = o = "⎥", c = "⎦", d = "Size4-Regular", h = "rfloor", f = 667) : t === "\\rceil" || t === "⌉" ? (o = "⎤", u = c = "⎥", d = "Size4-Regular", h = "rceil", f = 667) : t === "(" || t === "\\lparen" ? (o = "⎛", u = "⎜", c = "⎝", d = "Size4-Regular", h = "lparen", f = 875) : t === ")" || t === "\\rparen" ? (o = "⎞", u = "⎟", c = "⎠", d = "Size4-Regular", h = "rparen", f = 875) : t === "\\{" || t === "\\lbrace" ? (o = "⎧", l = "⎨", c = "⎩", u = "⎪", d = "Size4-Regular") : t === "\\}" || t === "\\rbrace" ? (o = "⎫", l = "⎬", c = "⎭", u = "⎪", d = "Size4-Regular") : t === "\\lgroup" || t === "⟮" ? (o = "⎧", c = "⎩", u = "⎪", d = "Size4-Regular") : t === "\\rgroup" || t === "⟯" ? (o = "⎫", c = "⎭", u = "⎪", d = "Size4-Regular") : t === "\\lmoustache" || t === "⎰" ? (o = "⎧", c = "⎭", u = "⎪", d = "Size4-Regular") : (t === "\\rmoustache" || t === "⎱") && (o = "⎫", c = "⎩", u = "⎪", d = "Size4-Regular");
    var b = Gn(o, d, i),
      k = b.height + b.depth,
      A = Gn(u, d, i),
      w = A.height + A.depth,
      _ = Gn(c, d, i),
      T = _.height + _.depth,
      I = 0,
      R = 1;
    if (l !== null) {
      var E = Gn(l, d, i);
      I = E.height + E.depth, R = 2;
    }
    var O = k + T + I,
      W = Math.max(0, Math.ceil((n - O) / (R * w))),
      G = O + W * R * w,
      M = a.fontMetrics().axisHeight;
    r && (M *= a.sizeMultiplier);
    var H = G / 2 - M,
      q = [];
    if (h.length > 0) {
      var ne = G - k - T,
        se = Math.round(G * 1e3),
        Y = S4(h, Math.round(ne * 1e3)),
        le = new Wt(h, Y),
        me = P(f / 1e3),
        Ne = P(se / 1e3),
        Ye = new Nt([le], {
          width: me,
          height: Ne,
          viewBox: "0 0 " + f + " " + se
        }),
        $ = Vt([], [Ye], a);
      $.height = se / 1e3, $.style.width = me, $.style.height = Ne, q.push({
        type: "elem",
        elem: $
      });
    } else {
      if (q.push(Ya(c, d, i)), q.push(Er), l === null) {
        var _e = G - k - T + 2 * qi;
        q.push(Za(u, _e, a));
      } else {
        var Oe = (G - k - T - I) / 2 + 2 * qi;
        q.push(Za(u, Oe, a)), q.push(Er), q.push(Ya(l, d, i)), q.push(Er), q.push(Za(u, Oe, a));
      }
      q.push(Er), q.push(Ya(o, d, i));
    }
    var C = a.havingBaseStyle(ee.TEXT),
      Be = ce({
        positionType: "bottom",
        positionData: H,
        children: q
      });
    return fs(B(["delimsizing", "mult"], [Be], C), ee.TEXT, a, s);
  },
  Ka = 80,
  Qa = .08,
  Ja = function (t, n, r, a, i) {
    var s = $4(t, a, r),
      o = new Wt(t, s),
      l = new Nt([o], {
        width: "400em",
        height: P(n),
        viewBox: "0 0 400000 " + r,
        preserveAspectRatio: "xMinYMin slice"
      });
    return Vt(["hide-tail"], [l], i);
  },
  S2 = function (t, n) {
    var r = n.havingBaseSizing(),
      a = ku("\\surd", t * r.sizeMultiplier, xu, r),
      i = r.sizeMultiplier,
      s = Math.max(0, n.minRuleThickness - n.fontMetrics().sqrtRuleThickness),
      o,
      l,
      u,
      c,
      h;
    return a.type === "small" ? (c = 1e3 + 1e3 * s + Ka, t < 1 ? i = 1 : t < 1.4 && (i = .7), l = (1 + s + Qa) / i, u = (1 + s) / i, o = Ja("sqrtMain", l, c, s, n), o.style.minWidth = "0.853em", h = .833 / i) : a.type === "large" ? (c = (1e3 + Ka) * Vn[a.size], u = (Vn[a.size] + s) / i, l = (Vn[a.size] + s + Qa) / i, o = Ja("sqrtSize" + a.size, l, c, s, n), o.style.minWidth = "1.02em", h = 1 / i) : (l = t + s + Qa, u = t + s, c = Math.floor(1e3 * t + s) + Ka, o = Ja("sqrtTall", l, c, s, n), o.style.minWidth = "0.742em", h = 1.056), o.height = u, o.style.height = P(l), {
      span: o,
      advanceWidth: h,
      ruleWidth: (n.fontMetrics().sqrtRuleThickness + s) * i
    };
  },
  yu = new Set(["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"]),
  A2 = new Set(["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"]),
  vu = new Set(["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"]),
  Vn = [0, 1.2, 1.8, 2.4, 3],
  wu = function (t, n, r, a, i) {
    if (t === "<" || t === "\\lt" || t === "⟨" ? t = "\\langle" : (t === ">" || t === "\\gt" || t === "⟩") && (t = "\\rangle"), yu.has(t) || vu.has(t)) return gu(t, n, !1, r, a, i);
    if (A2.has(t)) return bu(t, Vn[n], !1, r, a, i);
    throw new D("Illegal delimiter: '" + t + "'");
  },
  T2 = [{
    type: "small",
    style: ee.SCRIPTSCRIPT
  }, {
    type: "small",
    style: ee.SCRIPT
  }, {
    type: "small",
    style: ee.TEXT
  }, {
    type: "large",
    size: 1
  }, {
    type: "large",
    size: 2
  }, {
    type: "large",
    size: 3
  }, {
    type: "large",
    size: 4
  }],
  E2 = [{
    type: "small",
    style: ee.SCRIPTSCRIPT
  }, {
    type: "small",
    style: ee.SCRIPT
  }, {
    type: "small",
    style: ee.TEXT
  }, {
    type: "stack"
  }],
  xu = [{
    type: "small",
    style: ee.SCRIPTSCRIPT
  }, {
    type: "small",
    style: ee.SCRIPT
  }, {
    type: "small",
    style: ee.TEXT
  }, {
    type: "large",
    size: 1
  }, {
    type: "large",
    size: 2
  }, {
    type: "large",
    size: 3
  }, {
    type: "large",
    size: 4
  }, {
    type: "stack"
  }],
  M2 = function (t) {
    if (t.type === "small") return "Main-Regular";
    if (t.type === "large") return "Size" + t.size + "-Regular";
    if (t.type === "stack") return "Size4-Regular";
    var n = t.type;
    throw new Error("Add support for delim type '" + n + "' here.");
  },
  ku = function (t, n, r, a) {
    for (var i = Math.min(2, 3 - a.style.size), s = i; s < r.length; s++) {
      var o = r[s];
      if (o.type === "stack") break;
      var l = Gn(t, M2(o), "math"),
        u = l.height + l.depth;
      if (o.type === "small") {
        var c = a.havingBaseStyle(o.style);
        u *= c.sizeMultiplier;
      }
      if (u > n) return o;
    }
    return r[r.length - 1];
  },
  ji = function (t, n, r, a, i, s) {
    t === "<" || t === "\\lt" || t === "⟨" ? t = "\\langle" : (t === ">" || t === "\\gt" || t === "⟩") && (t = "\\rangle");
    var o;
    vu.has(t) ? o = T2 : yu.has(t) ? o = xu : o = E2;
    var l = ku(t, n, o, a);
    return l.type === "small" ? k2(t, l.style, r, a, i, s) : l.type === "large" ? gu(t, l.size, r, a, i, s) : bu(t, n, r, a, i, s);
  },
  ei = function (t, n, r, a, i, s) {
    var o = a.fontMetrics().axisHeight * a.sizeMultiplier,
      l = 901,
      u = 5 / a.fontMetrics().ptPerEm,
      c = Math.max(n - o, r + o),
      h = Math.max(c / 500 * l, 2 * c - u);
    return ji(t, h, !0, a, i, s);
  },
  Vo = {
    "\\bigl": {
      mclass: "mopen",
      size: 1
    },
    "\\Bigl": {
      mclass: "mopen",
      size: 2
    },
    "\\biggl": {
      mclass: "mopen",
      size: 3
    },
    "\\Biggl": {
      mclass: "mopen",
      size: 4
    },
    "\\bigr": {
      mclass: "mclose",
      size: 1
    },
    "\\Bigr": {
      mclass: "mclose",
      size: 2
    },
    "\\biggr": {
      mclass: "mclose",
      size: 3
    },
    "\\Biggr": {
      mclass: "mclose",
      size: 4
    },
    "\\bigm": {
      mclass: "mrel",
      size: 1
    },
    "\\Bigm": {
      mclass: "mrel",
      size: 2
    },
    "\\biggm": {
      mclass: "mrel",
      size: 3
    },
    "\\Biggm": {
      mclass: "mrel",
      size: 4
    },
    "\\big": {
      mclass: "mord",
      size: 1
    },
    "\\Big": {
      mclass: "mord",
      size: 2
    },
    "\\bigg": {
      mclass: "mord",
      size: 3
    },
    "\\Bigg": {
      mclass: "mord",
      size: 4
    }
  },
  z2 = new Set(["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."]);
function Xo(e) {
  return "isMiddle" in e;
}
function va(e, t) {
  var n = ba(e);
  if (n && z2.has(n.text)) return n;
  throw n ? new D("Invalid delimiter '" + n.text + "' after '" + t.funcName + "'", e) : new D("Invalid delimiter type '" + e.type + "'", e);
}
U({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  numArgs: 1,
  argTypes: ["primitive"],
  handler: (e, t) => {
    var n = va(nr(t[0]), e);
    return {
      type: "delimsizing",
      mode: e.parser.mode,
      size: Vo[e.funcName].size,
      mclass: Vo[e.funcName].mclass,
      delim: n.text
    };
  },
  htmlBuilder: (e, t) => e.delim === "." ? B([e.mclass]) : wu(e.delim, e.size, t, e.mode, [e.mclass]),
  mathmlBuilder: e => {
    var t = [];
    e.delim !== "." && t.push(ct(e.delim, e.mode));
    var n = new F("mo", t);
    e.mclass === "mopen" || e.mclass === "mclose" ? n.setAttribute("fence", "true") : n.setAttribute("fence", "false"), n.setAttribute("stretchy", "true");
    var r = P(Vn[e.size]);
    return n.setAttribute("minsize", r), n.setAttribute("maxsize", r), n;
  }
});
function Yo(e) {
  if (!e.body) throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
U({
  type: "leftright-right",
  names: ["\\right"],
  numArgs: 1,
  primitive: !0,
  handler: (e, t) => {
    var n = e.parser.gullet.macros.get("\\current@color");
    if (n && typeof n != "string") throw new D("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: e.parser.mode,
      delim: va(t[0], e).text,
      color: n
    };
  }
});
U({
  type: "leftright",
  names: ["\\left"],
  numArgs: 1,
  primitive: !0,
  handler: (e, t) => {
    var n = va(t[0], e),
      r = e.parser;
    ++r.leftrightDepth;
    var a = r.parseExpression(!1);
    --r.leftrightDepth, r.expect("\\right", !1);
    var i = ie(r.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: r.mode,
      body: a,
      left: n.text,
      right: i.delim,
      rightColor: i.color
    };
  },
  htmlBuilder: (e, t) => {
    Yo(e);
    for (var n = ze(e.body, t, !0, ["mopen", "mclose"]), r = 0, a = 0, i = !1, s = 0; s < n.length; s++) {
      var o = n[s];
      Xo(o) ? i = !0 : (r = Math.max(n[s].height, r), a = Math.max(n[s].depth, a));
    }
    r *= t.sizeMultiplier, a *= t.sizeMultiplier;
    var l;
    if (e.left === "." ? l = rr(t, ["mopen"]) : l = ei(e.left, r, a, t, e.mode, ["mopen"]), n.unshift(l), i) for (var u = 1; u < n.length; u++) {
      var c = n[u];
      if (Xo(c)) {
        var h = c.isMiddle;
        n[u] = ei(h.delim, r, a, h.options, e.mode, []);
      }
    }
    var f;
    if (e.right === ".") f = rr(t, ["mclose"]);else {
      var d = e.rightColor ? t.withColor(e.rightColor) : t;
      f = ei(e.right, r, a, d, e.mode, ["mclose"]);
    }
    return n.push(f), B(["minner"], n, t);
  },
  mathmlBuilder: (e, t) => {
    Yo(e);
    var n = rt(e.body, t);
    if (e.left !== ".") {
      var r = new F("mo", [ct(e.left, e.mode)]);
      r.setAttribute("fence", "true"), n.unshift(r);
    }
    if (e.right !== ".") {
      var a = new F("mo", [ct(e.right, e.mode)]);
      a.setAttribute("fence", "true"), e.rightColor && a.setAttribute("mathcolor", e.rightColor), n.push(a);
    }
    return hs(n);
  }
});
U({
  type: "middle",
  names: ["\\middle"],
  numArgs: 1,
  primitive: !0,
  handler: (e, t) => {
    var n = va(t[0], e);
    if (!e.parser.leftrightDepth) throw new D("\\middle without preceding \\left", n);
    return {
      type: "middle",
      mode: e.parser.mode,
      delim: n.text
    };
  },
  htmlBuilder: (e, t) => {
    var n;
    return e.delim === "." ? n = rr(t, []) : (n = wu(e.delim, 1, t, e.mode, []), n.isMiddle = {
      delim: e.delim,
      options: t
    }), n;
  },
  mathmlBuilder: (e, t) => {
    var n = e.delim === "\\vert" || e.delim === "|" ? ct("|", "text") : ct(e.delim, e.mode),
      r = new F("mo", [n]);
    return r.setAttribute("fence", "true"), r.setAttribute("lspace", "0.05em"), r.setAttribute("rspace", "0.05em"), r;
  }
});
var I2 = (e, t) => {
    var n = En(ue(e.body, t), t),
      r = e.label.slice(1),
      a = t.sizeMultiplier,
      i,
      s,
      o = Bt(e.body);
    if (r === "sout") i = B(["katex-stretchy", "katex-sout"]), i.height = t.fontMetrics().defaultRuleThickness / a, s = -.5 * t.fontMetrics().xHeight;else if (r === "phase") {
      var l = we({
          number: .6,
          unit: "pt"
        }, t),
        u = we({
          number: .35,
          unit: "ex"
        }, t),
        c = t.havingBaseSizing();
      a = a / c.sizeMultiplier;
      var h = n.height + n.depth + l + u;
      n.style.paddingLeft = P(h / 2 + l);
      var f = Math.floor(1e3 * h * a),
        d = k4(f),
        b = new Nt([new Wt("phase", d)], {
          width: "400em",
          height: P(f / 1e3),
          viewBox: "0 0 400000 " + f,
          preserveAspectRatio: "xMinYMin slice"
        });
      i = Vt(["hide-tail"], [b], t), i.style.height = P(h), s = n.depth + l + u;
    } else {
      /cancel/.test(r) ? o || n.classes.push("cancel-pad") : r === "angl" ? n.classes.push("anglpad") : n.classes.push("boxpad");
      var k,
        A,
        w = 0;
      /box/.test(r) ? (w = Math.max(t.fontMetrics().fboxrule, t.minRuleThickness), k = t.fontMetrics().fboxsep + (r === "colorbox" ? 0 : w), A = k) : r === "angl" ? (w = Math.max(t.fontMetrics().defaultRuleThickness, t.minRuleThickness), k = 4 * w, A = Math.max(0, .25 - n.depth)) : (k = o ? .2 : 0, A = k), i = i2(n, r, k, A, t), /fbox|boxed|fcolorbox/.test(r) ? (i.style.borderStyle = "solid", i.style.borderWidth = P(w)) : r === "angl" && w !== .049 && (i.style.borderTopWidth = P(w), i.style.borderRightWidth = P(w)), s = n.depth + A, e.backgroundColor && (i.style.backgroundColor = e.backgroundColor, e.borderColor && (i.style.borderColor = e.borderColor));
    }
    var _;
    if (e.backgroundColor) _ = ce({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: i,
        shift: s
      }, {
        type: "elem",
        elem: n,
        shift: 0
      }]
    });else {
      var T = /cancel|phase/.test(r) ? ["svg-align"] : [];
      _ = ce({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: n,
          shift: 0
        }, {
          type: "elem",
          elem: i,
          shift: s,
          wrapperClasses: T
        }]
      });
    }
    return /cancel/.test(r) && (_.height = n.height, _.depth = n.depth), /cancel/.test(r) && !o ? B(["mord", "cancel-lap"], [_], t) : B(["mord"], [_], t);
  },
  N2 = (e, t) => {
    var n,
      r = new F(e.label.includes("colorbox") ? "mpadded" : "menclose", [he(e.body, t)]);
    switch (e.label) {
      case "\\cancel":
        r.setAttribute("notation", "updiagonalstrike");
        break;
      case "\\bcancel":
        r.setAttribute("notation", "downdiagonalstrike");
        break;
      case "\\phase":
        r.setAttribute("notation", "phasorangle");
        break;
      case "\\sout":
        r.setAttribute("notation", "horizontalstrike");
        break;
      case "\\fbox":
        r.setAttribute("notation", "box");
        break;
      case "\\angl":
        r.setAttribute("notation", "actuarial");
        break;
      case "\\fcolorbox":
      case "\\colorbox":
        if (n = t.fontMetrics().fboxsep * t.fontMetrics().ptPerEm, r.setAttribute("width", "+" + 2 * n + "pt"), r.setAttribute("height", "+" + 2 * n + "pt"), r.setAttribute("lspace", n + "pt"), r.setAttribute("voffset", n + "pt"), e.label === "\\fcolorbox") {
          var a = Math.max(t.fontMetrics().fboxrule, t.minRuleThickness);
          r.setAttribute("style", "border: " + P(a) + " solid " + e.borderColor);
        }
        break;
      case "\\xcancel":
        r.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
        break;
    }
    return e.backgroundColor && r.setAttribute("mathbackground", e.backgroundColor), r;
  };
U({
  type: "enclose",
  names: ["\\colorbox"],
  numArgs: 2,
  allowedInText: !0,
  argTypes: ["color", "hbox"],
  handler(e, t, n) {
    var r = e.parser,
      a = e.funcName,
      i = ie(t[0], "color-token").color,
      s = t[1];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: i,
      body: s
    };
  },
  htmlBuilder: I2,
  mathmlBuilder: N2
});
U({
  type: "enclose",
  names: ["\\fcolorbox"],
  numArgs: 3,
  allowedInText: !0,
  argTypes: ["color", "color", "hbox"],
  handler(e, t, n) {
    var r = e.parser,
      a = e.funcName,
      i = ie(t[0], "color-token").color,
      s = ie(t[1], "color-token").color,
      o = t[2];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: s,
      borderColor: i,
      body: o
    };
  }
});
U({
  type: "enclose",
  names: ["\\fbox"],
  numArgs: 1,
  argTypes: ["hbox"],
  allowedInText: !0,
  handler(e, t) {
    var n = e.parser;
    return {
      type: "enclose",
      mode: n.mode,
      label: "\\fbox",
      body: t[0]
    };
  }
});
U({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\phase"],
  numArgs: 1,
  handler(e, t) {
    var n = e.parser,
      r = e.funcName,
      a = t[0];
    return {
      type: "enclose",
      mode: n.mode,
      label: r,
      body: a
    };
  }
});
U({
  type: "enclose",
  names: ["\\sout"],
  numArgs: 1,
  allowedInText: !0,
  handler(e, t) {
    var n = e.parser,
      r = e.funcName;
    n.mode === "math" && n.settings.reportNonstrict("mathVsSout", "LaTeX's \\sout works only in text mode");
    var a = t[0];
    return {
      type: "enclose",
      mode: n.mode,
      label: r,
      body: a
    };
  }
});
U({
  type: "enclose",
  names: ["\\angl"],
  numArgs: 1,
  argTypes: ["hbox"],
  allowedInText: !1,
  handler(e, t) {
    var n = e.parser;
    return {
      type: "enclose",
      mode: n.mode,
      label: "\\angl",
      body: t[0]
    };
  }
});
var _u = {};
function xt(e) {
  for (var t = e.type, n = e.names, r = e.props, a = e.handler, i = e.htmlBuilder, s = e.mathmlBuilder, o = {
      type: t,
      numArgs: r.numArgs || 0,
      allowedInText: !1,
      numOptionalArgs: 0,
      handler: a
    }, l = 0; l < n.length; ++l) _u[n[l]] = o;
  i && (er[t] = i), s && (tr[t] = s);
}
var $u = {};
function y(e, t) {
  $u[e] = t;
}
class Ve {
  constructor(t, n, r) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = t, this.start = n, this.end = r;
  }
  static range(t, n) {
    return n ? !t || !t.loc || !n.loc || t.loc.lexer !== n.loc.lexer ? null : new Ve(t.loc.lexer, t.loc.start, n.loc.end) : t && t.loc;
  }
}
class et {
  constructor(t, n) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = t, this.loc = n;
  }
  range(t, n) {
    return new et(n, Ve.range(this, t));
  }
}
function Zo(e) {
  var t = [];
  e.consumeSpaces();
  var n = e.fetch().text;
  for (n === "\\relax" && (e.consume(), e.consumeSpaces(), n = e.fetch().text); n === "\\hline" || n === "\\hdashline";) e.consume(), t.push(n === "\\hdashline"), e.consumeSpaces(), n = e.fetch().text;
  return t;
}
var wa = e => {
    var t = e.parser.settings;
    if (!t.displayMode) throw new D("{" + e.envName + "} can be used only in display mode.");
  },
  R2 = new Set(["gather", "gather*"]);
function gs(e) {
  if (!e.includes("ed")) return !e.includes("*");
}
function Zt(e, t, n) {
  var r = t.hskipBeforeAndAfter,
    a = t.addJot,
    i = t.cols,
    s = t.arraystretch,
    o = t.colSeparationType,
    l = t.autoTag,
    u = t.singleRow,
    c = t.emptySingleRow,
    h = t.maxNumCols,
    f = t.leqno;
  if (e.gullet.beginGroup(), u || e.gullet.macros.set("\\cr", "\\\\\\relax"), !s) {
    var d = e.gullet.expandMacroAsText("\\arraystretch");
    if (d == null) s = 1;else if (s = parseFloat(d), !s || s < 0) throw new D("Invalid \\arraystretch: " + d);
  }
  e.gullet.beginGroup();
  var b = [],
    k = [b],
    A = [],
    w = [],
    _ = l != null ? [] : void 0;
  function T() {
    l && e.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function I() {
    _ && (e.gullet.macros.get("\\df@tag") ? (_.push(e.subparse([new et("\\df@tag")])), e.gullet.macros.set("\\df@tag", void 0, !0)) : _.push(!!l && e.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (T(), w.push(Zo(e));;) {
    var R = e.parseExpression(!1, u ? "\\end" : "\\\\");
    e.gullet.endGroup(), e.gullet.beginGroup();
    var E = {
      type: "ordgroup",
      mode: e.mode,
      body: R
    };
    n && (E = {
      type: "styling",
      mode: e.mode,
      style: n,
      resetFont: !0,
      body: [E]
    }), b.push(E);
    var O = e.fetch().text;
    if (O === "&") {
      if (h && b.length === h) {
        if (u || o) throw new D("Too many tab characters: &", e.nextToken);
        e.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      e.consume();
    } else if (O === "\\end") {
      I(), b.length === 1 && E.type === "styling" && E.body.length === 1 && E.body[0].type === "ordgroup" && E.body[0].body.length === 0 && (k.length > 1 || !c) && !Array.isArray(_?.[_.length - 1]) && k.pop(), w.length < k.length + 1 && w.push([]);
      break;
    } else if (O === "\\\\") {
      e.consume();
      var W = void 0;
      e.gullet.future().text !== " " && (W = e.parseSizeGroup(!0)), A.push(W ? W.value : null), I(), w.push(Zo(e)), b = [], k.push(b), T();
    } else throw new D("Expected & or \\\\ or \\cr or \\end", e.nextToken);
  }
  return e.gullet.endGroup(), e.gullet.endGroup(), {
    type: "array",
    mode: e.mode,
    addJot: a,
    arraystretch: s,
    body: k,
    cols: i,
    rowGaps: A,
    hskipBeforeAndAfter: r,
    hLinesBeforeRow: w,
    colSeparationType: o,
    tags: _,
    leqno: f
  };
}
function bs(e) {
  return e.slice(0, 1) === "d" ? "display" : "text";
}
var kt = function (t, n) {
    var r,
      a,
      i = t.body.length,
      s = t.hLinesBeforeRow,
      o = 0,
      l = new Array(i),
      u = [],
      c = Math.max(n.fontMetrics().arrayRuleWidth, n.minRuleThickness),
      h = 1 / n.fontMetrics().ptPerEm,
      f = 5 * h;
    if (t.colSeparationType && t.colSeparationType === "small") {
      var d = n.havingStyle(ee.SCRIPT).sizeMultiplier;
      f = .2778 * (d / n.sizeMultiplier);
    }
    var b = t.colSeparationType === "CD" ? we({
        number: 3,
        unit: "ex"
      }, n) : 12 * h,
      k = 3 * h,
      A = t.arraystretch * b,
      w = .7 * A,
      _ = .3 * A,
      T = 0;
    function I(K) {
      for (var re = 0; re < K.length; ++re) re > 0 && (T += .25), u.push({
        pos: T,
        isDashed: K[re]
      });
    }
    for (I(s[0]), r = 0; r < t.body.length; ++r) {
      var R = t.body[r],
        E = w,
        O = _;
      o < R.length && (o = R.length);
      var W = {
        cells: new Array(R.length),
        height: 0,
        depth: 0,
        pos: 0
      };
      for (a = 0; a < R.length; ++a) {
        var G = ue(R[a], n);
        O < G.depth && (O = G.depth), E < G.height && (E = G.height), W.cells[a] = G;
      }
      var M = t.rowGaps[r],
        H = 0;
      M && (H = we(M, n), H > 0 && (H += _, O < H && (O = H), H = 0)), t.addJot && r < t.body.length - 1 && (O += k), W.height = E, W.depth = O, T += E, W.pos = T, T += O + H, l[r] = W, I(s[r + 1]);
    }
    var q = T / 2 + n.fontMetrics().axisHeight,
      ne = t.cols || [],
      se = [],
      Y,
      le,
      me = [];
    if (t.tags && t.tags.some(K => K)) for (r = 0; r < i; ++r) {
      var Ne = l[r],
        Ye = Ne.pos - q,
        $ = t.tags[r],
        _e = void 0;
      $ === !0 ? _e = B(["eqn-num"], [], n) : $ === !1 ? _e = B([], [], n) : _e = B([], ze($, n, !0), n), _e.depth = Ne.depth, _e.height = Ne.height, me.push({
        type: "elem",
        elem: _e,
        shift: Ye
      });
    }
    for (a = 0, le = 0; a < o || le < ne.length; ++a, ++le) {
      for (var Oe, C = ne[le], Be = !0; ((gt = C) == null ? void 0 : gt.type) === "separator";) {
        var gt;
        if (Be || (Y = B(["arraycolsep"], []), Y.style.width = P(n.fontMetrics().doubleRuleSep), se.push(Y)), C.separator === "|" || C.separator === ":") {
          var Te = C.separator === "|" ? "solid" : "dashed",
            at = B(["vertical-separator"], [], n);
          at.style.height = P(T), at.style.borderRightWidth = P(c), at.style.borderRightStyle = Te, at.style.margin = "0 " + P(-c / 2);
          var mt = T - q;
          mt && (at.style.verticalAlign = P(-mt)), se.push(at);
        } else throw new D("Invalid separator type: " + C.separator);
        le++, C = ne[le], Be = !1;
      }
      if (!(a >= o)) {
        var Ze = void 0;
        if (a > 0 || t.hskipBeforeAndAfter) {
          var $t, Kt;
          Ze = ($t = (Kt = C) == null ? void 0 : Kt.pregap) != null ? $t : f, Ze !== 0 && (Y = B(["arraycolsep"], []), Y.style.width = P(Ze), se.push(Y));
        }
        var cr = [];
        for (r = 0; r < i; ++r) {
          var gn = l[r],
            bn = gn.cells[a];
          if (bn) {
            var mr = gn.pos - q;
            bn.depth = gn.depth, bn.height = gn.height, cr.push({
              type: "elem",
              elem: bn,
              shift: mr
            });
          }
        }
        var hr = ce({
            positionType: "individualShift",
            children: cr
          }),
          pr = B(["col-align-" + (((Oe = C) == null ? void 0 : Oe.align) || "c")], [hr]);
        if (se.push(pr), a < o - 1 || t.hskipBeforeAndAfter) {
          var dr, Dn;
          Ze = (dr = (Dn = C) == null ? void 0 : Dn.postgap) != null ? dr : f, Ze !== 0 && (Y = B(["arraycolsep"], []), Y.style.width = P(Ze), se.push(Y));
        }
      }
    }
    var Qt = B(["mtable"], se);
    if (u.length > 0) {
      for (var ka = Tn("katex-hline", n, c), _a = Tn("katex-hdashline", n, c), Ln = [{
          type: "elem",
          elem: Qt,
          shift: 0
        }]; u.length > 0;) {
        var fr = u.pop(),
          gr = fr.pos - q;
        fr.isDashed ? Ln.push({
          type: "elem",
          elem: _a,
          shift: gr
        }) : Ln.push({
          type: "elem",
          elem: ka,
          shift: gr
        });
      }
      Qt = ce({
        positionType: "individualShift",
        children: Ln
      });
    }
    if (me.length === 0) return B(["mord"], [Qt], n);
    var z = ce({
        positionType: "individualShift",
        children: me
      }),
      j = B(["katex-tag"], [z], n);
    return Lt([Qt, j]);
  },
  B2 = {
    c: "center ",
    l: "left ",
    r: "right "
  },
  _t = function (t, n) {
    for (var r = [], a = new F("mtd", [], ["mtr-glue"]), i = new F("mtd", [], ["mml-eqn-num"]), s = 0; s < t.body.length; s++) {
      for (var o = t.body[s], l = [], u = 0; u < o.length; u++) l.push(new F("mtd", [he(o[u], n)]));
      t.tags && t.tags[s] && (l.unshift(a), l.push(a), t.leqno ? l.unshift(i) : l.push(i)), r.push(new F("mtr", l));
    }
    var c = new F("mtable", r),
      h = t.arraystretch === .5 ? .1 : .16 + t.arraystretch - 1 + (t.addJot ? .09 : 0);
    c.setAttribute("rowspacing", P(h));
    var f = "",
      d = "";
    if (t.cols && t.cols.length > 0) {
      var b = t.cols,
        k = "",
        A = !1,
        w = 0,
        _ = b.length;
      b[0].type === "separator" && (f += "top ", w = 1), b[b.length - 1].type === "separator" && (f += "bottom ", _ -= 1);
      for (var T = w; T < _; T++) {
        var I = b[T];
        I.type === "align" ? (d += B2[I.align], A && (k += "none "), A = !0) : I.type === "separator" && A && (k += I.separator === "|" ? "solid " : "dashed ", A = !1);
      }
      c.setAttribute("columnalign", d.trim()), /[sd]/.test(k) && c.setAttribute("columnlines", k.trim());
    }
    if (t.colSeparationType === "align") {
      for (var R = t.cols || [], E = "", O = 1; O < R.length; O++) E += O % 2 ? "0em " : "1em ";
      c.setAttribute("columnspacing", E.trim());
    } else t.colSeparationType === "alignat" || t.colSeparationType === "gather" ? c.setAttribute("columnspacing", "0em") : t.colSeparationType === "small" ? c.setAttribute("columnspacing", "0.2778em") : t.colSeparationType === "CD" ? c.setAttribute("columnspacing", "0.5em") : c.setAttribute("columnspacing", "1em");
    var W = "",
      G = t.hLinesBeforeRow;
    f += G[0].length > 0 ? "left " : "", f += G[G.length - 1].length > 0 ? "right " : "";
    for (var M = 1; M < G.length - 1; M++) W += G[M].length === 0 ? "none " : G[M][0] ? "dashed " : "solid ";
    return /[sd]/.test(W) && c.setAttribute("rowlines", W.trim()), f !== "" && (c = new F("menclose", [c]), c.setAttribute("notation", f.trim())), t.arraystretch && t.arraystretch < 1 && (c = new F("mstyle", [c]), c.setAttribute("scriptlevel", "1")), c;
  },
  Cu = function (t, n) {
    t.envName.includes("ed") || wa(t);
    var r = [],
      a = t.envName === "split",
      i = Zt(t.parser, {
        cols: r,
        addJot: !0,
        autoTag: a ? void 0 : gs(t.envName),
        emptySingleRow: !0,
        colSeparationType: t.envName.includes("at") ? "alignat" : "align",
        maxNumCols: a ? 2 : void 0,
        leqno: t.parser.settings.leqno
      }, "display"),
      s = 0,
      o = 0,
      l = {
        type: "ordgroup",
        mode: t.mode,
        body: []
      };
    if (n[0] && n[0].type === "ordgroup") {
      var u = "Number of columns should be a positive integer",
        c = ds(n[0], u);
      if (!/^[0-9]+$/.test(c) || Number(c) < 1) throw new D(u, n[0]);
      s = Number(c), o = s * 2;
    }
    var h = !o;
    i.body.forEach(function (k) {
      for (var A = 1; A < k.length; A += 2) {
        var w = ie(k[A], "styling"),
          _ = ie(w.body[0], "ordgroup");
        _.body.unshift(l);
      }
      if (h) o < k.length && (o = k.length);else {
        var T = k.length / 2;
        if (s < T) throw new D("Too many math in a row: " + ("expected " + s + ", but got " + T), k[0]);
      }
    });
    for (var f = 0; f < o; ++f) {
      var d = "r",
        b = 0;
      f % 2 === 1 ? d = "l" : f > 0 && h && (b = 1), r[f] = {
        type: "align",
        align: d,
        pregap: b,
        postgap: 0
      };
    }
    return i.colSeparationType = h ? "align" : "alignat", i;
  };
xt({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(e, t) {
    var n = ba(t[0]),
      r = n ? [t[0]] : ie(t[0], "ordgroup").body,
      a = r.map(function (s) {
        var o = ga(s),
          l = o.text;
        if ("lcr".includes(l)) return {
          type: "align",
          align: l
        };
        if (l === "|") return {
          type: "separator",
          separator: "|"
        };
        if (l === ":") return {
          type: "separator",
          separator: ":"
        };
        throw new D("Unknown column alignment: " + l, s);
      }),
      i = {
        cols: a,
        hskipBeforeAndAfter: !0,
        maxNumCols: a.length
      };
    return Zt(e.parser, i, bs(e.envName));
  },
  htmlBuilder: kt,
  mathmlBuilder: _t
});
xt({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(e) {
    var t = {
        matrix: null,
        pmatrix: ["(", ")"],
        bmatrix: ["[", "]"],
        Bmatrix: ["\\{", "\\}"],
        vmatrix: ["|", "|"],
        Vmatrix: ["\\Vert", "\\Vert"]
      }[e.envName.replace("*", "")],
      n = "c",
      r = {
        hskipBeforeAndAfter: !1,
        cols: [{
          type: "align",
          align: n
        }]
      };
    if (e.envName.charAt(e.envName.length - 1) === "*") {
      var a = e.parser;
      if (a.consumeSpaces(), a.fetch().text === "[") {
        if (a.consume(), a.consumeSpaces(), n = a.fetch().text, !"lcr".includes(n)) throw new D("Expected l or c or r", a.nextToken);
        a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), r.cols = [{
          type: "align",
          align: n
        }];
      }
    }
    var i = Zt(e.parser, r, bs(e.envName)),
      s = Math.max(0, ...i.body.map(o => o.length));
    return i.cols = new Array(s).fill({
      type: "align",
      align: n
    }), t ? {
      type: "leftright",
      mode: e.mode,
      body: [i],
      left: t[0],
      right: t[1],
      rightColor: void 0
    } : i;
  },
  htmlBuilder: kt,
  mathmlBuilder: _t
});
xt({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(e) {
    var t = {
        arraystretch: .5
      },
      n = Zt(e.parser, t, "script");
    return n.colSeparationType = "small", n;
  },
  htmlBuilder: kt,
  mathmlBuilder: _t
});
xt({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(e, t) {
    var n = ba(t[0]),
      r = n ? [t[0]] : ie(t[0], "ordgroup").body,
      a = r.map(function (o) {
        var l = ga(o),
          u = l.text;
        if ("lc".includes(u)) return {
          type: "align",
          align: u
        };
        throw new D("Unknown column alignment: " + u, o);
      });
    if (a.length > 1) throw new D("{subarray} can contain only one column");
    var i = {
        cols: a,
        hskipBeforeAndAfter: !1,
        arraystretch: .5
      },
      s = Zt(e.parser, i, "script");
    if (s.body.length > 0 && s.body[0].length > 1) throw new D("{subarray} can contain only one column");
    return s;
  },
  htmlBuilder: kt,
  mathmlBuilder: _t
});
xt({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(e) {
    var t = {
        arraystretch: 1.2,
        cols: [{
          type: "align",
          align: "l",
          pregap: 0,
          postgap: 1
        }, {
          type: "align",
          align: "l",
          pregap: 0,
          postgap: 0
        }]
      },
      n = Zt(e.parser, t, bs(e.envName));
    return {
      type: "leftright",
      mode: e.mode,
      body: [n],
      left: e.envName.includes("r") ? "." : "\\{",
      right: e.envName.includes("r") ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: kt,
  mathmlBuilder: _t
});
xt({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: Cu,
  htmlBuilder: kt,
  mathmlBuilder: _t
});
xt({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(e) {
    R2.has(e.envName) && wa(e);
    var t = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: gs(e.envName),
      emptySingleRow: !0,
      leqno: e.parser.settings.leqno
    };
    return Zt(e.parser, t, "display");
  },
  htmlBuilder: kt,
  mathmlBuilder: _t
});
xt({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: Cu,
  htmlBuilder: kt,
  mathmlBuilder: _t
});
xt({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(e) {
    wa(e);
    var t = {
      autoTag: gs(e.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: e.parser.settings.leqno
    };
    return Zt(e.parser, t, "display");
  },
  htmlBuilder: kt,
  mathmlBuilder: _t
});
xt({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(e) {
    return wa(e), y2(e.parser);
  },
  htmlBuilder: kt,
  mathmlBuilder: _t
});
y("\\nonumber", "\\gdef\\@eqnsw{0}");
y("\\notag", "\\nonumber");
U({
  type: "text",
  names: ["\\hline", "\\hdashline"],
  numArgs: 0,
  allowedInText: !0,
  allowedInMath: !0,
  handler(e, t) {
    throw new D(e.funcName + " valid only within array environment");
  }
});
var Ko = _u;
U({
  type: "environment",
  names: ["\\begin", "\\end"],
  numArgs: 1,
  argTypes: ["text"],
  handler(e, t) {
    var n = e.parser,
      r = e.funcName,
      a = t[0];
    if (a.type !== "ordgroup") throw new D("Invalid environment name", a);
    var i = ds(a, "Environment name should contain only text characters and spaces", !0);
    if (r === "\\begin") {
      if (!Object.prototype.hasOwnProperty.call(Ko, i)) throw new D("No such environment: " + i, a);
      var s = Ko[i],
        o = n.parseArguments("\\begin{" + i + "}", s),
        l = o.args,
        u = o.optArgs,
        c = {
          mode: n.mode,
          envName: i,
          parser: n
        },
        h = s.handler(c, l, u);
      n.expect("\\end", !1);
      var f = n.nextToken,
        d = ie(n.parseFunction(), "environment");
      if (d.name !== i) throw new D("Mismatch: \\begin{" + i + "} matched by \\end{" + d.name + "}", f);
      return h;
    }
    return {
      type: "environment",
      mode: n.mode,
      name: i,
      nameGroup: a
    };
  }
});
var D2 = (e, t) => {
    var n = e.font,
      r = t.withFont(n);
    return ue(e.body, r);
  },
  L2 = (e, t) => {
    var n = e.font,
      r = t.withFont(n);
    return he(e.body, r);
  },
  Qo = {
    "\\Bbb": "\\mathbb",
    "\\bold": "\\mathbf",
    "\\frak": "\\mathfrak"
  };
U({
  type: "font",
  names: ["\\mathrm", "\\mathit", "\\mathbf", "\\mathnormal", "\\mathsfit", "\\mathbb", "\\mathcal", "\\mathfrak", "\\mathscr", "\\mathsf", "\\mathtt", "\\Bbb", "\\bold", "\\frak"],
  numArgs: 1,
  allowedInArgument: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = e.funcName,
      a = nr(t[0]),
      i = r in Qo ? Qo[r] : r;
    return {
      type: "font",
      mode: n.mode,
      font: i.slice(1),
      body: a
    };
  },
  htmlBuilder: D2,
  mathmlBuilder: L2
});
U({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  numArgs: 1,
  handler: (e, t) => {
    var n = e.parser,
      r = t[0];
    return {
      type: "mclass",
      mode: n.mode,
      mclass: ya(r),
      body: [{
        type: "font",
        mode: n.mode,
        font: "boldsymbol",
        body: r
      }],
      isCharacterBox: Bt(r)
    };
  }
});
U({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  numArgs: 0,
  allowedInText: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = e.funcName,
      a = e.breakOnTokenText,
      i = n.mode,
      s = n.parseExpression(!0, a);
    return {
      type: "font",
      mode: i,
      font: "math" + r.slice(1),
      body: {
        type: "ordgroup",
        mode: n.mode,
        body: s
      }
    };
  }
});
var F2 = (e, t) => {
    var n = t.style,
      r = n.fracNum(),
      a = n.fracDen(),
      i;
    i = t.havingStyle(r);
    var s = ue(e.numer, i, t);
    if (e.continued) {
      var o = 8.5 / t.fontMetrics().ptPerEm,
        l = 3.5 / t.fontMetrics().ptPerEm;
      s.height = s.height < o ? o : s.height, s.depth = s.depth < l ? l : s.depth;
    }
    i = t.havingStyle(a);
    var u = ue(e.denom, i, t),
      c,
      h,
      f;
    e.hasBarLine ? (e.barSize ? (h = we(e.barSize, t), c = Tn("frac-line", t, h)) : c = Tn("frac-line", t), h = c.height, f = c.height) : (c = null, h = 0, f = t.fontMetrics().defaultRuleThickness);
    var d, b, k;
    n.size === ee.DISPLAY.size ? (d = t.fontMetrics().num1, h > 0 ? b = 3 * f : b = 7 * f, k = t.fontMetrics().denom1) : (h > 0 ? (d = t.fontMetrics().num2, b = f) : (d = t.fontMetrics().num3, b = 3 * f), k = t.fontMetrics().denom2);
    var A;
    if (c) {
      var _ = t.fontMetrics().axisHeight;
      d - s.depth - (_ + .5 * h) < b && (d += b - (d - s.depth - (_ + .5 * h))), _ - .5 * h - (u.height - k) < b && (k += b - (_ - .5 * h - (u.height - k)));
      var T = -(_ - .5 * h);
      A = ce({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: u,
          shift: k
        }, {
          type: "elem",
          elem: c,
          shift: T
        }, {
          type: "elem",
          elem: s,
          shift: -d
        }]
      });
    } else {
      var w = d - s.depth - (u.height - k);
      w < b && (d += .5 * (b - w), k += .5 * (b - w)), A = ce({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: u,
          shift: k
        }, {
          type: "elem",
          elem: s,
          shift: -d
        }]
      });
    }
    i = t.havingStyle(n), A.height *= i.sizeMultiplier / t.sizeMultiplier, A.depth *= i.sizeMultiplier / t.sizeMultiplier;
    var I;
    n.size === ee.DISPLAY.size ? I = t.fontMetrics().delim1 : n.size === ee.SCRIPTSCRIPT.size ? I = t.havingStyle(ee.SCRIPT).fontMetrics().delim2 : I = t.fontMetrics().delim2;
    var R, E;
    return e.leftDelim == null ? R = rr(t, ["mopen"]) : R = ji(e.leftDelim, I, !0, t.havingStyle(n), e.mode, ["mopen"]), e.continued ? E = B([]) : e.rightDelim == null ? E = rr(t, ["mclose"]) : E = ji(e.rightDelim, I, !0, t.havingStyle(n), e.mode, ["mclose"]), B(["mord"].concat(i.sizingClasses(t)), [R, B(["mfrac"], [A]), E], t);
  },
  P2 = (e, t) => {
    var n = new F("mfrac", [he(e.numer, t), he(e.denom, t)]);
    if (!e.hasBarLine) n.setAttribute("linethickness", "0px");else if (e.barSize) {
      var r = we(e.barSize, t);
      n.setAttribute("linethickness", P(r));
    }
    if (e.leftDelim != null || e.rightDelim != null) {
      var a = [];
      if (e.leftDelim != null) {
        var i = new F("mo", [new Se(e.leftDelim.replace("\\", ""))]);
        i.setAttribute("fence", "true"), a.push(i);
      }
      if (a.push(n), e.rightDelim != null) {
        var s = new F("mo", [new Se(e.rightDelim.replace("\\", ""))]);
        s.setAttribute("fence", "true"), a.push(s);
      }
      return hs(a);
    }
    return n;
  },
  Su = (e, t) => {
    if (!t) return e;
    var n = {
      type: "styling",
      mode: e.mode,
      style: t,
      body: [e]
    };
    return n;
  };
U({
  type: "genfrac",
  names: ["\\cfrac", "\\dfrac", "\\frac", "\\tfrac", "\\dbinom", "\\binom", "\\tbinom", "\\\\atopfrac", "\\\\bracefrac", "\\\\brackfrac"],
  numArgs: 2,
  allowedInArgument: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = e.funcName,
      a = t[0],
      i = t[1],
      s,
      o = null,
      l = null;
    switch (r) {
      case "\\cfrac":
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        s = !0;
        break;
      case "\\\\atopfrac":
        s = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        s = !1, o = "(", l = ")";
        break;
      case "\\\\bracefrac":
        s = !1, o = "\\{", l = "\\}";
        break;
      case "\\\\brackfrac":
        s = !1, o = "[", l = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    var u = r === "\\cfrac",
      c = null;
    return u || r.startsWith("\\d") ? c = "display" : r.startsWith("\\t") && (c = "text"), Su({
      type: "genfrac",
      mode: n.mode,
      numer: a,
      denom: i,
      continued: u,
      hasBarLine: s,
      leftDelim: o,
      rightDelim: l,
      barSize: null
    }, c);
  },
  htmlBuilder: F2,
  mathmlBuilder: P2
});
U({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  numArgs: 0,
  infix: !0,
  handler(e) {
    var t = e.parser,
      n = e.funcName,
      r = e.token,
      a;
    switch (n) {
      case "\\over":
        a = "\\frac";
        break;
      case "\\choose":
        a = "\\binom";
        break;
      case "\\atop":
        a = "\\\\atopfrac";
        break;
      case "\\brace":
        a = "\\\\bracefrac";
        break;
      case "\\brack":
        a = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: a,
      token: r
    };
  }
});
var Jo = ["display", "text", "script", "scriptscript"],
  el = function (t) {
    var n = null;
    return t.length > 0 && (n = t, n = n === "." ? null : n), n;
  };
U({
  type: "genfrac",
  names: ["\\genfrac"],
  numArgs: 6,
  allowedInArgument: !0,
  argTypes: ["math", "math", "size", "text", "math", "math"],
  handler(e, t) {
    var n = e.parser,
      r = t[4],
      a = t[5],
      i = nr(t[0]),
      s = i.type === "atom" && i.family === "open" ? el(i.text) : null,
      o = nr(t[1]),
      l = o.type === "atom" && o.family === "close" ? el(o.text) : null,
      u = ie(t[2], "size"),
      c,
      h = null;
    u.isBlank ? c = !0 : (h = u.value, c = h.number > 0);
    var f = null,
      d = t[3];
    if (d.type === "ordgroup") {
      if (d.body.length > 0) {
        var b = ie(d.body[0], "textord");
        f = Jo[Number(b.text)];
      }
    } else d = ie(d, "textord"), f = Jo[Number(d.text)];
    return Su({
      type: "genfrac",
      mode: n.mode,
      numer: r,
      denom: a,
      continued: !1,
      hasBarLine: c,
      barSize: h,
      leftDelim: s,
      rightDelim: l
    }, f);
  }
});
U({
  type: "infix",
  names: ["\\above"],
  numArgs: 1,
  argTypes: ["size"],
  infix: !0,
  handler(e, t) {
    var n = e.parser;
    e.funcName;
    var r = e.token;
    return {
      type: "infix",
      mode: n.mode,
      replaceWith: "\\\\abovefrac",
      size: ie(t[0], "size").value,
      token: r
    };
  }
});
U({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  numArgs: 3,
  argTypes: ["math", "size", "math"],
  handler: (e, t) => {
    var n = e.parser;
    e.funcName;
    var r = t[0],
      a = ie(t[1], "infix").size;
    if (!a) throw new Error("\\\\abovefrac expected size, but got " + String(a));
    var i = t[2],
      s = a.number > 0;
    return {
      type: "genfrac",
      mode: n.mode,
      numer: r,
      denom: i,
      continued: !1,
      hasBarLine: s,
      barSize: a,
      leftDelim: null,
      rightDelim: null
    };
  }
});
var Au = (e, t) => {
    var n = t.style,
      r,
      a;
    e.type === "supsub" ? (r = e.sup ? ue(e.sup, t.havingStyle(n.sup()), t) : ue(e.sub, t.havingStyle(n.sub()), t), a = ie(e.base, "horizBrace")) : a = ie(e, "horizBrace");
    var i = ue(a.base, t.havingBaseStyle(ee.DISPLAY)),
      s = fa(a, t),
      o;
    if (a.isOver ? o = ce({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: .1
      }, {
        type: "elem",
        elem: s,
        wrapperClasses: ["svg-align"]
      }]
    }) : o = ce({
      positionType: "bottom",
      positionData: i.depth + .1 + s.height,
      children: [{
        type: "elem",
        elem: s,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: .1
      }, {
        type: "elem",
        elem: i
      }]
    }), r) {
      var l = B(["minner", a.isOver ? "mover" : "munder"], [o], t);
      a.isOver ? o = ce({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: l
        }, {
          type: "kern",
          size: .2
        }, {
          type: "elem",
          elem: r
        }]
      }) : o = ce({
        positionType: "bottom",
        positionData: l.depth + .2 + r.height + r.depth,
        children: [{
          type: "elem",
          elem: r
        }, {
          type: "kern",
          size: .2
        }, {
          type: "elem",
          elem: l
        }]
      });
    }
    return B(["minner", a.isOver ? "mover" : "munder"], [o], t);
  },
  O2 = (e, t) => {
    var n = da(e.label);
    return new F(e.isOver ? "mover" : "munder", [he(e.base, t), n]);
  };
U({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace", "\\overbracket", "\\underbracket"],
  numArgs: 1,
  handler(e, t) {
    var n = e.parser,
      r = e.funcName;
    return {
      type: "horizBrace",
      mode: n.mode,
      label: r,
      isOver: r.includes("\\over"),
      base: t[0]
    };
  },
  htmlBuilder: Au,
  mathmlBuilder: O2
});
U({
  type: "href",
  names: ["\\href"],
  numArgs: 2,
  argTypes: ["url", "original"],
  allowedInText: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = t[1],
      a = ie(t[0], "url").url;
    return n.settings.isTrusted({
      command: "\\href",
      url: a
    }) ? {
      type: "href",
      mode: n.mode,
      href: a,
      body: Ce(r)
    } : n.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (e, t) => {
    var n = ze(e.body, t, !1);
    return j4(e.href, [], n, t);
  },
  mathmlBuilder: (e, t) => {
    var n = Xt(e.body, t);
    return n instanceof F || (n = new F("mrow", [n])), n.setAttribute("href", e.href), n;
  }
});
U({
  type: "href",
  names: ["\\url"],
  numArgs: 1,
  argTypes: ["url"],
  allowedInText: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = ie(t[0], "url").url;
    if (!n.settings.isTrusted({
      command: "\\url",
      url: r
    })) return n.formatUnsupportedCmd("\\url");
    for (var a = [], i = 0; i < r.length; i++) {
      var s = r[i];
      s === "~" && (s = "\\textasciitilde"), a.push({
        type: "textord",
        mode: "text",
        text: s
      });
    }
    var o = {
      type: "text",
      mode: n.mode,
      font: "\\texttt",
      body: a
    };
    return {
      type: "href",
      mode: n.mode,
      href: r,
      body: Ce(o)
    };
  }
});
U({
  type: "hbox",
  names: ["\\hbox"],
  numArgs: 1,
  argTypes: ["text"],
  allowedInText: !0,
  primitive: !0,
  handler(e, t) {
    var n = e.parser;
    return {
      type: "hbox",
      mode: n.mode,
      body: Ce(t[0])
    };
  },
  htmlBuilder(e, t) {
    var n = ze(e.body, t.withFont(""), !1);
    return Lt(n);
  },
  mathmlBuilder(e, t) {
    return new F("mrow", rt(e.body, t.withFont("")));
  }
});
U({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  numArgs: 2,
  argTypes: ["raw", "original"],
  allowedInText: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = e.funcName;
    e.token;
    var a = ie(t[0], "raw").string,
      i = t[1];
    n.settings.strict && n.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var s,
      o = {};
    switch (r) {
      case "\\htmlClass":
        o.class = a, s = {
          command: "\\htmlClass",
          class: a
        };
        break;
      case "\\htmlId":
        o.id = a, s = {
          command: "\\htmlId",
          id: a
        };
        break;
      case "\\htmlStyle":
        o.style = a, s = {
          command: "\\htmlStyle",
          style: a
        };
        break;
      case "\\htmlData":
        {
          for (var l = "{,}", u = [], c = "", h = 0; h < a.length; h++) a.startsWith(l, h) ? (c += ",", h += l.length - 1) : a[h] === "," ? (u.push(c), c = "") : c += a[h];
          u.push(c);
          for (var f = 0; f < u.length; f++) {
            var d = u[f],
              b = d.indexOf("=");
            if (b < 0) throw new D("\\htmlData key/value '" + d + "' missing equals sign");
            var k = d.slice(0, b),
              A = d.slice(b + 1);
            o["data-" + k.trim()] = A;
          }
          s = {
            command: "\\htmlData",
            attributes: o
          };
          break;
        }
      default:
        throw new Error("Unrecognized html command");
    }
    return n.settings.isTrusted(s) ? {
      type: "html",
      mode: n.mode,
      attributes: o,
      body: Ce(i)
    } : n.formatUnsupportedCmd(r);
  },
  htmlBuilder: (e, t) => {
    var n = ze(e.body, t, !1),
      r = ["enclosing"];
    e.attributes.class && r.push(...e.attributes.class.trim().split(/\s+/));
    var a = B(r, n, t);
    for (var i of Object.entries(e.attributes)) {
      var s = i[0],
        o = i[1];
      s !== "class" && a.setAttribute(s, o);
    }
    return a;
  },
  mathmlBuilder: (e, t) => Xt(e.body, t)
});
U({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  numArgs: 2,
  allowedInArgument: !0,
  allowedInText: !0,
  handler: (e, t) => {
    var n = e.parser;
    return {
      type: "htmlmathml",
      mode: n.mode,
      html: Ce(t[0]),
      mathml: Ce(t[1])
    };
  },
  htmlBuilder: (e, t) => {
    var n = ze(e.html, t, !1);
    return Lt(n);
  },
  mathmlBuilder: (e, t) => Xt(e.mathml, t)
});
var ti = function (t) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(t)) return {
    number: +t,
    unit: "bp"
  };
  var n = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(t);
  if (!n) throw new D("Invalid size: '" + t + "' in \\includegraphics");
  var r = {
    number: +(n[1] + n[2]),
    unit: n[3]
  };
  if (!Z0(r)) throw new D("Invalid unit: '" + r.unit + "' in \\includegraphics.");
  return r;
};
U({
  type: "includegraphics",
  names: ["\\includegraphics"],
  numArgs: 1,
  numOptionalArgs: 1,
  argTypes: ["raw", "url"],
  allowedInText: !1,
  handler: (e, t, n) => {
    var r = e.parser,
      a = {
        number: 0,
        unit: "em"
      },
      i = {
        number: .9,
        unit: "em"
      },
      s = {
        number: 0,
        unit: "em"
      },
      o = "";
    if (n[0]) for (var l = ie(n[0], "raw").string, u = l.split(","), c = 0; c < u.length; c++) {
      var h = u[c].split("=");
      if (h.length === 2) {
        var f = h[1].trim();
        switch (h[0].trim()) {
          case "alt":
            o = f;
            break;
          case "width":
            a = ti(f);
            break;
          case "height":
            i = ti(f);
            break;
          case "totalheight":
            s = ti(f);
            break;
          default:
            throw new D("Invalid key: '" + h[0] + "' in \\includegraphics.");
        }
      }
    }
    var d = ie(t[0], "url").url;
    return o === "" && (o = d, o = o.replace(/^.*[\\/]/, ""), o = o.substring(0, o.lastIndexOf("."))), r.settings.isTrusted({
      command: "\\includegraphics",
      url: d
    }) ? {
      type: "includegraphics",
      mode: r.mode,
      alt: o,
      width: a,
      height: i,
      totalheight: s,
      src: d
    } : r.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (e, t) => {
    var n = we(e.height, t),
      r = 0;
    e.totalheight.number > 0 && (r = we(e.totalheight, t) - n);
    var a = 0;
    e.width.number > 0 && (a = we(e.width, t));
    var i = {
      height: P(n + r)
    };
    a > 0 && (i.width = P(a)), r > 0 && (i.verticalAlign = P(-r));
    var s = new M4(e.src, e.alt, i);
    return s.height = n, s.depth = r, s;
  },
  mathmlBuilder: (e, t) => {
    var n = new F("mglyph", []);
    n.setAttribute("alt", e.alt);
    var r = we(e.height, t),
      a = 0;
    if (e.totalheight.number > 0 && (a = we(e.totalheight, t) - r, n.setAttribute("valign", P(-a))), n.setAttribute("height", P(r + a)), e.width.number > 0) {
      var i = we(e.width, t);
      n.setAttribute("width", P(i));
    }
    return n.setAttribute("src", e.src), n;
  }
});
U({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  numArgs: 1,
  argTypes: ["size"],
  primitive: !0,
  allowedInText: !0,
  handler(e, t) {
    var n = e.parser,
      r = e.funcName,
      a = ie(t[0], "size");
    if (n.settings.strict) {
      var i = r[1] === "m",
        s = a.value.unit === "mu";
      i ? (s || n.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " supports only mu units, " + ("not " + a.value.unit + " units")), n.mode !== "math" && n.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " works only in math mode")) : s && n.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: n.mode,
      dimension: a.value
    };
  },
  htmlBuilder(e, t) {
    return nu(e.dimension, t);
  },
  mathmlBuilder(e, t) {
    var n = we(e.dimension, t);
    return new lu(n);
  }
});
U({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  numArgs: 1,
  allowedInText: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = e.funcName,
      a = t[0];
    return {
      type: "lap",
      mode: n.mode,
      alignment: r.slice(5),
      body: a
    };
  },
  htmlBuilder: (e, t) => {
    var n;
    e.alignment === "clap" ? (n = B([], [ue(e.body, t)]), n = B(["katex-inner"], [n], t)) : n = B(["katex-inner"], [ue(e.body, t)]);
    var r = B(["katex-fix"], []),
      a = B([e.alignment], [n, r], t),
      i = B(["katex-strut"]);
    return i.style.height = P(a.height + a.depth), a.depth && (i.style.verticalAlign = P(-a.depth)), a.children.unshift(i), a = B(["katex-thinbox"], [a], t), B(["mord", "katex-vbox"], [a], t);
  },
  mathmlBuilder: (e, t) => {
    var n = new F("mpadded", [he(e.body, t)]);
    if (e.alignment !== "rlap") {
      var r = e.alignment === "llap" ? "-1" : "-0.5";
      n.setAttribute("lspace", r + "width");
    }
    return n.setAttribute("width", "0px"), n;
  }
});
U({
  type: "styling",
  names: ["\\(", "$"],
  numArgs: 0,
  allowedInText: !0,
  allowedInMath: !1,
  handler(e, t) {
    var n = e.funcName,
      r = e.parser,
      a = r.mode;
    r.switchMode("math");
    var i = n === "\\(" ? "\\)" : "$",
      s = r.parseExpression(!1, i);
    return r.expect(i), r.switchMode(a), {
      type: "styling",
      mode: r.mode,
      style: "text",
      resetFont: !0,
      body: s
    };
  }
});
U({
  type: "text",
  names: ["\\)", "\\]"],
  numArgs: 0,
  allowedInText: !0,
  allowedInMath: !1,
  handler(e, t) {
    throw new D("Mismatched " + e.funcName);
  }
});
var tl = (e, t) => {
  switch (t.style.size) {
    case ee.DISPLAY.size:
      return e.display;
    case ee.TEXT.size:
      return e.text;
    case ee.SCRIPT.size:
      return e.script;
    case ee.SCRIPTSCRIPT.size:
      return e.scriptscript;
    default:
      return e.text;
  }
};
U({
  type: "mathchoice",
  names: ["\\mathchoice"],
  numArgs: 4,
  primitive: !0,
  handler: (e, t) => {
    var n = e.parser;
    return {
      type: "mathchoice",
      mode: n.mode,
      display: Ce(t[0]),
      text: Ce(t[1]),
      script: Ce(t[2]),
      scriptscript: Ce(t[3])
    };
  },
  htmlBuilder: (e, t) => {
    var n = tl(e, t),
      r = ze(n, t, !1);
    return Lt(r);
  },
  mathmlBuilder: (e, t) => {
    var n = tl(e, t);
    return Xt(n, t);
  }
});
var Tu = (e, t, n, r, a, i, s) => {
    e = B([], [e]);
    var o = n && Bt(n),
      l,
      u;
    if (t) {
      var c = ue(t, r.havingStyle(a.sup()), r);
      u = {
        elem: c,
        kern: Math.max(r.fontMetrics().bigOpSpacing1, r.fontMetrics().bigOpSpacing3 - c.depth)
      };
    }
    if (n) {
      var h = ue(n, r.havingStyle(a.sub()), r);
      l = {
        elem: h,
        kern: Math.max(r.fontMetrics().bigOpSpacing2, r.fontMetrics().bigOpSpacing4 - h.height)
      };
    }
    var f;
    if (u && l) {
      var d = r.fontMetrics().bigOpSpacing5 + l.elem.height + l.elem.depth + l.kern + e.depth + s;
      f = ce({
        positionType: "bottom",
        positionData: d,
        children: [{
          type: "kern",
          size: r.fontMetrics().bigOpSpacing5
        }, {
          type: "elem",
          elem: l.elem,
          marginLeft: P(-i)
        }, {
          type: "kern",
          size: l.kern
        }, {
          type: "elem",
          elem: e
        }, {
          type: "kern",
          size: u.kern
        }, {
          type: "elem",
          elem: u.elem,
          marginLeft: P(i)
        }, {
          type: "kern",
          size: r.fontMetrics().bigOpSpacing5
        }]
      });
    } else if (l) {
      var b = e.height - s;
      f = ce({
        positionType: "top",
        positionData: b,
        children: [{
          type: "kern",
          size: r.fontMetrics().bigOpSpacing5
        }, {
          type: "elem",
          elem: l.elem,
          marginLeft: P(-i)
        }, {
          type: "kern",
          size: l.kern
        }, {
          type: "elem",
          elem: e
        }]
      });
    } else if (u) {
      var k = e.depth + s;
      f = ce({
        positionType: "bottom",
        positionData: k,
        children: [{
          type: "elem",
          elem: e
        }, {
          type: "kern",
          size: u.kern
        }, {
          type: "elem",
          elem: u.elem,
          marginLeft: P(i)
        }, {
          type: "kern",
          size: r.fontMetrics().bigOpSpacing5
        }]
      });
    } else return e;
    var A = [f];
    if (l && i !== 0 && !o) {
      var w = B(["mspace"], [], r);
      w.style.marginRight = P(i), A.unshift(w);
    }
    return B(["mop", "op-limits"], A, r);
  },
  Eu = new Set(["\\smallint"]),
  Mu = (e, t) => {
    var n,
      r,
      a = !1,
      i;
    e.type === "supsub" ? (n = e.sup, r = e.sub, i = ie(e.base, "op"), a = !0) : i = ie(e, "op");
    var s = t.style,
      o = !1;
    s.size === ee.DISPLAY.size && i.symbol && !Eu.has(i.name) && (o = !0);
    var l, u;
    if (i.symbol) {
      var c = o ? "Size2-Regular" : "Size1-Regular",
        h = "";
      if ((i.name === "\\oiint" || i.name === "\\oiiint") && (h = i.name.slice(1), i.name = h === "oiint" ? "\\iint" : "\\iiint"), l = je(i.name, c, "math", t, ["mop", "op-symbol", o ? "large-op" : "small-op"]), u = l.italic, h.length > 0) {
        var f = au(h + "Size" + (o ? "2" : "1"), t);
        l = ce({
          positionType: "individualShift",
          children: [{
            type: "elem",
            elem: l,
            shift: 0
          }, {
            type: "elem",
            elem: f,
            shift: o ? .08 : 0
          }]
        }), i.name = "\\" + h, l.classes.unshift("mop"), l.italic = u;
      }
    } else if (i.body) {
      var d = ze(i.body, t, !0);
      d.length === 1 && d[0] instanceof tt ? (l = d[0], l.classes[0] = "mop") : l = B(["mop"], d, t);
    } else {
      for (var b = [], k = 1; k < i.name.length; k++) b.push(cs(i.name[k], i.mode, t));
      l = B(["mop"], b, t);
    }
    var A = 0,
      w = 0;
    if ((l instanceof tt || i.name === "\\oiint" || i.name === "\\oiiint") && !i.suppressBaseShift) {
      var _;
      A = (l.height - l.depth) / 2 - t.fontMetrics().axisHeight, w = (_ = l.italic) != null ? _ : 0;
    }
    return a ? Tu(l, n, r, t, s, w, A) : (A && (l.style.position = "relative", l.style.top = P(A)), l);
  },
  q2 = (e, t) => {
    var n;
    if (e.symbol) n = new F("mo", [ct(e.name, e.mode)]), Eu.has(e.name) && n.setAttribute("largeop", "false");else if (e.body) n = new F("mo", rt(e.body, t));else {
      n = new F("mi", [new Se(e.name.slice(1))]);
      var r = new F("mo", [ct("⁡", "text")]);
      e.parentIsSupSub ? n = new F("mrow", [n, r]) : n = ou([n, r]);
    }
    return n;
  },
  j2 = {
    "∏": "\\prod",
    "∐": "\\coprod",
    "∑": "\\sum",
    "⋀": "\\bigwedge",
    "⋁": "\\bigvee",
    "⋂": "\\bigcap",
    "⋃": "\\bigcup",
    "⨀": "\\bigodot",
    "⨁": "\\bigoplus",
    "⨂": "\\bigotimes",
    "⨄": "\\biguplus",
    "⨆": "\\bigsqcup"
  };
U({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  numArgs: 0,
  handler: (e, t) => {
    var n = e.parser,
      r = e.funcName,
      a = r;
    return a.length === 1 && (a = j2[a]), {
      type: "op",
      mode: n.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: Mu,
  mathmlBuilder: q2
});
U({
  type: "op",
  names: ["\\mathop"],
  numArgs: 1,
  primitive: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = t[0];
    return {
      type: "op",
      mode: n.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: Ce(r)
    };
  }
});
var G2 = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
U({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  numArgs: 0,
  handler(e) {
    var t = e.parser,
      n = e.funcName;
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: n
    };
  }
});
U({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  numArgs: 0,
  handler(e) {
    var t = e.parser,
      n = e.funcName;
    return {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: n
    };
  }
});
U({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  numArgs: 0,
  allowedInArgument: !0,
  handler(e) {
    var t = e.parser,
      n = e.funcName,
      r = n;
    return r.length === 1 && (r = G2[r]), {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: r
    };
  }
});
var zu = (e, t) => {
    var n,
      r,
      a = !1,
      i;
    e.type === "supsub" ? (n = e.sup, r = e.sub, i = ie(e.base, "operatorname"), a = !0) : i = ie(e, "operatorname");
    var s;
    if (i.body.length > 0) {
      for (var o = i.body.map(h => {
          var f = "text" in h ? h.text : void 0;
          return typeof f == "string" ? {
            type: "textord",
            mode: h.mode,
            text: f
          } : h;
        }), l = ze(o, t.withFont("mathrm"), !0), u = 0; u < l.length; u++) {
        var c = l[u];
        c instanceof tt && (c.text = c.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
      }
      s = B(["mop"], l, t);
    } else s = B(["mop"], [], t);
    return a ? Tu(s, n, r, t, t.style, 0, 0) : s;
  },
  H2 = (e, t) => {
    for (var n = rt(e.body, t.withFont("mathrm")), r = !0, a = 0; a < n.length; a++) {
      var i = n[a];
      if (!(i instanceof lu)) if (i instanceof F) switch (i.type) {
        case "mi":
        case "mn":
        case "mspace":
        case "mtext":
          break;
        case "mo":
          {
            var s = i.children[0];
            i.children.length === 1 && s instanceof Se ? s.text = s.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : r = !1;
            break;
          }
        default:
          r = !1;
      } else r = !1;
    }
    if (r) {
      var o = n.map(c => c.toText()).join("");
      n = [new Se(o)];
    }
    var l = new F("mi", n);
    l.setAttribute("mathvariant", "normal");
    var u = new F("mo", [ct("⁡", "text")]);
    return e.parentIsSupSub ? new F("mrow", [l, u]) : ou([l, u]);
  };
U({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  numArgs: 1,
  handler: (e, t) => {
    var n = e.parser,
      r = e.funcName,
      a = t[0];
    return {
      type: "operatorname",
      mode: n.mode,
      body: Ce(a),
      alwaysHandleSupSub: r === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: zu,
  mathmlBuilder: H2
});
y("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
fn({
  type: "ordgroup",
  htmlBuilder(e, t) {
    return e.semisimple ? Lt(ze(e.body, t, !1)) : B(["mord"], ze(e.body, t, !0), t);
  },
  mathmlBuilder(e, t) {
    return Xt(e.body, t, !0);
  }
});
U({
  type: "overline",
  names: ["\\overline"],
  numArgs: 1,
  handler(e, t) {
    var n = e.parser,
      r = t[0];
    return {
      type: "overline",
      mode: n.mode,
      body: r
    };
  },
  htmlBuilder(e, t) {
    var n = ue(e.body, t.havingCrampedStyle()),
      r = Tn("overline-line", t),
      a = t.fontMetrics().defaultRuleThickness,
      i = ce({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: n
        }, {
          type: "kern",
          size: 3 * a
        }, {
          type: "elem",
          elem: r
        }, {
          type: "kern",
          size: a
        }]
      });
    return B(["mord", "katex-overline"], [i], t);
  },
  mathmlBuilder(e, t) {
    var n = new F("mo", [new Se("‾")]);
    n.setAttribute("stretchy", "true");
    var r = new F("mover", [he(e.body, t), n]);
    return r.setAttribute("accent", "true"), r;
  }
});
U({
  type: "phantom",
  names: ["\\phantom"],
  numArgs: 1,
  allowedInText: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = t[0];
    return {
      type: "phantom",
      mode: n.mode,
      body: Ce(r)
    };
  },
  htmlBuilder: (e, t) => {
    var n = ze(e.body, t.withPhantom(), !1);
    return Lt(n);
  },
  mathmlBuilder: (e, t) => {
    var n = rt(e.body, t);
    return new F("mphantom", n);
  }
});
y("\\hphantom", "\\smash{\\phantom{#1}}");
U({
  type: "vphantom",
  names: ["\\vphantom"],
  numArgs: 1,
  allowedInText: !0,
  handler: (e, t) => {
    var n = e.parser,
      r = t[0];
    return {
      type: "vphantom",
      mode: n.mode,
      body: r
    };
  },
  htmlBuilder: (e, t) => {
    var n = B(["katex-inner"], [ue(e.body, t.withPhantom())]),
      r = B(["katex-fix"], []);
    return B(["mord", "rlap"], [n, r], t);
  },
  mathmlBuilder: (e, t) => {
    var n = rt(Ce(e.body), t),
      r = new F("mphantom", n),
      a = new F("mpadded", [r]);
    return a.setAttribute("width", "0px"), a;
  }
});
U({
  type: "raisebox",
  names: ["\\raisebox"],
  numArgs: 2,
  argTypes: ["size", "hbox"],
  allowedInText: !0,
  handler(e, t) {
    var n = e.parser,
      r = ie(t[0], "size").value,
      a = t[1];
    return {
      type: "raisebox",
      mode: n.mode,
      dy: r,
      body: a
    };
  },
  htmlBuilder(e, t) {
    var n = ue(e.body, t),
      r = we(e.dy, t);
    return ce({
      positionType: "shift",
      positionData: -r,
      children: [{
        type: "elem",
        elem: n
      }]
    });
  },
  mathmlBuilder(e, t) {
    var n = new F("mpadded", [he(e.body, t)]),
      r = e.dy.number + e.dy.unit;
    return n.setAttribute("voffset", r), n;
  }
});
var Iu = (e, t) => {
  var n = e.parser;
  return {
    type: "reflectbox",
    mode: n.mode,
    body: t[0]
  };
};
U({
  type: "reflectbox",
  names: ["\\reflectbox"],
  numArgs: 1,
  argTypes: ["hbox"],
  allowedInText: !0,
  handler: Iu,
  htmlBuilder(e, t) {
    return B(["mord", "reflectbox"], [ue(e.body, t)], t);
  },
  mathmlBuilder(e, t) {
    return he(e.body, t);
  }
});
U({
  type: "reflectbox",
  names: ["\\mathreflectbox"],
  numArgs: 1,
  argTypes: ["math"],
  handler: Iu
});
U({
  type: "internal",
  names: ["\\relax"],
  numArgs: 0,
  allowedInText: !0,
  allowedInArgument: !0,
  handler(e) {
    var t = e.parser;
    return {
      type: "internal",
      mode: t.mode
    };
  }
});
U({
  type: "rule",
  names: ["\\rule"],
  numArgs: 2,
  numOptionalArgs: 1,
  allowedInText: !0,
  allowedInMath: !0,
  argTypes: ["size", "size", "size"],
  handler(e, t, n) {
    var r = e.parser,
      a = n[0],
      i = ie(t[0], "size"),
      s = ie(t[1], "size");
    return {
      type: "rule",
      mode: r.mode,
      shift: a && ie(a, "size").value,
      width: i.value,
      height: s.value
    };
  },
  htmlBuilder(e, t) {
    var n = B(["mord", "katex-rule"], [], t),
      r = we(e.width, t),
      a = we(e.height, t),
      i = e.shift ? we(e.shift, t) : 0;
    return n.style.borderRightWidth = P(r), n.style.borderTopWidth = P(a), n.style.bottom = P(i), n.width = r, n.height = a + i, n.depth = -i, n.maxFontSize = a * 1.125 * t.sizeMultiplier, n;
  },
  mathmlBuilder(e, t) {
    var n = we(e.width, t),
      r = we(e.height, t),
      a = e.shift ? we(e.shift, t) : 0,
      i = t.color && t.getColor() || "black",
      s = new F("mspace");
    s.setAttribute("mathbackground", i), s.setAttribute("width", P(n)), s.setAttribute("height", P(r));
    var o = new F("mpadded", [s]);
    return a >= 0 ? o.setAttribute("height", P(a)) : (o.setAttribute("height", P(a)), o.setAttribute("depth", P(-a))), o.setAttribute("voffset", P(a)), o;
  }
});
function Nu(e, t, n) {
  for (var r = ze(e, t, !1), a = t.sizeMultiplier / n.sizeMultiplier, i = 0; i < r.length; i++) {
    var s = r[i].classes.indexOf("katex-sizing");
    s < 0 ? Array.prototype.push.apply(r[i].classes, t.sizingClasses(n)) : r[i].classes[s + 1] === "reset-size" + t.size && (r[i].classes[s + 1] = "reset-size" + n.size), r[i].height *= a, r[i].depth *= a;
  }
  return Lt(r);
}
var nl = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"],
  U2 = (e, t) => {
    var n = t.havingSize(e.size);
    return Nu(e.body, n, t);
  };
U({
  type: "sizing",
  names: nl,
  numArgs: 0,
  allowedInText: !0,
  handler: (e, t) => {
    var n = e.breakOnTokenText,
      r = e.funcName,
      a = e.parser,
      i = a.parseExpression(!1, n);
    return {
      type: "sizing",
      mode: a.mode,
      size: nl.indexOf(r) + 1,
      body: i
    };
  },
  htmlBuilder: U2,
  mathmlBuilder: (e, t) => {
    var n = t.havingSize(e.size),
      r = rt(e.body, n),
      a = new F("mstyle", r);
    return a.setAttribute("mathsize", P(n.sizeMultiplier)), a;
  }
});
U({
  type: "smash",
  names: ["\\smash"],
  numArgs: 1,
  numOptionalArgs: 1,
  allowedInText: !0,
  handler: (e, t, n) => {
    var r = e.parser,
      a = !1,
      i = !1,
      s = n[0] && ie(n[0], "ordgroup");
    if (s) for (var o, l = 0; l < s.body.length; ++l) {
      var u = s.body[l];
      if (o = ga(u).text, o === "t") a = !0;else if (o === "b") i = !0;else {
        a = !1, i = !1;
        break;
      }
    } else a = !0, i = !0;
    var c = t[0];
    return {
      type: "smash",
      mode: r.mode,
      body: c,
      smashHeight: a,
      smashDepth: i
    };
  },
  htmlBuilder: (e, t) => {
    var n = B([], [ue(e.body, t)]);
    if (!e.smashHeight && !e.smashDepth) return n;
    if (e.smashHeight && (n.height = 0), e.smashDepth && (n.depth = 0), e.smashHeight && e.smashDepth) return B(["mord", "katex-smash"], [n], t);
    if (n.children) for (var r = 0; r < n.children.length; r++) e.smashHeight && (n.children[r].height = 0), e.smashDepth && (n.children[r].depth = 0);
    var a = ce({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: n
      }]
    });
    return B(["mord"], [a], t);
  },
  mathmlBuilder: (e, t) => {
    var n = new F("mpadded", [he(e.body, t)]);
    return e.smashHeight && n.setAttribute("height", "0px"), e.smashDepth && n.setAttribute("depth", "0px"), n;
  }
});
U({
  type: "sqrt",
  names: ["\\sqrt"],
  numArgs: 1,
  numOptionalArgs: 1,
  handler(e, t, n) {
    var r = e.parser,
      a = n[0],
      i = t[0];
    return {
      type: "sqrt",
      mode: r.mode,
      body: i,
      index: a
    };
  },
  htmlBuilder(e, t) {
    var n = ue(e.body, t.havingCrampedStyle());
    n.height === 0 && (n.height = t.fontMetrics().xHeight), n = En(n, t);
    var r = t.fontMetrics(),
      a = r.defaultRuleThickness,
      i = a;
    t.style.id < ee.TEXT.id && (i = t.fontMetrics().xHeight);
    var s = a + i / 4,
      o = n.height + n.depth + s + a,
      l = S2(o, t),
      u = l.span,
      c = l.ruleWidth,
      h = l.advanceWidth,
      f = u.height - c;
    f > n.height + n.depth + s && (s = (s + f - n.height - n.depth) / 2);
    var d = u.height - n.height - s - c;
    n.style.paddingLeft = P(h);
    var b = ce({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: n,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(n.height + d)
      }, {
        type: "elem",
        elem: u
      }, {
        type: "kern",
        size: c
      }]
    });
    if (e.index) {
      var k = t.havingStyle(ee.SCRIPTSCRIPT),
        A = ue(e.index, k, t),
        w = .6 * (b.height - b.depth),
        _ = ce({
          positionType: "shift",
          positionData: -w,
          children: [{
            type: "elem",
            elem: A
          }]
        }),
        T = B(["katex-root"], [_]);
      return B(["mord", "sqrt"], [T, b], t);
    } else return B(["mord", "sqrt"], [b], t);
  },
  mathmlBuilder(e, t) {
    var n = e.body,
      r = e.index;
    return r ? new F("mroot", [he(n, t), he(r, t)]) : new F("msqrt", [he(n, t)]);
  }
});
var Gi = {
  display: ee.DISPLAY,
  text: ee.TEXT,
  script: ee.SCRIPT,
  scriptscript: ee.SCRIPTSCRIPT
};
function W2(e) {
  return e in Gi;
}
U({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  numArgs: 0,
  allowedInText: !0,
  primitive: !0,
  handler(e, t) {
    var n = e.breakOnTokenText,
      r = e.funcName,
      a = e.parser,
      i = a.parseExpression(!0, n),
      s = r.slice(1, r.length - 5);
    if (!W2(s)) throw new Error("Unknown style: " + s);
    return {
      type: "styling",
      mode: a.mode,
      style: s,
      body: i
    };
  },
  htmlBuilder(e, t) {
    var n = Gi[e.style],
      r = t.havingStyle(n);
    return e.resetFont && (r = r.withFont("")), Nu(e.body, r, t);
  },
  mathmlBuilder(e, t) {
    var n = Gi[e.style],
      r = t.havingStyle(n);
    e.resetFont && (r = r.withFont(""));
    var a = rt(e.body, r),
      i = new F("mstyle", a),
      s = {
        display: ["0", "true"],
        text: ["0", "false"],
        script: ["1", "false"],
        scriptscript: ["2", "false"]
      },
      o = s[e.style];
    return i.setAttribute("scriptlevel", o[0]), i.setAttribute("displaystyle", o[1]), i;
  }
});
var V2 = function (t, n) {
  var r = t.base;
  if (r) {
    if (r.type === "op") {
      var a = r.limits && (n.style.size === ee.DISPLAY.size || r.alwaysHandleSupSub);
      return a ? Mu : null;
    } else if (r.type === "operatorname") {
      var i = r.alwaysHandleSupSub && (n.style.size === ee.DISPLAY.size || r.limits);
      return i ? zu : null;
    } else {
      if (r.type === "accent") return Bt(r.base) ? hu : null;
      if (r.type === "horizBrace") {
        var s = !t.sub;
        return s === r.isOver ? Au : null;
      } else return null;
    }
  } else return null;
};
fn({
  type: "supsub",
  htmlBuilder(e, t) {
    var n = V2(e, t);
    if (n) return n(e, t);
    var r = e.base,
      a = e.sup,
      i = e.sub,
      s = ue(r, t),
      o,
      l,
      u = t.fontMetrics(),
      c = 0,
      h = 0,
      f = r && Bt(r);
    if (a) {
      var d = t.havingStyle(t.style.sup());
      o = ue(a, d, t), f || (c = s.height - d.fontMetrics().supDrop * d.sizeMultiplier / t.sizeMultiplier);
    }
    if (i) {
      var b = t.havingStyle(t.style.sub());
      l = ue(i, b, t), f || (h = s.depth + b.fontMetrics().subDrop * b.sizeMultiplier / t.sizeMultiplier);
    }
    var k;
    t.style === ee.DISPLAY ? k = u.sup1 : t.style.cramped ? k = u.sup3 : k = u.sup2;
    var A = t.sizeMultiplier,
      w = P(.5 / u.ptPerEm / A),
      _ = null;
    if (l) {
      var T = e.base && e.base.type === "op" && e.base.name && (e.base.name === "\\oiint" || e.base.name === "\\oiiint");
      if (s instanceof tt || T) {
        var I;
        _ = P(-((I = s.italic) != null ? I : 0));
      }
    }
    var R;
    if (o && l) {
      c = Math.max(c, k, o.depth + .25 * u.xHeight), h = Math.max(h, u.sub2);
      var E = u.defaultRuleThickness,
        O = 4 * E;
      if (c - o.depth - (l.height - h) < O) {
        h = O - (c - o.depth) + l.height;
        var W = .8 * u.xHeight - (c - o.depth);
        W > 0 && (c += W, h -= W);
      }
      var G = [{
        type: "elem",
        elem: l,
        shift: h,
        marginRight: w,
        marginLeft: _
      }, {
        type: "elem",
        elem: o,
        shift: -c,
        marginRight: w
      }];
      R = ce({
        positionType: "individualShift",
        children: G
      });
    } else if (l) {
      h = Math.max(h, u.sub1, l.height - .8 * u.xHeight);
      var M = [{
        type: "elem",
        elem: l,
        marginLeft: _,
        marginRight: w
      }];
      R = ce({
        positionType: "shift",
        positionData: h,
        children: M
      });
    } else if (o) c = Math.max(c, k, o.depth + .25 * u.xHeight), R = ce({
      positionType: "shift",
      positionData: -c,
      children: [{
        type: "elem",
        elem: o,
        marginRight: w
      }]
    });else throw new Error("supsub must have either sup or sub.");
    var H = Fi(s, "right") || "mord";
    return B([H], [s, B(["msupsub"], [R])], t);
  },
  mathmlBuilder(e, t) {
    var n = !1,
      r,
      a;
    e.base && e.base.type === "horizBrace" && (a = !!e.sup, a === e.base.isOver && (n = !0, r = e.base.isOver)), e.base && (e.base.type === "op" || e.base.type === "operatorname") && (e.base.parentIsSupSub = !0);
    var i = [he(e.base, t)];
    e.sub && i.push(he(e.sub, t)), e.sup && i.push(he(e.sup, t));
    var s;
    if (n) s = r ? "mover" : "munder";else if (e.sub) {
      if (e.sup) {
        var u = e.base;
        u && u.type === "op" && u.limits && t.style === ee.DISPLAY || u && u.type === "operatorname" && u.alwaysHandleSupSub && (t.style === ee.DISPLAY || u.limits) ? s = "munderover" : s = "msubsup";
      } else {
        var l = e.base;
        l && l.type === "op" && l.limits && (t.style === ee.DISPLAY || l.alwaysHandleSupSub) || l && l.type === "operatorname" && l.alwaysHandleSupSub && (l.limits || t.style === ee.DISPLAY) ? s = "munder" : s = "msub";
      }
    } else {
      var o = e.base;
      o && o.type === "op" && o.limits && (t.style === ee.DISPLAY || o.alwaysHandleSupSub) || o && o.type === "operatorname" && o.alwaysHandleSupSub && (o.limits || t.style === ee.DISPLAY) ? s = "mover" : s = "msup";
    }
    return new F(s, i);
  }
});
fn({
  type: "atom",
  htmlBuilder(e, t) {
    return cs(e.text, e.mode, t, ["m" + e.family]);
  },
  mathmlBuilder(e, t) {
    var n = new F("mo", [ct(e.text, e.mode)]);
    if (e.family === "bin") {
      var r = ps(e, t);
      r === "bold-italic" && n.setAttribute("mathvariant", r);
    } else e.family === "punct" ? n.setAttribute("separator", "true") : (e.family === "open" || e.family === "close") && n.setAttribute("stretchy", "false");
    return n;
  }
});
var Ru = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
fn({
  type: "mathord",
  htmlBuilder(e, t) {
    return pa(e, t);
  },
  mathmlBuilder(e, t) {
    var n = new F("mi", [ct(e.text, e.mode, t)]),
      r = ps(e, t) || "italic";
    return r !== Ru[n.type] && n.setAttribute("mathvariant", r), n;
  }
});
fn({
  type: "textord",
  htmlBuilder(e, t) {
    return pa(e, t);
  },
  mathmlBuilder(e, t) {
    var n = ct(e.text, e.mode, t),
      r = ps(e, t) || "normal",
      a;
    return e.mode === "text" ? a = new F("mtext", [n]) : /[0-9]/.test(e.text) ? a = new F("mn", [n]) : e.text === "\\prime" ? a = new F("mo", [n]) : a = new F("mi", [n]), r !== Ru[a.type] && a.setAttribute("mathvariant", r), a;
  }
});
var rl = new Map([["\\nobreak", "nobreak"], ["\\allowbreak", "allowbreak"]]),
  al = new Map([[" ", {}], ["\\ ", {}], ["~", {
    className: "nobreak"
  }], ["\\space", {}], ["\\nobreakspace", {
    className: "nobreak"
  }]]);
fn({
  type: "spacing",
  htmlBuilder(e, t) {
    var n = al.get(e.text),
      r = rl.get(e.text);
    if (n) {
      var a = n.className || "";
      if (e.mode === "text") {
        var i = pa(e, t);
        return i.classes.push(a), i;
      } else return B(["mspace", a], [cs(e.text, e.mode, t)], t);
    } else {
      if (r) return B(["mspace", r], [], t);
      throw new D('Unknown type of space "' + e.text + '"');
    }
  },
  mathmlBuilder(e, t) {
    var n;
    if (al.has(e.text)) n = new F("mtext", [new Se(" ")]);else {
      if (rl.has(e.text)) return new F("mspace");
      throw new D('Unknown type of space "' + e.text + '"');
    }
    return n;
  }
});
var il = () => {
  var e = new F("mtd", []);
  return e.setAttribute("width", "50%"), e;
};
fn({
  type: "tag",
  mathmlBuilder(e, t) {
    var n = new F("mtable", [new F("mtr", [il(), new F("mtd", [Xt(e.body, t)]), il(), new F("mtd", [Xt(e.tag, t)])])]);
    return n.setAttribute("width", "100%"), n;
  }
});
var sl = {
    "\\text": void 0,
    "\\textrm": "textrm",
    "\\textsf": "textsf",
    "\\texttt": "texttt",
    "\\textnormal": "textrm"
  },
  ol = {
    "\\textbf": "textbf",
    "\\textmd": "textmd"
  },
  X2 = {
    "\\textit": "textit",
    "\\textup": "textup"
  },
  ll = (e, t) => {
    var n = e.font;
    if (n) {
      if (sl[n]) return t.withTextFontFamily(sl[n]);
      if (ol[n]) return t.withTextFontWeight(ol[n]);
      if (n === "\\emph") return t.fontShape === "textit" ? t.withTextFontShape("textup") : t.withTextFontShape("textit");
    } else return t;
    return t.withTextFontShape(X2[n]);
  };
U({
  type: "text",
  names: ["\\text", "\\textrm", "\\textsf", "\\texttt", "\\textnormal", "\\textbf", "\\textmd", "\\textit", "\\textup", "\\emph"],
  numArgs: 1,
  argTypes: ["text"],
  allowedInArgument: !0,
  allowedInText: !0,
  handler(e, t) {
    var n = e.parser,
      r = e.funcName,
      a = t[0];
    return {
      type: "text",
      mode: n.mode,
      body: Ce(a),
      font: r
    };
  },
  htmlBuilder(e, t) {
    var n = ll(e, t),
      r = ze(e.body, n, !0);
    return B(["mord", "text"], r, n);
  },
  mathmlBuilder(e, t) {
    var n = ll(e, t);
    return Xt(e.body, n);
  }
});
U({
  type: "underline",
  names: ["\\underline"],
  numArgs: 1,
  allowedInText: !0,
  handler(e, t) {
    var n = e.parser;
    return {
      type: "underline",
      mode: n.mode,
      body: t[0]
    };
  },
  htmlBuilder(e, t) {
    var n = ue(e.body, t),
      r = Tn("underline-line", t),
      a = t.fontMetrics().defaultRuleThickness,
      i = ce({
        positionType: "top",
        positionData: n.height,
        children: [{
          type: "kern",
          size: a
        }, {
          type: "elem",
          elem: r
        }, {
          type: "kern",
          size: 3 * a
        }, {
          type: "elem",
          elem: n
        }]
      });
    return B(["mord", "katex-underline"], [i], t);
  },
  mathmlBuilder(e, t) {
    var n = new F("mo", [new Se("‾")]);
    n.setAttribute("stretchy", "true");
    var r = new F("munder", [he(e.body, t), n]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
U({
  type: "vcenter",
  names: ["\\vcenter"],
  numArgs: 1,
  argTypes: ["original"],
  allowedInText: !1,
  handler(e, t) {
    var n = e.parser;
    return {
      type: "vcenter",
      mode: n.mode,
      body: t[0]
    };
  },
  htmlBuilder(e, t) {
    var n = ue(e.body, t),
      r = t.fontMetrics().axisHeight,
      a = .5 * (n.height - r - (n.depth + r));
    return ce({
      positionType: "shift",
      positionData: a,
      children: [{
        type: "elem",
        elem: n
      }]
    });
  },
  mathmlBuilder(e, t) {
    var n = new F("mpadded", [he(e.body, t)], ["vcenter"]);
    return new F("mrow", [n]);
  }
});
U({
  type: "verb",
  names: ["\\verb"],
  numArgs: 0,
  allowedInText: !0,
  handler(e, t, n) {
    throw new D("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(e, t) {
    for (var n = ul(e), r = [], a = t.havingStyle(t.style.text()), i = 0; i < n.length; i++) {
      var s = n[i];
      s === "~" && (s = "\\textasciitilde"), r.push(je(s, "Typewriter-Regular", e.mode, a, ["mord", "texttt"]));
    }
    return B(["mord", "text"].concat(a.sizingClasses(t)), tu(r), a);
  },
  mathmlBuilder(e, t) {
    var n = new Se(ul(e)),
      r = new F("mtext", [n]);
    return r.setAttribute("mathvariant", "monospace"), r;
  }
});
var ul = e => e.body.replace(/ /g, e.star ? "␣" : " "),
  Gt = iu,
  Bu = `[ \r
	]`,
  Y2 = "\\\\[a-zA-Z@]+",
  Z2 = "\\\\[^\uD800-\uDFFF]",
  K2 = "(" + Y2 + ")" + Bu + "*",
  Q2 = `\\\\(
|[ \r	]+
?)[ \r	]*`,
  Hi = "[̀-ͯ]",
  J2 = new RegExp(Hi + "+$"),
  e5 = "(" + Bu + "+)|" + (Q2 + "|") + "([!-\\[\\]-‧‪-퟿豈-￿]" + (Hi + "*") + "|[\uD800-\uDBFF][\uDC00-\uDFFF]" + (Hi + "*") + "|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + ("|" + K2) + ("|" + Z2 + ")");
class cl {
  constructor(t, n) {
    this.input = void 0, this.settings = void 0, this.tokenRegex = void 0, this.catcodes = void 0, this.input = t, this.settings = n, this.tokenRegex = new RegExp(e5, "g"), this.catcodes = {
      "%": 14,
      "~": 13
    };
  }
  setCatcode(t, n) {
    this.catcodes[t] = n;
  }
  lex() {
    var t = this.input,
      n = this.tokenRegex.lastIndex;
    if (n === t.length) return new et("EOF", new Ve(this, n, n));
    var r = this.tokenRegex.exec(t);
    if (r === null || r.index !== n) throw new D("Unexpected character: '" + t[n] + "'", new et(t[n], new Ve(this, n, n + 1)));
    var a = r[6] || r[3] || (r[2] ? "\\ " : " ");
    if (this.catcodes[a] === 14) {
      var i = t.indexOf(`
`, this.tokenRegex.lastIndex);
      return i === -1 ? (this.tokenRegex.lastIndex = t.length, this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")) : this.tokenRegex.lastIndex = i + 1, this.lex();
    }
    return new et(a, new Ve(this, n, this.tokenRegex.lastIndex));
  }
}
class t5 {
  constructor(t, n) {
    t === void 0 && (t = {}), n === void 0 && (n = {}), this.current = void 0, this.builtins = void 0, this.undefStack = void 0, this.current = n, this.builtins = t, this.undefStack = [];
  }
  beginGroup() {
    this.undefStack.push({});
  }
  endGroup() {
    if (this.undefStack.length === 0) throw new D("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
    var t = this.undefStack.pop();
    for (var n of Object.keys(t)) t[n] === void 0 ? delete this.current[n] : this.current[n] = t[n];
  }
  endGroups() {
    for (; this.undefStack.length > 0;) this.endGroup();
  }
  has(t) {
    return Object.prototype.hasOwnProperty.call(this.current, t) || Object.prototype.hasOwnProperty.call(this.builtins, t);
  }
  get(t) {
    return Object.prototype.hasOwnProperty.call(this.current, t) ? this.current[t] : Object.prototype.hasOwnProperty.call(this.builtins, t) ? this.builtins[t] : void 0;
  }
  set(t, n, r) {
    if (r === void 0 && (r = !1), r) {
      for (var a = 0; a < this.undefStack.length; a++) delete this.undefStack[a][t];
      this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][t] = n);
    } else {
      var i = this.undefStack[this.undefStack.length - 1];
      i && !Object.prototype.hasOwnProperty.call(i, t) && (i[t] = Object.prototype.hasOwnProperty.call(this.current, t) ? this.current[t] : void 0);
    }
    n == null ? delete this.current[t] : this.current[t] = n;
  }
}
var n5 = $u;
y("\\noexpand", function (e) {
  var t = e.popToken();
  return e.isExpandable(t.text) && (t.noexpand = !0, t.treatAsRelax = !0), {
    tokens: [t],
    numArgs: 0
  };
});
y("\\expandafter", function (e) {
  var t = e.popToken();
  return e.expandOnce(!0), {
    tokens: [t],
    numArgs: 0
  };
});
y("\\@firstoftwo", function (e) {
  var t = e.consumeArgs(2);
  return {
    tokens: t[0],
    numArgs: 0
  };
});
y("\\@secondoftwo", function (e) {
  var t = e.consumeArgs(2);
  return {
    tokens: t[1],
    numArgs: 0
  };
});
y("\\@ifnextchar", function (e) {
  var t = e.consumeArgs(3);
  e.consumeSpaces();
  var n = e.future();
  return t[0].length === 1 && t[0][0].text === n.text ? {
    tokens: t[1],
    numArgs: 0
  } : {
    tokens: t[2],
    numArgs: 0
  };
});
y("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
y("\\TextOrMath", function (e) {
  var t = e.consumeArgs(2);
  return e.mode === "text" ? {
    tokens: t[0],
    numArgs: 0
  } : {
    tokens: t[1],
    numArgs: 0
  };
});
var ml = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
y("\\char", function (e) {
  var t = e.popToken(),
    n,
    r = 0;
  if (t.text === "'") n = 8, t = e.popToken();else if (t.text === '"') n = 16, t = e.popToken();else if (t.text === "`") {
    if (t = e.popToken(), t.text[0] === "\\") r = t.text.charCodeAt(1);else {
      if (t.text === "EOF") throw new D("\\char` missing argument");
      r = t.text.charCodeAt(0);
    }
  } else n = 10;
  if (n) {
    if (r = ml[t.text], r == null || r >= n) throw new D("Invalid base-" + n + " digit " + t.text);
    for (var a; (a = ml[e.future().text]) != null && a < n;) r *= n, r += a, e.popToken();
  }
  return "\\@char{" + r + "}";
});
var ys = (e, t, n, r) => {
  var a = e.consumeArg().tokens;
  if (a.length !== 1) throw new D("\\newcommand's first argument must be a macro name");
  var i = a[0].text,
    s = e.isDefined(i);
  if (s && !t) throw new D("\\newcommand{" + i + "} attempting to redefine " + (i + "; use \\renewcommand"));
  if (!s && !n) throw new D("\\renewcommand{" + i + "} when command " + i + " does not yet exist; use \\newcommand");
  var o = 0;
  if (a = e.consumeArg().tokens, a.length === 1 && a[0].text === "[") {
    for (var l = "", u = e.expandNextToken(); u.text !== "]" && u.text !== "EOF";) l += u.text, u = e.expandNextToken();
    if (!l.match(/^\s*[0-9]+\s*$/)) throw new D("Invalid number of arguments: " + l);
    o = parseInt(l), a = e.consumeArg().tokens;
  }
  return s && r || e.macros.set(i, {
    tokens: a,
    numArgs: o
  }), "";
};
y("\\newcommand", e => ys(e, !1, !0, !1));
y("\\renewcommand", e => ys(e, !0, !1, !1));
y("\\providecommand", e => ys(e, !0, !0, !0));
y("\\message", e => {
  var t = e.consumeArgs(1)[0];
  return console.log(t.reverse().map(n => n.text).join("")), "";
});
y("\\errmessage", e => {
  var t = e.consumeArgs(1)[0];
  return console.error(t.reverse().map(n => n.text).join("")), "";
});
y("\\show", e => {
  var t = e.popToken(),
    n = t.text;
  return console.log(t, e.macros.get(n), Gt[n], be.math[n], be.text[n]), "";
});
y("\\bgroup", "{");
y("\\egroup", "}");
y("~", "\\nobreakspace");
y("\\lq", "`");
y("\\rq", "'");
y("\\aa", "\\r a");
y("\\AA", "\\r A");
y("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
y("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
y("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
y("ℬ", "\\mathscr{B}");
y("ℰ", "\\mathscr{E}");
y("ℱ", "\\mathscr{F}");
y("ℋ", "\\mathscr{H}");
y("ℐ", "\\mathscr{I}");
y("ℒ", "\\mathscr{L}");
y("ℳ", "\\mathscr{M}");
y("ℛ", "\\mathscr{R}");
y("ℭ", "\\mathfrak{C}");
y("ℌ", "\\mathfrak{H}");
y("ℨ", "\\mathfrak{Z}");
y("\\Bbbk", "\\Bbb{k}");
y("\\llap", "\\mathllap{\\textrm{#1}}");
y("\\rlap", "\\mathrlap{\\textrm{#1}}");
y("\\clap", "\\mathclap{\\textrm{#1}}");
y("\\mathstrut", "\\vphantom{(}");
y("\\underbar", "\\underline{\\text{#1}}");
y("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}\\nobreak}{\\char"338}');
y("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
y("\\ne", "\\neq");
y("≠", "\\neq");
y("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
y("∉", "\\notin");
y("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
y("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
y("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
y("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
y("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
y("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
y("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
y("⟂", "\\perp");
y("‼", "\\mathclose{!\\mkern-0.8mu!}");
y("∌", "\\notni");
y("⌜", "\\ulcorner");
y("⌝", "\\urcorner");
y("⌞", "\\llcorner");
y("⌟", "\\lrcorner");
y("©", "\\copyright");
y("®", "\\textregistered");
y("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
y("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
y("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
y("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
y("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
y("⋮", "\\vdots");
y("\\varGamma", "\\mathit{\\Gamma}");
y("\\varDelta", "\\mathit{\\Delta}");
y("\\varTheta", "\\mathit{\\Theta}");
y("\\varLambda", "\\mathit{\\Lambda}");
y("\\varXi", "\\mathit{\\Xi}");
y("\\varPi", "\\mathit{\\Pi}");
y("\\varSigma", "\\mathit{\\Sigma}");
y("\\varUpsilon", "\\mathit{\\Upsilon}");
y("\\varPhi", "\\mathit{\\Phi}");
y("\\varPsi", "\\mathit{\\Psi}");
y("\\varOmega", "\\mathit{\\Omega}");
y("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
y("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
y("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
y("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
y("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
y("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
y("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
y("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var hl = {
    ",": "\\dotsc",
    "\\not": "\\dotsb",
    "+": "\\dotsb",
    "=": "\\dotsb",
    "<": "\\dotsb",
    ">": "\\dotsb",
    "-": "\\dotsb",
    "*": "\\dotsb",
    ":": "\\dotsb",
    "\\DOTSB": "\\dotsb",
    "\\coprod": "\\dotsb",
    "\\bigvee": "\\dotsb",
    "\\bigwedge": "\\dotsb",
    "\\biguplus": "\\dotsb",
    "\\bigcap": "\\dotsb",
    "\\bigcup": "\\dotsb",
    "\\prod": "\\dotsb",
    "\\sum": "\\dotsb",
    "\\bigotimes": "\\dotsb",
    "\\bigoplus": "\\dotsb",
    "\\bigodot": "\\dotsb",
    "\\bigsqcup": "\\dotsb",
    "\\And": "\\dotsb",
    "\\longrightarrow": "\\dotsb",
    "\\Longrightarrow": "\\dotsb",
    "\\longleftarrow": "\\dotsb",
    "\\Longleftarrow": "\\dotsb",
    "\\longleftrightarrow": "\\dotsb",
    "\\Longleftrightarrow": "\\dotsb",
    "\\mapsto": "\\dotsb",
    "\\longmapsto": "\\dotsb",
    "\\hookrightarrow": "\\dotsb",
    "\\doteq": "\\dotsb",
    "\\mathbin": "\\dotsb",
    "\\mathrel": "\\dotsb",
    "\\relbar": "\\dotsb",
    "\\Relbar": "\\dotsb",
    "\\xrightarrow": "\\dotsb",
    "\\xleftarrow": "\\dotsb",
    "\\DOTSI": "\\dotsi",
    "\\int": "\\dotsi",
    "\\oint": "\\dotsi",
    "\\iint": "\\dotsi",
    "\\iiint": "\\dotsi",
    "\\iiiint": "\\dotsi",
    "\\idotsint": "\\dotsi",
    "\\DOTSX": "\\dotsx"
  },
  r5 = new Set(["bin", "rel"]);
y("\\dots", function (e) {
  var t = "\\dotso",
    n = e.expandAfterFuture().text;
  return n in hl ? t = hl[n] : (n.slice(0, 4) === "\\not" || n in be.math && r5.has(be.math[n].group)) && (t = "\\dotsb"), t;
});
var vs = {
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  $: !0,
  ";": !0,
  ".": !0,
  ",": !0
};
y("\\dotso", function (e) {
  var t = e.future().text;
  return t in vs ? "\\ldots\\," : "\\ldots";
});
y("\\dotsc", function (e) {
  var t = e.future().text;
  return t in vs && t !== "," ? "\\ldots\\," : "\\ldots";
});
y("\\cdots", function (e) {
  var t = e.future().text;
  return t in vs ? "\\@cdots\\," : "\\@cdots";
});
y("\\dotsb", "\\cdots");
y("\\dotsm", "\\cdots");
y("\\dotsi", "\\!\\cdots");
y("\\dotsx", "\\ldots\\,");
y("\\DOTSI", "\\relax");
y("\\DOTSB", "\\relax");
y("\\DOTSX", "\\relax");
y("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
y("\\,", "\\tmspace+{3mu}{.1667em}");
y("\\thinspace", "\\,");
y("\\>", "\\mskip{4mu}");
y("\\:", "\\tmspace+{4mu}{.2222em}");
y("\\medspace", "\\:");
y("\\;", "\\tmspace+{5mu}{.2777em}");
y("\\thickspace", "\\;");
y("\\!", "\\tmspace-{3mu}{.1667em}");
y("\\negthinspace", "\\!");
y("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
y("\\negthickspace", "\\tmspace-{5mu}{.277em}");
y("\\enspace", "\\kern.5em ");
y("\\enskip", "\\hskip.5em\\relax");
y("\\quad", "\\hskip1em\\relax");
y("\\qquad", "\\hskip2em\\relax");
y("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
y("\\tag@paren", "\\tag@literal{({#1})}");
y("\\tag@literal", e => {
  if (e.macros.get("\\df@tag")) throw new D("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
y("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
y("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
y("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
y("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
y("\\newline", "\\\\\\relax");
y("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var Du = P(vt["Main-Regular"][84][1] - .7 * vt["Main-Regular"][65][1]);
y("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + Du + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
y("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + Du + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
y("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
y("\\@hspace", "\\hskip #1\\relax");
y("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
y("\\ordinarycolon", ":");
y("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
y("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
y("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
y("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
y("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
y("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
y("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
y("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
y("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
y("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
y("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
y("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
y("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
y("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
y("∷", "\\dblcolon");
y("∹", "\\eqcolon");
y("≔", "\\coloneqq");
y("≕", "\\eqqcolon");
y("⩴", "\\Coloneqq");
y("\\ratio", "\\vcentcolon");
y("\\coloncolon", "\\dblcolon");
y("\\colonequals", "\\coloneqq");
y("\\coloncolonequals", "\\Coloneqq");
y("\\equalscolon", "\\eqqcolon");
y("\\equalscoloncolon", "\\Eqqcolon");
y("\\colonminus", "\\coloneq");
y("\\coloncolonminus", "\\Coloneq");
y("\\minuscolon", "\\eqcolon");
y("\\minuscoloncolon", "\\Eqcolon");
y("\\coloncolonapprox", "\\Colonapprox");
y("\\coloncolonsim", "\\Colonsim");
y("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
y("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
y("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
y("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
y("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
y("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
y("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
y("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
y("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
y("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
y("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
y("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
y("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
y("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
y("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
y("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
y("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
y("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
y("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
y("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
y("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
y("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
y("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
y("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
y("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
y("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
y("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
y("\\imath", "\\html@mathml{\\@imath}{ı}");
y("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
y("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
y("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
y("⟦", "\\llbracket");
y("⟧", "\\rrbracket");
y("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
y("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
y("↤", "\\mapsfrom");
y("\\mapsfrom", "\\html@mathml{\\mathrel{\\mathreflectbox{\\mapsto}}}{\\mathrel{\\char`↤}}");
y("⦃", "\\lBrace");
y("⦄", "\\rBrace");
y("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
y("⦵", "\\minuso");
y("\\darr", "\\downarrow");
y("\\dArr", "\\Downarrow");
y("\\Darr", "\\Downarrow");
y("\\lang", "\\langle");
y("\\rang", "\\rangle");
y("\\uarr", "\\uparrow");
y("\\uArr", "\\Uparrow");
y("\\Uarr", "\\Uparrow");
y("\\N", "\\mathbb{N}");
y("\\R", "\\mathbb{R}");
y("\\Z", "\\mathbb{Z}");
y("\\alef", "\\aleph");
y("\\alefsym", "\\aleph");
y("\\Alpha", "\\mathrm{A}");
y("\\Beta", "\\mathrm{B}");
y("\\bull", "\\bullet");
y("\\Chi", "\\mathrm{X}");
y("\\clubs", "\\clubsuit");
y("\\cnums", "\\mathbb{C}");
y("\\Complex", "\\mathbb{C}");
y("\\Dagger", "\\ddagger");
y("\\diamonds", "\\diamondsuit");
y("\\empty", "\\emptyset");
y("\\Epsilon", "\\mathrm{E}");
y("\\Eta", "\\mathrm{H}");
y("\\exist", "\\exists");
y("\\harr", "\\leftrightarrow");
y("\\hArr", "\\Leftrightarrow");
y("\\Harr", "\\Leftrightarrow");
y("\\hearts", "\\heartsuit");
y("\\image", "\\Im");
y("\\infin", "\\infty");
y("\\Iota", "\\mathrm{I}");
y("\\isin", "\\in");
y("\\Kappa", "\\mathrm{K}");
y("\\larr", "\\leftarrow");
y("\\lArr", "\\Leftarrow");
y("\\Larr", "\\Leftarrow");
y("\\lrarr", "\\leftrightarrow");
y("\\lrArr", "\\Leftrightarrow");
y("\\Lrarr", "\\Leftrightarrow");
y("\\Mu", "\\mathrm{M}");
y("\\natnums", "\\mathbb{N}");
y("\\Nu", "\\mathrm{N}");
y("\\Omicron", "\\mathrm{O}");
y("\\plusmn", "\\pm");
y("\\rarr", "\\rightarrow");
y("\\rArr", "\\Rightarrow");
y("\\Rarr", "\\Rightarrow");
y("\\real", "\\Re");
y("\\reals", "\\mathbb{R}");
y("\\Reals", "\\mathbb{R}");
y("\\Rho", "\\mathrm{P}");
y("\\sdot", "\\cdot");
y("\\sect", "\\S");
y("\\spades", "\\spadesuit");
y("\\sub", "\\subset");
y("\\sube", "\\subseteq");
y("\\supe", "\\supseteq");
y("\\Tau", "\\mathrm{T}");
y("\\thetasym", "\\vartheta");
y("\\weierp", "\\wp");
y("\\Zeta", "\\mathrm{Z}");
y("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
y("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
y("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
y("\\bra", "\\mathinner{\\langle{#1}|}");
y("\\ket", "\\mathinner{|{#1}\\rangle}");
y("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
y("\\Bra", "\\left\\langle#1\\right|");
y("\\Ket", "\\left|#1\\right\\rangle");
var Lu = e => t => {
  var n = t.consumeArg().tokens,
    r = t.consumeArg().tokens,
    a = t.consumeArg().tokens,
    i = t.consumeArg().tokens,
    s = t.macros.get("|"),
    o = t.macros.get("\\|");
  t.macros.beginGroup();
  var l = h => f => {
    e && (f.macros.set("|", s), a.length && f.macros.set("\\|", o));
    var d = h;
    if (!h && a.length) {
      var b = f.future();
      b.text === "|" && (f.popToken(), d = !0);
    }
    return {
      tokens: d ? a : r,
      numArgs: 0
    };
  };
  t.macros.set("|", l(!1)), a.length && t.macros.set("\\|", l(!0));
  var u = t.consumeArg().tokens,
    c = t.expandTokens([...i, ...u, ...n]);
  return t.macros.endGroup(), {
    tokens: c.reverse(),
    numArgs: 0
  };
};
y("\\bra@ket", Lu(!1));
y("\\bra@set", Lu(!0));
y("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
y("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
y("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
y("\\angln", "{\\angl n}");
y("\\blue", "\\textcolor{##6495ed}{#1}");
y("\\orange", "\\textcolor{##ffa500}{#1}");
y("\\pink", "\\textcolor{##ff00af}{#1}");
y("\\red", "\\textcolor{##df0030}{#1}");
y("\\green", "\\textcolor{##28ae7b}{#1}");
y("\\gray", "\\textcolor{gray}{#1}");
y("\\purple", "\\textcolor{##9d38bd}{#1}");
y("\\blueA", "\\textcolor{##ccfaff}{#1}");
y("\\blueB", "\\textcolor{##80f6ff}{#1}");
y("\\blueC", "\\textcolor{##63d9ea}{#1}");
y("\\blueD", "\\textcolor{##11accd}{#1}");
y("\\blueE", "\\textcolor{##0c7f99}{#1}");
y("\\tealA", "\\textcolor{##94fff5}{#1}");
y("\\tealB", "\\textcolor{##26edd5}{#1}");
y("\\tealC", "\\textcolor{##01d1c1}{#1}");
y("\\tealD", "\\textcolor{##01a995}{#1}");
y("\\tealE", "\\textcolor{##208170}{#1}");
y("\\greenA", "\\textcolor{##b6ffb0}{#1}");
y("\\greenB", "\\textcolor{##8af281}{#1}");
y("\\greenC", "\\textcolor{##74cf70}{#1}");
y("\\greenD", "\\textcolor{##1fab54}{#1}");
y("\\greenE", "\\textcolor{##0d923f}{#1}");
y("\\goldA", "\\textcolor{##ffd0a9}{#1}");
y("\\goldB", "\\textcolor{##ffbb71}{#1}");
y("\\goldC", "\\textcolor{##ff9c39}{#1}");
y("\\goldD", "\\textcolor{##e07d10}{#1}");
y("\\goldE", "\\textcolor{##a75a05}{#1}");
y("\\redA", "\\textcolor{##fca9a9}{#1}");
y("\\redB", "\\textcolor{##ff8482}{#1}");
y("\\redC", "\\textcolor{##f9685d}{#1}");
y("\\redD", "\\textcolor{##e84d39}{#1}");
y("\\redE", "\\textcolor{##bc2612}{#1}");
y("\\maroonA", "\\textcolor{##ffbde0}{#1}");
y("\\maroonB", "\\textcolor{##ff92c6}{#1}");
y("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
y("\\maroonD", "\\textcolor{##ca337c}{#1}");
y("\\maroonE", "\\textcolor{##9e034e}{#1}");
y("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
y("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
y("\\purpleC", "\\textcolor{##aa87ff}{#1}");
y("\\purpleD", "\\textcolor{##7854ab}{#1}");
y("\\purpleE", "\\textcolor{##543b78}{#1}");
y("\\mintA", "\\textcolor{##f5f9e8}{#1}");
y("\\mintB", "\\textcolor{##edf2df}{#1}");
y("\\mintC", "\\textcolor{##e0e5cc}{#1}");
y("\\grayA", "\\textcolor{##f6f7f7}{#1}");
y("\\grayB", "\\textcolor{##f0f1f2}{#1}");
y("\\grayC", "\\textcolor{##e3e5e6}{#1}");
y("\\grayD", "\\textcolor{##d6d8da}{#1}");
y("\\grayE", "\\textcolor{##babec2}{#1}");
y("\\grayF", "\\textcolor{##888d93}{#1}");
y("\\grayG", "\\textcolor{##626569}{#1}");
y("\\grayH", "\\textcolor{##3b3e40}{#1}");
y("\\grayI", "\\textcolor{##21242c}{#1}");
y("\\kaBlue", "\\textcolor{##314453}{#1}");
y("\\kaGreen", "\\textcolor{##71B307}{#1}");
var Fu = {
  "^": !0,
  _: !0,
  "\\limits": !0,
  "\\nolimits": !0
};
class a5 {
  constructor(t, n, r) {
    this.settings = void 0, this.expansionCount = void 0, this.lexer = void 0, this.macros = void 0, this.stack = void 0, this.mode = void 0, this.settings = n, this.expansionCount = 0, this.feed(t), this.macros = new t5(n5, n.macros), this.mode = r, this.stack = [];
  }
  feed(t) {
    this.lexer = new cl(t, this.settings);
  }
  switchMode(t) {
    this.mode = t;
  }
  beginGroup() {
    this.macros.beginGroup();
  }
  endGroup() {
    this.macros.endGroup();
  }
  endGroups() {
    this.macros.endGroups();
  }
  future() {
    return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1];
  }
  popToken() {
    return this.future(), this.stack.pop();
  }
  pushToken(t) {
    this.stack.push(t);
  }
  pushTokens(t) {
    this.stack.push(...t);
  }
  scanArgument(t) {
    var n, r, a;
    if (t) {
      if (this.consumeSpaces(), this.future().text !== "[") return null;
      n = this.popToken();
      var i = this.consumeArg(["]"]);
      a = i.tokens, r = i.end;
    } else {
      var s = this.consumeArg();
      a = s.tokens, n = s.start, r = s.end;
    }
    return this.pushToken(new et("EOF", r.loc)), this.pushTokens(a), new et("", Ve.range(n, r));
  }
  consumeSpaces() {
    for (;;) {
      var t = this.future();
      if (t.text === " ") this.stack.pop();else break;
    }
  }
  consumeArg(t) {
    var n = [],
      r = t && t.length > 0;
    r || this.consumeSpaces();
    var a = this.future(),
      i,
      s = 0,
      o = 0;
    do {
      if (i = this.popToken(), n.push(i), i.text === "{") ++s;else if (i.text === "}") {
        if (--s, s === -1) throw new D("Extra }", i);
      } else if (i.text === "EOF") throw new D("Unexpected end of input in a macro argument, expected '" + (t && r ? t[o] : "}") + "'", i);
      if (t && r) if ((s === 0 || s === 1 && t[o] === "{") && i.text === t[o]) {
        if (++o, o === t.length) {
          n.splice(-o, o);
          break;
        }
      } else o = 0;
    } while (s !== 0 || r);
    return a.text === "{" && n[n.length - 1].text === "}" && (n.pop(), n.shift()), n.reverse(), {
      tokens: n,
      start: a,
      end: i
    };
  }
  consumeArgs(t, n) {
    if (n) {
      if (n.length !== t + 1) throw new D("The length of delimiters doesn't match the number of args!");
      for (var r = n[0], a = 0; a < r.length; a++) {
        var i = this.popToken();
        if (r[a] !== i.text) throw new D("Use of the macro doesn't match its definition", i);
      }
    }
    for (var s = [], o = 0; o < t; o++) s.push(this.consumeArg(n && n[o + 1]).tokens);
    return s;
  }
  countExpansion(t) {
    if (this.expansionCount += t, this.expansionCount > this.settings.maxExpand) throw new D("Too many expansions: infinite loop or need to increase maxExpand setting");
  }
  expandOnce(t) {
    var n = this.popToken(),
      r = n.text,
      a = n.noexpand ? null : this._getExpansion(r);
    if (a == null || t && a.unexpandable) {
      if (t && a == null && r[0] === "\\" && !this.isDefined(r)) throw new D("Undefined control sequence: " + r);
      return this.pushToken(n), !1;
    }
    this.countExpansion(1);
    var i = a.tokens,
      s = this.consumeArgs(a.numArgs, a.delimiters);
    if (a.numArgs) {
      i = i.slice();
      for (var o = i.length - 1; o >= 0; --o) {
        var l = i[o];
        if (l.text === "#") {
          if (o === 0) throw new D("Incomplete placeholder at end of macro body", l);
          if (l = i[--o], l.text === "#") i.splice(o + 1, 1);else if (/^[1-9]$/.test(l.text)) i.splice(o, 2, ...s[+l.text - 1]);else throw new D("Not a valid argument number", l);
        }
      }
    }
    return this.pushTokens(i), i.length;
  }
  expandAfterFuture() {
    return this.expandOnce(), this.future();
  }
  expandNextToken() {
    for (;;) if (this.expandOnce() === !1) {
      var t = this.stack.pop();
      return t.treatAsRelax && (t.text = "\\relax"), t;
    }
  }
  expandMacro(t) {
    return this.macros.has(t) ? this.expandTokens([new et(t)]) : void 0;
  }
  expandTokens(t) {
    var n = [],
      r = this.stack.length;
    for (this.pushTokens(t); this.stack.length > r;) if (this.expandOnce(!0) === !1) {
      var a = this.stack.pop();
      a.treatAsRelax && (a.noexpand = !1, a.treatAsRelax = !1), n.push(a);
    }
    return this.countExpansion(n.length), n;
  }
  expandMacroAsText(t) {
    var n = this.expandMacro(t);
    return n && n.map(r => r.text).join("");
  }
  _getExpansion(t) {
    var n = this.macros.get(t);
    if (n == null) return n;
    if (t.length === 1) {
      var r = this.lexer.catcodes[t];
      if (r != null && r !== 13) return;
    }
    var a = typeof n == "function" ? n(this) : n;
    if (typeof a == "string") {
      var i = 0;
      if (a.includes("#")) for (var s = a.replace(/##/g, ""); s.includes("#" + (i + 1));) ++i;
      for (var o = new cl(a, this.settings), l = [], u = o.lex(); u.text !== "EOF";) l.push(u), u = o.lex();
      l.reverse();
      var c = {
        tokens: l,
        numArgs: i
      };
      return c;
    }
    return a;
  }
  isDefined(t) {
    return this.macros.has(t) || Object.prototype.hasOwnProperty.call(Gt, t) || Object.prototype.hasOwnProperty.call(be.math, t) || Object.prototype.hasOwnProperty.call(be.text, t) || Object.prototype.hasOwnProperty.call(Fu, t);
  }
  isExpandable(t) {
    var n = this.macros.get(t);
    return n != null ? typeof n == "string" || typeof n == "function" || !n.unexpandable : Object.prototype.hasOwnProperty.call(Gt, t) && !Gt[t].primitive;
  }
}
var pl = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/,
  Mr = Object.freeze({
    "₊": "+",
    "₋": "-",
    "₌": "=",
    "₍": "(",
    "₎": ")",
    "₀": "0",
    "₁": "1",
    "₂": "2",
    "₃": "3",
    "₄": "4",
    "₅": "5",
    "₆": "6",
    "₇": "7",
    "₈": "8",
    "₉": "9",
    "ₐ": "a",
    "ₑ": "e",
    "ₕ": "h",
    "ᵢ": "i",
    "ⱼ": "j",
    "ₖ": "k",
    "ₗ": "l",
    "ₘ": "m",
    "ₙ": "n",
    "ₒ": "o",
    "ₚ": "p",
    "ᵣ": "r",
    "ₛ": "s",
    "ₜ": "t",
    "ᵤ": "u",
    "ᵥ": "v",
    "ₓ": "x",
    "ᵦ": "β",
    "ᵧ": "γ",
    "ᵨ": "ρ",
    "ᵩ": "ϕ",
    "ᵪ": "χ",
    "⁺": "+",
    "⁻": "-",
    "⁼": "=",
    "⁽": "(",
    "⁾": ")",
    "⁰": "0",
    "¹": "1",
    "²": "2",
    "³": "3",
    "⁴": "4",
    "⁵": "5",
    "⁶": "6",
    "⁷": "7",
    "⁸": "8",
    "⁹": "9",
    "ᴬ": "A",
    "ᴮ": "B",
    "ᴰ": "D",
    "ᴱ": "E",
    "ᴳ": "G",
    "ᴴ": "H",
    "ᴵ": "I",
    "ᴶ": "J",
    "ᴷ": "K",
    "ᴸ": "L",
    "ᴹ": "M",
    "ᴺ": "N",
    "ᴼ": "O",
    "ᴾ": "P",
    "ᴿ": "R",
    "ᵀ": "T",
    "ᵁ": "U",
    "ⱽ": "V",
    "ᵂ": "W",
    "ᵃ": "a",
    "ᵇ": "b",
    "ᶜ": "c",
    "ᵈ": "d",
    "ᵉ": "e",
    "ᶠ": "f",
    "ᵍ": "g",
    ʰ: "h",
    "ⁱ": "i",
    ʲ: "j",
    "ᵏ": "k",
    ˡ: "l",
    "ᵐ": "m",
    ⁿ: "n",
    "ᵒ": "o",
    "ᵖ": "p",
    ʳ: "r",
    ˢ: "s",
    "ᵗ": "t",
    "ᵘ": "u",
    "ᵛ": "v",
    ʷ: "w",
    ˣ: "x",
    ʸ: "y",
    "ᶻ": "z",
    "ᵝ": "β",
    "ᵞ": "γ",
    "ᵟ": "δ",
    "ᵠ": "ϕ",
    "ᵡ": "χ",
    "ᶿ": "θ"
  }),
  ni = {
    "́": {
      text: "\\'",
      math: "\\acute"
    },
    "̀": {
      text: "\\`",
      math: "\\grave"
    },
    "̈": {
      text: '\\"',
      math: "\\ddot"
    },
    "̃": {
      text: "\\~",
      math: "\\tilde"
    },
    "̄": {
      text: "\\=",
      math: "\\bar"
    },
    "̆": {
      text: "\\u",
      math: "\\breve"
    },
    "̌": {
      text: "\\v",
      math: "\\check"
    },
    "̂": {
      text: "\\^",
      math: "\\hat"
    },
    "̇": {
      text: "\\.",
      math: "\\dot"
    },
    "̊": {
      text: "\\r",
      math: "\\mathring"
    },
    "̋": {
      text: "\\H"
    },
    "̧": {
      text: "\\c"
    }
  },
  dl = {
    á: "á",
    à: "à",
    ä: "ä",
    ǟ: "ǟ",
    ã: "ã",
    ā: "ā",
    ă: "ă",
    ắ: "ắ",
    ằ: "ằ",
    ẵ: "ẵ",
    ǎ: "ǎ",
    â: "â",
    ấ: "ấ",
    ầ: "ầ",
    ẫ: "ẫ",
    ȧ: "ȧ",
    ǡ: "ǡ",
    å: "å",
    ǻ: "ǻ",
    ḃ: "ḃ",
    ć: "ć",
    ḉ: "ḉ",
    č: "č",
    ĉ: "ĉ",
    ċ: "ċ",
    ç: "ç",
    ď: "ď",
    ḋ: "ḋ",
    ḑ: "ḑ",
    é: "é",
    è: "è",
    ë: "ë",
    ẽ: "ẽ",
    ē: "ē",
    ḗ: "ḗ",
    ḕ: "ḕ",
    ĕ: "ĕ",
    ḝ: "ḝ",
    ě: "ě",
    ê: "ê",
    ế: "ế",
    ề: "ề",
    ễ: "ễ",
    ė: "ė",
    ȩ: "ȩ",
    ḟ: "ḟ",
    ǵ: "ǵ",
    ḡ: "ḡ",
    ğ: "ğ",
    ǧ: "ǧ",
    ĝ: "ĝ",
    ġ: "ġ",
    ģ: "ģ",
    ḧ: "ḧ",
    ȟ: "ȟ",
    ĥ: "ĥ",
    ḣ: "ḣ",
    ḩ: "ḩ",
    í: "í",
    ì: "ì",
    ï: "ï",
    ḯ: "ḯ",
    ĩ: "ĩ",
    ī: "ī",
    ĭ: "ĭ",
    ǐ: "ǐ",
    î: "î",
    ǰ: "ǰ",
    ĵ: "ĵ",
    ḱ: "ḱ",
    ǩ: "ǩ",
    ķ: "ķ",
    ĺ: "ĺ",
    ľ: "ľ",
    ļ: "ļ",
    ḿ: "ḿ",
    ṁ: "ṁ",
    ń: "ń",
    ǹ: "ǹ",
    ñ: "ñ",
    ň: "ň",
    ṅ: "ṅ",
    ņ: "ņ",
    ó: "ó",
    ò: "ò",
    ö: "ö",
    ȫ: "ȫ",
    õ: "õ",
    ṍ: "ṍ",
    ṏ: "ṏ",
    ȭ: "ȭ",
    ō: "ō",
    ṓ: "ṓ",
    ṑ: "ṑ",
    ŏ: "ŏ",
    ǒ: "ǒ",
    ô: "ô",
    ố: "ố",
    ồ: "ồ",
    ỗ: "ỗ",
    ȯ: "ȯ",
    ȱ: "ȱ",
    ő: "ő",
    ṕ: "ṕ",
    ṗ: "ṗ",
    ŕ: "ŕ",
    ř: "ř",
    ṙ: "ṙ",
    ŗ: "ŗ",
    ś: "ś",
    ṥ: "ṥ",
    š: "š",
    ṧ: "ṧ",
    ŝ: "ŝ",
    ṡ: "ṡ",
    ş: "ş",
    ẗ: "ẗ",
    ť: "ť",
    ṫ: "ṫ",
    ţ: "ţ",
    ú: "ú",
    ù: "ù",
    ü: "ü",
    ǘ: "ǘ",
    ǜ: "ǜ",
    ǖ: "ǖ",
    ǚ: "ǚ",
    ũ: "ũ",
    ṹ: "ṹ",
    ū: "ū",
    ṻ: "ṻ",
    ŭ: "ŭ",
    ǔ: "ǔ",
    û: "û",
    ů: "ů",
    ű: "ű",
    ṽ: "ṽ",
    ẃ: "ẃ",
    ẁ: "ẁ",
    ẅ: "ẅ",
    ŵ: "ŵ",
    ẇ: "ẇ",
    ẘ: "ẘ",
    ẍ: "ẍ",
    ẋ: "ẋ",
    ý: "ý",
    ỳ: "ỳ",
    ÿ: "ÿ",
    ỹ: "ỹ",
    ȳ: "ȳ",
    ŷ: "ŷ",
    ẏ: "ẏ",
    ẙ: "ẙ",
    ź: "ź",
    ž: "ž",
    ẑ: "ẑ",
    ż: "ż",
    Á: "Á",
    À: "À",
    Ä: "Ä",
    Ǟ: "Ǟ",
    Ã: "Ã",
    Ā: "Ā",
    Ă: "Ă",
    Ắ: "Ắ",
    Ằ: "Ằ",
    Ẵ: "Ẵ",
    Ǎ: "Ǎ",
    Â: "Â",
    Ấ: "Ấ",
    Ầ: "Ầ",
    Ẫ: "Ẫ",
    Ȧ: "Ȧ",
    Ǡ: "Ǡ",
    Å: "Å",
    Ǻ: "Ǻ",
    Ḃ: "Ḃ",
    Ć: "Ć",
    Ḉ: "Ḉ",
    Č: "Č",
    Ĉ: "Ĉ",
    Ċ: "Ċ",
    Ç: "Ç",
    Ď: "Ď",
    Ḋ: "Ḋ",
    Ḑ: "Ḑ",
    É: "É",
    È: "È",
    Ë: "Ë",
    Ẽ: "Ẽ",
    Ē: "Ē",
    Ḗ: "Ḗ",
    Ḕ: "Ḕ",
    Ĕ: "Ĕ",
    Ḝ: "Ḝ",
    Ě: "Ě",
    Ê: "Ê",
    Ế: "Ế",
    Ề: "Ề",
    Ễ: "Ễ",
    Ė: "Ė",
    Ȩ: "Ȩ",
    Ḟ: "Ḟ",
    Ǵ: "Ǵ",
    Ḡ: "Ḡ",
    Ğ: "Ğ",
    Ǧ: "Ǧ",
    Ĝ: "Ĝ",
    Ġ: "Ġ",
    Ģ: "Ģ",
    Ḧ: "Ḧ",
    Ȟ: "Ȟ",
    Ĥ: "Ĥ",
    Ḣ: "Ḣ",
    Ḩ: "Ḩ",
    Í: "Í",
    Ì: "Ì",
    Ï: "Ï",
    Ḯ: "Ḯ",
    Ĩ: "Ĩ",
    Ī: "Ī",
    Ĭ: "Ĭ",
    Ǐ: "Ǐ",
    Î: "Î",
    İ: "İ",
    Ĵ: "Ĵ",
    Ḱ: "Ḱ",
    Ǩ: "Ǩ",
    Ķ: "Ķ",
    Ĺ: "Ĺ",
    Ľ: "Ľ",
    Ļ: "Ļ",
    Ḿ: "Ḿ",
    Ṁ: "Ṁ",
    Ń: "Ń",
    Ǹ: "Ǹ",
    Ñ: "Ñ",
    Ň: "Ň",
    Ṅ: "Ṅ",
    Ņ: "Ņ",
    Ó: "Ó",
    Ò: "Ò",
    Ö: "Ö",
    Ȫ: "Ȫ",
    Õ: "Õ",
    Ṍ: "Ṍ",
    Ṏ: "Ṏ",
    Ȭ: "Ȭ",
    Ō: "Ō",
    Ṓ: "Ṓ",
    Ṑ: "Ṑ",
    Ŏ: "Ŏ",
    Ǒ: "Ǒ",
    Ô: "Ô",
    Ố: "Ố",
    Ồ: "Ồ",
    Ỗ: "Ỗ",
    Ȯ: "Ȯ",
    Ȱ: "Ȱ",
    Ő: "Ő",
    Ṕ: "Ṕ",
    Ṗ: "Ṗ",
    Ŕ: "Ŕ",
    Ř: "Ř",
    Ṙ: "Ṙ",
    Ŗ: "Ŗ",
    Ś: "Ś",
    Ṥ: "Ṥ",
    Š: "Š",
    Ṧ: "Ṧ",
    Ŝ: "Ŝ",
    Ṡ: "Ṡ",
    Ş: "Ş",
    Ť: "Ť",
    Ṫ: "Ṫ",
    Ţ: "Ţ",
    Ú: "Ú",
    Ù: "Ù",
    Ü: "Ü",
    Ǘ: "Ǘ",
    Ǜ: "Ǜ",
    Ǖ: "Ǖ",
    Ǚ: "Ǚ",
    Ũ: "Ũ",
    Ṹ: "Ṹ",
    Ū: "Ū",
    Ṻ: "Ṻ",
    Ŭ: "Ŭ",
    Ǔ: "Ǔ",
    Û: "Û",
    Ů: "Ů",
    Ű: "Ű",
    Ṽ: "Ṽ",
    Ẃ: "Ẃ",
    Ẁ: "Ẁ",
    Ẅ: "Ẅ",
    Ŵ: "Ŵ",
    Ẇ: "Ẇ",
    Ẍ: "Ẍ",
    Ẋ: "Ẋ",
    Ý: "Ý",
    Ỳ: "Ỳ",
    Ÿ: "Ÿ",
    Ỹ: "Ỹ",
    Ȳ: "Ȳ",
    Ŷ: "Ŷ",
    Ẏ: "Ẏ",
    Ź: "Ź",
    Ž: "Ž",
    Ẑ: "Ẑ",
    Ż: "Ż",
    ά: "ά",
    ὰ: "ὰ",
    ᾱ: "ᾱ",
    ᾰ: "ᾰ",
    έ: "έ",
    ὲ: "ὲ",
    ή: "ή",
    ὴ: "ὴ",
    ί: "ί",
    ὶ: "ὶ",
    ϊ: "ϊ",
    ΐ: "ΐ",
    ῒ: "ῒ",
    ῑ: "ῑ",
    ῐ: "ῐ",
    ό: "ό",
    ὸ: "ὸ",
    ύ: "ύ",
    ὺ: "ὺ",
    ϋ: "ϋ",
    ΰ: "ΰ",
    ῢ: "ῢ",
    ῡ: "ῡ",
    ῠ: "ῠ",
    ώ: "ώ",
    ὼ: "ὼ",
    Ύ: "Ύ",
    Ὺ: "Ὺ",
    Ϋ: "Ϋ",
    Ῡ: "Ῡ",
    Ῠ: "Ῠ",
    Ώ: "Ώ",
    Ὼ: "Ὼ"
  };
class xa {
  constructor(t, n) {
    this.mode = void 0, this.gullet = void 0, this.settings = void 0, this.leftrightDepth = void 0, this.nextToken = void 0, this.mode = "math", this.gullet = new a5(t, n, this.mode), this.settings = n, this.leftrightDepth = 0, this.nextToken = null;
  }
  expect(t, n) {
    if (n === void 0 && (n = !0), this.fetch().text !== t) throw new D("Expected '" + t + "', got '" + this.fetch().text + "'", this.fetch());
    n && this.consume();
  }
  consume() {
    this.nextToken = null;
  }
  fetch() {
    return this.nextToken == null && (this.nextToken = this.gullet.expandNextToken()), this.nextToken;
  }
  switchMode(t) {
    this.mode = t, this.gullet.switchMode(t);
  }
  parse() {
    this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor");
    try {
      var t = this.parseExpression(!1);
      return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), t;
    } finally {
      this.gullet.endGroups();
    }
  }
  subparse(t) {
    var n = this.nextToken;
    this.consume(), this.gullet.pushToken(new et("}")), this.gullet.pushTokens(t);
    var r = this.parseExpression(!1);
    return this.expect("}"), this.nextToken = n, r;
  }
  parseExpression(t, n) {
    for (var r = [];;) {
      this.mode === "math" && this.consumeSpaces();
      var a = this.fetch();
      if (xa.endOfExpression.has(a.text) || n && a.text === n || t && Gt[a.text] && Gt[a.text].infix) break;
      var i = this.parseAtom(n);
      if (i) {
        if (i.type === "internal") continue;
      } else break;
      r.push(i);
    }
    return this.mode === "text" && this.formLigatures(r), this.handleInfixNodes(r);
  }
  handleInfixNodes(t) {
    for (var n = -1, r, a = 0; a < t.length; a++) {
      var i = t[a];
      if (i.type === "infix") {
        if (n !== -1) throw new D("only one infix operator per group", i.token);
        n = a, r = i.replaceWith;
      }
    }
    if (n !== -1 && r) {
      var s,
        o,
        l = t.slice(0, n),
        u = t.slice(n + 1);
      l.length === 1 && l[0].type === "ordgroup" ? s = l[0] : s = {
        type: "ordgroup",
        mode: this.mode,
        body: l
      }, u.length === 1 && u[0].type === "ordgroup" ? o = u[0] : o = {
        type: "ordgroup",
        mode: this.mode,
        body: u
      };
      var c;
      return r === "\\\\abovefrac" ? c = this.callFunction(r, [s, t[n], o], []) : c = this.callFunction(r, [s, o], []), [c];
    } else return t;
  }
  handleSupSubscript(t) {
    var n = this.fetch(),
      r = n.text;
    this.consume(), this.consumeSpaces();
    var a;
    do {
      var i;
      a = this.parseGroup(t);
    } while (((i = a) == null ? void 0 : i.type) === "internal");
    if (!a) throw new D("Expected group after '" + r + "'", n);
    return a;
  }
  formatUnsupportedCmd(t) {
    for (var n = [], r = 0; r < t.length; r++) n.push({
      type: "textord",
      mode: "text",
      text: t[r]
    });
    var a = {
        type: "text",
        mode: this.mode,
        body: n
      },
      i = {
        type: "color",
        mode: this.mode,
        color: this.settings.errorColor,
        body: [a]
      };
    return i;
  }
  parseAtom(t) {
    var n = this.parseGroup("atom", t);
    if (n?.type === "internal" || this.mode === "text") return n;
    for (var r, a;;) {
      this.consumeSpaces();
      var i = this.fetch();
      if (i.text === "\\limits" || i.text === "\\nolimits") {
        if (n && n.type === "op") n.limits = i.text === "\\limits", n.alwaysHandleSupSub = !0;else if (n && n.type === "operatorname") n.alwaysHandleSupSub && (n.limits = i.text === "\\limits");else throw new D("Limit controls must follow a math operator", i);
        this.consume();
      } else if (i.text === "^") {
        if (r) throw new D("Double superscript", i);
        r = this.handleSupSubscript("superscript");
      } else if (i.text === "_") {
        if (a) throw new D("Double subscript", i);
        a = this.handleSupSubscript("subscript");
      } else if (i.text === "'") {
        if (r) throw new D("Double superscript", i);
        var s = {
            type: "textord",
            mode: this.mode,
            text: "\\prime"
          },
          o = [s];
        for (this.consume(); this.fetch().text === "'";) o.push(s), this.consume();
        this.fetch().text === "^" && o.push(this.handleSupSubscript("superscript")), r = {
          type: "ordgroup",
          mode: this.mode,
          body: o
        };
      } else if (Mr[i.text]) {
        var l = pl.test(i.text),
          u = [];
        for (u.push(new et(Mr[i.text])), this.consume();;) {
          var c = this.fetch().text;
          if (!Mr[c] || pl.test(c) !== l) break;
          u.unshift(new et(Mr[c])), this.consume();
        }
        var h = this.subparse(u);
        l ? a = {
          type: "ordgroup",
          mode: "math",
          body: h
        } : r = {
          type: "ordgroup",
          mode: "math",
          body: h
        };
      } else break;
    }
    return r && a ? {
      type: "supsub",
      mode: this.mode,
      base: n,
      sup: r,
      sub: a
    } : r ? {
      type: "supsub",
      mode: this.mode,
      base: n,
      sup: r
    } : a ? {
      type: "supsub",
      mode: this.mode,
      base: n,
      sub: a
    } : n;
  }
  parseFunction(t, n) {
    var r = this.fetch(),
      a = r.text,
      i = Gt[a];
    if (!i) return null;
    if (this.consume(), n && n !== "atom" && !i.allowedInArgument) throw new D("Got function '" + a + "' with no arguments" + (n ? " as " + n : ""), r);
    if (this.mode === "text" && !i.allowedInText) throw new D("Can't use function '" + a + "' in text mode", r);
    if (this.mode === "math" && i.allowedInMath === !1) throw new D("Can't use function '" + a + "' in math mode", r);
    var s = this.parseArguments(a, i),
      o = s.args,
      l = s.optArgs;
    return this.callFunction(a, o, l, r, t);
  }
  callFunction(t, n, r, a, i) {
    var s = {
        funcName: t,
        parser: this,
        token: a,
        breakOnTokenText: i
      },
      o = Gt[t];
    if (o && o.handler) return o.handler(s, n, r);
    throw new D("No function handler for " + t);
  }
  parseArguments(t, n) {
    var r,
      a = (r = n.numOptionalArgs) != null ? r : 0,
      i = n.numArgs + a;
    if (i === 0) return {
      args: [],
      optArgs: []
    };
    for (var s = [], o = [], l = 0; l < i; l++) {
      var u,
        c = (u = n.argTypes) == null ? void 0 : u[l],
        h = l < a;
      ("primitive" in n && n.primitive && c == null || n.type === "sqrt" && l === 1 && o[0] == null) && (c = "primitive");
      var f = this.parseGroupOfType("argument to '" + t + "'", c, h);
      if (h) o.push(f);else if (f != null) s.push(f);else throw new D("Null argument, please report this as a bug");
    }
    return {
      args: s,
      optArgs: o
    };
  }
  parseGroupOfType(t, n, r) {
    switch (n) {
      case "color":
        return this.parseColorGroup(r);
      case "size":
        return this.parseSizeGroup(r);
      case "url":
        return this.parseUrlGroup(r);
      case "math":
      case "text":
        return this.parseArgumentGroup(r, n);
      case "hbox":
        {
          var a = this.parseArgumentGroup(r, "text");
          return a != null ? {
            type: "styling",
            mode: a.mode,
            body: [a],
            style: "text",
            resetFont: !0
          } : null;
        }
      case "raw":
        {
          var i = this.parseStringGroup(r);
          return i != null ? {
            type: "raw",
            mode: "text",
            string: i.text
          } : null;
        }
      case "primitive":
        {
          if (r) throw new D("A primitive argument cannot be optional");
          var s = this.parseGroup(t);
          if (s == null) throw new D("Expected group as " + t, this.fetch());
          return s;
        }
      case "original":
      case void 0:
        return this.parseArgumentGroup(r);
      default:
        throw new D("Unknown group type as " + t, this.fetch());
    }
  }
  consumeSpaces() {
    for (; this.fetch().text === " ";) this.consume();
  }
  parseStringGroup(t) {
    var n = this.gullet.scanArgument(t);
    if (n == null) return null;
    for (var r = "", a; (a = this.fetch()).text !== "EOF";) r += a.text, this.consume();
    return this.consume(), n.text = r, n;
  }
  parseRegexGroup(t, n) {
    for (var r = this.fetch(), a = r, i = "", s; (s = this.fetch()).text !== "EOF" && t.test(i + s.text);) a = s, i += a.text, this.consume();
    if (i === "") throw new D("Invalid " + n + ": '" + r.text + "'", r);
    return r.range(a, i);
  }
  parseColorGroup(t) {
    var n = this.parseStringGroup(t);
    if (n == null) return null;
    var r = /^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(n.text);
    if (!r) throw new D("Invalid color: '" + n.text + "'", n);
    var a = r[0];
    return /^[0-9a-f]{6}$/i.test(a) && (a = "#" + a), {
      type: "color-token",
      mode: this.mode,
      color: a
    };
  }
  parseSizeGroup(t) {
    var n,
      r = !1;
    if (this.gullet.consumeSpaces(), !t && this.gullet.future().text !== "{" ? n = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : n = this.parseStringGroup(t), !n) return null;
    !t && n.text.length === 0 && (n.text = "0pt", r = !0);
    var a = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(n.text);
    if (!a) throw new D("Invalid size: '" + n.text + "'", n);
    var i = {
      number: +(a[1] + a[2]),
      unit: a[3]
    };
    if (!Z0(i)) throw new D("Invalid unit: '" + i.unit + "'", n);
    return {
      type: "size",
      mode: this.mode,
      value: i,
      isBlank: r
    };
  }
  parseUrlGroup(t) {
    this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12);
    var n = this.parseStringGroup(t);
    if (this.gullet.lexer.setCatcode("%", 14), this.gullet.lexer.setCatcode("~", 13), n == null) return null;
    var r = n.text.replace(/\\([#$%&~_^{}])/g, "$1");
    return {
      type: "url",
      mode: this.mode,
      url: r
    };
  }
  parseArgumentGroup(t, n) {
    var r = this.gullet.scanArgument(t);
    if (r == null) return null;
    var a = this.mode;
    n && this.switchMode(n), this.gullet.beginGroup();
    var i = this.parseExpression(!1, "EOF");
    this.expect("EOF"), this.gullet.endGroup();
    var s = {
      type: "ordgroup",
      mode: this.mode,
      loc: r.loc,
      body: i
    };
    return n && this.switchMode(a), s;
  }
  parseGroup(t, n) {
    var r = this.fetch(),
      a = r.text,
      i;
    if (a === "{" || a === "\\begingroup") {
      this.consume();
      var s = a === "{" ? "}" : "\\endgroup";
      this.gullet.beginGroup();
      var o = this.parseExpression(!1, s),
        l = this.fetch();
      this.expect(s), this.gullet.endGroup(), i = {
        type: "ordgroup",
        mode: this.mode,
        loc: Ve.range(r, l),
        body: o,
        semisimple: a === "\\begingroup" || void 0
      };
    } else if (i = this.parseFunction(n, t) || this.parseSymbol(), i == null && a[0] === "\\" && !Object.prototype.hasOwnProperty.call(Fu, a)) {
      if (this.settings.throwOnError) throw new D("Undefined control sequence: " + a, r);
      i = this.formatUnsupportedCmd(a), this.consume();
    }
    return i;
  }
  formLigatures(t) {
    for (var n = t.length - 1, r = 0; r < n; ++r) {
      var a = t[r];
      if (a.type === "textord") {
        var i = a.text,
          s = t[r + 1];
        if (!(!s || s.type !== "textord")) {
          if (i === "-" && s.text === "-") {
            var o = t[r + 2];
            r + 1 < n && o && o.type === "textord" && o.text === "-" ? (t.splice(r, 3, {
              type: "textord",
              mode: "text",
              loc: Ve.range(a, o),
              text: "---"
            }), n -= 2) : (t.splice(r, 2, {
              type: "textord",
              mode: "text",
              loc: Ve.range(a, s),
              text: "--"
            }), n -= 1);
          }
          (i === "'" || i === "`") && s.text === i && (t.splice(r, 2, {
            type: "textord",
            mode: "text",
            loc: Ve.range(a, s),
            text: i + i
          }), n -= 1);
        }
      }
    }
  }
  parseSymbol() {
    var t = this.fetch(),
      n = t.text;
    if (/^\\verb[^a-zA-Z]/.test(n)) {
      this.consume();
      var r = n.slice(5),
        a = r.charAt(0) === "*";
      if (a && (r = r.slice(1)), r.length < 2 || r.charAt(0) !== r.slice(-1)) throw new D(`\\verb assertion failed --
                    please report what input caused this bug`);
      return r = r.slice(1, -1), {
        type: "verb",
        mode: "text",
        body: r,
        star: a
      };
    }
    Object.prototype.hasOwnProperty.call(dl, n[0]) && !be[this.mode][n[0]] && (this.settings.strict && this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Accented Unicode text character "' + n[0] + '" used in math mode', t), n = dl[n[0]] + n.slice(1));
    var i = J2.exec(n);
    i && (n = n.substring(0, i.index), n === "i" ? n = "ı" : n === "j" && (n = "ȷ"));
    var s;
    if (be[this.mode][n]) {
      this.settings.strict && this.mode === "math" && Mi.includes(n) && this.settings.reportNonstrict("unicodeTextInMathMode", 'Latin-1/Unicode text character "' + n[0] + '" used in math mode', t);
      var o = be[this.mode][n].group,
        l = Ve.range(t),
        u;
      c2(o) ? u = {
        type: "atom",
        mode: this.mode,
        family: o,
        loc: l,
        text: n
      } : u = {
        type: o,
        mode: this.mode,
        loc: l,
        text: n
      }, s = u;
    } else if (n.charCodeAt(0) >= 128) this.settings.strict && (Y0(n.charCodeAt(0)) ? this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Unicode text character "' + n[0] + '" used in math mode', t) : this.settings.reportNonstrict("unknownSymbol", 'Unrecognized Unicode character "' + n[0] + '"' + (" (" + n.charCodeAt(0) + ")"), t)), s = {
      type: "textord",
      mode: "text",
      loc: Ve.range(t),
      text: n
    };else return null;
    if (this.consume(), i) for (var c = 0; c < i[0].length; c++) {
      var h = i[0][c];
      if (!ni[h]) throw new D("Unknown accent ' " + h + "'", t);
      var f = ni[h][this.mode] || ni[h].text;
      if (!f) throw new D("Accent " + h + " unsupported in " + this.mode + " mode", t);
      s = {
        type: "accent",
        mode: this.mode,
        loc: Ve.range(t),
        label: f,
        isStretchy: !1,
        isShifty: !0,
        base: s
      };
    }
    return s;
  }
}
xa.endOfExpression = new Set(["}", "\\endgroup", "\\end", "\\right", "&"]);
var ws = function (t, n) {
    if (!(typeof t == "string" || t instanceof String)) throw new TypeError("KaTeX can only parse string typed expression");
    var r = new xa(t, n);
    delete r.gullet.macros.current["\\df@tag"];
    var a = r.parse();
    if (delete r.gullet.macros.current["\\current@color"], delete r.gullet.macros.current["\\color"], r.gullet.macros.get("\\df@tag")) {
      if (!n.displayMode) throw new D("\\tag works only in display equations");
      a = [{
        type: "tag",
        mode: "text",
        body: a,
        tag: r.subparse([new et("\\df@tag")])
      }];
    }
    return a;
  },
  Pu = function (t, n, r) {
    n.textContent = "";
    var a = xs(t, r).toNode();
    n.appendChild(a);
  };
typeof document < "u" && document.compatMode !== "CSS1Compat" && (typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."), Pu = function () {
  throw new D("KaTeX doesn't work in quirks mode.");
});
var i5 = function (t, n) {
    var r = xs(t, n).toMarkup();
    return r;
  },
  s5 = function (t, n) {
    var r = new ss(n);
    return ws(t, r);
  },
  Ou = function (t, n, r) {
    if (r.throwOnError || !(t instanceof D)) throw t;
    var a = B(["katex-error"], [new tt(n)]);
    return a.setAttribute("title", t.toString()), a.setAttribute("style", "color:" + r.errorColor), a;
  },
  xs = function (t, n) {
    var r = new ss(n);
    try {
      var a = ws(t, r);
      return e2(a, t, r);
    } catch (i) {
      return Ou(i, t, r);
    }
  },
  o5 = function (t, n) {
    var r = new ss(n);
    try {
      var a = ws(t, r);
      return t2(a, t, r);
    } catch (i) {
      return Ou(i, t, r);
    }
  },
  l5 = "0.18.7",
  u5 = {
    Span: Rn,
    Anchor: ma,
    SymbolNode: tt,
    SvgNode: Nt,
    PathNode: Wt,
    LineNode: Ei
  },
  S5 = {
    version: l5,
    render: Pu,
    renderToString: i5,
    ParseError: D,
    SETTINGS_SCHEMA: Si,
    __parse: s5,
    __renderToDomTree: xs,
    __renderToHTMLTree: o5,
    __setFontMetrics: B4,
    __defineSymbol: m,
    __defineFunction: U,
    __defineMacro: y,
    __domTree: u5
  };
export { p5 as a, m5 as b, h5 as c, _i as d, _5 as e, y5 as f, x5 as g, Kr as h, $5 as i, X as j, S5 as k, ae as l, k5 as m, b5 as n, wd as o, d5 as p, g5 as q, v5 as r, f5 as s, C5 as t, or as u, w5 as v, kf as w };